const { chromium } = require('playwright');
const fs = require('fs');
const W = '../../src/main/webapp/';
let pass = 0, fail = 0;
const check = (n, ok) => { console.log((ok ? 'PASS  ' : 'FAIL  ') + n); ok ? pass++ : fail++; };

// minimal JSP -> HTML for the fragments under test (EL/JSTL replaced by fixed values)
function jsp(t) {
  return t.replace(/<%--[\s\S]*?--%>/g, '').replace(/<%@[\s\S]*?%>/g, '')
    .replace(/<c:out value="\$\{csrf\}"\/>/g, 'TOKEN-XYZ').replace(/<c:out value='\$\{csrf\}'\/>/g, 'TOKEN-XYZ')
    .replace(/<c:out value="\$\{ccUser\.firstName\}"\/>/g, 'Demo').replace(/<c:out value='\$\{loginId\}'\/>/g, '')
    .replace(/<c:if test="\$\{not empty error\}">[\s\S]*?<\/c:if>/g, '')
    .replace(/<\/?c:if[^>]*>/g, '').replace(/\$\{ctx\}/g, '');
}
const CSS = '<style>.hidden{display:none}.flex{display:flex}</style>';

(async () => {
  const browser = await chromium.launch();

  // ============================================================ widgets: pop-ups + chat
  const widgets = jsp(fs.readFileSync(W + 'WEB-INF/jspf/widgets.jspf', 'utf8'));
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const errors = []; page.on('pageerror', e => errors.push(String(e)));
  const posts = [];
  let popupServed = false;
  await page.route('**/api/**', async route => {
    const req = route.request(), url = new URL(req.url()), p = url.pathname;
    const json = o => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(o) });
    if (req.method() === 'POST') posts.push({ p, csrf: req.headers()['x-csrf-token'], body: req.postData() });
    if (p === '/api/notifications/popups') {
      if (popupServed) return json({ items: [], unread: 0 }); popupServed = true;
      return json({ items: [
        { id: 1, color: 'RED', category: 'FEES', title: 'Final fee due in 2 days', message: 'Pay now', actionLabel: 'Pay Now', actionUrl: '/app/fees' },
        { id: 2, color: 'ORANGE', category: 'ASSIGNMENT', title: 'DS Lab #4 pending', message: 'Due tomorrow', actionLabel: 'Upload', actionUrl: '/app/assignments' },
        { id: 3, color: 'BLUE', category: 'MATERIAL', title: 'New e-content', message: 'AJT slides', actionLabel: null, actionUrl: null }], unread: 3 });
    }
    if (p === '/api/chat/history') return json({ messages: [] });
    if (p === '/api/chat/proactive') return json({ messages: [{ kind: 'RED', text: 'Very low attendance in CNF (61%)' }, { kind: 'FEEDBACK', text: 'How is AJT going? Type "skip" to ignore.' }] });
    if (p === '/api/chat/send') {
      const msg = new URLSearchParams(req.postData()).get('message');
      return json({ reply: msg.includes('xss') ? '<img src=x onerror="window.__xss=1"><b>bold</b>' : 'Reply to: ' + msg, blocked: false });
    }
    return json({});
  });
  await page.route('http://app.test/page', r => r.fulfill({ status: 200, contentType: 'text/html', body: CSS + '<body>' + widgets + '</body>' }));
  await page.goto('http://app.test/page');

  // ---- pop-ups
  await page.waitForSelector('#cc-toasts > div', { timeout: 5000 });
  const toasts = await page.$$eval('#cc-toasts > div', els => els.map(e => ({ text: e.innerText, cls: e.className })));
  check('3 pop-up toasts shown from /api/notifications/popups', toasts.length === 3);
  check('RED template: URGENT badge + red styling', /URGENT/.test(toasts[0].text) && /border-red-600/.test(toasts[0].cls));
  check('ORANGE template: WARNING badge + amber styling', /WARNING/.test(toasts[1].text) && /border-amber-500/.test(toasts[1].cls));
  check('BLUE template: UPDATE badge + blue styling', /UPDATE/.test(toasts[2].text) && /border-blue-600/.test(toasts[2].cls));
  check('toast action link points to the page', await page.$eval('#cc-toasts a', a => a.getAttribute('href')) === '/app/fees');
  await page.click('#cc-toasts > div:first-child button');
  await page.waitForTimeout(200);
  check('closing a toast removes it and marks it read (POST with CSRF header)', (await page.$$('#cc-toasts > div')).length === 2
        && posts.some(x => x.p === '/api/notifications/read' && x.csrf === 'TOKEN-XYZ' && x.body === 'id=1'));

  // ---- chat window
  check('chat panel is closed at first', await page.$eval('#cc-chat', e => e.classList.contains('hidden')));
  await page.waitForTimeout(4300);                                   // the bot reaches out by itself after ~4 s
  check('red dot appears on the Ask AI button when the bot has news', await page.$eval('#cc-chat-dot', e => !e.classList.contains('hidden')));
  await page.click('#cc-chat-fab');
  await page.waitForSelector('#cc-msgs > div');
  await page.waitForTimeout(300);
  const bubbles = await page.$$eval('#cc-msgs > div', els => els.map(e => ({ t: e.textContent, c: e.className })));
  check('panel opens with greeting for the student', bubbles[0].t.startsWith('Hi Demo'));
  check('proactive RED alert appears as red bubble', bubbles.some(b => b.t.includes('Very low attendance') && /border-red-600/.test(b.c)));
  check('feedback question appears as its own bubble type', bubbles.some(b => b.t.includes('How is AJT going') && /border-secondary/.test(b.c)));
  check('red dot is cleared after opening', await page.$eval('#cc-chat-dot', e => e.classList.contains('hidden')));

  await page.fill('#cc-input', 'Which assignments are pending?');
  await page.click('#cc-send');
  await page.waitForFunction(() => [...document.querySelectorAll('#cc-msgs > div')].some(d => d.textContent.startsWith('Reply to:')));
  const sent = posts.filter(x => x.p === '/api/chat/send').pop();
  check('message POSTed to /api/chat/send with CSRF header', sent && sent.csrf === 'TOKEN-XYZ' && new URLSearchParams(sent.body).get('message') === 'Which assignments are pending?');
  check('user bubble (right) + bot reply bubble rendered', await page.$$eval('#cc-msgs > div', els => els.some(e => e.textContent === 'Which assignments are pending?' && /self-end/.test(e.className)) && els.some(e => e.textContent === 'Reply to: Which assignments are pending?')));
  check('input is cleared after sending', (await page.inputValue('#cc-input')) === '');

  await page.fill('#cc-input', 'enter key test'); await page.press('#cc-input', 'Enter');
  await page.waitForFunction(() => [...document.querySelectorAll('#cc-msgs > div')].some(d => d.textContent === 'Reply to: enter key test'));
  check('Enter key sends the message', true);
  await page.click('.cc-chip[data-chip="When is my next class?"]');
  await page.waitForFunction(() => [...document.querySelectorAll('#cc-msgs > div')].some(d => d.textContent === 'Reply to: When is my next class?'));
  check('quick-reply chip sends its question', true);

  await page.fill('#cc-input', 'xss test'); await page.click('#cc-send');
  await page.waitForFunction(() => [...document.querySelectorAll('#cc-msgs > div')].some(d => d.textContent.includes('<img src=x')));
  check('XSS: HTML in a bot reply is shown as text, never executed', (await page.$$('#cc-msgs img')).length === 0 && (await page.evaluate(() => window.__xss)) === undefined);

  await page.click('#cc-chat-close');
  check('close button hides the panel', await page.$eval('#cc-chat', e => e.classList.contains('hidden')));
  check('no JavaScript errors in the widgets', errors.length === 0);
  if (errors.length) console.log(errors);

  // ============================================================ theme script
  const theme = fs.readFileSync(W + 'assets/js/theme.js', 'utf8');
  const tp = await browser.newPage();
  await tp.clock.install({ time: new Date('2026-10-20T20:30:00') });
  await tp.route('http://app.test/theme', r => r.fulfill({ status: 200, contentType: 'text/html', body: '<button data-theme-toggle onclick="ccTheme.toggle()"><span data-theme-icon></span></button>' }));
  await tp.goto('http://app.test/theme');
  await tp.addScriptTag({ content: theme });
  const isDark = () => tp.evaluate(() => document.documentElement.classList.contains('dark'));
  check('theme: 8:30 PM, auto mode -> DARK', await isDark());
  await tp.clock.setSystemTime(new Date('2026-10-21T12:00:00')); await tp.clock.runFor(61000);
  check('theme: noon, auto mode flips to LIGHT by itself (timer)', !(await isDark()));
  await tp.clock.setSystemTime(new Date('2026-10-21T06:00:00')); await tp.clock.runFor(61000);
  check('theme: 6:00 AM -> LIGHT (boundary)', !(await isDark()));
  await tp.clock.setSystemTime(new Date('2026-10-21T18:00:00')); await tp.clock.runFor(61000);
  check('theme: 6:00 PM -> DARK (boundary)', await isDark());
  await tp.click('[data-theme-toggle]');            // auto -> light
  check('toggle auto -> light overrides the clock', !(await isDark()) && await tp.evaluate(() => localStorage.getItem('cc-theme')) === 'light');
  await tp.click('[data-theme-toggle]');            // light -> dark
  check('toggle light -> dark', await isDark());
  await tp.click('[data-theme-toggle]');            // dark -> auto
  check('toggle dark -> auto (clock decides again)', (await tp.evaluate(() => localStorage.getItem('cc-theme'))) === 'auto' && await isDark());

  // ============================================================ login form validation
  let login = jsp(fs.readFileSync(W + 'WEB-INF/views/login.jsp', 'utf8'));
  const lp = await browser.newPage();
  const loginHtml = CSS + login.replace(/<head>[\s\S]*?<\/head>/, '');
  await lp.route('http://app.test/login', r => r.fulfill({ status: 200, contentType: 'text/html', body: r.request().method() === 'GET' ? loginHtml : 'submitted' }));
  await lp.goto('http://app.test/login');
  await lp.click('button[type=submit]');
  check('login: empty form is blocked with messages', (await lp.textContent('#err-id')).length > 0 && (await lp.textContent('#err-pw')).length > 0);
  await lp.fill('#login-id', 'abc'); await lp.fill('#login-password', '123456'); await lp.click('button[type=submit]');
  check('login: invalid id is blocked', /valid/.test(await lp.textContent('#err-id')));
  await lp.fill('#login-id', 'DEMO-STU-001'); await lp.fill('#login-password', '123'); await lp.click('button[type=submit]');
  check('login: short password is blocked', /6 characters/.test(await lp.textContent('#err-pw')));
  await lp.click('button[aria-label="Show password"]');
  check('login: eye button toggles password visibility', await lp.$eval('#login-password', e => e.type) === 'text');
  await lp.fill('#login-id', 'student.one@example.invalid'); await lp.fill('#login-password', 'Student@123');
  const nav = lp.waitForRequest(r => r.url().endsWith('/login') && r.method() === 'POST', { timeout: 3000 }).catch(() => null);
  await lp.click('button[type=submit]');
  const pr = await nav;
  check('login: valid e-mail + password is submitted (POST /login with csrf field)', !!pr && /csrf=TOKEN-XYZ/.test(pr.postData() || '') && /loginId=student\.one%40example\.invalid/.test(pr.postData() || ''));

  await browser.close();
  console.log(`\nRESULT: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
