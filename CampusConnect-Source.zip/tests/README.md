# Tests

These are the end-to-end checks used to audit the project. None of them needs Tomcat, MySQL or a real Gemini key.

| Test | What it checks | How to run |
|------|----------------|------------|
| `java/ChatE2E.java` | The whole chatbot pipeline against a **mock Gemini server**: out-of-scope refusal (no API call), request format (URL, `x-goog-api-key`, thinking config), data privacy of the prompt, retry on 429, fallback when Gemini is down or has no key, rate limit, history alternation, proactive alerts, feedback processing/rejection | Copy to `src/test/java`, run `main` (NetBeans: *Run File*) |
| `java/NotifE2E.java` | The BLUE / RED / ORANGE rules with the risk and the healthy demo student, de-duplication and one-time pop-ups | same |
| `ui/ui.js` | Browser test (Playwright + Chromium) of the pop-up toasts, chat window, automatic day/night theme and login form validation, with mocked server responses | `npm i playwright && npx playwright install chromium && node tests/ui/ui.js` |

Both Java tests use the real service classes; the database layer is replaced by small fake DAOs. Expected result: all checks print `PASS`.
