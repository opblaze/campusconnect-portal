import com.campusconnect.config.AppProperties;
import com.campusconnect.dao.*;
import com.campusconnect.model.*;
import com.campusconnect.model.enums.*;
import com.campusconnect.service.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import java.util.stream.Collectors;

/** Simulates the notification engine with Meera's (risk) and Demo's (healthy) demo data. */
public class NotifE2E {
    static int pass = 0, fail = 0;
    static void check(String n, boolean ok) { System.out.println((ok ? "PASS  " : "FAIL  ") + n); if (ok) pass++; else fail++; }

    public static void main(String[] args) {
        AppProperties props = new AppProperties();
        LocalDateTime now = LocalDateTime.now(props.zone());
        User fu = new User(); fu.setFullName("Demo Faculty One"); Faculty fac = new Faculty(); fac.setUser(fu); fac.setTitle("Prof."); fac.setId(1L);
        String[][] subj = {{"1","CNF"},{"2","DBS"},{"3","PPS"},{"4","AJT"},{"5","PS"},{"6","DS"}};
        List<Subject> subjects = new ArrayList<>();
        for (String[] s : subj) { Subject x = new Subject(); x.setId(Long.valueOf(s[0])); x.setShortName(s[1]); x.setName(s[1] + " course"); x.setFaculty(fac); subjects.add(x); }
        User su = new User(); su.setFullName("Demo Student Two"); su.setEmail("meera@x");
        Student st = new Student(); st.setId(2L); st.setUser(su);

        Map<Long, long[]> attendance = new HashMap<>();
        long[][] meera = {{28,17},{28,23},{28,16},{28,20},{28,24},{28,22}};
        for (int i = 0; i < 6; i++) attendance.put((long) (i + 1), meera[i]);

        List<Assignment> asg = new ArrayList<>();
        Object[][] a = {{101L,"PPS Assignment 2",3L,5L*60},{102L,"AJT Lab Manual",4L,40L*60},{103L,"PPS Assignment 1",3L,-2L*24*60},
                        {104L,"CNF Assignment 2",1L,10L*24*60},{105L,"DS Lab #3 (submitted)",6L,3L*60}};
        for (Object[] r : a) { Assignment x = new Assignment(); x.setId((Long) r[0]); x.setTitle((String) r[1]); x.setSubject(subjects.get(((Long) r[2]).intValue() - 1)); x.setDueAt(now.plusMinutes((Long) r[3])); asg.add(x); }
        Set<Long> submitted = Set.of(105L);

        List<Mark> marks = new ArrayList<>();
        Mark m1 = new Mark(); m1.setId(1L); m1.setStudent(st); m1.setSubject(subjects.get(3)); m1.setExamType("CIE-I"); m1.setObtained(new BigDecimal("10")); m1.setMaximum(new BigDecimal("30")); m1.setPublishedOn(now.toLocalDate());
        Mark m2 = new Mark(); m2.setId(2L); m2.setStudent(st); m2.setSubject(subjects.get(2)); m2.setExamType("CIE-I"); m2.setObtained(new BigDecimal("25")); m2.setMaximum(new BigDecimal("30")); m2.setPublishedOn(now.toLocalDate());
        marks.addAll(List.of(m1, m2));

        List<StudyMaterial> mats = new ArrayList<>();
        StudyMaterial n1 = new StudyMaterial(); n1.setId(1L); n1.setSubject(subjects.get(5)); n1.setTitle("Unit 3 AVL"); n1.setUploadedBy(fac); n1.setUploadedAt(now.minusHours(5));
        StudyMaterial n2 = new StudyMaterial(); n2.setId(2L); n2.setSubject(subjects.get(0)); n2.setTitle("Old notes"); n2.setUploadedBy(fac); n2.setUploadedAt(now.minusHours(100));
        mats.addAll(List.of(n1, n2));
        List<Announcement> anns = new ArrayList<>();
        Announcement b1 = new Announcement(); b1.setId(1L); b1.setTitle("Wi-Fi maintenance"); b1.setBody("Saturday night"); b1.setCreatedAt(now.minusHours(2));
        Announcement b2 = new Announcement(); b2.setId(2L); b2.setTitle("Old notice"); b2.setBody("x"); b2.setCreatedAt(now.minusDays(10));
        anns.addAll(List.of(b1, b2));
        List<FeeRecord> fees = new ArrayList<>();
        FeeRecord f1 = new FeeRecord(); f1.setId(1L); f1.setTitle("Final instalment"); f1.setAmount(new BigDecimal("42500")); f1.setDueDate(now.toLocalDate().plusDays(1)); f1.setPaid(false);
        FeeRecord f2 = new FeeRecord(); f2.setId(2L); f2.setTitle("Library fine"); f2.setAmount(new BigDecimal("300")); f2.setDueDate(now.toLocalDate().minusDays(3)); f2.setPaid(false);
        FeeRecord f3 = new FeeRecord(); f3.setId(3L); f3.setTitle("Paid one"); f3.setAmount(new BigDecimal("1")); f3.setDueDate(now.toLocalDate().minusDays(30)); f3.setPaid(true);
        fees.addAll(List.of(f1, f2, f3));

        List<Notification> store = new ArrayList<>();
        NotificationDao nDao = new NotificationDao(null) {
            @Override public Optional<Notification> findByDedupe(Long sid, String key) { return store.stream().filter(n -> key.equals(n.getDedupeKey())).findFirst(); }
            @Override public Notification save(Notification n) { n.setId((long) store.size() + 1); store.add(n); return n; }
            @Override public List<Notification> unshownPopups(Long sid) { return store.stream().filter(n -> !n.isPopupShown()).limit(5).collect(Collectors.toList()); }
            @Override public void markPopupShown(Long id) { store.stream().filter(n -> n.getId().equals(id)).forEach(n -> n.setPopupShown(true)); }
        };
        EnrollmentDao eDao = new EnrollmentDao(null) { @Override public List<Subject> subjectsOf(Long id) { return subjects; } };
        final Map<Long, long[]>[] att = new Map[] { attendance };
        AttendanceRecordDao aDao = new AttendanceRecordDao(null) { @Override public Map<Long, long[]> summaryByStudent(Long id) { return att[0]; } };
        AssignmentDao asDao = new AssignmentDao(null) { @Override public List<Assignment> forSubjects(Collection<Long> ids) { return asg; } };
        SubmissionDao suDao = new SubmissionDao(null) { @Override public Set<Long> submittedAssignmentIds(Long id) { return submitted; } };
        MarkDao mDao = new MarkDao(null) { @Override public List<Mark> byStudent(Long id) { return marks; } };
        StudyMaterialDao matDao = new StudyMaterialDao(null) { @Override public List<StudyMaterial> latestForSubjects(Collection<Long> ids, int l) { return mats; } };
        AnnouncementDao anDao = new AnnouncementDao(null) { @Override public List<Announcement> latest(int l) { return anns; } };
        FeeRecordDao fDao = new FeeRecordDao(null) { @Override public List<FeeRecord> byStudent(Long id) { return fees; } };
        NotificationService svc = new NotificationService(nDao, null, eDao, aDao, asDao, suDao, mDao, matDao, anDao, fDao, new AttendancePolicy(props), new EmailService(props), props);

        System.out.println("== Meera (risk student)");
        int created = svc.scanStudent(st, now);
        Map<String, NotificationColor> byKey = new HashMap<>();
        store.forEach(n -> byKey.put(n.getDedupeKey(), n.getColor()));
        long red = store.stream().filter(n -> n.getColor() == NotificationColor.RED).count();
        long orange = store.stream().filter(n -> n.getColor() == NotificationColor.ORANGE).count();
        long blue = store.stream().filter(n -> n.getColor() == NotificationColor.BLUE).count();
        System.out.println("   created " + created + " -> RED " + red + ", ORANGE " + orange + ", BLUE " + blue + "   keys=" + new TreeSet<>(byKey.keySet()));
        check("CNF 60.7% (<65) -> RED", byKey.get("att-red-1") == NotificationColor.RED);
        check("PPS 57.1% (<65) -> RED", byKey.get("att-red-3") == NotificationColor.RED);
        check("AJT 71.4% (65-75) -> ORANGE", byKey.get("att-low-4") == NotificationColor.ORANGE);
        check("DS 78.6% (75-80) -> ORANGE borderline", byKey.get("att-border-6") == NotificationColor.ORANGE);
        check("DBS 82.1% / PS 85.7% -> no alert", !byKey.containsKey("att-low-2") && !byKey.containsKey("att-border-2") && !byKey.containsKey("att-red-5") && !byKey.containsKey("att-border-5"));
        check("assignment due in 5 h -> RED (12-hour rule)", byKey.get("due12-101") == NotificationColor.RED);
        check("assignment due in 40 h -> ORANGE", byKey.get("asg-102") == NotificationColor.ORANGE);
        check("assignment overdue 2 days -> ORANGE", byKey.get("late-103") == NotificationColor.ORANGE);
        check("assignment due in 10 days -> no alert", byKey.keySet().stream().noneMatch(k -> k.endsWith("-104")));
        check("submitted assignment -> no alert", byKey.keySet().stream().noneMatch(k -> k.endsWith("-105")));
        check("score 10/30 -> ORANGE poor-score warning, 25/30 -> none", byKey.get("lowmark-1") == NotificationColor.ORANGE && !byKey.containsKey("lowmark-2"));
        check("results declared -> BLUE", byKey.get("result-CIE-I") == NotificationColor.BLUE);
        check("material 5 h old -> BLUE, 100 h old -> none", byKey.get("mat-1") == NotificationColor.BLUE && !byKey.containsKey("mat-2"));
        check("notice 2 h old -> BLUE, 10 days old -> none", byKey.get("ann-1") == NotificationColor.BLUE && !byKey.containsKey("ann-2"));
        check("fee due tomorrow -> RED, overdue fee -> ORANGE, paid fee -> none", byKey.get("fee-1") == NotificationColor.RED && byKey.get("feeover-2") == NotificationColor.ORANGE && !byKey.containsKey("fee-3"));
        check("totals: 4 RED, 6 ORANGE, 3 BLUE", red == 4 && orange == 6 && blue == 3 && created == 13);
        check("second scan creates NOTHING (dedupe keys)", svc.scanStudent(st, now) == 0 && store.size() == 13);

        System.out.println("== pop-ups");
        List<Notification> p1 = svc.takePopups(2L);
        check("first poll returns at most 5 new pop-ups", p1.size() == 5);
        check("second poll returns the NEXT ones (each pop-up shows once)", svc.takePopups(2L).stream().noneMatch(n -> p1.contains(n)));
        svc.takePopups(2L);
        check("after all are shown, polling returns nothing", svc.takePopups(2L).isEmpty());

        System.out.println("== Demo (healthy student)");
        store.clear(); marks.clear(); fees.clear(); anns.clear(); mats.clear(); asg.removeIf(x -> x.getId() != 105L);
        long[][] rak = {{28,25},{28,25},{28,24},{28,25},{28,25},{28,24}};
        Map<Long, long[]> healthy = new HashMap<>(); for (int i = 0; i < 6; i++) healthy.put((long) (i + 1), rak[i]); att[0] = healthy;
        check("88% attendance, nothing pending -> no alerts at all", svc.scanStudent(st, now) == 0);

        System.out.println("\nRESULT: " + pass + " passed, " + fail + " failed");
        System.exit(fail == 0 ? 0 : 1);
    }
}
