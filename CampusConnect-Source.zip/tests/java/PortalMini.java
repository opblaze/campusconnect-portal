import com.campusconnect.config.AppProperties;
import com.campusconnect.dao.*;
import com.campusconnect.model.*;
import com.campusconnect.model.enums.*;
import com.campusconnect.service.*;
import com.campusconnect.util.FeeStatus;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.time.*;
import java.util.*;
import java.util.stream.Collectors;

/** Focused test of the new portal logic: fee status/categories/hostel rule, demo payment, profile, search, preview files, notes. */
public class PortalMini {
    static int pass = 0, fail = 0;
    static void check(String n, boolean ok) { System.out.println((ok ? "PASS  " : "FAIL  ") + n); if (ok) pass++; else fail++; }
    static final LocalDate TODAY = LocalDate.now(new AppProperties().zone());

    static FeeRecord fee(long id, Student st, String title, String cat, String amt, int dueDays, boolean paid) {
        FeeRecord f = new FeeRecord(); f.setId(id); f.setStudent(st); f.setTitle(title); f.setCategory(cat);
        f.setAmount(new BigDecimal(amt)); f.setDueDate(TODAY.plusDays(dueDays)); f.setPaid(paid);
        if (paid) { f.setPaidOn(TODAY.minusDays(2)); f.setReceiptNo("CC-DEMO-0001"); f.setPaymentMethod("UPI"); }
        return f;
    }

    public static void main(String[] args) throws Exception {
        AppProperties props = new AppProperties();
        System.setProperty("upload.dir", Files.createTempDirectory("ccup").toString());
        props = new AppProperties();

        User ru = new User(); ru.setFullName("Demo Student One"); ru.setEmail("student.one@example.invalid");
        User mu = new User(); mu.setFullName("Demo Student Two"); mu.setEmail("student.two@example.invalid");
        Student rak = new Student(); rak.setId(1L); rak.setUser(ru); rak.setEnrollmentNo("DEMO-STU-001");
        rak.setGmail("student.one@example.invalid"); rak.setHosteler(true); rak.setHostelName("Aryabhatta Boys Hostel");
        rak.setProgram("B.Tech in Computer Science & Engineering"); rak.setBranchCode("CSE-CS"); rak.setSemester(3); rak.setAcademicYear("2026-27");
        Student mee = new Student(); mee.setId(2L); mee.setUser(mu); mee.setEnrollmentNo("DEMO-STU-002");
        mee.setGmail("student.two@example.invalid"); mee.setHosteler(false);
        mee.setProgram("B.Tech in Computer Science & Engineering"); mee.setBranchCode("CSE-CS"); mee.setSemester(3); mee.setAcademicYear("2026-27");
        Map<Long, Student> students = Map.of(1L, rak, 2L, mee);

        List<FeeRecord> fees = new ArrayList<>(List.of(
                fee(1, rak, "Semester 3 - Instalment 1", "TUITION", "38000", -60, true),
                fee(2, rak, "Semester 3 - Final Fee Instalment", "TUITION", "42500", 2, false),
                fee(4, rak, "Mid-Semester Exam II Fee", "EXAM", "1200", 10, false),
                fee(5, rak, "PRC - Professional Regularity Charges (Sem 3)", "PRC", "500", -3, false),
                fee(6, rak, "Hostel Fee - Semester 3", "HOSTEL", "45000", 25, false),
                fee(9, mee, "Hostel Fee - should never show", "HOSTEL", "45000", 25, false),
                fee(3, mee, "Semester 3 - Final Fee Instalment", "TUITION", "42500", 2, false)));

        StudentDao studentDao = new StudentDao(null) { @Override public Optional<Student> findById(Long id) { return Optional.ofNullable(students.get(id)); } };
        FeeRecordDao feeDao = new FeeRecordDao(null) {
            @Override public List<FeeRecord> byStudent(Long id) { return fees.stream().filter(f -> f.getStudent().getId().equals(id)).collect(Collectors.toList()); }
            @Override public Optional<FeeRecord> findById(Long id) { return fees.stream().filter(f -> f.getId().equals(id)).findFirst(); }
            @Override public FeeRecord update(FeeRecord f) { return f; }
        };
        List<String> created = new ArrayList<>();
        NotificationService ns = new NotificationService(null, null, null, null, null, null, null, null, null, null, null, null, props) {
            @Override public Notification create(Student st, NotificationColor c, String cat, String title, String msg, String l, String u, String key) { created.add(key + "|" + c); return null; }
        };
        List<StudentNote> notes = new ArrayList<>();
        StudentNoteDao noteDao = new StudentNoteDao(null) {
            @Override public List<StudentNote> byStudent(Long sid) { return notes.stream().filter(n -> n.getStudent().getId().equals(sid)).collect(Collectors.toList()); }
            @Override public StudentNote save(StudentNote n) { n.setId(notes.size() + 1L); notes.add(n); return n; }
            @Override public Optional<StudentNote> findById(Long id) { return notes.stream().filter(n -> n.getId().equals(id)).findFirst(); }
            @Override public void delete(StudentNote n) { notes.remove(n); }
        };
        EnrollmentDao enrollDao = new EnrollmentDao(null) { @Override public List<Subject> subjectsOf(Long id) { return List.of(); } @Override public boolean isEnrolled(Long s, Long sub) { return true; } };
        AssignmentDao asgDao = new AssignmentDao(null) { @Override public List<Assignment> forSubjects(Collection<Long> ids) { return List.of(); } };
        SubmissionDao subDao = new SubmissionDao(null) { @Override public Set<Long> submittedAssignmentIds(Long id) { return Set.of(); } @Override public List<Submission> byStudent(Long id) { return List.of(); } };
        StudyMaterialDao matDao = new StudyMaterialDao(null) { @Override public List<StudyMaterial> latestForSubjects(Collection<Long> ids, int l) { return List.of(); } };
        ExamScheduleDao examDao = new ExamScheduleDao(null) { @Override public List<ExamSchedule> upcomingForSubjects(Collection<Long> ids, LocalDate d) { return List.of(); } };
        AnnouncementDao annDao = new AnnouncementDao(null) { @Override public List<Announcement> latest(int l) { return List.of(); } };
        TimetableSlotDao ttDao = new TimetableSlotDao(null) { @Override public List<TimetableSlot> forSubjects(Collection<Long> ids) { return List.of(); } };
        MarkDao markDao = new MarkDao(null) { @Override public List<Mark> byStudent(Long id) { return List.of(); } };
        AttendancePolicy policy = new AttendancePolicy(props);
        PortalService portal = new PortalService(studentDao, noteDao, enrollDao, null, matDao, markDao, examDao, asgDao, subDao, ttDao, feeDao, annDao, policy, ns, props);

        System.out.println("== 1. Fee status");
        Map<String, String> st = new HashMap<>();
        for (Map<String, Object> f : portal.feeRows(1L)) st.put(String.valueOf(f.get("id")), (String) f.get("state"));
        check("paid -> PAID", "PAID".equals(st.get("1")));
        check("due in 2 days -> DUE", "DUE".equals(st.get("2")));
        check("due in 10 days -> DUE (within 15-day window)", "DUE".equals(st.get("4")));
        check("3 days overdue -> OVERDUE (PRC)", "OVERDUE".equals(st.get("5")));
        check("due in 25 days -> PENDING (Hostel)", "PENDING".equals(st.get("6")));
        check("all four statuses present", new HashSet<>(st.values()).containsAll(Set.of("PAID", "DUE", "PENDING", "OVERDUE")));

        System.out.println("\n== 2. Fee categories + hostel rule");
        List<Map<String, Object>> rakFees = portal.feeRows(1L), meeFees = portal.feeRows(2L);
        check("hosteler sees HOSTEL + EXAM + PRC + TUITION", rakFees.stream().map(f -> f.get("category")).collect(Collectors.toSet()).containsAll(Set.of("HOSTEL", "EXAM", "PRC", "TUITION")));
        check("non-hosteler never sees a HOSTEL fee", meeFees.stream().noneMatch(f -> "HOSTEL".equals(f.get("category"))));
        check("PRC labelled 'Professional Regularity Charges'", rakFees.stream().anyMatch(f -> String.valueOf(f.get("categoryLabel")).contains("Professional Regularity Charges")));
        check("non-hosteler cannot pay a hostel fee by guessing the id", portal.payFee(2L, 9L, "UPI").isEmpty());

        System.out.println("\n== 3. Demo payment");
        check("invalid method rejected", portal.payFee(1L, 2L, "BITCOIN").isEmpty());
        check("another student's fee cannot be paid", portal.payFee(1L, 3L, "UPI").isEmpty());
        Optional<FeeRecord> paid = portal.payFee(1L, 2L, "upi");
        check("UPI payment succeeds, dated today, receipt format correct", paid.isPresent() && TODAY.equals(paid.get().getPaidOn()) && paid.get().getReceiptNo().matches("CC\\d{8}-2-\\d{4}"));
        check("paying twice is blocked", portal.payFee(1L, 2L, "CARD").isEmpty());
        check("hosteler can pay hostel fee by card", portal.payFee(1L, 6L, "CARD").isPresent());
        check("BLUE payment notification created", created.stream().anyMatch(c -> c.equals("paid-2|BLUE")));
        Optional<Map<String, Object>> rc = portal.receipt(1L, 2L);
        check("receipt data correct", rc.isPresent() && rc.get().get("amount").equals("42,500") && rc.get().get("name").equals("Demo Student One"));
        check("no receipt for unpaid or other student's fee", portal.receipt(1L, 4L).isEmpty() && portal.receipt(2L, 2L).isEmpty());

        System.out.println("\n== 4. Profile");
        Map<String, Object> p = portal.profile(1L), pm = portal.profile(2L);
        check("profile: name, branch, gmail, enrollment", p.get("name").equals("Demo Student One") && p.get("branch").equals("CSE-CS") && p.get("gmail").equals("student.one@example.invalid") && p.get("enrollment").equals("DEMO-STU-001"));
        check("hosteler=Yes -> hostel name set", (Boolean) p.get("hosteler") && p.get("hostelName").equals("Aryabhatta Boys Hostel"));
        check("hosteler=No -> no hostel name", !(Boolean) pm.get("hosteler") && pm.get("hostelName").equals(""));

        System.out.println("\n== 5. Live search keywords");
        List<String> k0 = portal.suggest("");
        check("keyword list starts pending, done, due, late", k0.subList(0, 4).equals(List.of("pending", "done", "due", "late")));
        check("'pe' suggests pending", portal.suggest("pe").contains("pending"));
        List<Map<String, Object>> sHostel = portal.searchRows(1L, "hostel");
        check("'hostel' finds the hostel fee", sHostel.stream().anyMatch(x -> String.valueOf(x.get("title")).contains("Hostel Fee")));
        check("non-hosteler searching 'hostel' finds no hostel FEE", portal.searchRows(2L, "hostel").stream().noneMatch(x -> "Fee".equals(x.get("type"))));
        check("'prc' finds the PRC fee with OVERDUE badge", portal.searchRows(1L, "prc").stream().anyMatch(x -> "OVERDUE".equals(x.get("badge"))));
        check("'fees' opens Fees & Dues page", portal.searchRows(1L, "fees").stream().anyMatch(x -> "/app/fees".equals(x.get("href"))));
        check("nonsense query returns nothing", portal.searchRows(1L, "zzzxq").isEmpty());

        System.out.println("\n== 6. Study material preview (demo PDF generation) + notes");
        Subject s4 = new Subject(); s4.setId(4L); s4.setName("Advance Java Technology"); s4.setShortName("AJT");
        Faculty f4 = new Faculty(); User fu = new User(); fu.setFullName("Demo Faculty Four"); f4.setUser(fu); f4.setTitle("Prof.");
        StudyMaterial pdfMat = new StudyMaterial(); pdfMat.setId(1L); pdfMat.setSubject(s4); pdfMat.setTitle("Unit 4"); pdfMat.setFileType("PDF"); pdfMat.setUploadedBy(f4); pdfMat.setFilePath("x.pdf");
        StudyMaterialDao matDao2 = new StudyMaterialDao(null) { @Override public Optional<StudyMaterial> findById(Long id) { return id == 1L ? Optional.of(pdfMat) : Optional.empty(); } };
        PortalService portal2 = new PortalService(studentDao, noteDao, enrollDao, null, matDao2, markDao, examDao, asgDao, subDao, ttDao, feeDao, annDao, policy, ns, props);
        Optional<PortalService.FileData> pdf = portal2.fileOf(1L, "material", 1L);
        check("PDF material generates a real PDF (%PDF- header)", pdf.isPresent() && new String(pdf.get().bytes(), 0, 5, java.nio.charset.StandardCharsets.ISO_8859_1).equals("%PDF-"));
        check("preview kind mapping: pdf/image/text/none", PortalService.previewKind(java.nio.file.Path.of("a.pdf"), null).equals("pdf")
                && PortalService.previewKind(java.nio.file.Path.of("a.png"), null).equals("image")
                && PortalService.previewKind(java.nio.file.Path.of("a.java"), null).equals("text")
                && PortalService.previewKind(java.nio.file.Path.of("a.docx"), null).equals("none"));
        StudentNote n1 = portal2.addNote(1L, null, "My notes", "x.txt", "1-abc-x.txt", 5);
        check("upload note -> listed", portal2.noteRows(1L).size() == 1);
        check("note private: another student cannot open/delete it", portal2.noteFor(2L, n1.getId()).isEmpty() && portal2.deleteNote(2L, n1.getId()).isEmpty());
        check("owner can delete own note", portal2.deleteNote(1L, n1.getId()).isPresent() && portal2.noteRows(1L).isEmpty());

        System.out.println("\nRESULT: " + pass + " passed, " + fail + " failed");
        System.exit(fail == 0 ? 0 : 1);
    }
}
