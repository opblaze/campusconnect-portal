# Campus Connect - Smart Student Portal (Advanced Java)

The bundled seed records are synthetic demo data. Contact fields use reserved `.invalid` addresses and contain no real student contact details.

A student portal built with **Servlets, JSP/JSTL/EL, Spring (dependency injection) and Hibernate ORM on MySQL**.
The UI is a pixel-faithful port of the CampusConnect design (Tailwind tokens, Material Symbols, Plus Jakarta Sans / Inter)
with an **automatic light/dark theme** (light 06:00-18:00, dark otherwise, manual override available).

| Phase | Content | Status |
|-------|---------|--------|
| 1 | Database, Hibernate DAOs (CRUD), Spring DI, login + session security, dashboard, theme | done |
| 2 | Notification engine (BLUE/RED/ORANGE pop-ups), Gemini chatbot, feedback e-mail to faculty | done |
| 3 | All sidebar pages, Swing faculty console, PWA (desktop + mobile install), Docker, project report | done |

## Architecture (layered)

```
Browser -> Filters (security headers, AuthFilter)
        -> Servlets (controllers: LoginServlet, DashboardServlet, PageServlet, LogoutServlet)
        -> Services  (Spring @Service: AuthService, DashboardService, AttendancePolicy)
        -> DAOs      (Spring @Repository, generic BaseDao<T,ID> = full CRUD)
        -> Hibernate ORM (17 annotated entities, HikariCP pool)
        -> MySQL (17 related tables)
JSP views (/WEB-INF/views) + JSTL/EL render DTOs prepared by the services.
```

## Run it (NetBeans + Tomcat 11 + XAMPP)

1. Start **Apache + MySQL** in XAMPP.
2. phpMyAdmin -> *Import* -> `sql/01_schema.sql`, then `sql/02_seed.sql` (creates DB `campusconnect`).
3. NetBeans -> *Open Project* -> this folder (Maven web project). First build downloads dependencies (internet needed).
4. If your MySQL root has a password, create `src/main/resources/app-local.properties` with `db.password=...`.
5. **Use Tomcat 10.1 or 11 (NOT 8.5 / 9).** Add **Tomcat 11** in NetBeans (Services -> Servers), right-click project -> *Run*.
6. Open `http://localhost:8080/campusconnect/` (the port/context may differ in your Tomcat setup).

Optional console CRUD demo: run `com.campusconnect.tools.CrudDemo` (Create/Read/Update/Delete via Hibernate).

### Demo accounts (all passwords are demo-only; change them before any real deployment)

| Role | Login id | Password | Shows |
|------|----------|----------|-------|
| Student | `DEMO-STU-001` | `Student@123` | healthy dashboard (88 % attendance, GREEN) |
| Student | `DEMO-STU-002` | `Student@123` | **risk state** (attendance RED, warnings) |
| Student | `DEMO-STU-003` | `Student@123` | empty-enrollment state |
| Faculty | `faculty.one@example.invalid` (`DEMO-FAC-001`) | `Faculty@123` | CNF - Faculty Web Portal & Swing console |
| Faculty | `faculty.two@example.invalid` (`DEMO-FAC-002`) | `Faculty@123` | DBS - Faculty Web Portal |
| Faculty | `faculty.three@example.invalid` (`DEMO-FAC-003`) | `Faculty@123` | PPS - Faculty Web Portal |
| Faculty | `faculty.four@example.invalid` (`DEMO-FAC-004`) | `Faculty@123` | AJT - Faculty Web Portal |
| Faculty | `faculty.five@example.invalid` (`DEMO-FAC-005`) | `Faculty@123` | PS - Faculty Web Portal |
| Faculty | `faculty.six@example.invalid` (`DEMO-FAC-006`) | `Faculty@123` | DS - Faculty Web Portal |
| Admin | `admin@example.invalid` | `Admin@123` | Admin Control Panel |

Students can sign in with their enrollment number or e-mail; faculty can sign in with their employee code (`DEMO-FAC-001`..`DEMO-FAC-006`) or e-mail; administrators sign in at the same login screen to open the Admin Control Panel (`/dashboard` & `/admin/*`).
Database (XAMPP default): user `root`, empty password, database `campusconnect`.

## Deployment status

This is a server-backed Java application and needs a Docker-capable host plus MySQL. No public runtime is configured yet; see [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md) for the deployment requirements.

### Troubleshooting

| Symptom | Cause / fix |
|---------|-------------|
| `NoClassDefFoundError: jakarta/servlet/jsp/tagext/...`, `javax.servlet.ServletException`, "Apache Tomcat/8.5" in the error page | The project runs on the wrong server. It needs **Tomcat 10.1 or 11** (Jakarta namespace). NetBeans: *Services -> Servers -> Add Server -> Apache Tomcat or TomEE* (point to the Tomcat 11 folder), then *Project -> Properties -> Run -> Server* = Tomcat 11, *Clean and Build*, run. |
| Error page "Campus Connect could not start" | MySQL is not running, or `sql/01_schema.sql` / `02_seed.sql` were not imported, or wrong `db.url/db.user/db.password`. Open `/campusconnect/health` for a yes/no self-test; details are in the Tomcat log. Start MySQL and reload - no redeploy needed. |
| `Unknown system variable 'transaction_isolation'` | XAMPP MariaDB vs MySQL driver. Set in `app-local.properties`: `db.driver=org.mariadb.jdbc.Driver`, `db.url=jdbc:mariadb://localhost:3306/campusconnect`, `db.dialect=org.hibernate.dialect.MariaDBDialect`. |
| Browser console: "cdn.tailwindcss.com should not be used in production" | Harmless warning of the design's Tailwind CDN script. |

## Enhancement round (payment, profile, search, preview, Sanjii)

- **Demo payment module**: Fees & Dues shows Tuition, Exam Fees, PRC (Professional Regularity Charges) and Hostel Fees
  (hostel fees only appear/are payable for students flagged as hostelers). Status is PAID / DUE (within 15 days) /
  PENDING / OVERDUE. Paying opens a demo card/UPI/net-banking window (client-side only - no card data is ever sent to
  the server) and issues a receipt (`/app/receipt?id=`).
- **Student profile** (`/app/profile`): full name, stream/branch, Gmail, enrollment number, hosteler Yes/No + hostel name.
- **Header**: live semester + academic year pill and today's date, both driven by the dashboard data / session.
- **Live search**: the top-bar box calls `/api/search` on every keystroke and shows a keyword list (pending, done, due,
  late, overdue, paid, fees, hostel, prc, exam ...) plus matching assignments, fees, material, exams, subjects and notices.
- **Study material**: every item (faculty material and your own private "My notes" uploads) has an eye button that opens
  an in-page preview (PDF/image/text) without downloading; Upload and Download are unchanged.
- **Chatbot "Sanjii"**: a visible "AI is thinking..." indicator while it answers; instant friendly replies to greetings
  and "what can you do?"; a single, exact refusal for anything outside campus/academic topics (programming help,
  general knowledge, unethical requests): *"I'm sorry, I'm only able to assist with campus and academic-related topics.
  For other queries, please use a general-purpose assistant. 😊"*

## Gemini chatbot, e-mail and secrets

Copy `src/main/resources/app-local.properties.example` to `app-local.properties` (git-ignored) and fill in:
`gemini.api.key`, and for e-mail `mail.smtp.user` / `mail.smtp.password` (Gmail **app password**) and `mail.demo.redirect`
(all demo mails go to this inbox). Without these the chatbot answers from a rule-based fallback and mails are skipped - nothing crashes.

* Model: `gemini-2.5-flash` (free tier). Change with `gemini.model`.
* Chatbot guards: local scope/injection filter -> restrictive system prompt -> rate limit -> fallback answers.
* Feedback: asked every `feedback.interval.days` days (set `1` to test); the reply is cleaned/filtered by Gemini and e-mailed to the faculty.
* Notifications: a background job runs every `scheduler.minutes` minutes; pop-ups appear within 30 s.

Automated checks of the chatbot, notification rules and browser scripts: `tests/README.md`.

More: `docs/DESKTOP_MOBILE.md`, `docs/DEPLOYMENT.md`.

## Rubric mapping

* **Database + JDBC/Hibernate:** 17 related tables (`sql/01_schema.sql`), Hibernate entities in `model/`, CRUD in `dao/BaseDao`,
  custom HQL in the DAOs, one exception type (`DataAccessException`) with rollback handling.
* **AJT technologies:** Servlets + Filters, JSP with JSTL (`c:`, `fn:`) and EL, session management (new session on login,
  timeout, HttpOnly cookie, CSRF token, no-store cache headers), Spring DI (`AppConfig`, `@Service`, `@Repository`),
  form validation on client **and** server (`Validator`).
* **Final submission:** this repository + ZIP + README (deployment in phase 3).

## Colour rules

* Attendance: `>= 85 %` GREEN, `75-84 %` YELLOW, `< 75 %` RED (thresholds live in `app.properties`).
* Notifications (phase 2): BLUE = general, RED = urgent (due in 12 h, very low attendance), ORANGE = warnings.

## Security notes

Passwords: PBKDF2-HMAC-SHA256 with per-user salt. Login lock-out after 5 failures. Generic login error (no user enumeration).
Output escaping with `c:out`. **Never commit API keys** - put them in `app-local.properties` (git-ignored) or env variables.
