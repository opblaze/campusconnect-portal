-- =====================================================================
-- Campus Connect - database schema (generated from the same spec as the
-- Hibernate entities, so tables and entities always match).
-- Engine: InnoDB, charset utf8mb4.  Tables: 18
-- =====================================================================
CREATE DATABASE IF NOT EXISTS campusconnect CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE campusconnect;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS feedback;
DROP TABLE IF EXISTS chat_messages;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS announcements;
DROP TABLE IF EXISTS student_notes;
DROP TABLE IF EXISTS fees;
DROP TABLE IF EXISTS exam_schedule;
DROP TABLE IF EXISTS timetable;
DROP TABLE IF EXISTS materials;
DROP TABLE IF EXISTS submissions;
DROP TABLE IF EXISTS assignments;
DROP TABLE IF EXISTS marks;
DROP TABLE IF EXISTS attendance;
DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS subjects;
DROP TABLE IF EXISTS faculty;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- Login account shared by students and faculty.
CREATE TABLE users (
  id BIGINT NOT NULL AUTO_INCREMENT,
  email VARCHAR(150) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  last_login_at DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Academic profile of a student (1:1 with User).
CREATE TABLE students (
  id BIGINT NOT NULL AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  enrollment_no VARCHAR(20) NOT NULL,
  program VARCHAR(120) NOT NULL,
  branch_code VARCHAR(20) NOT NULL,
  semester INT NOT NULL,
  academic_year VARCHAR(20) NOT NULL,
  cgpa DECIMAL(4,2) NOT NULL,
  previous_sgpa DECIMAL(4,2) NOT NULL,
  earned_credits INT NOT NULL,
  backlogs INT NOT NULL,
  cohort_standing VARCHAR(80) NULL,
  phone VARCHAR(20) NULL,
  gmail VARCHAR(150) NULL,
  hosteler TINYINT(1) NOT NULL DEFAULT 0,
  hostel_name VARCHAR(80) NULL,
  semester_start DATE NOT NULL,
  semester_weeks INT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_students_user_id (user_id),
  CONSTRAINT fk_students_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_students_enrollment_no (enrollment_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Teaching staff profile (1:1 with User).
CREATE TABLE faculty (
  id BIGINT NOT NULL AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  employee_code VARCHAR(20) NOT NULL,
  title VARCHAR(10) NOT NULL,
  designation VARCHAR(60) NOT NULL,
  department VARCHAR(80) NOT NULL,
  cabin VARCHAR(40) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_faculty_user_id (user_id),
  CONSTRAINT fk_faculty_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_faculty_employee_code (employee_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- A course offered in a semester.
CREATE TABLE subjects (
  id BIGINT NOT NULL AUTO_INCREMENT,
  code VARCHAR(20) NOT NULL,
  name VARCHAR(120) NOT NULL,
  short_name VARCHAR(20) NOT NULL,
  credits INT NOT NULL,
  category VARCHAR(20) NOT NULL,
  semester INT NOT NULL,
  faculty_id BIGINT NOT NULL,
  syllabus_completion DECIMAL(5,2) NOT NULL,
  meeting_days VARCHAR(40) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_subjects_code (code),
  KEY ix_subjects_faculty_id (faculty_id),
  CONSTRAINT fk_subjects_faculty_id FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Student registered for a subject.
CREATE TABLE enrollments (
  id BIGINT NOT NULL AUTO_INCREMENT,
  student_id BIGINT NOT NULL,
  subject_id BIGINT NOT NULL,
  enrolled_on DATE NOT NULL,
  PRIMARY KEY (id),
  KEY ix_enrollments_student_id (student_id),
  CONSTRAINT fk_enrollments_student_id FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  KEY ix_enrollments_subject_id (subject_id),
  CONSTRAINT fk_enrollments_subject_id FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
  UNIQUE KEY uq_enrollments_c0 (student_id, subject_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- One lecture, present or absent.
CREATE TABLE attendance (
  id BIGINT NOT NULL AUTO_INCREMENT,
  student_id BIGINT NOT NULL,
  subject_id BIGINT NOT NULL,
  lecture_date DATE NOT NULL,
  present TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY ix_attendance_student_id (student_id),
  CONSTRAINT fk_attendance_student_id FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  KEY ix_attendance_subject_id (subject_id),
  CONSTRAINT fk_attendance_subject_id FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
  UNIQUE KEY uq_attendance_c0 (student_id, subject_id, lecture_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Marks obtained in one evaluation component.
CREATE TABLE marks (
  id BIGINT NOT NULL AUTO_INCREMENT,
  student_id BIGINT NOT NULL,
  subject_id BIGINT NOT NULL,
  exam_type VARCHAR(30) NOT NULL,
  obtained DECIMAL(5,2) NOT NULL,
  maximum DECIMAL(5,2) NOT NULL,
  published_on DATE NOT NULL,
  PRIMARY KEY (id),
  KEY ix_marks_student_id (student_id),
  CONSTRAINT fk_marks_student_id FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  KEY ix_marks_subject_id (subject_id),
  CONSTRAINT fk_marks_subject_id FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Assignment / lab manual set by faculty.
CREATE TABLE assignments (
  id BIGINT NOT NULL AUTO_INCREMENT,
  subject_id BIGINT NOT NULL,
  title VARCHAR(200) NOT NULL,
  description VARCHAR(1000) NULL,
  due_at DATETIME NOT NULL,
  max_marks INT NOT NULL,
  PRIMARY KEY (id),
  KEY ix_assignments_subject_id (subject_id),
  CONSTRAINT fk_assignments_subject_id FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Student's submission for an assignment.
CREATE TABLE submissions (
  id BIGINT NOT NULL AUTO_INCREMENT,
  assignment_id BIGINT NOT NULL,
  student_id BIGINT NOT NULL,
  submitted_at DATETIME NOT NULL,
  status VARCHAR(20) NOT NULL,
  marks_awarded DECIMAL(5,2) NULL,
  PRIMARY KEY (id),
  KEY ix_submissions_assignment_id (assignment_id),
  CONSTRAINT fk_submissions_assignment_id FOREIGN KEY (assignment_id) REFERENCES assignments(id) ON DELETE CASCADE,
  KEY ix_submissions_student_id (student_id),
  CONSTRAINT fk_submissions_student_id FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  UNIQUE KEY uq_submissions_c0 (assignment_id, student_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- E-content uploaded by faculty.
CREATE TABLE materials (
  id BIGINT NOT NULL AUTO_INCREMENT,
  subject_id BIGINT NOT NULL,
  title VARCHAR(200) NOT NULL,
  file_type VARCHAR(20) NOT NULL,
  size_mb DECIMAL(6,2) NOT NULL,
  uploaded_by BIGINT NOT NULL,
  uploaded_at DATETIME NOT NULL,
  file_path VARCHAR(255) NOT NULL,
  PRIMARY KEY (id),
  KEY ix_materials_subject_id (subject_id),
  CONSTRAINT fk_materials_subject_id FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
  KEY ix_materials_uploaded_by (uploaded_by),
  CONSTRAINT fk_materials_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES faculty(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Weekly recurring lecture slot.
CREATE TABLE timetable (
  id BIGINT NOT NULL AUTO_INCREMENT,
  subject_id BIGINT NOT NULL,
  day_of_week INT NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  room VARCHAR(40) NOT NULL,
  block VARCHAR(40) NULL,
  topic VARCHAR(120) NULL,
  PRIMARY KEY (id),
  KEY ix_timetable_subject_id (subject_id),
  CONSTRAINT fk_timetable_subject_id FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Examination date sheet entry.
CREATE TABLE exam_schedule (
  id BIGINT NOT NULL AUTO_INCREMENT,
  subject_id BIGINT NOT NULL,
  exam_name VARCHAR(60) NOT NULL,
  exam_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  PRIMARY KEY (id),
  KEY ix_exam_schedule_subject_id (subject_id),
  CONSTRAINT fk_exam_schedule_subject_id FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Fee instalment due from a student.
CREATE TABLE fees (
  id BIGINT NOT NULL AUTO_INCREMENT,
  student_id BIGINT NOT NULL,
  title VARCHAR(150) NOT NULL,
  category VARCHAR(20) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  due_date DATE NOT NULL,
  paid TINYINT(1) NOT NULL DEFAULT 0,
  paid_on DATE NULL,
  receipt_no VARCHAR(30) NULL,
  payment_method VARCHAR(20) NULL,
  PRIMARY KEY (id),
  KEY ix_fees_student_id (student_id),
  CONSTRAINT fk_fees_student_id FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Private study note uploaded by a student (visible only to the owner).
CREATE TABLE student_notes (
  id BIGINT NOT NULL AUTO_INCREMENT,
  student_id BIGINT NOT NULL,
  subject_id BIGINT NULL,
  title VARCHAR(200) NOT NULL,
  file_name VARCHAR(200) NOT NULL,
  stored_name VARCHAR(255) NOT NULL,
  size_kb INT NOT NULL,
  uploaded_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY ix_student_notes_student_id (student_id),
  CONSTRAINT fk_student_notes_student_id FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  KEY ix_student_notes_subject_id (subject_id),
  CONSTRAINT fk_student_notes_subject_id FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Campus-wide or subject notice.
CREATE TABLE announcements (
  id BIGINT NOT NULL AUTO_INCREMENT,
  title VARCHAR(200) NOT NULL,
  body VARCHAR(1000) NOT NULL,
  important TINYINT(1) NOT NULL DEFAULT 0,
  subject_id BIGINT NULL,
  posted_by BIGINT NULL,
  created_at DATETIME NOT NULL,
  expires_at DATETIME NULL,
  PRIMARY KEY (id),
  KEY ix_announcements_subject_id (subject_id),
  CONSTRAINT fk_announcements_subject_id FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
  KEY ix_announcements_posted_by (posted_by),
  CONSTRAINT fk_announcements_posted_by FOREIGN KEY (posted_by) REFERENCES faculty(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Smart notification (BLUE / RED / ORANGE).
CREATE TABLE notifications (
  id BIGINT NOT NULL AUTO_INCREMENT,
  student_id BIGINT NOT NULL,
  color VARCHAR(10) NOT NULL,
  category VARCHAR(30) NOT NULL,
  title VARCHAR(200) NOT NULL,
  message VARCHAR(1000) NOT NULL,
  action_label VARCHAR(40) NULL,
  action_url VARCHAR(200) NULL,
  dedupe_key VARCHAR(120) NULL,
  created_at DATETIME NOT NULL,
  read_at DATETIME NULL,
  popup_shown TINYINT(1) NOT NULL DEFAULT 0,
  email_sent TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY ix_notifications_student_id (student_id),
  CONSTRAINT fk_notifications_student_id FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  UNIQUE KEY uq_notifications_c0 (student_id, dedupe_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- One message of the AI chatbot conversation.
CREATE TABLE chat_messages (
  id BIGINT NOT NULL AUTO_INCREMENT,
  student_id BIGINT NOT NULL,
  role VARCHAR(10) NOT NULL,
  content VARCHAR(4000) NOT NULL,
  blocked TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY ix_chat_messages_student_id (student_id),
  CONSTRAINT fk_chat_messages_student_id FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Student feedback processed by AI and mailed to faculty.
CREATE TABLE feedback (
  id BIGINT NOT NULL AUTO_INCREMENT,
  student_id BIGINT NOT NULL,
  subject_id BIGINT NULL,
  faculty_id BIGINT NULL,
  raw_text VARCHAR(2000) NOT NULL,
  processed_text VARCHAR(2000) NULL,
  category VARCHAR(40) NULL,
  status VARCHAR(20) NOT NULL,
  created_at DATETIME NOT NULL,
  emailed_at DATETIME NULL,
  PRIMARY KEY (id),
  KEY ix_feedback_student_id (student_id),
  CONSTRAINT fk_feedback_student_id FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  KEY ix_feedback_subject_id (subject_id),
  CONSTRAINT fk_feedback_subject_id FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
  KEY ix_feedback_faculty_id (faculty_id),
  CONSTRAINT fk_feedback_faculty_id FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
