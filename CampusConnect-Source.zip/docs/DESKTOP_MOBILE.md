# Desktop and mobile versions of Campus Connect

Campus Connect is delivered as **one codebase for every platform**.

## 1. Installable web app (PWA) - desktop and mobile
The portal ships a `manifest.webmanifest`, a service worker (`sw.js`), icons and an offline page.

| Platform | How to install |
|----------|----------------|
| Windows / macOS / Linux (Chrome, Edge) | open the portal, click the **install icon** in the address bar -> *Install Campus Connect* |
| Android (Chrome) | menu -> **Install app** / *Add to Home screen* |
| iPhone / iPad (Safari) | Share -> **Add to Home Screen** |

The installed app opens in its own window without browser chrome, follows the automatic light/dark theme, caches its
static files for fast start and shows an offline page when there is no network.
Private data is never cached by the service worker.

Pop-up notifications: inside the app they appear as coloured toasts (BLUE / RED / ORANGE). After you click the bell icon
in the chat window and allow notifications, the browser also shows system notifications while the tab is in the background.
(True push while the app is closed needs a Web-Push server with VAPID keys - listed as future work.)

The PWA install requires **HTTPS** (or `localhost`). For the deployed link use a host that provides HTTPS.

## 2. Swing desktop console (faculty)
`com.campusconnect.swing.FacultyConsole` is a Java Swing application. Start it from NetBeans (*Run File*) with XAMPP MySQL
running. Sign in with a faculty account, e.g. `faculty.one@example.invalid` / `Faculty@123`.
It posts announcements, uploads material, publishes marks and takes attendance - students receive the matching
notifications in the portal automatically.

## 3. Optional: Android APK
Because the portal is a PWA served over HTTPS, it can be wrapped as an Android app without new code using
**Bubblewrap / Trusted Web Activity** (`npm i -g @bubblewrap/cli`, `bubblewrap init --manifest https://YOUR-SITE/manifest.webmanifest`,
`bubblewrap build`). Capacitor is an alternative.
