# Running and deploying Campus Connect

## Local with Docker

From the project root, run:

```sh
docker compose up --build
```

Open `http://localhost:8080`. Docker Compose initializes MySQL from `sql/01_schema.sql` and `sql/02_seed.sql` on the database's first start. Its credentials are local-demo values only. Do not reuse them for a public database.

## Public deployment

GitHub stores the source; it does not run this Java web application. The app needs a host that can build the included `Dockerfile` and a reachable MySQL database. The container listens on port `8080` and serves the WAR at `/`.

1. Create a MySQL database and import `sql/01_schema.sql`, then `sql/02_seed.sql`.
2. Deploy the repository's `Dockerfile` from the repository root.
3. Set `DB_URL`, `DB_USER`, and `DB_PASSWORD` as runtime environment variables. Set `GEMINI_API_KEY`, `MAIL_SMTP_USER`, `MAIL_SMTP_PASSWORD`, and `MAIL_DEMO_REDIRECT` only if those optional integrations are needed. Keep all credentials in the host's secret settings; never commit them.
4. Enable the secure session-cookie setting in `src/main/webapp/WEB-INF/web.xml` when serving the app over HTTPS.
5. Check `/health` after deployment. Use only the synthetic accounts documented in the README; never load real student records into a public demo database.

The application writes uploaded files under `UPLOAD_DIR` when configured. Use persistent storage for that path if uploads must survive restarts, and configure database backups with the database host.
