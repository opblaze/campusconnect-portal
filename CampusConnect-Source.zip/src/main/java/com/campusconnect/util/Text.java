package com.campusconnect.util;

import java.util.Locale;

/** Small text helpers shared by the services. */
public final class Text {
    private Text() { }

    /** "Demo Student One" -> "RJ". */
    public static String initials(String name) {
        if (name == null || name.isBlank()) {
            return "?";
        }
        String[] parts = name.trim().split("\\s+");
        String first = parts[0].substring(0, 1);
        String last = parts.length > 1 ? parts[parts.length - 1].substring(0, 1) : "";
        return (first + last).toUpperCase(Locale.ROOT);
    }

    /** "Demo Student One" -> "Demo". */
    public static String firstName(String name) {
        return name == null || name.isBlank() ? "" : name.trim().split("\\s+")[0];
    }

    /** Formats a percentage with one decimal, e.g. 41.3. */
    public static String pct1(double v) {
        return String.format(Locale.ROOT, "%.1f", v);
    }

    /** Formats a percentage without decimals, e.g. 88. */
    public static String pct0(double v) {
        return String.format(Locale.ROOT, "%.0f", v);
    }
}
