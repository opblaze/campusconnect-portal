package com.campusconnect.util;

import java.util.regex.Pattern;

/** Server-side form validation helpers (client-side checks can always be bypassed). */
public final class Validator {

    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9.-]{1,190}\\.[A-Za-z]{2,}$");
    private static final Pattern ENROLLMENT = Pattern.compile("^[A-Za-z0-9-]{6,20}$");

    private Validator() { }

    public static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    /** A login id is either an institutional e-mail or an enrollment number. */
    public static boolean isValidLoginId(String s) {
        return !isBlank(s) && (EMAIL.matcher(s.trim()).matches() || ENROLLMENT.matcher(s.trim()).matches());
    }

    /** Strict e-mail validation for account creation. */
    public static boolean isEmail(String s) {
        return !isBlank(s) && EMAIL.matcher(s.trim()).matches();
    }

    public static boolean isValidPassword(String s) {
        return s != null && s.length() >= 6 && s.length() <= 100;
    }

    /** Password strength check (at least 8 chars including at least one digit). */
    public static boolean isStrongPassword(String s) {
        return s != null && s.length() >= 8 && s.length() <= 100 && s.chars().anyMatch(Character::isDigit);
    }

    /** Escapes text for HTML so user input can never inject markup (XSS protection). */
    public static String escapeHtml(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }
}
