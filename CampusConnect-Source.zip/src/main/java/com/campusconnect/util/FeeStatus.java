package com.campusconnect.util;

import com.campusconnect.model.FeeRecord;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * One place that decides the status label of a fee, so the Fees page, dashboard, search, notifications and the
 * chatbot always agree.
 *
 *   PAID     the fee is settled
 *   OVERDUE  not paid and the due date has passed
 *   DUE      not paid and due within the next {@value #DUE_WINDOW_DAYS} days (pay soon)
 *   PENDING  not paid, but the due date is still further away (upcoming)
 */
public final class FeeStatus {

    public static final int DUE_WINDOW_DAYS = 15;

    private FeeStatus() { }

    public static String of(FeeRecord f, LocalDate today) {
        if (f.isPaid()) {
            return "PAID";
        }
        long days = ChronoUnit.DAYS.between(today, f.getDueDate());
        if (days < 0) {
            return "OVERDUE";
        }
        return days <= DUE_WINDOW_DAYS ? "DUE" : "PENDING";
    }

    /** Human readable category name. */
    public static String categoryLabel(String category) {
        if (category == null) {
            return "Fee";
        }
        switch (category) {
            case "HOSTEL": return "Hostel Fees";
            case "EXAM": return "Exam Fees";
            case "PRC": return "PRC (Professional Regularity Charges)";
            case "TUITION": return "Tuition Fees";
            default: return category;
        }
    }
}
