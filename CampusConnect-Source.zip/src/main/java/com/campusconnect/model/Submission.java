package com.campusconnect.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Student's submission for an assignment.
 * Table: submissions
 * Mapped with JPA annotations so Hibernate ORM can run all CRUD operations on it.
 */
@Entity
@Table(name = "submissions", uniqueConstraints = {@UniqueConstraint(columnNames = {"assignment_id", "student_id"})})
public class Submission {

    /** Surrogate primary key (AUTO_INCREMENT in MySQL). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Assignment */
    @ManyToOne(optional = false)
    @JoinColumn(name = "assignment_id", nullable = false)
    private Assignment assignment;

    /** Student */
    @ManyToOne(optional = false)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    /** Submission time */
    @Column(name = "submitted_at", nullable = false)
    private LocalDateTime submittedAt;

    /** ON_TIME / LATE / GRADED */
    @Column(name = "status", nullable = false, length = 20)
    private String status;

    /** Marks given by faculty */
    @Column(name = "marks_awarded", precision = 5, scale = 2)
    private BigDecimal marksAwarded;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Assignment getAssignment() { return assignment; }
    public void setAssignment(Assignment assignment) { this.assignment = assignment; }
    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }
    public LocalDateTime getSubmittedAt() { return submittedAt; }
    public void setSubmittedAt(LocalDateTime submittedAt) { this.submittedAt = submittedAt; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public BigDecimal getMarksAwarded() { return marksAwarded; }
    public void setMarksAwarded(BigDecimal marksAwarded) { this.marksAwarded = marksAwarded; }
}
