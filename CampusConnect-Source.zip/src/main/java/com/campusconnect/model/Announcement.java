package com.campusconnect.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Campus-wide or subject notice.
 * Table: announcements
 * Mapped with JPA annotations so Hibernate ORM can run all CRUD operations on it.
 */
@Entity
@Table(name = "announcements")
public class Announcement {

    /** Surrogate primary key (AUTO_INCREMENT in MySQL). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Headline */
    @Column(name = "title", nullable = false, length = 200)
    private String title;

    /** Text */
    @Column(name = "body", nullable = false, length = 1000)
    private String body;

    /** true = show in the top banner */
    @Column(name = "important", nullable = false)
    private boolean important;

    /** Related subject, if any */
    @ManyToOne(optional = true)
    @JoinColumn(name = "subject_id", nullable = true)
    private Subject subject;

    /** Author, if posted by faculty */
    @ManyToOne(optional = true)
    @JoinColumn(name = "posted_by", nullable = true)
    private Faculty postedBy;

    /** Posted at */
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    /** Hide after this time */
    @Column(name = "expires_at")
    private LocalDateTime expiresAt;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getBody() { return body; }
    public void setBody(String body) { this.body = body; }
    public boolean isImportant() { return important; }
    public void setImportant(boolean important) { this.important = important; }
    public Subject getSubject() { return subject; }
    public void setSubject(Subject subject) { this.subject = subject; }
    public Faculty getPostedBy() { return postedBy; }
    public void setPostedBy(Faculty postedBy) { this.postedBy = postedBy; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getExpiresAt() { return expiresAt; }
    public void setExpiresAt(LocalDateTime expiresAt) { this.expiresAt = expiresAt; }
}
