package com.campusconnect.model;

import com.campusconnect.model.enums.Role;
import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Login account shared by students and faculty.
 * Table: users
 * Mapped with JPA annotations so Hibernate ORM can run all CRUD operations on it.
 */
@Entity
@Table(name = "users")
public class User {

    /** Surrogate primary key (AUTO_INCREMENT in MySQL). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Institutional e-mail, used as login id */
    @Column(name = "email", nullable = false, unique = true, length = 150)
    private String email;

    /** PBKDF2 hash - the plain password is never stored */
    @Column(name = "password_hash", nullable = false, length = 255)
    private String passwordHash;

    /** STUDENT or FACULTY */
    @Enumerated(EnumType.STRING)
    @Column(name = "role", nullable = false)
    private Role role;

    /** Display name */
    @Column(name = "full_name", nullable = false, length = 120)
    private String fullName;

    /** false = account disabled */
    @Column(name = "active", nullable = false)
    private boolean active;

    /** Account creation time */
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    /** Time of last successful login */
    @Column(name = "last_login_at")
    private LocalDateTime lastLoginAt;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getLastLoginAt() { return lastLoginAt; }
    public void setLastLoginAt(LocalDateTime lastLoginAt) { this.lastLoginAt = lastLoginAt; }
}
