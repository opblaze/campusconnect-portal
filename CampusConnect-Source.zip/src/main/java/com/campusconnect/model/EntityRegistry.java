package com.campusconnect.model;

/** List of every mapped entity - Hibernate is told about them in HibernateConfig. */
public final class EntityRegistry {
    private EntityRegistry() { }

    public static final Class<?>[] ALL = {
            User.class,
            Student.class,
            Faculty.class,
            Subject.class,
            Enrollment.class,
            AttendanceRecord.class,
            Mark.class,
            Assignment.class,
            Submission.class,
            StudyMaterial.class,
            TimetableSlot.class,
            ExamSchedule.class,
            FeeRecord.class,
            StudentNote.class,
            Announcement.class,
            Notification.class,
            ChatMessage.class,
            Feedback.class
    };
}
