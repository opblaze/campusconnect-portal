package com.campusconnect.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

/**
 * A course offered in a semester.
 * Table: subjects
 * Mapped with JPA annotations so Hibernate ORM can run all CRUD operations on it.
 */
@Entity
@Table(name = "subjects")
public class Subject {

    /** Surrogate primary key (AUTO_INCREMENT in MySQL). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Course code, e.g. 01CE0308 */
    @Column(name = "code", nullable = false, unique = true, length = 20)
    private String code;

    /** Full course name */
    @Column(name = "name", nullable = false, length = 120)
    private String name;

    /** Abbreviation, e.g. AJT */
    @Column(name = "short_name", nullable = false, length = 20)
    private String shortName;

    /** Credit points */
    @Column(name = "credits", nullable = false)
    private int credits;

    /** CORE or LAB */
    @Column(name = "category", nullable = false, length = 20)
    private String category;

    /** Semester in which it is taught */
    @Column(name = "semester", nullable = false)
    private int semester;

    /** Teaching faculty */
    @ManyToOne(optional = false)
    @JoinColumn(name = "faculty_id", nullable = false)
    private Faculty faculty;

    /** Percent of syllabus covered */
    @Column(name = "syllabus_completion", nullable = false, precision = 5, scale = 2)
    private BigDecimal syllabusCompletion;

    /** Weekly days, e.g. MO,TH,FR */
    @Column(name = "meeting_days", nullable = false, length = 40)
    private String meetingDays;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getShortName() { return shortName; }
    public void setShortName(String shortName) { this.shortName = shortName; }
    public int getCredits() { return credits; }
    public void setCredits(int credits) { this.credits = credits; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public int getSemester() { return semester; }
    public void setSemester(int semester) { this.semester = semester; }
    public Faculty getFaculty() { return faculty; }
    public void setFaculty(Faculty faculty) { this.faculty = faculty; }
    public BigDecimal getSyllabusCompletion() { return syllabusCompletion; }
    public void setSyllabusCompletion(BigDecimal syllabusCompletion) { this.syllabusCompletion = syllabusCompletion; }
    public String getMeetingDays() { return meetingDays; }
    public void setMeetingDays(String meetingDays) { this.meetingDays = meetingDays; }
}
