package com.campusconnect.model;

import com.campusconnect.model.enums.FeedbackStatus;
import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Student feedback processed by AI and mailed to faculty.
 * Table: feedback
 * Mapped with JPA annotations so Hibernate ORM can run all CRUD operations on it.
 */
@Entity
@Table(name = "feedback")
public class Feedback {

    /** Surrogate primary key (AUTO_INCREMENT in MySQL). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Author */
    @ManyToOne(optional = false)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    /** Subject concerned */
    @ManyToOne(optional = true)
    @JoinColumn(name = "subject_id", nullable = true)
    private Subject subject;

    /** Faculty who receives the mail */
    @ManyToOne(optional = true)
    @JoinColumn(name = "faculty_id", nullable = true)
    private Faculty faculty;

    /** What the student typed */
    @Column(name = "raw_text", nullable = false, length = 2000)
    private String rawText;

    /** Cleaned / summarised text sent to faculty */
    @Column(name = "processed_text", length = 2000)
    private String processedText;

    /** TEACHING, CONTENT, LAB, OTHER ... */
    @Column(name = "category", length = 40)
    private String category;

    /** NEW / SENT / REJECTED */
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private FeedbackStatus status;

    /** Created at */
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    /** When the mail left the server */
    @Column(name = "emailed_at")
    private LocalDateTime emailedAt;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }
    public Subject getSubject() { return subject; }
    public void setSubject(Subject subject) { this.subject = subject; }
    public Faculty getFaculty() { return faculty; }
    public void setFaculty(Faculty faculty) { this.faculty = faculty; }
    public String getRawText() { return rawText; }
    public void setRawText(String rawText) { this.rawText = rawText; }
    public String getProcessedText() { return processedText; }
    public void setProcessedText(String processedText) { this.processedText = processedText; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public FeedbackStatus getStatus() { return status; }
    public void setStatus(FeedbackStatus status) { this.status = status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getEmailedAt() { return emailedAt; }
    public void setEmailedAt(LocalDateTime emailedAt) { this.emailedAt = emailedAt; }
}
