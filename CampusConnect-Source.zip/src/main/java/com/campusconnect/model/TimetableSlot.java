package com.campusconnect.model;

import jakarta.persistence.*;
import java.time.LocalTime;

/**
 * Weekly recurring lecture slot.
 * Table: timetable
 * Mapped with JPA annotations so Hibernate ORM can run all CRUD operations on it.
 */
@Entity
@Table(name = "timetable")
public class TimetableSlot {

    /** Surrogate primary key (AUTO_INCREMENT in MySQL). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Subject */
    @ManyToOne(optional = false)
    @JoinColumn(name = "subject_id", nullable = false)
    private Subject subject;

    /** 1 = Monday ... 7 = Sunday */
    @Column(name = "day_of_week", nullable = false)
    private int dayOfWeek;

    /** Start */
    @Column(name = "start_time", nullable = false)
    private LocalTime startTime;

    /** End */
    @Column(name = "end_time", nullable = false)
    private LocalTime endTime;

    /** Room / lab */
    @Column(name = "room", nullable = false, length = 40)
    private String room;

    /** Building block */
    @Column(name = "block", length = 40)
    private String block;

    /** Current topic being taught */
    @Column(name = "topic", length = 120)
    private String topic;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Subject getSubject() { return subject; }
    public void setSubject(Subject subject) { this.subject = subject; }
    public int getDayOfWeek() { return dayOfWeek; }
    public void setDayOfWeek(int dayOfWeek) { this.dayOfWeek = dayOfWeek; }
    public LocalTime getStartTime() { return startTime; }
    public void setStartTime(LocalTime startTime) { this.startTime = startTime; }
    public LocalTime getEndTime() { return endTime; }
    public void setEndTime(LocalTime endTime) { this.endTime = endTime; }
    public String getRoom() { return room; }
    public void setRoom(String room) { this.room = room; }
    public String getBlock() { return block; }
    public void setBlock(String block) { this.block = block; }
    public String getTopic() { return topic; }
    public void setTopic(String topic) { this.topic = topic; }
}
