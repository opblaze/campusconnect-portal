package com.campusconnect.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Examination date sheet entry.
 * Table: exam_schedule
 * Mapped with JPA annotations so Hibernate ORM can run all CRUD operations on it.
 */
@Entity
@Table(name = "exam_schedule")
public class ExamSchedule {

    /** Surrogate primary key (AUTO_INCREMENT in MySQL). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Subject */
    @ManyToOne(optional = false)
    @JoinColumn(name = "subject_id", nullable = false)
    private Subject subject;

    /** e.g. Mid-Semester Exam II */
    @Column(name = "exam_name", nullable = false, length = 60)
    private String examName;

    /** Date */
    @Column(name = "exam_date", nullable = false)
    private LocalDate examDate;

    /** Start */
    @Column(name = "start_time", nullable = false)
    private LocalTime startTime;

    /** End */
    @Column(name = "end_time", nullable = false)
    private LocalTime endTime;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Subject getSubject() { return subject; }
    public void setSubject(Subject subject) { this.subject = subject; }
    public String getExamName() { return examName; }
    public void setExamName(String examName) { this.examName = examName; }
    public LocalDate getExamDate() { return examDate; }
    public void setExamDate(LocalDate examDate) { this.examDate = examDate; }
    public LocalTime getStartTime() { return startTime; }
    public void setStartTime(LocalTime startTime) { this.startTime = startTime; }
    public LocalTime getEndTime() { return endTime; }
    public void setEndTime(LocalTime endTime) { this.endTime = endTime; }
}
