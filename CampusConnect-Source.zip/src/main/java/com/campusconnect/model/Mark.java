package com.campusconnect.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Marks obtained in one evaluation component.
 * Table: marks
 * Mapped with JPA annotations so Hibernate ORM can run all CRUD operations on it.
 */
@Entity
@Table(name = "marks")
public class Mark {

    /** Surrogate primary key (AUTO_INCREMENT in MySQL). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Student */
    @ManyToOne(optional = false)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    /** Subject */
    @ManyToOne(optional = false)
    @JoinColumn(name = "subject_id", nullable = false)
    private Subject subject;

    /** CIE-I, CIE-II, MID ... */
    @Column(name = "exam_type", nullable = false, length = 30)
    private String examType;

    /** Marks obtained */
    @Column(name = "obtained", nullable = false, precision = 5, scale = 2)
    private BigDecimal obtained;

    /** Maximum marks */
    @Column(name = "maximum", nullable = false, precision = 5, scale = 2)
    private BigDecimal maximum;

    /** Result declaration date */
    @Column(name = "published_on", nullable = false)
    private LocalDate publishedOn;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }
    public Subject getSubject() { return subject; }
    public void setSubject(Subject subject) { this.subject = subject; }
    public String getExamType() { return examType; }
    public void setExamType(String examType) { this.examType = examType; }
    public BigDecimal getObtained() { return obtained; }
    public void setObtained(BigDecimal obtained) { this.obtained = obtained; }
    public BigDecimal getMaximum() { return maximum; }
    public void setMaximum(BigDecimal maximum) { this.maximum = maximum; }
    public LocalDate getPublishedOn() { return publishedOn; }
    public void setPublishedOn(LocalDate publishedOn) { this.publishedOn = publishedOn; }
}
