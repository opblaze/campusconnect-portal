package com.campusconnect.model;

import com.campusconnect.model.enums.NotificationColor;
import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Smart notification (BLUE / RED / ORANGE).
 * Table: notifications
 * Mapped with JPA annotations so Hibernate ORM can run all CRUD operations on it.
 */
@Entity
@Table(name = "notifications", uniqueConstraints = {@UniqueConstraint(columnNames = {"student_id", "dedupe_key"})})
public class Notification {

    /** Surrogate primary key (AUTO_INCREMENT in MySQL). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Recipient */
    @ManyToOne(optional = false)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    /** BLUE = general, RED = urgent, ORANGE = warning */
    @Enumerated(EnumType.STRING)
    @Column(name = "color", nullable = false)
    private NotificationColor color;

    /** ASSIGNMENT, ATTENDANCE, RESULT, MATERIAL ... */
    @Column(name = "category", nullable = false, length = 30)
    private String category;

    /** Headline */
    @Column(name = "title", nullable = false, length = 200)
    private String title;

    /** Body text */
    @Column(name = "message", nullable = false, length = 1000)
    private String message;

    /** Button text */
    @Column(name = "action_label", length = 40)
    private String actionLabel;

    /** Button target */
    @Column(name = "action_url", length = 200)
    private String actionUrl;

    /** Prevents the scheduler creating the same alert twice */
    @Column(name = "dedupe_key", length = 120)
    private String dedupeKey;

    /** Created at */
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    /** Read at (null = unread) */
    @Column(name = "read_at")
    private LocalDateTime readAt;

    /** true = pop-up already displayed */
    @Column(name = "popup_shown", nullable = false)
    private boolean popupShown;

    /** true = e-mail copy sent */
    @Column(name = "email_sent", nullable = false)
    private boolean emailSent;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }
    public NotificationColor getColor() { return color; }
    public void setColor(NotificationColor color) { this.color = color; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getActionLabel() { return actionLabel; }
    public void setActionLabel(String actionLabel) { this.actionLabel = actionLabel; }
    public String getActionUrl() { return actionUrl; }
    public void setActionUrl(String actionUrl) { this.actionUrl = actionUrl; }
    public String getDedupeKey() { return dedupeKey; }
    public void setDedupeKey(String dedupeKey) { this.dedupeKey = dedupeKey; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getReadAt() { return readAt; }
    public void setReadAt(LocalDateTime readAt) { this.readAt = readAt; }
    public boolean isPopupShown() { return popupShown; }
    public void setPopupShown(boolean popupShown) { this.popupShown = popupShown; }
    public boolean isEmailSent() { return emailSent; }
    public void setEmailSent(boolean emailSent) { this.emailSent = emailSent; }
}
