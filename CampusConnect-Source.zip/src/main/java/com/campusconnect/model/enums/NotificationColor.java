package com.campusconnect.model.enums;

/**
 * Smart-notification template colours:
 * BLUE   = general news (new material, results, day-off)
 * RED    = urgent (assignment due within 12 h, very low attendance)
 * ORANGE = warning (pending work, low attendance, poor scores)
 */
public enum NotificationColor { BLUE, RED, ORANGE }
