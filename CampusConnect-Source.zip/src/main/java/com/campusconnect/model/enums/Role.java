package com.campusconnect.model.enums;

/** Who is logged in. Decides which pages and actions are allowed. */
public enum Role { STUDENT, FACULTY, ADMIN }
