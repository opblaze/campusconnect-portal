package com.campusconnect.model.enums;

/** Author of a chatbot message. */
public enum ChatRole { USER, BOT }
