package com.campusconnect.model.enums;

/** Life-cycle of a student feedback item. */
public enum FeedbackStatus { NEW, SENT, REJECTED }
