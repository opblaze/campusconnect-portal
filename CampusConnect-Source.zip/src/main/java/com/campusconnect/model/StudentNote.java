package com.campusconnect.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Private study note uploaded by a student (visible only to the owner).
 * Table: student_notes
 * Mapped with JPA annotations so Hibernate ORM can run all CRUD operations on it.
 */
@Entity
@Table(name = "student_notes")
public class StudentNote {

    /** Surrogate primary key (AUTO_INCREMENT in MySQL). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Owner */
    @ManyToOne(optional = false)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    /** Related subject, if any */
    @ManyToOne(optional = true)
    @JoinColumn(name = "subject_id", nullable = true)
    private Subject subject;

    /** Title shown in the list */
    @Column(name = "title", nullable = false, length = 200)
    private String title;

    /** Original file name */
    @Column(name = "file_name", nullable = false, length = 200)
    private String fileName;

    /** Name of the file on the server disk */
    @Column(name = "stored_name", nullable = false, length = 255)
    private String storedName;

    /** File size in KB */
    @Column(name = "size_kb", nullable = false)
    private int sizeKb;

    /** Upload time */
    @Column(name = "uploaded_at", nullable = false)
    private LocalDateTime uploadedAt;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }
    public Subject getSubject() { return subject; }
    public void setSubject(Subject subject) { this.subject = subject; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
    public String getStoredName() { return storedName; }
    public void setStoredName(String storedName) { this.storedName = storedName; }
    public int getSizeKb() { return sizeKb; }
    public void setSizeKb(int sizeKb) { this.sizeKb = sizeKb; }
    public LocalDateTime getUploadedAt() { return uploadedAt; }
    public void setUploadedAt(LocalDateTime uploadedAt) { this.uploadedAt = uploadedAt; }
}
