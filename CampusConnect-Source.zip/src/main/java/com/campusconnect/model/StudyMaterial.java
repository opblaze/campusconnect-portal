package com.campusconnect.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * E-content uploaded by faculty.
 * Table: materials
 * Mapped with JPA annotations so Hibernate ORM can run all CRUD operations on it.
 */
@Entity
@Table(name = "materials")
public class StudyMaterial {

    /** Surrogate primary key (AUTO_INCREMENT in MySQL). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Subject */
    @ManyToOne(optional = false)
    @JoinColumn(name = "subject_id", nullable = false)
    private Subject subject;

    /** Title */
    @Column(name = "title", nullable = false, length = 200)
    private String title;

    /** PDF / SLIDES / CODE / ZIP */
    @Column(name = "file_type", nullable = false, length = 20)
    private String fileType;

    /** File size in MB */
    @Column(name = "size_mb", nullable = false, precision = 6, scale = 2)
    private BigDecimal sizeMb;

    /** Uploading faculty */
    @ManyToOne(optional = false)
    @JoinColumn(name = "uploaded_by", nullable = false)
    private Faculty uploadedBy;

    /** Upload time */
    @Column(name = "uploaded_at", nullable = false)
    private LocalDateTime uploadedAt;

    /** Relative path / URL of the file */
    @Column(name = "file_path", nullable = false, length = 255)
    private String filePath;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Subject getSubject() { return subject; }
    public void setSubject(Subject subject) { this.subject = subject; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getFileType() { return fileType; }
    public void setFileType(String fileType) { this.fileType = fileType; }
    public BigDecimal getSizeMb() { return sizeMb; }
    public void setSizeMb(BigDecimal sizeMb) { this.sizeMb = sizeMb; }
    public Faculty getUploadedBy() { return uploadedBy; }
    public void setUploadedBy(Faculty uploadedBy) { this.uploadedBy = uploadedBy; }
    public LocalDateTime getUploadedAt() { return uploadedAt; }
    public void setUploadedAt(LocalDateTime uploadedAt) { this.uploadedAt = uploadedAt; }
    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }
}
