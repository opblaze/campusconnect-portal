package com.campusconnect.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Academic profile of a student (1:1 with User).
 * Table: students
 * Mapped with JPA annotations so Hibernate ORM can run all CRUD operations on it.
 */
@Entity
@Table(name = "students")
public class Student {

    /** Surrogate primary key (AUTO_INCREMENT in MySQL). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Owning login account */
    @OneToOne(optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    /** University enrollment number (login id) */
    @Column(name = "enrollment_no", nullable = false, unique = true, length = 20)
    private String enrollmentNo;

    /** Degree programme */
    @Column(name = "program", nullable = false, length = 120)
    private String program;

    /** Short branch label, e.g. CSE-CS */
    @Column(name = "branch_code", nullable = false, length = 20)
    private String branchCode;

    /** Current semester number */
    @Column(name = "semester", nullable = false)
    private int semester;

    /** e.g. 2026-27 */
    @Column(name = "academic_year", nullable = false, length = 20)
    private String academicYear;

    /** Cumulative GPA */
    @Column(name = "cgpa", nullable = false, precision = 4, scale = 2)
    private BigDecimal cgpa;

    /** SGPA of the previous semester */
    @Column(name = "previous_sgpa", nullable = false, precision = 4, scale = 2)
    private BigDecimal previousSgpa;

    /** Credits earned last semester */
    @Column(name = "earned_credits", nullable = false)
    private int earnedCredits;

    /** Number of active backlogs */
    @Column(name = "backlogs", nullable = false)
    private int backlogs;

    /** Short text, e.g. Top 5% in CSE cohort */
    @Column(name = "cohort_standing", length = 80)
    private String cohortStanding;

    /** Contact number */
    @Column(name = "phone", length = 20)
    private String phone;

    /** Personal Gmail address */
    @Column(name = "gmail", length = 150)
    private String gmail;

    /** true = lives in a college hostel */
    @Column(name = "hosteler", nullable = false)
    private boolean hosteler;

    /** Hostel name (only when hosteler) */
    @Column(name = "hostel_name", length = 80)
    private String hostelName;

    /** First day of the running semester */
    @Column(name = "semester_start", nullable = false)
    private LocalDate semesterStart;

    /** Length of the semester in weeks */
    @Column(name = "semester_weeks", nullable = false)
    private int semesterWeeks;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    public String getEnrollmentNo() { return enrollmentNo; }
    public void setEnrollmentNo(String enrollmentNo) { this.enrollmentNo = enrollmentNo; }
    public String getProgram() { return program; }
    public void setProgram(String program) { this.program = program; }
    public String getBranchCode() { return branchCode; }
    public void setBranchCode(String branchCode) { this.branchCode = branchCode; }
    public int getSemester() { return semester; }
    public void setSemester(int semester) { this.semester = semester; }
    public String getAcademicYear() { return academicYear; }
    public void setAcademicYear(String academicYear) { this.academicYear = academicYear; }
    public BigDecimal getCgpa() { return cgpa; }
    public void setCgpa(BigDecimal cgpa) { this.cgpa = cgpa; }
    public BigDecimal getPreviousSgpa() { return previousSgpa; }
    public void setPreviousSgpa(BigDecimal previousSgpa) { this.previousSgpa = previousSgpa; }
    public int getEarnedCredits() { return earnedCredits; }
    public void setEarnedCredits(int earnedCredits) { this.earnedCredits = earnedCredits; }
    public int getBacklogs() { return backlogs; }
    public void setBacklogs(int backlogs) { this.backlogs = backlogs; }
    public String getCohortStanding() { return cohortStanding; }
    public void setCohortStanding(String cohortStanding) { this.cohortStanding = cohortStanding; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getGmail() { return gmail; }
    public void setGmail(String gmail) { this.gmail = gmail; }
    public boolean isHosteler() { return hosteler; }
    public void setHosteler(boolean hosteler) { this.hosteler = hosteler; }
    public String getHostelName() { return hostelName; }
    public void setHostelName(String hostelName) { this.hostelName = hostelName; }
    public LocalDate getSemesterStart() { return semesterStart; }
    public void setSemesterStart(LocalDate semesterStart) { this.semesterStart = semesterStart; }
    public int getSemesterWeeks() { return semesterWeeks; }
    public void setSemesterWeeks(int semesterWeeks) { this.semesterWeeks = semesterWeeks; }
}
