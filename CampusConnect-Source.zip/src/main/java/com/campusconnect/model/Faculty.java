package com.campusconnect.model;

import jakarta.persistence.*;

/**
 * Teaching staff profile (1:1 with User).
 * Table: faculty
 * Mapped with JPA annotations so Hibernate ORM can run all CRUD operations on it.
 */
@Entity
@Table(name = "faculty")
public class Faculty {

    /** Surrogate primary key (AUTO_INCREMENT in MySQL). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Owning login account */
    @OneToOne(optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    /** Employee code */
    @Column(name = "employee_code", nullable = false, unique = true, length = 20)
    private String employeeCode;

    /** Prof. / Dr. */
    @Column(name = "title", nullable = false, length = 10)
    private String title;

    /** Designation */
    @Column(name = "designation", nullable = false, length = 60)
    private String designation;

    /** Department */
    @Column(name = "department", nullable = false, length = 80)
    private String department;

    /** Cabin / room */
    @Column(name = "cabin", length = 40)
    private String cabin;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    public String getEmployeeCode() { return employeeCode; }
    public void setEmployeeCode(String employeeCode) { this.employeeCode = employeeCode; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public String getCabin() { return cabin; }
    public void setCabin(String cabin) { this.cabin = cabin; }
}
