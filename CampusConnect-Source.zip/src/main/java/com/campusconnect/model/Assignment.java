package com.campusconnect.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Assignment / lab manual set by faculty.
 * Table: assignments
 * Mapped with JPA annotations so Hibernate ORM can run all CRUD operations on it.
 */
@Entity
@Table(name = "assignments")
public class Assignment {

    /** Surrogate primary key (AUTO_INCREMENT in MySQL). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Subject */
    @ManyToOne(optional = false)
    @JoinColumn(name = "subject_id", nullable = false)
    private Subject subject;

    /** Title */
    @Column(name = "title", nullable = false, length = 200)
    private String title;

    /** Instructions */
    @Column(name = "description", length = 1000)
    private String description;

    /** Deadline */
    @Column(name = "due_at", nullable = false)
    private LocalDateTime dueAt;

    /** Maximum marks */
    @Column(name = "max_marks", nullable = false)
    private int maxMarks;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Subject getSubject() { return subject; }
    public void setSubject(Subject subject) { this.subject = subject; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public LocalDateTime getDueAt() { return dueAt; }
    public void setDueAt(LocalDateTime dueAt) { this.dueAt = dueAt; }
    public int getMaxMarks() { return maxMarks; }
    public void setMaxMarks(int maxMarks) { this.maxMarks = maxMarks; }
}
