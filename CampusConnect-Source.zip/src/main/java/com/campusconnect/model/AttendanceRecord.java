package com.campusconnect.model;

import jakarta.persistence.*;
import java.time.LocalDate;

/**
 * One lecture, present or absent.
 * Table: attendance
 * Mapped with JPA annotations so Hibernate ORM can run all CRUD operations on it.
 */
@Entity
@Table(name = "attendance", uniqueConstraints = {@UniqueConstraint(columnNames = {"student_id", "subject_id", "lecture_date"})})
public class AttendanceRecord {

    /** Surrogate primary key (AUTO_INCREMENT in MySQL). */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Student */
    @ManyToOne(optional = false)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    /** Subject */
    @ManyToOne(optional = false)
    @JoinColumn(name = "subject_id", nullable = false)
    private Subject subject;

    /** Date of the lecture */
    @Column(name = "lecture_date", nullable = false)
    private LocalDate lectureDate;

    /** true = attended */
    @Column(name = "present", nullable = false)
    private boolean present;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }
    public Subject getSubject() { return subject; }
    public void setSubject(Subject subject) { this.subject = subject; }
    public LocalDate getLectureDate() { return lectureDate; }
    public void setLectureDate(LocalDate lectureDate) { this.lectureDate = lectureDate; }
    public boolean isPresent() { return present; }
    public void setPresent(boolean present) { this.present = present; }
}
