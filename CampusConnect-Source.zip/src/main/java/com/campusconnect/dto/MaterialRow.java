package com.campusconnect.dto;

/** Plain data holder (generated). Getters follow JavaBean naming so JSP EL can read them. */
public class MaterialRow {

    private Long id;
    private String title;
    private String subjectName;
    private String sizeLabel;
    private String icon;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getSubjectName() { return subjectName; }
    public void setSubjectName(String subjectName) { this.subjectName = subjectName; }
    public String getSizeLabel() { return sizeLabel; }
    public void setSizeLabel(String sizeLabel) { this.sizeLabel = sizeLabel; }
    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }
}
