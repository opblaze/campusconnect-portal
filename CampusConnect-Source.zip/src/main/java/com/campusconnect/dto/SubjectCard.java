package com.campusconnect.dto;

/** Plain data holder (generated). Getters follow JavaBean naming so JSP EL can read them. */
public class SubjectCard {

    private Long id;
    private String code;
    private String name;
    private String shortName;
    private int credits;
    private String meetingDays;
    private String syllabusPct;
    private String attendancePct;
    private String status;
    private String statusLabel;
    private String barClass;
    private String chipClass;
    private String nextSession;
    private String nextRoom;
    private String facultyName;
    private String facultyInitials;
    private String category;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getShortName() { return shortName; }
    public void setShortName(String shortName) { this.shortName = shortName; }
    public int getCredits() { return credits; }
    public void setCredits(int credits) { this.credits = credits; }
    public String getMeetingDays() { return meetingDays; }
    public void setMeetingDays(String meetingDays) { this.meetingDays = meetingDays; }
    public String getSyllabusPct() { return syllabusPct; }
    public void setSyllabusPct(String syllabusPct) { this.syllabusPct = syllabusPct; }
    public String getAttendancePct() { return attendancePct; }
    public void setAttendancePct(String attendancePct) { this.attendancePct = attendancePct; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getStatusLabel() { return statusLabel; }
    public void setStatusLabel(String statusLabel) { this.statusLabel = statusLabel; }
    public String getBarClass() { return barClass; }
    public void setBarClass(String barClass) { this.barClass = barClass; }
    public String getChipClass() { return chipClass; }
    public void setChipClass(String chipClass) { this.chipClass = chipClass; }
    public String getNextSession() { return nextSession; }
    public void setNextSession(String nextSession) { this.nextSession = nextSession; }
    public String getNextRoom() { return nextRoom; }
    public void setNextRoom(String nextRoom) { this.nextRoom = nextRoom; }
    public String getFacultyName() { return facultyName; }
    public void setFacultyName(String facultyName) { this.facultyName = facultyName; }
    public String getFacultyInitials() { return facultyInitials; }
    public void setFacultyInitials(String facultyInitials) { this.facultyInitials = facultyInitials; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
}
