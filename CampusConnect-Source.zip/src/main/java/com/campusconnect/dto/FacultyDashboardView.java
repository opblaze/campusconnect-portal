package com.campusconnect.dto;

import java.util.List;

/** Everything rendered on the faculty home dashboard. JavaBean getters allow JSP EL binding. */
public class FacultyDashboardView {

    private String fullName;
    private String firstName;
    private String title;
    private String designation;
    private String department;
    private String employeeCode;
    private String cabin;
    private String email;
    private String todayLabel;

    private int subjectCount;
    private int coreCount;
    private int labCount;
    private int totalStudents;
    private int totalAssignments;
    private int pendingSubmissions;
    private int totalMaterials;
    private long feedbackCount;
    private int todayClassCount;
    private int avgSyllabusPct;

    private List<SubjectRow> subjects;
    private List<ScheduleRow> todaySchedule;
    private List<ExamRow> upcomingExams;
    private List<MaterialRow> recentMaterials;
    private List<FeedbackRow> recentFeedback;
    private List<NoticeRow> notices;

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public String getEmployeeCode() { return employeeCode; }
    public void setEmployeeCode(String employeeCode) { this.employeeCode = employeeCode; }
    public String getCabin() { return cabin; }
    public void setCabin(String cabin) { this.cabin = cabin; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getTodayLabel() { return todayLabel; }
    public void setTodayLabel(String todayLabel) { this.todayLabel = todayLabel; }

    public int getSubjectCount() { return subjectCount; }
    public void setSubjectCount(int subjectCount) { this.subjectCount = subjectCount; }
    public int getCoreCount() { return coreCount; }
    public void setCoreCount(int coreCount) { this.coreCount = coreCount; }
    public int getLabCount() { return labCount; }
    public void setLabCount(int labCount) { this.labCount = labCount; }
    public int getTotalStudents() { return totalStudents; }
    public void setTotalStudents(int totalStudents) { this.totalStudents = totalStudents; }
    public int getTotalAssignments() { return totalAssignments; }
    public void setTotalAssignments(int totalAssignments) { this.totalAssignments = totalAssignments; }
    public int getPendingSubmissions() { return pendingSubmissions; }
    public void setPendingSubmissions(int pendingSubmissions) { this.pendingSubmissions = pendingSubmissions; }
    public int getTotalMaterials() { return totalMaterials; }
    public void setTotalMaterials(int totalMaterials) { this.totalMaterials = totalMaterials; }
    public long getFeedbackCount() { return feedbackCount; }
    public void setFeedbackCount(long feedbackCount) { this.feedbackCount = feedbackCount; }
    public int getTodayClassCount() { return todayClassCount; }
    public void setTodayClassCount(int todayClassCount) { this.todayClassCount = todayClassCount; }
    public int getAvgSyllabusPct() { return avgSyllabusPct; }
    public void setAvgSyllabusPct(int avgSyllabusPct) { this.avgSyllabusPct = avgSyllabusPct; }

    public List<SubjectRow> getSubjects() { return subjects; }
    public void setSubjects(List<SubjectRow> subjects) { this.subjects = subjects; }
    public List<ScheduleRow> getTodaySchedule() { return todaySchedule; }
    public void setTodaySchedule(List<ScheduleRow> todaySchedule) { this.todaySchedule = todaySchedule; }
    public List<ExamRow> getUpcomingExams() { return upcomingExams; }
    public void setUpcomingExams(List<ExamRow> upcomingExams) { this.upcomingExams = upcomingExams; }
    public List<MaterialRow> getRecentMaterials() { return recentMaterials; }
    public void setRecentMaterials(List<MaterialRow> recentMaterials) { this.recentMaterials = recentMaterials; }
    public List<FeedbackRow> getRecentFeedback() { return recentFeedback; }
    public void setRecentFeedback(List<FeedbackRow> recentFeedback) { this.recentFeedback = recentFeedback; }
    public List<NoticeRow> getNotices() { return notices; }
    public void setNotices(List<NoticeRow> notices) { this.notices = notices; }

    public static class SubjectRow {
        private Long id;
        private String code;
        private String name;
        private String shortName;
        private int credits;
        private String category;
        private int semester;
        private long enrolledCount;
        private int syllabusPct;
        private String meetingDays;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getCode() { return code; }
        public void setCode(String code) { this.code = code; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getShortName() { return shortName; }
        public void setShortName(String shortName) { this.shortName = shortName; }
        public int getCredits() { return credits; }
        public void setCredits(int credits) { this.credits = credits; }
        public String getCategory() { return category; }
        public void setCategory(String category) { this.category = category; }
        public int getSemester() { return semester; }
        public void setSemester(int semester) { this.semester = semester; }
        public long getEnrolledCount() { return enrolledCount; }
        public void setEnrolledCount(long enrolledCount) { this.enrolledCount = enrolledCount; }
        public int getSyllabusPct() { return syllabusPct; }
        public void setSyllabusPct(int syllabusPct) { this.syllabusPct = syllabusPct; }
        public String getMeetingDays() { return meetingDays; }
        public void setMeetingDays(String meetingDays) { this.meetingDays = meetingDays; }
    }

    public static class ScheduleRow {
        private String subjectCode;
        private String subjectName;
        private String timeRange;
        private String room;
        private String block;
        private String topic;
        private String dayLabel;

        public String getSubjectCode() { return subjectCode; }
        public void setSubjectCode(String subjectCode) { this.subjectCode = subjectCode; }
        public String getSubjectName() { return subjectName; }
        public void setSubjectName(String subjectName) { this.subjectName = subjectName; }
        public String getTimeRange() { return timeRange; }
        public void setTimeRange(String timeRange) { this.timeRange = timeRange; }
        public String getRoom() { return room; }
        public void setRoom(String room) { this.room = room; }
        public String getBlock() { return block; }
        public void setBlock(String block) { this.block = block; }
        public String getTopic() { return topic; }
        public void setTopic(String topic) { this.topic = topic; }
        public String getDayLabel() { return dayLabel; }
        public void setDayLabel(String dayLabel) { this.dayLabel = dayLabel; }
    }

    public static class FeedbackRow {
        private Long id;
        private String subjectCode;
        private String studentName;
        private String category;
        private String message;
        private String status;
        private String createdLabel;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getSubjectCode() { return subjectCode; }
        public void setSubjectCode(String subjectCode) { this.subjectCode = subjectCode; }
        public String getStudentName() { return studentName; }
        public void setStudentName(String studentName) { this.studentName = studentName; }
        public String getCategory() { return category; }
        public void setCategory(String category) { this.category = category; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getCreatedLabel() { return createdLabel; }
        public void setCreatedLabel(String createdLabel) { this.createdLabel = createdLabel; }
    }

    public static class NoticeRow {
        private Long id;
        private String title;
        private String body;
        private String subjectCode;
        private String authorName;
        private boolean important;
        private String createdLabel;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        public String getBody() { return body; }
        public void setBody(String body) { this.body = body; }
        public String getSubjectCode() { return subjectCode; }
        public void setSubjectCode(String subjectCode) { this.subjectCode = subjectCode; }
        public String getAuthorName() { return authorName; }
        public void setAuthorName(String authorName) { this.authorName = authorName; }
        public boolean isImportant() { return important; }
        public void setImportant(boolean important) { this.important = important; }
        public String getCreatedLabel() { return createdLabel; }
        public void setCreatedLabel(String createdLabel) { this.createdLabel = createdLabel; }
    }
}

