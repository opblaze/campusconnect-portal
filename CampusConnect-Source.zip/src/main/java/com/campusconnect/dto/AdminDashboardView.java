package com.campusconnect.dto;

import java.util.List;

/** Everything rendered on the administrator control panel dashboard. */
public class AdminDashboardView {

    private String fullName;
    private String firstName;
    private String email;
    private String todayLabel;

    private int totalStudents;
    private int hostelerCount;
    private int dayScholarCount;
    private int totalFaculty;
    private int departmentCount;
    private int totalSubjects;
    private int coreSubjects;
    private int labSubjects;

    private int totalUsers;
    private int activeUsers;
    private int inactiveUsers;
    private int studentUsers;
    private int facultyUsers;
    private int adminUsers;

    private long feeCollected;
    private long feePending;
    private long feeOverdue;
    private long totalFeeBilled;
    private int feeCollectionPct;
    private int unpaidFeeCount;
    private int overdueFeeCount;
    private String feeCollectedLabel;
    private String feePendingLabel;
    private String feeOverdueLabel;
    private String totalFeeBilledLabel;

    private int totalAssignments;
    private int totalSubmissions;
    private int pendingGradingCount;
    private int avgAttendancePct;
    private int atRiskStudents;
    private int feedbackCount;
    private int newFeedbackCount;
    private int announcementCount;

    private List<DepartmentRow> departmentStats;
    private List<SemesterRow> semesterStats;
    private List<UserRow> recentUsers;
    private List<FeedbackRow> recentFeedback;
    private List<NoticeRow> recentAnnouncements;

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getTodayLabel() { return todayLabel; }
    public void setTodayLabel(String todayLabel) { this.todayLabel = todayLabel; }

    public int getTotalStudents() { return totalStudents; }
    public void setTotalStudents(int totalStudents) { this.totalStudents = totalStudents; }
    public int getHostelerCount() { return hostelerCount; }
    public void setHostelerCount(int hostelerCount) { this.hostelerCount = hostelerCount; }
    public int getDayScholarCount() { return dayScholarCount; }
    public void setDayScholarCount(int dayScholarCount) { this.dayScholarCount = dayScholarCount; }
    public int getTotalFaculty() { return totalFaculty; }
    public void setTotalFaculty(int totalFaculty) { this.totalFaculty = totalFaculty; }
    public int getDepartmentCount() { return departmentCount; }
    public void setDepartmentCount(int departmentCount) { this.departmentCount = departmentCount; }
    public int getTotalSubjects() { return totalSubjects; }
    public void setTotalSubjects(int totalSubjects) { this.totalSubjects = totalSubjects; }
    public int getCoreSubjects() { return coreSubjects; }
    public void setCoreSubjects(int coreSubjects) { this.coreSubjects = coreSubjects; }
    public int getLabSubjects() { return labSubjects; }
    public void setLabSubjects(int labSubjects) { this.labSubjects = labSubjects; }

    public int getTotalUsers() { return totalUsers; }
    public void setTotalUsers(int totalUsers) { this.totalUsers = totalUsers; }
    public int getActiveUsers() { return activeUsers; }
    public void setActiveUsers(int activeUsers) { this.activeUsers = activeUsers; }
    public int getInactiveUsers() { return inactiveUsers; }
    public void setInactiveUsers(int inactiveUsers) { this.inactiveUsers = inactiveUsers; }
    public int getStudentUsers() { return studentUsers; }
    public void setStudentUsers(int studentUsers) { this.studentUsers = studentUsers; }
    public int getFacultyUsers() { return facultyUsers; }
    public void setFacultyUsers(int facultyUsers) { this.facultyUsers = facultyUsers; }
    public int getAdminUsers() { return adminUsers; }
    public void setAdminUsers(int adminUsers) { this.adminUsers = adminUsers; }

    public long getFeeCollected() { return feeCollected; }
    public void setFeeCollected(long feeCollected) { this.feeCollected = feeCollected; }
    public long getFeePending() { return feePending; }
    public void setFeePending(long feePending) { this.feePending = feePending; }
    public long getFeeOverdue() { return feeOverdue; }
    public void setFeeOverdue(long feeOverdue) { this.feeOverdue = feeOverdue; }
    public long getTotalFeeBilled() { return totalFeeBilled; }
    public void setTotalFeeBilled(long totalFeeBilled) { this.totalFeeBilled = totalFeeBilled; }
    public int getFeeCollectionPct() { return feeCollectionPct; }
    public void setFeeCollectionPct(int feeCollectionPct) { this.feeCollectionPct = feeCollectionPct; }
    public int getUnpaidFeeCount() { return unpaidFeeCount; }
    public void setUnpaidFeeCount(int unpaidFeeCount) { this.unpaidFeeCount = unpaidFeeCount; }
    public int getOverdueFeeCount() { return overdueFeeCount; }
    public void setOverdueFeeCount(int overdueFeeCount) { this.overdueFeeCount = overdueFeeCount; }
    public String getFeeCollectedLabel() { return feeCollectedLabel; }
    public void setFeeCollectedLabel(String feeCollectedLabel) { this.feeCollectedLabel = feeCollectedLabel; }
    public String getFeePendingLabel() { return feePendingLabel; }
    public void setFeePendingLabel(String feePendingLabel) { this.feePendingLabel = feePendingLabel; }
    public String getFeeOverdueLabel() { return feeOverdueLabel; }
    public void setFeeOverdueLabel(String feeOverdueLabel) { this.feeOverdueLabel = feeOverdueLabel; }
    public String getTotalFeeBilledLabel() { return totalFeeBilledLabel; }
    public void setTotalFeeBilledLabel(String totalFeeBilledLabel) { this.totalFeeBilledLabel = totalFeeBilledLabel; }

    public int getTotalAssignments() { return totalAssignments; }
    public void setTotalAssignments(int totalAssignments) { this.totalAssignments = totalAssignments; }
    public int getTotalSubmissions() { return totalSubmissions; }
    public void setTotalSubmissions(int totalSubmissions) { this.totalSubmissions = totalSubmissions; }
    public int getPendingGradingCount() { return pendingGradingCount; }
    public void setPendingGradingCount(int pendingGradingCount) { this.pendingGradingCount = pendingGradingCount; }
    public int getAvgAttendancePct() { return avgAttendancePct; }
    public void setAvgAttendancePct(int avgAttendancePct) { this.avgAttendancePct = avgAttendancePct; }
    public int getAtRiskStudents() { return atRiskStudents; }
    public void setAtRiskStudents(int atRiskStudents) { this.atRiskStudents = atRiskStudents; }
    public int getFeedbackCount() { return feedbackCount; }
    public void setFeedbackCount(int feedbackCount) { this.feedbackCount = feedbackCount; }
    public int getNewFeedbackCount() { return newFeedbackCount; }
    public void setNewFeedbackCount(int newFeedbackCount) { this.newFeedbackCount = newFeedbackCount; }
    public int getAnnouncementCount() { return announcementCount; }
    public void setAnnouncementCount(int announcementCount) { this.announcementCount = announcementCount; }

    public List<DepartmentRow> getDepartmentStats() { return departmentStats; }
    public void setDepartmentStats(List<DepartmentRow> departmentStats) { this.departmentStats = departmentStats; }
    public List<SemesterRow> getSemesterStats() { return semesterStats; }
    public void setSemesterStats(List<SemesterRow> semesterStats) { this.semesterStats = semesterStats; }
    public List<UserRow> getRecentUsers() { return recentUsers; }
    public void setRecentUsers(List<UserRow> recentUsers) { this.recentUsers = recentUsers; }
    public List<FeedbackRow> getRecentFeedback() { return recentFeedback; }
    public void setRecentFeedback(List<FeedbackRow> recentFeedback) { this.recentFeedback = recentFeedback; }
    public List<NoticeRow> getRecentAnnouncements() { return recentAnnouncements; }
    public void setRecentAnnouncements(List<NoticeRow> recentAnnouncements) { this.recentAnnouncements = recentAnnouncements; }

    public static class DepartmentRow {
        private String department;
        private int facultyCount;
        private int subjectCount;

        public String getDepartment() { return department; }
        public void setDepartment(String department) { this.department = department; }
        public int getFacultyCount() { return facultyCount; }
        public void setFacultyCount(int facultyCount) { this.facultyCount = facultyCount; }
        public int getSubjectCount() { return subjectCount; }
        public void setSubjectCount(int subjectCount) { this.subjectCount = subjectCount; }
    }

    public static class SemesterRow {
        private int semester;
        private int studentCount;
        private int subjectCount;
        private String avgCgpa;

        public int getSemester() { return semester; }
        public void setSemester(int semester) { this.semester = semester; }
        public int getStudentCount() { return studentCount; }
        public void setStudentCount(int studentCount) { this.studentCount = studentCount; }
        public int getSubjectCount() { return subjectCount; }
        public void setSubjectCount(int subjectCount) { this.subjectCount = subjectCount; }
        public String getAvgCgpa() { return avgCgpa; }
        public void setAvgCgpa(String avgCgpa) { this.avgCgpa = avgCgpa; }
    }

    public static class UserRow {
        private Long id;
        private String fullName;
        private String email;
        private String role;
        private boolean active;
        private String lastLoginLabel;
        private String codeLabel;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getFullName() { return fullName; }
        public void setFullName(String fullName) { this.fullName = fullName; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getRole() { return role; }
        public void setRole(String role) { this.role = role; }
        public boolean isActive() { return active; }
        public void setActive(boolean active) { this.active = active; }
        public String getLastLoginLabel() { return lastLoginLabel; }
        public void setLastLoginLabel(String lastLoginLabel) { this.lastLoginLabel = lastLoginLabel; }
        public String getCodeLabel() { return codeLabel; }
        public void setCodeLabel(String codeLabel) { this.codeLabel = codeLabel; }
    }

    public static class FeedbackRow {
        private Long id;
        private String studentName;
        private String studentEnroll;
        private String subjectCode;
        private String facultyName;
        private String category;
        private String status;
        private String message;
        private String createdLabel;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getStudentName() { return studentName; }
        public void setStudentName(String studentName) { this.studentName = studentName; }
        public String getStudentEnroll() { return studentEnroll; }
        public void setStudentEnroll(String studentEnroll) { this.studentEnroll = studentEnroll; }
        public String getSubjectCode() { return subjectCode; }
        public void setSubjectCode(String subjectCode) { this.subjectCode = subjectCode; }
        public String getFacultyName() { return facultyName; }
        public void setFacultyName(String facultyName) { this.facultyName = facultyName; }
        public String getCategory() { return category; }
        public void setCategory(String category) { this.category = category; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public String getCreatedLabel() { return createdLabel; }
        public void setCreatedLabel(String createdLabel) { this.createdLabel = createdLabel; }
    }

    public static class NoticeRow {
        private Long id;
        private String title;
        private String body;
        private String subjectCode;
        private String authorName;
        private boolean important;
        private String createdLabel;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        public String getBody() { return body; }
        public void setBody(String body) { this.body = body; }
        public String getSubjectCode() { return subjectCode; }
        public void setSubjectCode(String subjectCode) { this.subjectCode = subjectCode; }
        public String getAuthorName() { return authorName; }
        public void setAuthorName(String authorName) { this.authorName = authorName; }
        public boolean isImportant() { return important; }
        public void setImportant(boolean important) { this.important = important; }
        public String getCreatedLabel() { return createdLabel; }
        public void setCreatedLabel(String createdLabel) { this.createdLabel = createdLabel; }
    }
}

