package com.campusconnect.dto;

/** Plain data holder (generated). Getters follow JavaBean naming so JSP EL can read them. */
public class RecoveryRow {

    private String subjectName;
    private String currentPct;
    private int classesNeeded;
    private String status;

    public String getSubjectName() { return subjectName; }
    public void setSubjectName(String subjectName) { this.subjectName = subjectName; }
    public String getCurrentPct() { return currentPct; }
    public void setCurrentPct(String currentPct) { this.currentPct = currentPct; }
    public int getClassesNeeded() { return classesNeeded; }
    public void setClassesNeeded(int classesNeeded) { this.classesNeeded = classesNeeded; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
