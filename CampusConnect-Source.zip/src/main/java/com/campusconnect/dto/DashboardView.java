package com.campusconnect.dto;

/** Plain data holder (generated). Getters follow JavaBean naming so JSP EL can read them. */
public class DashboardView {

    private String firstName;
    private String fullName;
    private String enrollmentNo;
    private String program;
    private String semesterLabel;
    private String academicYear;
    private String branchCode;
    private int unreadCount;
    private String todayLabel;
    private boolean hosteler;
    private String hostelName;
    private int feesDueCount;
    private String feesDueAmount;
    private String nextFeeTitle;
    private String nextFeeDue;
    private int weekNo;
    private int totalWeeks;
    private String timelinePct;
    private String cgpa;
    private String cohortStanding;
    private String previousSgpa;
    private int earnedCredits;
    private String attendancePct;
    private String attendanceStatus;
    private String attendanceLabel;
    private int minAttendance;
    private int attendanceDeficit;
    private int atRiskCount;
    private int submittedAssignments;
    private int totalAssignments;
    private int pendingAssignments;
    private int backlogs;
    private String standing;
    private boolean goodStanding;
    private boolean hasEnrollments;
    private String tickerExamName;
    private String tickerExam;
    private String tickerAssignmentTitle;
    private String tickerAssignment;
    private String nextLectureSubject;
    private String nextLectureCode;
    private String nextLectureTime;
    private String nextLectureTopic;
    private String nextLectureFaculty;
    private String nextLectureRoom;
    private String examMonthLabel;
    private String cieTitle;
    private String cieText;
    private String noticeTitle;
    private String noticeText;
    private int coreCount;
    private int labCount;
    private java.util.List<SubjectCard> subjects;
    private java.util.List<ExamRow> exams;
    private java.util.List<MaterialRow> materials;
    private java.util.List<RecoveryRow> recovery;

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getEnrollmentNo() { return enrollmentNo; }
    public void setEnrollmentNo(String enrollmentNo) { this.enrollmentNo = enrollmentNo; }
    public String getProgram() { return program; }
    public void setProgram(String program) { this.program = program; }
    public String getSemesterLabel() { return semesterLabel; }
    public void setSemesterLabel(String semesterLabel) { this.semesterLabel = semesterLabel; }
    public String getAcademicYear() { return academicYear; }
    public void setAcademicYear(String academicYear) { this.academicYear = academicYear; }
    public String getBranchCode() { return branchCode; }
    public void setBranchCode(String branchCode) { this.branchCode = branchCode; }
    public int getUnreadCount() { return unreadCount; }
    public void setUnreadCount(int unreadCount) { this.unreadCount = unreadCount; }
    public String getTodayLabel() { return todayLabel; }
    public void setTodayLabel(String todayLabel) { this.todayLabel = todayLabel; }
    public boolean isHosteler() { return hosteler; }
    public void setHosteler(boolean hosteler) { this.hosteler = hosteler; }
    public String getHostelName() { return hostelName; }
    public void setHostelName(String hostelName) { this.hostelName = hostelName; }
    public int getFeesDueCount() { return feesDueCount; }
    public void setFeesDueCount(int feesDueCount) { this.feesDueCount = feesDueCount; }
    public String getFeesDueAmount() { return feesDueAmount; }
    public void setFeesDueAmount(String feesDueAmount) { this.feesDueAmount = feesDueAmount; }
    public String getNextFeeTitle() { return nextFeeTitle; }
    public void setNextFeeTitle(String nextFeeTitle) { this.nextFeeTitle = nextFeeTitle; }
    public String getNextFeeDue() { return nextFeeDue; }
    public void setNextFeeDue(String nextFeeDue) { this.nextFeeDue = nextFeeDue; }
    public int getWeekNo() { return weekNo; }
    public void setWeekNo(int weekNo) { this.weekNo = weekNo; }
    public int getTotalWeeks() { return totalWeeks; }
    public void setTotalWeeks(int totalWeeks) { this.totalWeeks = totalWeeks; }
    public String getTimelinePct() { return timelinePct; }
    public void setTimelinePct(String timelinePct) { this.timelinePct = timelinePct; }
    public String getCgpa() { return cgpa; }
    public void setCgpa(String cgpa) { this.cgpa = cgpa; }
    public String getCohortStanding() { return cohortStanding; }
    public void setCohortStanding(String cohortStanding) { this.cohortStanding = cohortStanding; }
    public String getPreviousSgpa() { return previousSgpa; }
    public void setPreviousSgpa(String previousSgpa) { this.previousSgpa = previousSgpa; }
    public int getEarnedCredits() { return earnedCredits; }
    public void setEarnedCredits(int earnedCredits) { this.earnedCredits = earnedCredits; }
    public String getAttendancePct() { return attendancePct; }
    public void setAttendancePct(String attendancePct) { this.attendancePct = attendancePct; }
    public String getAttendanceStatus() { return attendanceStatus; }
    public void setAttendanceStatus(String attendanceStatus) { this.attendanceStatus = attendanceStatus; }
    public String getAttendanceLabel() { return attendanceLabel; }
    public void setAttendanceLabel(String attendanceLabel) { this.attendanceLabel = attendanceLabel; }
    public int getMinAttendance() { return minAttendance; }
    public void setMinAttendance(int minAttendance) { this.minAttendance = minAttendance; }
    public int getAttendanceDeficit() { return attendanceDeficit; }
    public void setAttendanceDeficit(int attendanceDeficit) { this.attendanceDeficit = attendanceDeficit; }
    public int getAtRiskCount() { return atRiskCount; }
    public void setAtRiskCount(int atRiskCount) { this.atRiskCount = atRiskCount; }
    public int getSubmittedAssignments() { return submittedAssignments; }
    public void setSubmittedAssignments(int submittedAssignments) { this.submittedAssignments = submittedAssignments; }
    public int getTotalAssignments() { return totalAssignments; }
    public void setTotalAssignments(int totalAssignments) { this.totalAssignments = totalAssignments; }
    public int getPendingAssignments() { return pendingAssignments; }
    public void setPendingAssignments(int pendingAssignments) { this.pendingAssignments = pendingAssignments; }
    public int getBacklogs() { return backlogs; }
    public void setBacklogs(int backlogs) { this.backlogs = backlogs; }
    public String getStanding() { return standing; }
    public void setStanding(String standing) { this.standing = standing; }
    public boolean isGoodStanding() { return goodStanding; }
    public void setGoodStanding(boolean goodStanding) { this.goodStanding = goodStanding; }
    public boolean isHasEnrollments() { return hasEnrollments; }
    public void setHasEnrollments(boolean hasEnrollments) { this.hasEnrollments = hasEnrollments; }
    public String getTickerExamName() { return tickerExamName; }
    public void setTickerExamName(String tickerExamName) { this.tickerExamName = tickerExamName; }
    public String getTickerExam() { return tickerExam; }
    public void setTickerExam(String tickerExam) { this.tickerExam = tickerExam; }
    public String getTickerAssignmentTitle() { return tickerAssignmentTitle; }
    public void setTickerAssignmentTitle(String tickerAssignmentTitle) { this.tickerAssignmentTitle = tickerAssignmentTitle; }
    public String getTickerAssignment() { return tickerAssignment; }
    public void setTickerAssignment(String tickerAssignment) { this.tickerAssignment = tickerAssignment; }
    public String getNextLectureSubject() { return nextLectureSubject; }
    public void setNextLectureSubject(String nextLectureSubject) { this.nextLectureSubject = nextLectureSubject; }
    public String getNextLectureCode() { return nextLectureCode; }
    public void setNextLectureCode(String nextLectureCode) { this.nextLectureCode = nextLectureCode; }
    public String getNextLectureTime() { return nextLectureTime; }
    public void setNextLectureTime(String nextLectureTime) { this.nextLectureTime = nextLectureTime; }
    public String getNextLectureTopic() { return nextLectureTopic; }
    public void setNextLectureTopic(String nextLectureTopic) { this.nextLectureTopic = nextLectureTopic; }
    public String getNextLectureFaculty() { return nextLectureFaculty; }
    public void setNextLectureFaculty(String nextLectureFaculty) { this.nextLectureFaculty = nextLectureFaculty; }
    public String getNextLectureRoom() { return nextLectureRoom; }
    public void setNextLectureRoom(String nextLectureRoom) { this.nextLectureRoom = nextLectureRoom; }
    public String getExamMonthLabel() { return examMonthLabel; }
    public void setExamMonthLabel(String examMonthLabel) { this.examMonthLabel = examMonthLabel; }
    public String getCieTitle() { return cieTitle; }
    public void setCieTitle(String cieTitle) { this.cieTitle = cieTitle; }
    public String getCieText() { return cieText; }
    public void setCieText(String cieText) { this.cieText = cieText; }
    public String getNoticeTitle() { return noticeTitle; }
    public void setNoticeTitle(String noticeTitle) { this.noticeTitle = noticeTitle; }
    public String getNoticeText() { return noticeText; }
    public void setNoticeText(String noticeText) { this.noticeText = noticeText; }
    public int getCoreCount() { return coreCount; }
    public void setCoreCount(int coreCount) { this.coreCount = coreCount; }
    public int getLabCount() { return labCount; }
    public void setLabCount(int labCount) { this.labCount = labCount; }
    public java.util.List<SubjectCard> getSubjects() { return subjects; }
    public void setSubjects(java.util.List<SubjectCard> subjects) { this.subjects = subjects; }
    public java.util.List<ExamRow> getExams() { return exams; }
    public void setExams(java.util.List<ExamRow> exams) { this.exams = exams; }
    public java.util.List<MaterialRow> getMaterials() { return materials; }
    public void setMaterials(java.util.List<MaterialRow> materials) { this.materials = materials; }
    public java.util.List<RecoveryRow> getRecovery() { return recovery; }
    public void setRecovery(java.util.List<RecoveryRow> recovery) { this.recovery = recovery; }
}
