package com.campusconnect.dto;

/** Plain data holder (generated). Getters follow JavaBean naming so JSP EL can read them. */
public class ExamRow {

    private String month;
    private String day;
    private String subjectName;
    private String timeRange;
    private String code;

    public String getMonth() { return month; }
    public void setMonth(String month) { this.month = month; }
    public String getDay() { return day; }
    public void setDay(String day) { this.day = day; }
    public String getSubjectName() { return subjectName; }
    public void setSubjectName(String subjectName) { this.subjectName = subjectName; }
    public String getTimeRange() { return timeRange; }
    public void setTimeRange(String timeRange) { this.timeRange = timeRange; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
}
