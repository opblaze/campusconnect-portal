package com.campusconnect.tools;

import com.campusconnect.config.AppConfig;
import com.campusconnect.dao.AnnouncementDao;
import com.campusconnect.dao.DataAccessException;
import com.campusconnect.model.Announcement;
import java.time.LocalDateTime;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Stand-alone console demo of all four CRUD operations through Hibernate (handy for the viva).
 * Run it from NetBeans: right-click the file -> Run File. XAMPP MySQL must be running and
 * sql/01_schema.sql + sql/02_seed.sql must have been imported.
 */
public class CrudDemo {

    public static void main(String[] args) {
        try (AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class)) {
            AnnouncementDao dao = ctx.getBean(AnnouncementDao.class);

            // CREATE
            Announcement a = new Announcement();
            a.setTitle("CRUD demo notice");
            a.setBody("Created from CrudDemo.main()");
            a.setImportant(false);
            a.setCreatedAt(LocalDateTime.now());
            dao.save(a);
            System.out.println("CREATE -> new row id = " + a.getId());

            // READ
            Announcement loaded = dao.findById(a.getId()).orElseThrow();
            System.out.println("READ   -> " + loaded.getTitle() + " | total rows now: " + dao.count());

            // UPDATE
            loaded.setBody("Updated text");
            loaded.setImportant(true);
            dao.update(loaded);
            System.out.println("UPDATE -> body is now: " + dao.findById(a.getId()).orElseThrow().getBody());

            // DELETE
            boolean deleted = dao.deleteById(a.getId());
            System.out.println("DELETE -> removed = " + deleted + " | total rows now: " + dao.count());
        } catch (DataAccessException ex) {
            // Exception handling: every Hibernate/JDBC failure arrives here as one friendly type
            System.err.println("Database problem: " + ex.getMessage());
        }
    }
}
