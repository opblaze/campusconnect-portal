package com.campusconnect.swing;

import com.campusconnect.config.AppConfig;
import com.campusconnect.config.AppProperties;
import com.campusconnect.model.Faculty;
import com.campusconnect.model.Feedback;
import com.campusconnect.model.Student;
import com.campusconnect.model.Subject;
import com.campusconnect.service.FacultyService;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Campus Connect - Faculty Console (Java Swing desktop application).
 *
 * It talks to the same database and services as the web portal, so everything a teacher does here
 * (post a notice, upload material, publish marks, take attendance) shows up for students as BLUE / ORANGE / RED
 * notifications and pop-ups. Run the main() method (NetBeans: Run File) with XAMPP MySQL running.
 */
public final class FacultyConsole extends JFrame {

    private static final long serialVersionUID = 1L;

    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH);

    private final transient FacultyService service;
    private final transient AppProperties props;
    private final transient Faculty faculty;
    private final transient List<Subject> subjects;

    // widgets that are read by several handlers
    private final JComboBox<Subject> annSubject = new JComboBox<>();
    private final JComboBox<Subject> matSubject = new JComboBox<>();
    private final JComboBox<Subject> markSubject = new JComboBox<>();
    private final JComboBox<Subject> attSubject = new JComboBox<>();
    private final DefaultTableModel markModel = tableModel("Student ID", "Enrollment", "Name", "Marks");
    private final DefaultTableModel attModel = tableModel("Student ID", "Enrollment", "Name", "Present");
    private final DefaultTableModel inboxModel = tableModel("When", "Student", "Subject", "Category", "Status", "Message");

    public FacultyConsole(FacultyService service, AppProperties props, Faculty faculty) {
        super("Campus Connect - Faculty Console - " + faculty.getTitle() + " " + faculty.getUser().getFullName());
        this.service = service;
        this.props = props;
        this.faculty = faculty;
        this.subjects = service.subjectsOf(faculty);

        for (JComboBox<Subject> box : List.of(annSubject, matSubject, markSubject, attSubject)) {
            box.setModel(new DefaultComboBoxModel<>(subjects.toArray(new Subject[0])));
            box.setRenderer((list, value, index, selected, focus) -> new JLabel(value == null ? "" : value.getCode() + " - " + value.getName()));
        }
        annSubject.insertItemAt(null, 0); // null item = announce to the whole campus
        annSubject.setSelectedIndex(0);
        annSubject.setRenderer((list, value, index, selected, focus) ->
                new JLabel(value == null ? "ALL STUDENTS (campus-wide)" : value.getCode() + " - " + value.getName()));

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Announcement", announcementTab());
        tabs.addTab("Upload material", materialTab());
        tabs.addTab("Publish marks", marksTab());
        tabs.addTab("Take attendance", attendanceTab());
        tabs.addTab("Feedback inbox", inboxTab());
        add(tabs, BorderLayout.CENTER);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(860, 560);
        setLocationRelativeTo(null);
    }

    // ------------------------------------------------------------------ tabs
    private JPanel announcementTab() {
        JTextField title = new JTextField(40);
        JTextArea body = new JTextArea(6, 40);
        body.setLineWrap(true);
        body.setWrapStyleWord(true);
        JCheckBox important = new JCheckBox("Important (show in the portal banner)");
        JButton post = new JButton("Post and notify students");
        post.addActionListener(e -> run(() -> {
            if (title.getText().isBlank() || body.getText().isBlank()) {
                throw new IllegalArgumentException("Title and text are required.");
            }
            int n = service.postAnnouncement(faculty, (Subject) annSubject.getSelectedItem(), title.getText().trim(),
                    body.getText().trim(), important.isSelected());
            title.setText("");
            body.setText("");
            info("Posted. " + n + " student(s) received a BLUE notification.");
        }));
        JPanel p = form();
        p.add(row("Send to", annSubject));
        p.add(row("Title", title));
        p.add(row("Text", new JScrollPane(body)));
        p.add(row("", important));
        p.add(row("", post));
        return p;
    }

    private JPanel materialTab() {
        JTextField title = new JTextField(36);
        JComboBox<String> type = new JComboBox<>(new String[] {"PDF", "SLIDES", "CODE", "ZIP"});
        JTextField path = new JTextField(30);
        path.setEditable(false);
        JButton browse = new JButton("Choose file...");
        final File[] chosen = new File[1];
        browse.addActionListener(e -> {
            JFileChooser fc = new JFileChooser();
            if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                chosen[0] = fc.getSelectedFile();
                path.setText(chosen[0].getName());
                if (title.getText().isBlank()) {
                    title.setText(chosen[0].getName());
                }
            }
        });
        JButton upload = new JButton("Upload and notify students");
        upload.addActionListener(e -> run(() -> {
            if (chosen[0] == null || title.getText().isBlank()) {
                throw new IllegalArgumentException("Choose a file and enter a title.");
            }
            Path dir = Paths.get(props.get("upload.dir", System.getProperty("user.home") + "/campusconnect-uploads"), "materials");
            Files.createDirectories(dir);
            String safe = chosen[0].getName().replaceAll("[^A-Za-z0-9._-]", "_");
            Files.copy(chosen[0].toPath(), dir.resolve(safe), StandardCopyOption.REPLACE_EXISTING);
            BigDecimal mb = BigDecimal.valueOf(chosen[0].length() / 1048576.0).setScale(2, java.math.RoundingMode.HALF_UP);
            int n = service.uploadMaterial(faculty, (Subject) matSubject.getSelectedItem(), title.getText().trim(),
                    (String) type.getSelectedItem(), mb, safe);
            info("Uploaded. " + n + " student(s) were notified.");
        }));
        JPanel p = form();
        p.add(row("Subject", matSubject));
        p.add(row("Title", title));
        p.add(row("Type", type));
        p.add(row("File", wrap(path, browse)));
        p.add(row("", upload));
        return p;
    }

    private JPanel marksTab() {
        JTextField exam = new JTextField("CIE-II", 10);
        JTextField max = new JTextField("30", 6);
        markSubject.addActionListener(e -> loadStudents(markSubject, markModel, 3, ""));
        JButton publish = new JButton("Publish marks");
        publish.addActionListener(e -> run(() -> {
            BigDecimal maximum = new BigDecimal(max.getText().trim());
            Map<Long, BigDecimal> marks = new HashMap<>();
            for (int i = 0; i < markModel.getRowCount(); i++) {
                String v = String.valueOf(markModel.getValueAt(i, 3)).trim();
                if (!v.isEmpty()) {
                    BigDecimal got = new BigDecimal(v);
                    if (got.signum() < 0 || got.compareTo(maximum) > 0) {
                        throw new IllegalArgumentException("Marks must be between 0 and " + maximum + " (row " + (i + 1) + ").");
                    }
                    marks.put((Long) markModel.getValueAt(i, 0), got);
                }
            }
            if (marks.isEmpty() || exam.getText().isBlank()) {
                throw new IllegalArgumentException("Enter an exam name and at least one mark.");
            }
            int n = service.publishMarks((Subject) markSubject.getSelectedItem(), exam.getText().trim(), maximum, marks);
            info("Published for " + n + " student(s); results were announced.");
        }));
        JPanel top = wrap(new JLabel("Subject"), markSubject, new JLabel("Exam"), exam, new JLabel("Max"), max, publish);
        loadStudents(markSubject, markModel, 3, "");
        return tablePanel(top, markModel);
    }

    private JPanel attendanceTab() {
        JTextField date = new JTextField(LocalDate.now().format(DATE), 10);
        attSubject.addActionListener(e -> loadStudents(attSubject, attModel, 3, Boolean.TRUE));
        JButton save = new JButton("Save attendance");
        save.addActionListener(e -> run(() -> {
            LocalDate d = LocalDate.parse(date.getText().trim(), DATE);
            if (d.isAfter(LocalDate.now())) {
                throw new IllegalArgumentException("The date cannot be in the future.");
            }
            Map<Long, Boolean> present = new HashMap<>();
            for (int i = 0; i < attModel.getRowCount(); i++) {
                present.put((Long) attModel.getValueAt(i, 0), (Boolean) attModel.getValueAt(i, 3));
            }
            int n = service.markAttendance((Subject) attSubject.getSelectedItem(), d, present);
            info(n + " record(s) saved. Low-attendance alerts were sent where needed.");
        }));
        JPanel top = wrap(new JLabel("Subject"), attSubject, new JLabel("Date (yyyy-MM-dd)"), date, save);
        loadStudents(attSubject, attModel, 3, Boolean.TRUE);
        return tablePanel(top, attModel);
    }

    private JPanel inboxTab() {
        JButton refresh = new JButton("Refresh");
        refresh.addActionListener(e -> run(() -> {
            inboxModel.setRowCount(0);
            for (Feedback f : service.inbox(faculty)) {
                inboxModel.addRow(new Object[] {f.getCreatedAt().toString().replace('T', ' '),
                        f.getStudent().getUser().getFullName(), f.getSubject() == null ? "-" : f.getSubject().getShortName(),
                        f.getCategory(), f.getStatus(), f.getProcessedText()});
            }
        }));
        refresh.doClick();
        return tablePanel(wrap(refresh), inboxModel);
    }

    // ------------------------------------------------------------------ helpers
    private void loadStudents(JComboBox<Subject> box, DefaultTableModel model, int valueColumn, Object initial) {
        model.setRowCount(0);
        Subject s = (Subject) box.getSelectedItem();
        if (s == null) {
            return;
        }
        for (Student st : service.studentsOf(s)) {
            model.addRow(new Object[] {st.getId(), st.getEnrollmentNo(), st.getUser().getFullName(), initial});
        }
    }

    private void run(ThrowingRunnable r) {
        try {
            r.run();
        } catch (IllegalArgumentException | java.time.format.DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Please check the input", JOptionPane.WARNING_MESSAGE);
        } catch (IOException | RuntimeException ex) { // includes DataAccessException from the DAO layer
            JOptionPane.showMessageDialog(this, "Operation failed: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void info(String m) {
        JOptionPane.showMessageDialog(this, m, "Campus Connect", JOptionPane.INFORMATION_MESSAGE);
    }

    private interface ThrowingRunnable {
        void run() throws IOException;
    }

    private static DefaultTableModel tableModel(String... cols) {
        return new DefaultTableModel(cols, 0) {
            private static final long serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(int r, int c) {
                return c == 3 && cols.length == 4;
            }

            @Override
            public Class<?> getColumnClass(int c) {
                if (c == 0 && cols.length == 4) return Long.class;
                if (c == 3 && cols[3].equals("Present")) return Boolean.class;
                return Object.class;
            }
        };
    }

    private static JPanel form() {
        JPanel p = new JPanel(new GridLayout(0, 1, 4, 8));
        p.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        return p;
    }

    private static JPanel row(String label, java.awt.Component c) {
        JPanel p = new JPanel(new BorderLayout(8, 0));
        JLabel l = new JLabel(label);
        l.setPreferredSize(new Dimension(90, 24));
        p.add(l, BorderLayout.WEST);
        p.add(c, BorderLayout.CENTER);
        return p;
    }

    private static JPanel wrap(java.awt.Component... cs) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        for (java.awt.Component c : cs) {
            p.add(c);
        }
        return p;
    }

    private static JPanel tablePanel(JPanel top, DefaultTableModel model) {
        JPanel p = new JPanel(new BorderLayout());
        p.add(top, BorderLayout.NORTH);
        JTable t = new JTable(model);
        if ("Student ID".equals(t.getColumnModel().getColumn(0).getHeaderValue())) {
            t.removeColumn(t.getColumnModel().getColumn(0)); // the id stays in the model, only hidden from the view
        }
        p.add(new JScrollPane(t), BorderLayout.CENTER);
        return p;
    }

    // ------------------------------------------------------------------ entry point
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // default look and feel is fine
        }
        SwingUtilities.invokeLater(() -> {
            AnnotationConfigApplicationContext ctx;
            try {
                ctx = new AnnotationConfigApplicationContext(AppConfig.class);
            } catch (RuntimeException ex) {
                JOptionPane.showMessageDialog(null, "Cannot connect to the database. Is XAMPP MySQL running and sql/ imported?\n"
                        + ex.getMessage(), "Campus Connect", JOptionPane.ERROR_MESSAGE);
                return;
            }
            FacultyService service = ctx.getBean(FacultyService.class);
            JTextField email = new JTextField("faculty.one@example.invalid");
            JPasswordField pw = new JPasswordField();
            Object[] form = {"Faculty e-mail", email, "Password", pw};
            while (true) {
                if (JOptionPane.showConfirmDialog(null, form, "Campus Connect - Faculty sign in",
                        JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) {
                    ctx.close();
                    return;
                }
                java.util.Optional<Faculty> f = service.authenticate(email.getText(), new String(pw.getPassword()));
                if (f.isPresent()) {
                    new FacultyConsole(service, ctx.getBean(AppProperties.class), f.get()).setVisible(true);
                    return;
                }
                JOptionPane.showMessageDialog(null, "Invalid e-mail or password.", "Sign in failed", JOptionPane.WARNING_MESSAGE);
            }
        });
    }
}
