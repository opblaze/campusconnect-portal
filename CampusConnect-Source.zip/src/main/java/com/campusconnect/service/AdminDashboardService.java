package com.campusconnect.service;

import com.campusconnect.config.AppProperties;
import com.campusconnect.dao.*;
import com.campusconnect.dto.AdminDashboardView;
import com.campusconnect.dto.AdminDashboardView.*;
import com.campusconnect.model.*;
import com.campusconnect.model.enums.FeedbackStatus;
import com.campusconnect.model.enums.Role;
import com.campusconnect.util.Text;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Builds the institutional analytics & control-panel view model for the admin dashboard. */
@Service
public class AdminDashboardService {

    private static final DateTimeFormatter TODAY_FMT = DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.ENGLISH);
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH);
    private static final Locale IN_LOCALE = Locale.forLanguageTag("en-IN");

    private final UserDao userDao;
    private final StudentDao studentDao;
    private final FacultyDao facultyDao;
    private final SubjectDao subjectDao;
    private final FeeRecordDao feeDao;
    private final AssignmentDao assignmentDao;
    private final SubmissionDao submissionDao;
    private final AttendanceRecordDao attendanceDao;
    private final FeedbackDao feedbackDao;
    private final AnnouncementDao announcementDao;
    private final AppProperties props;

    @Autowired
    public AdminDashboardService(UserDao userDao, StudentDao studentDao, FacultyDao facultyDao, SubjectDao subjectDao,
            FeeRecordDao feeDao, AssignmentDao assignmentDao, SubmissionDao submissionDao,
            AttendanceRecordDao attendanceDao, FeedbackDao feedbackDao, AnnouncementDao announcementDao,
            AppProperties props) {
        this.userDao = userDao;
        this.studentDao = studentDao;
        this.facultyDao = facultyDao;
        this.subjectDao = subjectDao;
        this.feeDao = feeDao;
        this.assignmentDao = assignmentDao;
        this.submissionDao = submissionDao;
        this.attendanceDao = attendanceDao;
        this.feedbackDao = feedbackDao;
        this.announcementDao = announcementDao;
        this.props = props;
    }

    public AdminDashboardView build(Long adminUserId) {
        User adminUser = userDao.findById(adminUserId)
                .orElseThrow(() -> new IllegalStateException("Admin user not found: " + adminUserId));
        return build(adminUser);
    }

    public AdminDashboardView build(User adminUser) {
        LocalDate today = LocalDate.now(props.zone());
        AdminDashboardView v = new AdminDashboardView();
        v.setFullName(adminUser.getFullName());
        v.setFirstName(Text.firstName(adminUser.getFullName()));
        v.setEmail(adminUser.getEmail());
        v.setTodayLabel(today.format(TODAY_FMT));

        List<User> users = userDao.allOrdered();
        List<Student> students = studentDao.allOrdered();
        List<Faculty> facultyList = facultyDao.allOrdered();
        List<Subject> subjects = subjectDao.allOrdered();
        List<FeeRecord> fees = feeDao.allOrdered();
        List<Assignment> assignments = assignmentDao.allOrdered();
        List<Submission> submissions = submissionDao.findAll();
        List<Feedback> feedbacks = feedbackDao.latestAll(50);
        List<Announcement> announcements = announcementDao.latest(50);

        Map<Long, String> userCode = new HashMap<>();
        int hostelers = 0;
        Map<Integer, List<Student>> studentsBySem = new TreeMap<>();
        for (Student st : students) {
            userCode.put(st.getUser().getId(), st.getEnrollmentNo());
            if (st.isHosteler()) hostelers++;
            studentsBySem.computeIfAbsent(st.getSemester(), k -> new ArrayList<>()).add(st);
        }
        v.setTotalStudents(students.size());
        v.setHostelerCount(hostelers);
        v.setDayScholarCount(students.size() - hostelers);

        Map<String, Integer> facByDept = new TreeMap<>();
        for (Faculty f : facultyList) {
            userCode.put(f.getUser().getId(), f.getEmployeeCode());
            String dept = f.getDepartment() == null ? "General" : f.getDepartment();
            facByDept.merge(dept, 1, Integer::sum);
        }
        v.setTotalFaculty(facultyList.size());
        v.setDepartmentCount(facByDept.size());

        int core = 0, lab = 0;
        Map<String, Integer> subByDept = new HashMap<>();
        Map<Integer, Integer> subBySem = new HashMap<>();
        for (Subject s : subjects) {
            if ("LAB".equalsIgnoreCase(s.getCategory())) lab++;
            else core++;
            String dept = s.getFaculty() != null && s.getFaculty().getDepartment() != null
                    ? s.getFaculty().getDepartment() : "General";
            subByDept.merge(dept, 1, Integer::sum);
            subBySem.merge(s.getSemester(), 1, Integer::sum);
            studentsBySem.computeIfAbsent(s.getSemester(), k -> new ArrayList<>());
        }
        v.setTotalSubjects(subjects.size());
        v.setCoreSubjects(core);
        v.setLabSubjects(lab);

        int active = 0, stUsers = 0, facUsers = 0, admUsers = 0;
        List<UserRow> recentUsers = new ArrayList<>();
        for (User u : users) {
            if (u.isActive()) active++;
            if (u.getRole() == Role.STUDENT) stUsers++;
            else if (u.getRole() == Role.FACULTY) facUsers++;
            else admUsers++;

            if (recentUsers.size() < 8) {
                UserRow ur = new UserRow();
                ur.setId(u.getId());
                ur.setFullName(u.getFullName());
                ur.setEmail(u.getEmail());
                ur.setRole(u.getRole().name());
                ur.setActive(u.isActive());
                ur.setLastLoginLabel(u.getLastLoginAt() == null ? "Never"
                        : u.getLastLoginAt().toLocalDate().format(DATE_FMT));
                ur.setCodeLabel(userCode.getOrDefault(u.getId(), u.getRole() == Role.ADMIN ? "ADMIN" : "-"));
                recentUsers.add(ur);
            }
        }
        v.setTotalUsers(users.size());
        v.setActiveUsers(active);
        v.setInactiveUsers(users.size() - active);
        v.setStudentUsers(stUsers);
        v.setFacultyUsers(facUsers);
        v.setAdminUsers(admUsers);
        v.setRecentUsers(recentUsers);

        BigDecimal collected = BigDecimal.ZERO;
        BigDecimal pending = BigDecimal.ZERO;
        BigDecimal overdue = BigDecimal.ZERO;
        int unpaidCount = 0, overdueCount = 0;
        for (FeeRecord f : fees) {
            BigDecimal amt = f.getAmount() == null ? BigDecimal.ZERO : f.getAmount();
            if (f.isPaid()) {
                collected = collected.add(amt);
            } else {
                unpaidCount++;
                pending = pending.add(amt);
                if (f.getDueDate() != null && f.getDueDate().isBefore(today)) {
                    overdueCount++;
                    overdue = overdue.add(amt);
                }
            }
        }
        BigDecimal totalBilled = collected.add(pending);
        int feePct = totalBilled.compareTo(BigDecimal.ZERO) == 0 ? 0
                : collected.multiply(BigDecimal.valueOf(100)).divide(totalBilled, 0, RoundingMode.HALF_UP).intValue();
        v.setFeeCollected(collected.longValue());
        v.setFeePending(pending.longValue());
        v.setFeeOverdue(overdue.longValue());
        v.setTotalFeeBilled(totalBilled.longValue());
        v.setFeeCollectionPct(feePct);
        v.setUnpaidFeeCount(unpaidCount);
        v.setOverdueFeeCount(overdueCount);
        v.setFeeCollectedLabel(formatInr(collected));
        v.setFeePendingLabel(formatInr(pending));
        v.setFeeOverdueLabel(formatInr(overdue));
        v.setTotalFeeBilledLabel(formatInr(totalBilled));

        v.setTotalAssignments(assignments.size());
        v.setTotalSubmissions(submissions.size());
        int ungraded = 0;
        for (Submission sub : submissions) {
            if (!"GRADED".equalsIgnoreCase(sub.getStatus())) ungraded++;
        }
        v.setPendingGradingCount(ungraded);

        Map<Long, long[]> attMap = attendanceDao.overallByStudent();
        long sumHeld = 0, sumAtt = 0;
        int atRisk = 0;
        int minPct = props.getInt("attendance.min", 75);
        for (Student st : students) {
            long[] counts = attMap.get(st.getId());
            if (counts != null && counts[0] > 0) {
                sumHeld += counts[0];
                sumAtt += counts[1];
                double pct = (counts[1] * 100.0) / counts[0];
                if (pct < minPct) atRisk++;
            }
        }
        v.setAvgAttendancePct(sumHeld == 0 ? 0 : (int) Math.round((sumAtt * 100.0) / sumHeld));
        v.setAtRiskStudents(atRisk);

        int newFb = 0;
        List<FeedbackRow> fbRows = new ArrayList<>();
        for (Feedback fb : feedbacks) {
            if (fb.getStatus() == FeedbackStatus.NEW) newFb++;
            if (fbRows.size() < 6) {
                FeedbackRow fr = new FeedbackRow();
                fr.setId(fb.getId());
                fr.setStudentName(fb.getStudent().getUser().getFullName());
                fr.setStudentEnroll(fb.getStudent().getEnrollmentNo());
                fr.setSubjectCode(fb.getSubject() != null ? fb.getSubject().getCode() : "General");
                fr.setFacultyName(fb.getFaculty() != null ? fb.getFaculty().getUser().getFullName() : "Campus Admin");
                fr.setCategory(fb.getCategory() == null ? "General" : fb.getCategory());
                fr.setStatus(fb.getStatus().name());
                String msg = fb.getProcessedText() != null && !fb.getProcessedText().isBlank()
                        ? fb.getProcessedText() : fb.getRawText();
                fr.setMessage(msg);
                fr.setCreatedLabel(fb.getCreatedAt() == null ? "" : fb.getCreatedAt().toLocalDate().format(DATE_FMT));
                fbRows.add(fr);
            }
        }
        v.setFeedbackCount(feedbacks.size());
        v.setNewFeedbackCount(newFb);
        v.setRecentFeedback(fbRows);

        List<NoticeRow> noticeRows = new ArrayList<>();
        for (int i = 0; i < Math.min(6, announcements.size()); i++) {
            Announcement a = announcements.get(i);
            NoticeRow nr = new NoticeRow();
            nr.setId(a.getId());
            nr.setTitle(a.getTitle());
            nr.setBody(a.getBody());
            nr.setSubjectCode(a.getSubject() != null ? a.getSubject().getCode() : "Campus-wide");
            nr.setAuthorName(a.getPostedBy() != null ? a.getPostedBy().getUser().getFullName() : "Administration");
            nr.setImportant(a.isImportant());
            nr.setCreatedLabel(a.getCreatedAt() == null ? "" : a.getCreatedAt().toLocalDate().format(DATE_FMT));
            noticeRows.add(nr);
        }
        v.setAnnouncementCount(announcements.size());
        v.setRecentAnnouncements(noticeRows);

        List<DepartmentRow> deptRows = new ArrayList<>();
        for (Map.Entry<String, Integer> e : facByDept.entrySet()) {
            DepartmentRow dr = new DepartmentRow();
            dr.setDepartment(e.getKey());
            dr.setFacultyCount(e.getValue());
            dr.setSubjectCount(subByDept.getOrDefault(e.getKey(), 0));
            deptRows.add(dr);
        }
        v.setDepartmentStats(deptRows);

        List<SemesterRow> semRows = new ArrayList<>();
        for (Map.Entry<Integer, List<Student>> e : studentsBySem.entrySet()) {
            SemesterRow sr = new SemesterRow();
            sr.setSemester(e.getKey());
            sr.setStudentCount(e.getValue().size());
            sr.setSubjectCount(subBySem.getOrDefault(e.getKey(), 0));
            if (e.getValue().isEmpty()) {
                sr.setAvgCgpa("0.00");
            } else {
                BigDecimal sum = BigDecimal.ZERO;
                for (Student st : e.getValue()) {
                    if (st.getCgpa() != null) sum = sum.add(st.getCgpa());
                }
                sr.setAvgCgpa(sum.divide(BigDecimal.valueOf(e.getValue().size()), 2, RoundingMode.HALF_UP).toPlainString());
            }
            semRows.add(sr);
        }
        v.setSemesterStats(semRows);

        return v;
    }

    public static String formatInr(BigDecimal amount) {
        if (amount == null) return "\u20B90";
        NumberFormat nf = NumberFormat.getNumberInstance(IN_LOCALE);
        nf.setMaximumFractionDigits(0);
        return "\u20B9" + nf.format(amount.setScale(0, RoundingMode.HALF_UP));
    }
}
