package com.campusconnect.service;

import java.util.Locale;
import java.util.Optional;
import java.util.regex.Pattern;

/**
 * Friendly conversation basics for the assistant "Sanjii": greetings, "what can you do?", thanks and goodbye.
 * Answering these locally makes the bot instant and consistent, and saves free-tier Gemini calls for real questions.
 */
public final class SmallTalk {

    public static final String BOT_NAME = "Sanjii";

    private static final Pattern GREETING = Pattern.compile(
            "^(h+i+|h+e+y+|h+e+l+o+|h+e+l+l*o+|hlo|hola|yo+|sup|namaste|namaskar|kem cho|"
                    + "good (morning|afternoon|evening))( (there|sanjii|sanji|sanjee|sir|madam|bot|buddy|friend|everyone))?$");
    private static final Pattern CAPABILITIES = Pattern.compile(
            "(what|how) (all )?(can|could|do) (you|u) (do|help|assist|offer)|what do you do|what can i ask|your (features|capabilities|abilities|skills)"
                    + "|^help( me)?$|^menu$|what are you able to do|tell me what you can do|how can you help|what (services|things) (do you|can you)");
    private static final Pattern WHO = Pattern.compile(
            "who are you|who r u|what is your name|what's your name|your name|what are you|are you (a |an )?(bot|ai|human|robot|real)|who is sanjii|introduce yourself");
    private static final Pattern HOW_ARE_YOU = Pattern.compile("how are you|how r u|how are u|how do you do|what's up|whats up|how is it going|how's it going");
    private static final Pattern THANKS = Pattern.compile("^(thanks|thank you|thx|thankyou|ty|thank u|thanks a lot|thank you so much|many thanks|tysm|dhanyavad|aabhar)( sanjii| sanji)?$");
    private static final Pattern BYE = Pattern.compile("^(bye|goodbye|good bye|see you|see ya|ok bye|bye bye|byee+|tc|take care|good night|gn)( sanjii| sanji)?$");

    private SmallTalk() { }

    /** @return the answer when the message is plain conversation, otherwise empty (the real pipeline handles it). */
    public static Optional<String> reply(String message) {
        String t = normalise(message);
        if (t.isEmpty()) {
            return Optional.empty();
        }
        if (GREETING.matcher(t).matches()) {
            String lead = "Hi!";
            if (t.startsWith("good morning")) lead = "Good morning!";
            else if (t.startsWith("good afternoon")) lead = "Good afternoon!";
            else if (t.startsWith("good evening")) lead = "Good evening!";
            else if (t.startsWith("namaste") || t.startsWith("namaskar")) lead = "Namaste! \uD83D\uDE4F";
            return Optional.of(lead + " I'm " + BOT_NAME + ", your AI assistant from Campus Connect. How can I help you today? \uD83D\uDE0A");
        }
        if (CAPABILITIES.matcher(t).find()) {
            return Optional.of("I can help you with:\n"
                    + "- Checking your academic progress\n"
                    + "- Viewing pending, done, or due tasks\n"
                    + "- Exam schedules and timetable info\n"
                    + "- Announcements and notices\n"
                    + "- Fee status and hostel information\n"
                    + "...and much more related to your campus life!");
        }
        if (WHO.matcher(t).find()) {
            return Optional.of("I'm " + BOT_NAME + " \uD83E\uDD16, the AI assistant of Campus Connect. I help students with their attendance, marks, "
                    + "assignments, exams, fees, notices and study material. What would you like to know?");
        }
        if (HOW_ARE_YOU.matcher(t).find()) {
            return Optional.of("I'm doing great, thanks for asking! \uD83D\uDE0A How can I help you with your campus life today?");
        }
        if (THANKS.matcher(t).matches()) {
            return Optional.of("You're welcome! \uD83D\uDE0A Is there anything else I can help you with?");
        }
        if (BYE.matcher(t).matches()) {
            return Optional.of("Bye! \uD83D\uDC4B All the best with your studies. I'm here whenever you need me.");
        }
        return Optional.empty();
    }

    /** lower case, punctuation removed, spaces collapsed ("Hiii!!" -> "hiii"). */
    static String normalise(String s) {
        if (s == null) {
            return "";
        }
        return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z' ]", " ").replaceAll("\\s+", " ").trim();
    }
}
