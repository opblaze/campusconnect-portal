package com.campusconnect.service;

import com.campusconnect.config.AppProperties;
import com.campusconnect.dao.AnnouncementDao;
import com.campusconnect.dao.AssignmentDao;
import com.campusconnect.dao.AttendanceRecordDao;
import com.campusconnect.dao.EnrollmentDao;
import com.campusconnect.dao.FeeRecordDao;
import com.campusconnect.dao.ExamScheduleDao;
import com.campusconnect.dao.MarkDao;
import com.campusconnect.dao.NotificationDao;
import com.campusconnect.dao.StudentDao;
import com.campusconnect.dao.StudyMaterialDao;
import com.campusconnect.dao.SubmissionDao;
import com.campusconnect.dao.TimetableSlotDao;
import com.campusconnect.dto.DashboardView;
import com.campusconnect.dto.ExamRow;
import com.campusconnect.dto.MaterialRow;
import com.campusconnect.dto.RecoveryRow;
import com.campusconnect.dto.SubjectCard;
import com.campusconnect.model.Announcement;
import com.campusconnect.model.Assignment;
import com.campusconnect.model.ExamSchedule;
import com.campusconnect.model.FeeRecord;
import com.campusconnect.model.Mark;
import com.campusconnect.model.Student;
import com.campusconnect.model.StudyMaterial;
import com.campusconnect.model.Subject;
import com.campusconnect.model.TimetableSlot;
import com.campusconnect.util.FeeStatus;
import com.campusconnect.util.Text;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Business logic behind the student dashboard.
 * It reads data through the DAOs and turns it into a {@link DashboardView} that the JSP only has to print.
 * (Controller -> Service -> DAO -> Hibernate -> MySQL is the layered architecture used everywhere.)
 */
@Service
public class DashboardService {

    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("hh:mm a", Locale.ENGLISH);
    private static final DateTimeFormatter DAY_TIME = DateTimeFormatter.ofPattern("EEEE hh:mm a", Locale.ENGLISH);
    private static final DateTimeFormatter DUE = DateTimeFormatter.ofPattern("EEE, d MMM 'at' hh:mm a", Locale.ENGLISH);

    /** A concrete upcoming lecture (a weekly slot placed on a calendar date). */
    private record Occurrence(LocalDateTime start, TimetableSlot slot) { }

    private final StudentDao studentDao;
    private final EnrollmentDao enrollmentDao;
    private final AttendanceRecordDao attendanceDao;
    private final AssignmentDao assignmentDao;
    private final SubmissionDao submissionDao;
    private final TimetableSlotDao timetableDao;
    private final ExamScheduleDao examDao;
    private final StudyMaterialDao materialDao;
    private final AnnouncementDao announcementDao;
    private final NotificationDao notificationDao;
    private final FeeRecordDao feeDao;
    private final MarkDao markDao;
    private final AttendancePolicy policy;
    private final AppProperties props;

    @Autowired
    public DashboardService(StudentDao studentDao, EnrollmentDao enrollmentDao, AttendanceRecordDao attendanceDao,
                            AssignmentDao assignmentDao, SubmissionDao submissionDao, TimetableSlotDao timetableDao,
                            ExamScheduleDao examDao, StudyMaterialDao materialDao, AnnouncementDao announcementDao,
                            NotificationDao notificationDao, FeeRecordDao feeDao, MarkDao markDao,
                            AttendancePolicy policy, AppProperties props) {
        this.studentDao = studentDao;
        this.enrollmentDao = enrollmentDao;
        this.attendanceDao = attendanceDao;
        this.assignmentDao = assignmentDao;
        this.submissionDao = submissionDao;
        this.timetableDao = timetableDao;
        this.examDao = examDao;
        this.materialDao = materialDao;
        this.announcementDao = announcementDao;
        this.notificationDao = notificationDao;
        this.feeDao = feeDao;
        this.markDao = markDao;
        this.policy = policy;
        this.props = props;
    }

    /** Builds everything the dashboard page needs for one student. */
    public DashboardView build(Long studentId) {
        LocalDateTime now = LocalDateTime.now(props.zone());
        LocalDate today = now.toLocalDate();

        Student st = studentDao.findById(studentId)
                .orElseThrow(() -> new IllegalStateException("Student " + studentId + " does not exist"));
        List<Subject> subjects = enrollmentDao.subjectsOf(studentId);
        List<Long> ids = subjects.stream().map(Subject::getId).collect(Collectors.toList());
        Map<Long, long[]> attendance = attendanceDao.summaryByStudent(studentId);
        List<TimetableSlot> slots = timetableDao.forSubjects(ids);

        DashboardView v = new DashboardView();

        // ---------- header and hero ----------
        v.setFirstName(Text.firstName(st.getUser().getFullName()));
        v.setFullName(st.getUser().getFullName());
        v.setEnrollmentNo(st.getEnrollmentNo());
        v.setProgram(st.getProgram());
        v.setBranchCode(st.getBranchCode());
        v.setSemesterLabel("Sem " + st.getSemester());
        v.setAcademicYear(st.getAcademicYear());
        v.setUnreadCount(notificationDao.countUnread(studentId));
        v.setTodayLabel(today.format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.ENGLISH)));
        v.setHosteler(st.isHosteler());
        v.setHostelName(st.getHostelName() == null ? "" : st.getHostelName());
        v.setHasEnrollments(!subjects.isEmpty());

        long days = ChronoUnit.DAYS.between(st.getSemesterStart(), today);
        int weeks = Math.max(1, st.getSemesterWeeks());
        int weekNo = (int) Math.min(weeks, Math.max(1, days / 7 + 1));
        v.setWeekNo(weekNo);
        v.setTotalWeeks(weeks);
        v.setTimelinePct(Text.pct1(weekNo * 100.0 / weeks));

        // ---------- stat cards ----------
        v.setCgpa(st.getCgpa().toPlainString());
        v.setPreviousSgpa(st.getPreviousSgpa().toPlainString());
        v.setEarnedCredits(st.getEarnedCredits());
        v.setCohortStanding(st.getCohortStanding() == null ? "" : st.getCohortStanding());
        v.setBacklogs(st.getBacklogs());

        // ---------- subject cards + overall attendance ----------
        long totalHeld = 0;
        long totalAttended = 0;
        int atRisk = 0;
        int core = 0;
        int labs = 0;
        List<SubjectCard> cards = new ArrayList<>();
        Occurrence nextLecture = null;

        for (Subject s : subjects) {
            long[] a = attendance.getOrDefault(s.getId(), new long[] {0, 0});
            totalHeld += a[0];
            totalAttended += a[1];
            double pct = a[0] == 0 ? 100.0 : a[1] * 100.0 / a[0];
            String status = policy.statusOf(pct);
            if (AttendancePolicy.RED.equals(status)) {
                atRisk++;
            }
            if ("LAB".equalsIgnoreCase(s.getCategory())) {
                labs++;
            } else {
                core++;
            }

            Occurrence next = nextOccurrence(slots.stream()
                    .filter(t -> t.getSubject().getId().equals(s.getId())).collect(Collectors.toList()), now);
            if (next != null && (nextLecture == null || next.start().isBefore(nextLecture.start()))) {
                nextLecture = next;
            }

            SubjectCard c = new SubjectCard();
            c.setId(s.getId());
            c.setCode(s.getCode());
            c.setName(s.getName());
            c.setShortName(s.getShortName());
            c.setCredits(s.getCredits());
            c.setCategory(s.getCategory());
            c.setMeetingDays(s.getMeetingDays().replace(",", " \u2022 "));
            c.setSyllabusPct(Text.pct1(s.getSyllabusCompletion().doubleValue()));
            c.setAttendancePct(Text.pct0(pct));
            c.setStatus(status);
            c.setStatusLabel(policy.labelOf(pct));
            c.setBarClass(barClass(status));
            c.setChipClass(chipClass(status));
            c.setNextSession(next == null ? "No upcoming session" : label(next.start(), now));
            c.setNextRoom(next == null ? "" : next.slot().getRoom());
            String fac = s.getFaculty().getTitle() + " " + s.getFaculty().getUser().getFullName();
            c.setFacultyName(fac);
            c.setFacultyInitials(Text.initials(s.getFaculty().getUser().getFullName()));
            cards.add(c);
        }
        v.setSubjects(cards);
        // Recovery tracker: how many classes in a row are needed to reach the minimum (risk dashboard)
        List<RecoveryRow> recovery = new ArrayList<>();
        int minPct = policy.getMin();
        for (Subject s : subjects) {
            long[] a = attendance.getOrDefault(s.getId(), new long[] {0, 0});
            double pct = a[0] == 0 ? 100.0 : a[1] * 100.0 / a[0];
            if (pct < minPct) {
                RecoveryRow r = new RecoveryRow();
                r.setSubjectName(s.getName());
                r.setCurrentPct(Text.pct0(pct));
                r.setClassesNeeded((int) Math.ceil((minPct * a[0] - 100.0 * a[1]) / (100.0 - minPct)));
                r.setStatus(pct < policy.getCritical() ? "RED" : "ORANGE");
                recovery.add(r);
            }
        }
        v.setRecovery(recovery);
        v.setCoreCount(core);
        v.setLabCount(labs);
        v.setAtRiskCount(atRisk);

        double overall = totalHeld == 0 ? 100.0 : totalAttended * 100.0 / totalHeld;
        v.setAttendancePct(Text.pct0(overall));
        v.setAttendanceStatus(policy.statusOf(overall));
        v.setAttendanceLabel(policy.labelOf(overall));
        v.setMinAttendance(policy.getMin());
        v.setAttendanceDeficit(overall < policy.getMin() ? (int) Math.ceil(policy.getMin() - overall) : 0);

        boolean good = overall >= policy.getMin() && st.getBacklogs() == 0;
        v.setGoodStanding(good);
        v.setStanding(good ? "Good Standing" : "Academic Warning");

        // ---------- next lecture spotlight ----------
        if (nextLecture != null) {
            TimetableSlot t = nextLecture.slot();
            v.setNextLectureSubject(t.getSubject().getName() + " (" + t.getSubject().getShortName() + ")");
            v.setNextLectureCode(t.getSubject().getCode());
            LocalDate d = nextLecture.start().toLocalDate();
            v.setNextLectureTime(d.equals(today) ? nextLecture.start().format(TIME) : label(nextLecture.start(), now));
            v.setNextLectureTopic(t.getTopic() == null ? "" : t.getTopic());
            v.setNextLectureFaculty(t.getSubject().getFaculty().getTitle() + " "
                    + t.getSubject().getFaculty().getUser().getFullName());
            v.setNextLectureRoom(t.getRoom() + (t.getBlock() == null ? "" : " \u2022 " + t.getBlock()));
        }

        // ---------- assignments ----------
        List<Assignment> assignments = assignmentDao.forSubjects(ids);
        Set<Long> submitted = submissionDao.submittedAssignmentIds(studentId);
        int done = (int) assignments.stream().filter(a -> submitted.contains(a.getId())).count();
        v.setTotalAssignments(assignments.size());
        v.setSubmittedAssignments(done);
        v.setPendingAssignments(assignments.size() - done);
        assignments.stream()
                .filter(a -> !submitted.contains(a.getId()) && a.getDueAt().isAfter(now))
                .findFirst()
                .ifPresent(a -> {
                    v.setTickerAssignmentTitle(a.getTitle());
                    v.setTickerAssignment(dueLabel(a.getDueAt(), now));
                });

        // ---------- exams ----------
        List<ExamSchedule> exams = examDao.upcomingForSubjects(ids, today);
        List<ExamRow> rows = new ArrayList<>();
        for (ExamSchedule x : exams) {
            if (rows.size() == 4) {
                break;
            }
            ExamRow r = new ExamRow();
            r.setMonth(x.getExamDate().getMonth().getDisplayName(TextStyle.SHORT, Locale.ENGLISH));
            r.setDay(String.valueOf(x.getExamDate().getDayOfMonth()));
            r.setSubjectName(x.getSubject().getName());
            r.setCode(x.getSubject().getCode());
            r.setTimeRange(x.getStartTime().format(TIME) + " \u2013 " + x.getEndTime().format(TIME));
            rows.add(r);
        }
        v.setExams(rows);
        if (!exams.isEmpty()) {
            ExamSchedule first = exams.get(0);
            long inDays = ChronoUnit.DAYS.between(today, first.getExamDate());
            v.setTickerExamName(first.getExamName());
            v.setTickerExam(inDays <= 0 ? "today" : inDays == 1 ? "1 day" : inDays + " days");
            v.setExamMonthLabel(first.getExamDate().getMonth().getDisplayName(TextStyle.SHORT, Locale.ENGLISH)
                    + " " + first.getExamDate().getYear());
        }

        // ---------- fees summary (hostel fees only count for hostelers) ----------
        int feeCount = 0;
        java.math.BigDecimal feeSum = java.math.BigDecimal.ZERO;
        FeeRecord nextFee = null;
        for (FeeRecord f : feeDao.byStudent(studentId)) {
            if (f.isPaid() || ("HOSTEL".equals(f.getCategory()) && !st.isHosteler())) {
                continue;
            }
            feeCount++;
            feeSum = feeSum.add(f.getAmount());
            if (nextFee == null || f.getDueDate().isBefore(nextFee.getDueDate())) {
                nextFee = f;
            }
        }
        v.setFeesDueCount(feeCount);
        v.setFeesDueAmount(feeSum.stripTrailingZeros().toPlainString());
        if (nextFee != null) {
            v.setNextFeeTitle(nextFee.getTitle() + " (" + FeeStatus.of(nextFee, today) + ")");
            v.setNextFeeDue(nextFee.getDueDate().toString());
        }

        // ---------- fresh e-materials ----------
        List<MaterialRow> mats = new ArrayList<>();
        for (StudyMaterial m : materialDao.latestForSubjects(ids, 3)) {
            MaterialRow r = new MaterialRow();
            r.setId(m.getId());
            r.setTitle(m.getTitle());
            r.setSubjectName(m.getSubject().getName());
            r.setSizeLabel(String.format(Locale.ROOT, "%.1f MB", m.getSizeMb().doubleValue()));
            r.setIcon(iconFor(m.getFileType()));
            mats.add(r);
        }
        v.setMaterials(mats);

        // ---------- CIE banner ----------
        List<Mark> cie = markDao.byStudentAndType(studentId, "CIE-I");
        if (!cie.isEmpty()) {
            String names = cie.stream().map(m -> m.getSubject().getShortName()).collect(Collectors.joining(", "));
            Double avg = markDao.classAverage("CIE-I");
            v.setCieTitle("Continuous Internal Evaluation (CIE-I) Released");
            v.setCieText("Scores verified for " + names + "."
                    + (avg == null ? "" : " Class average: " + Text.pct1(avg) + " / "
                    + cie.get(0).getMaximum().stripTrailingZeros().toPlainString() + "."));
        }

        // ---------- campus notice ----------
        List<Announcement> notices = announcementDao.latestActive(now, 1);
        if (!notices.isEmpty()) {
            v.setNoticeTitle(notices.get(0).getTitle());
            v.setNoticeText(notices.get(0).getBody());
        }
        return v;
    }

    // ------------------------------------------------------------ helpers
    /** Finds the first time a weekly slot happens after "now" (looking at most one week ahead). */
    private Occurrence nextOccurrence(List<TimetableSlot> slots, LocalDateTime now) {
        Occurrence best = null;
        for (int d = 0; d < 8 && best == null; d++) {
            LocalDate date = now.toLocalDate().plusDays(d);
            int dow = date.getDayOfWeek().getValue();
            for (TimetableSlot t : slots) {
                if (t.getDayOfWeek() != dow) {
                    continue;
                }
                LocalDateTime start = date.atTime(t.getStartTime());
                if (start.isBefore(now)) {
                    continue;
                }
                if (best == null || start.isBefore(best.start())) {
                    best = new Occurrence(start, t);
                }
            }
        }
        return best;
    }

    private String label(LocalDateTime start, LocalDateTime now) {
        LocalDate today = now.toLocalDate();
        String time = start.format(TIME);
        if (start.toLocalDate().equals(today)) {
            long mins = Duration.between(now, start).toMinutes();
            return mins < 180 ? "Today " + time + " (in " + mins + " mins)" : "Today " + time;
        }
        if (start.toLocalDate().equals(today.plusDays(1))) {
            return "Tomorrow " + time;
        }
        return start.format(DAY_TIME);
    }

    private String dueLabel(LocalDateTime due, LocalDateTime now) {
        String time = due.format(TIME);
        if (due.toLocalDate().equals(now.toLocalDate())) {
            return "Today at " + time;
        }
        if (due.toLocalDate().equals(now.toLocalDate().plusDays(1))) {
            return "Tomorrow at " + time;
        }
        return due.format(DUE);
    }

    private String barClass(String status) {
        switch (status) {
            case AttendancePolicy.GREEN: return "bg-emerald-500";
            case AttendancePolicy.YELLOW: return "bg-amber-400";
            default: return "bg-red-500";
        }
    }

    private String chipClass(String status) {
        switch (status) {
            case AttendancePolicy.GREEN:
                return "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200";
            case AttendancePolicy.YELLOW:
                return "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200";
            default:
                return "bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-200";
        }
    }

    private String iconFor(String fileType) {
        switch (fileType == null ? "" : fileType.toUpperCase(Locale.ROOT)) {
            case "PDF": return "picture_as_pdf";
            case "SLIDES": return "slideshow";
            case "CODE": return "terminal";
            default: return "folder_zip";
        }
    }
}
