package com.campusconnect.service;

import com.campusconnect.config.AppProperties;
import com.campusconnect.dao.*;
import com.campusconnect.dto.ExamRow;
import com.campusconnect.dto.FacultyDashboardView.*;
import com.campusconnect.model.*;
import com.campusconnect.model.enums.FeedbackStatus;
import com.campusconnect.model.enums.NotificationColor;
import com.campusconnect.util.DemoContent;
import com.campusconnect.util.PasswordHasher;
import com.campusconnect.util.Text;
import com.campusconnect.util.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.*;

/** Business logic backing every /faculty/* web page and action. */
@Service
public class FacultyPortalService {

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH);
    private static final DateTimeFormatter DT_FMT = DateTimeFormatter.ofPattern("d MMM, HH:mm", Locale.ENGLISH);
    private static final DateTimeFormatter INPUT_DT_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter MON_FMT = DateTimeFormatter.ofPattern("MMM", Locale.ENGLISH);
    private static final DateTimeFormatter DAY_FMT = DateTimeFormatter.ofPattern("dd");

    private final FacultyDao facultyDao;
    private final UserDao userDao;
    private final SubjectDao subjectDao;
    private final EnrollmentDao enrollmentDao;
    private final StudentDao studentDao;
    private final AttendanceRecordDao attendanceDao;
    private final AssignmentDao assignmentDao;
    private final SubmissionDao submissionDao;
    private final StudyMaterialDao materialDao;
    private final MarkDao markDao;
    private final AnnouncementDao announcementDao;
    private final TimetableSlotDao timetableDao;
    private final ExamScheduleDao examDao;
    private final FeedbackDao feedbackDao;
    private final NotificationDao notificationDao;
    private final FacultyService facultyService;
    private final AppProperties props;

    @Autowired
    public FacultyPortalService(FacultyDao facultyDao, UserDao userDao, SubjectDao subjectDao,
            EnrollmentDao enrollmentDao, StudentDao studentDao, AttendanceRecordDao attendanceDao,
            AssignmentDao assignmentDao, SubmissionDao submissionDao, StudyMaterialDao materialDao,
            MarkDao markDao, AnnouncementDao announcementDao, TimetableSlotDao timetableDao,
            ExamScheduleDao examDao, FeedbackDao feedbackDao, NotificationDao notificationDao,
            FacultyService facultyService, AppProperties props) {
        this.facultyDao = facultyDao;
        this.userDao = userDao;
        this.subjectDao = subjectDao;
        this.enrollmentDao = enrollmentDao;
        this.studentDao = studentDao;
        this.attendanceDao = attendanceDao;
        this.assignmentDao = assignmentDao;
        this.submissionDao = submissionDao;
        this.materialDao = materialDao;
        this.markDao = markDao;
        this.announcementDao = announcementDao;
        this.timetableDao = timetableDao;
        this.examDao = examDao;
        this.feedbackDao = feedbackDao;
        this.notificationDao = notificationDao;
        this.facultyService = facultyService;
        this.props = props;
    }

    public Faculty requireFaculty(Long facultyId) {
        return facultyDao.findById(facultyId)
                .orElseThrow(() -> new IllegalStateException("Faculty not found: " + facultyId));
    }

    private Subject requireOwnedSubject(Long facultyId, Long subjectId) {
        Subject sub = subjectDao.findById(subjectId)
                .orElseThrow(() -> new IllegalArgumentException("Subject not found."));
        if (!sub.getFaculty().getId().equals(facultyId)) {
            throw new SecurityException("You are not assigned to this subject.");
        }
        return sub;
    }

    private Path uploadsRoot() throws IOException {
        String configured = props.get("uploads.dir", "");
        Path dir = configured.isBlank()
                ? Paths.get(System.getProperty("user.home"), ".campusconnect", "uploads")
                : Paths.get(configured);
        Files.createDirectories(dir);
        return dir.toAbsolutePath().normalize();
    }

    // ------------------------------------------------------------------ Subjects & Roster

    public SubjectsPageData subjectsPage(Long facultyId, Long selectedSubjectId) {
        SubjectsPageData data = new SubjectsPageData();
        List<Subject> list = subjectDao.byFaculty(facultyId);
        Map<Long, Long> counts = enrollmentDao.countBySubject();
        List<SubjectRow> rows = new ArrayList<>();
        Subject selected = null;
        for (Subject s : list) {
            SubjectRow r = new SubjectRow();
            r.setId(s.getId());
            r.setCode(s.getCode());
            r.setName(s.getName());
            r.setShortName(s.getShortName());
            r.setCredits(s.getCredits());
            r.setCategory(s.getCategory());
            r.setSemester(s.getSemester());
            r.setEnrolledCount(counts.getOrDefault(s.getId(), 0L));
            r.setSyllabusPct(s.getSyllabusCompletion() == null ? 0 : s.getSyllabusCompletion().intValue());
            r.setMeetingDays(s.getMeetingDays());
            rows.add(r);
            if (selectedSubjectId != null && s.getId().equals(selectedSubjectId)) {
                selected = s;
            }
        }
        if (selected == null && !list.isEmpty()) {
            selected = list.get(0);
        }
        data.setSubjects(rows);
        if (selected != null) {
            data.setSelectedSubjectId(selected.getId());
            data.setSelectedSubjectCode(selected.getCode());
            data.setSelectedSubjectName(selected.getName());
            data.setSelectedSyllabusPct(selected.getSyllabusCompletion() == null ? 0 : selected.getSyllabusCompletion().intValue());
            data.setSelectedMeetingDays(selected.getMeetingDays());
            Map<Long, long[]> attSummary = attendanceDao.summaryBySubject(selected.getId());
            List<RosterStudentRow> roster = new ArrayList<>();
            int minPct = props.getInt("attendance.min", 75);
            int greenPct = props.getInt("attendance.green.min", 85);
            for (Student st : enrollmentDao.studentsOf(selected.getId())) {
                long[] a = attSummary.getOrDefault(st.getId(), new long[]{0L, 0L});
                int pct = a[0] == 0 ? 100 : (int) Math.round((a[1] * 100.0) / a[0]);
                RosterStudentRow rs = new RosterStudentRow();
                rs.setStudentId(st.getId());
                rs.setEnrollmentNo(st.getEnrollmentNo());
                rs.setFullName(st.getUser().getFullName());
                rs.setEmail(st.getUser().getEmail());
                rs.setBranchCode(st.getBranchCode());
                rs.setSemester(st.getSemester());
                rs.setHeld(a[0]);
                rs.setAttended(a[1]);
                rs.setPct(pct);
                rs.setTone(a[0] == 0 ? "BLUE" : (pct >= greenPct ? "GREEN" : (pct >= minPct ? "YELLOW" : "RED")));
                roster.add(rs);
            }
            data.setRoster(roster);
        } else {
            data.setRoster(Collections.emptyList());
        }
        return data;
    }

    public void updateSyllabus(Long facultyId, Long subjectId, int syllabusPct, String meetingDays) {
        Subject sub = requireOwnedSubject(facultyId, subjectId);
        int clamped = Math.max(0, Math.min(100, syllabusPct));
        sub.setSyllabusCompletion(BigDecimal.valueOf(clamped));
        if (meetingDays != null && !meetingDays.trim().isEmpty()) {
            sub.setMeetingDays(meetingDays.trim().toUpperCase(Locale.ROOT));
        }
        subjectDao.update(sub);
    }

    // ------------------------------------------------------------------ Attendance

    public AttendancePageData attendancePage(Long facultyId, Long subjectId, LocalDate date) {
        LocalDate targetDate = date != null ? date : LocalDate.now(props.zone());
        AttendancePageData data = new AttendancePageData();
        data.setDateValue(targetDate.toString());
        data.setDateLabel(targetDate.format(DATE_FMT));

        List<Subject> subs = subjectDao.byFaculty(facultyId);
        List<SubjectRow> subRows = new ArrayList<>();
        Subject selected = null;
        for (Subject s : subs) {
            SubjectRow r = new SubjectRow();
            r.setId(s.getId());
            r.setCode(s.getCode());
            r.setName(s.getName());
            r.setShortName(s.getShortName());
            subRows.add(r);
            if (subjectId != null && s.getId().equals(subjectId)) selected = s;
        }
        if (selected == null && !subs.isEmpty()) selected = subs.get(0);
        data.setSubjects(subRows);

        if (selected != null) {
            data.setSelectedSubjectId(selected.getId());
            data.setSelectedSubjectCode(selected.getCode());
            data.setSelectedSubjectName(selected.getName());

            Map<Long, long[]> summary = attendanceDao.summaryBySubject(selected.getId());
            List<AttendanceRecord> onDate = attendanceDao.bySubjectAndDate(selected.getId(), targetDate);
            Map<Long, Boolean> dateMap = new HashMap<>();
            for (AttendanceRecord ar : onDate) {
                dateMap.put(ar.getStudent().getId(), ar.isPresent());
            }
            data.setAlreadyMarked(!dateMap.isEmpty());

            int minPct = props.getInt("attendance.min", 75);
            int greenPct = props.getInt("attendance.green.min", 85);
            List<AttendanceEntryRow> entries = new ArrayList<>();
            for (Student st : enrollmentDao.studentsOf(selected.getId())) {
                long[] counts = summary.getOrDefault(st.getId(), new long[]{0L, 0L});
                int pct = counts[0] == 0 ? 100 : (int) Math.round((counts[1] * 100.0) / counts[0]);
                AttendanceEntryRow row = new AttendanceEntryRow();
                row.setStudentId(st.getId());
                row.setEnrollmentNo(st.getEnrollmentNo());
                row.setFullName(st.getUser().getFullName());
                row.setHeld(counts[0]);
                row.setAttended(counts[1]);
                row.setPct(pct);
                row.setTone(counts[0] == 0 ? "BLUE" : (pct >= greenPct ? "GREEN" : (pct >= minPct ? "YELLOW" : "RED")));
                row.setPresent(dateMap.getOrDefault(st.getId(), true));
                entries.add(row);
            }
            data.setEntries(entries);
        } else {
            data.setEntries(Collections.emptyList());
        }
        return data;
    }

    public int saveAttendance(Long facultyId, Long subjectId, LocalDate date, Set<Long> presentStudentIds) {
        if (date == null) throw new IllegalArgumentException("Lecture date is required.");
        Subject sub = requireOwnedSubject(facultyId, subjectId);
        List<Student> enrolled = enrollmentDao.studentsOf(sub.getId());
        if (enrolled.isEmpty()) throw new IllegalArgumentException("No students enrolled in this subject.");

        Map<Long, Boolean> unmarked = new LinkedHashMap<>();
        int updated = 0;
        for (Student st : enrolled) {
            boolean isPresent = presentStudentIds.contains(st.getId());
            Optional<AttendanceRecord> existing = attendanceDao.findOne(st.getId(), sub.getId(), date);
            if (existing.isPresent()) {
                AttendanceRecord ar = existing.get();
                if (ar.isPresent() != isPresent) {
                    ar.setPresent(isPresent);
                    attendanceDao.update(ar);
                }
                updated++;
            } else {
                unmarked.put(st.getId(), isPresent);
            }
        }
        int savedNew = unmarked.isEmpty() ? 0 : facultyService.markAttendance(sub, date, unmarked);
        return savedNew + updated;
    }

    // ------------------------------------------------------------------ Assignments & Grading

    public AssignmentsPageData assignmentsPage(Long facultyId, Long subjectIdFilter, Long selectedAssignmentId) {
        AssignmentsPageData data = new AssignmentsPageData();
        List<Subject> subs = subjectDao.byFaculty(facultyId);
        List<SubjectRow> subRows = new ArrayList<>();
        for (Subject s : subs) {
            SubjectRow r = new SubjectRow();
            r.setId(s.getId());
            r.setCode(s.getCode());
            r.setName(s.getName());
            r.setShortName(s.getShortName());
            subRows.add(r);
        }
        data.setSubjects(subRows);

        List<Assignment> allAsgns = assignmentDao.forFaculty(facultyId);
        Map<Long, Long> enrolledCounts = enrollmentDao.countBySubject();
        LocalDateTime now = LocalDateTime.now(props.zone());

        List<AssignmentItem> items = new ArrayList<>();
        Assignment selected = null;
        for (Assignment a : allAsgns) {
            if (subjectIdFilter != null && !a.getSubject().getId().equals(subjectIdFilter)) continue;
            List<Submission> subsForA = submissionDao.byAssignment(a.getId());
            long graded = subsForA.stream().filter(s -> "GRADED".equalsIgnoreCase(s.getStatus())).count();
            AssignmentItem item = new AssignmentItem();
            item.setId(a.getId());
            item.setSubjectId(a.getSubject().getId());
            item.setSubjectCode(a.getSubject().getCode());
            item.setSubjectName(a.getSubject().getName());
            item.setTitle(a.getTitle());
            item.setDescription(a.getDescription() == null ? "" : a.getDescription());
            item.setDueLabel(a.getDueAt().format(DT_FMT));
            item.setMaxMarks(a.getMaxMarks());
            item.setOverdue(a.getDueAt().isBefore(now));
            item.setTotalEnrolled(enrolledCounts.getOrDefault(a.getSubject().getId(), 0L));
            item.setSubmittedCount(subsForA.size());
            item.setGradedCount(graded);
            items.add(item);
            if (selectedAssignmentId != null && a.getId().equals(selectedAssignmentId)) {
                selected = a;
            }
        }
        if (selected == null && !items.isEmpty()) {
            Long firstId = items.get(0).getId();
            selected = allAsgns.stream().filter(x -> x.getId().equals(firstId)).findFirst().orElse(null);
        }
        data.setAssignments(items);
        data.setDefaultDueValue(LocalDateTime.now(props.zone()).plusDays(7).withHour(23).withMinute(55).format(INPUT_DT_FMT));

        if (selected != null) {
            data.setSelectedAssignmentId(selected.getId());
            data.setSelectedAssignmentTitle(selected.getTitle());
            data.setSelectedSubjectCode(selected.getSubject().getCode());
            data.setSelectedMaxMarks(selected.getMaxMarks());
            List<Submission> list = submissionDao.byAssignment(selected.getId());
            List<SubmissionItem> subItems = new ArrayList<>();
            Set<Long> submittedStudentIds = new HashSet<>();
            for (Submission s : list) {
                submittedStudentIds.add(s.getStudent().getId());
                SubmissionItem si = new SubmissionItem();
                si.setSubmissionId(s.getId());
                si.setStudentId(s.getStudent().getId());
                si.setEnrollmentNo(s.getStudent().getEnrollmentNo());
                si.setStudentName(s.getStudent().getUser().getFullName());
                si.setSubmittedLabel(s.getSubmittedAt().format(DT_FMT));
                si.setStatus(s.getStatus());
                si.setMarksAwarded(s.getMarksAwarded() == null ? "" : s.getMarksAwarded().stripTrailingZeros().toPlainString());
                si.setMaxMarks(selected.getMaxMarks());
                subItems.add(si);
            }
            for (Student st : enrollmentDao.studentsOf(selected.getSubject().getId())) {
                if (!submittedStudentIds.contains(st.getId())) {
                    SubmissionItem si = new SubmissionItem();
                    si.setStudentId(st.getId());
                    si.setEnrollmentNo(st.getEnrollmentNo());
                    si.setStudentName(st.getUser().getFullName());
                    si.setSubmittedLabel("Not submitted");
                    si.setStatus("PENDING");
                    si.setMarksAwarded("");
                    si.setMaxMarks(selected.getMaxMarks());
                    subItems.add(si);
                }
            }
            data.setSubmissions(subItems);
        } else {
            data.setSubmissions(Collections.emptyList());
        }
        return data;
    }

    public Assignment createAssignment(Long facultyId, Long subjectId, String title, String description,
            LocalDateTime dueAt, int maxMarks) {
        if (Validator.isBlank(title)) throw new IllegalArgumentException("Assignment title is required.");
        if (dueAt == null) throw new IllegalArgumentException("Due date/time is required.");
        if (maxMarks <= 0 || maxMarks > 500) throw new IllegalArgumentException("Max marks must be between 1 and 500.");
        Subject sub = requireOwnedSubject(facultyId, subjectId);

        Assignment a = new Assignment();
        a.setSubject(sub);
        a.setTitle(title.trim());
        a.setDescription(description == null ? "" : description.trim());
        a.setDueAt(dueAt);
        a.setMaxMarks(maxMarks);
        Assignment saved = assignmentDao.save(a);

        LocalDateTime now = LocalDateTime.now(props.zone());
        for (Student st : enrollmentDao.studentsOf(sub.getId())) {
            Notification n = new Notification();
            n.setStudent(st);
            n.setColor(NotificationColor.BLUE);
            n.setCategory("ASSIGNMENT");
            n.setTitle("New assignment: " + sub.getShortName());
            n.setMessage(saved.getTitle() + " (Due " + saved.getDueAt().format(DT_FMT) + ")");
            n.setActionLabel("Open");
            n.setActionUrl("/app/assignments");
            n.setDedupeKey("new-asgn-" + saved.getId() + "-" + st.getId());
            n.setCreatedAt(now);
            n.setPopupShown(false);
            n.setEmailSent(false);
            try {
                notificationDao.save(n);
            } catch (RuntimeException ignored) {
                // Ignore dedupe conflicts
            }
        }
        return saved;
    }

    public void gradeSubmission(Long facultyId, Long submissionId, BigDecimal marks) {
        Submission sub = submissionDao.findById(submissionId)
                .orElseThrow(() -> new IllegalArgumentException("Submission not found."));
        requireOwnedSubject(facultyId, sub.getAssignment().getSubject().getId());
        int max = sub.getAssignment().getMaxMarks();
        if (marks == null || marks.compareTo(BigDecimal.ZERO) < 0 || marks.compareTo(BigDecimal.valueOf(max)) > 0) {
            throw new IllegalArgumentException("Marks must be between 0 and " + max + ".");
        }
        sub.setMarksAwarded(marks.setScale(2, RoundingMode.HALF_UP));
        sub.setStatus("GRADED");
        submissionDao.update(sub);
    }

    // ------------------------------------------------------------------ E-Content Materials

    public MaterialsPageData materialsPage(Long facultyId, Long subjectIdFilter) {
        MaterialsPageData data = new MaterialsPageData();
        List<Subject> subs = subjectDao.byFaculty(facultyId);
        List<SubjectRow> subRows = new ArrayList<>();
        for (Subject s : subs) {
            SubjectRow r = new SubjectRow();
            r.setId(s.getId());
            r.setCode(s.getCode());
            r.setName(s.getName());
            r.setShortName(s.getShortName());
            subRows.add(r);
        }
        data.setSubjects(subRows);

        List<StudyMaterial> mats = materialDao.byFaculty(facultyId);
        List<MaterialItem> items = new ArrayList<>();
        for (StudyMaterial m : mats) {
            if (subjectIdFilter != null && !m.getSubject().getId().equals(subjectIdFilter)) continue;
            MaterialItem mi = new MaterialItem();
            mi.setId(m.getId());
            mi.setSubjectId(m.getSubject().getId());
            mi.setSubjectCode(m.getSubject().getCode());
            mi.setSubjectName(m.getSubject().getShortName());
            mi.setTitle(m.getTitle());
            mi.setFileType(m.getFileType());
            mi.setSizeLabel(FacultyDashboardService.formatSize(m.getSizeMb()));
            mi.setIcon(FacultyDashboardService.materialIcon(m.getFileType()));
            mi.setUploadedLabel(m.getUploadedAt() == null ? "" : m.getUploadedAt().format(DT_FMT));
            mi.setFilePath(m.getFilePath());
            items.add(mi);
        }
        data.setMaterials(items);
        return data;
    }

    public int uploadMaterial(Long facultyId, Long subjectId, String title, String fileType,
            String originalFilename, InputStream fileStream, long sizeBytes, String fallbackPath) throws IOException {
        if (Validator.isBlank(title)) throw new IllegalArgumentException("Material title is required.");
        Subject sub = requireOwnedSubject(facultyId, subjectId);
        Faculty faculty = requireFaculty(facultyId);
        String type = normalizeFileType(fileType);

        String storedPath;
        BigDecimal sizeMb;
        if (fileStream != null && sizeBytes > 0) {
            String safeName = originalFilename == null ? "file.dat"
                    : originalFilename.replaceAll("[^A-Za-z0-9._-]", "_");
            Path root = uploadsRoot();
            Path target = root.resolve(UUID.randomUUID() + "_" + safeName).normalize();
            if (!target.startsWith(root)) {
                throw new SecurityException("Invalid file name.");
            }
            Files.copy(fileStream, target, StandardCopyOption.REPLACE_EXISTING);
            storedPath = target.toString();
            sizeMb = BigDecimal.valueOf(Math.max(0.1, sizeBytes / (1024.0 * 1024.0))).setScale(2, RoundingMode.HALF_UP);
        } else {
            storedPath = Validator.isBlank(fallbackPath)
                    ? "demo/" + sub.getShortName().toLowerCase(Locale.ROOT) + "-" + System.currentTimeMillis()
                    : fallbackPath.trim();
            sizeMb = new BigDecimal("1.00");
        }
        return facultyService.uploadMaterial(faculty, sub, title.trim(), type, sizeMb, storedPath);
    }

    public void deleteMaterial(Long facultyId, Long materialId) {
        StudyMaterial m = materialDao.findById(materialId)
                .orElseThrow(() -> new IllegalArgumentException("Material not found."));
        boolean ownsSubject = m.getSubject().getFaculty().getId().equals(facultyId);
        boolean uploadedByMe = m.getUploadedBy() != null && m.getUploadedBy().getId().equals(facultyId);
        if (!ownsSubject && !uploadedByMe) {
            throw new SecurityException("Not allowed to remove this material.");
        }
        materialDao.delete(m);
        if (m.getFilePath() != null && !m.getFilePath().startsWith("demo/")) {
            try {
                Path p = Paths.get(m.getFilePath()).toAbsolutePath().normalize();
                if (p.startsWith(uploadsRoot())) {
                    Files.deleteIfExists(p);
                }
            } catch (IOException ignored) {
                // Best effort cleanup
            }
        }
    }

    public FilePayload loadMaterialFile(Long facultyId, Long materialId) throws IOException {
        StudyMaterial m = materialDao.findById(materialId)
                .orElseThrow(() -> new IllegalArgumentException("Material not found."));
        boolean ownsSubject = m.getSubject().getFaculty().getId().equals(facultyId);
        boolean uploadedByMe = m.getUploadedBy() != null && m.getUploadedBy().getId().equals(facultyId);
        if (!ownsSubject && !uploadedByMe) {
            throw new SecurityException("Access denied.");
        }
        Path disk = m.getFilePath() == null ? null : Paths.get(m.getFilePath());
        if (disk != null && Files.isRegularFile(disk)) {
            byte[] bytes = Files.readAllBytes(disk);
            String filename = disk.getFileName().toString();
            String mime = Files.probeContentType(disk);
            if (mime == null) mime = defaultMime(m.getFileType());
            return new FilePayload(filename, mime, bytes);
        }
        String safeTitle = m.getTitle().replaceAll("[^A-Za-z0-9._-]", "_");
        String facultyName = m.getUploadedBy() != null ? m.getUploadedBy().getUser().getFullName() : "Faculty";
        switch (m.getFileType().toUpperCase(Locale.ROOT)) {
            case "SLIDES":
                return new FilePayload(safeTitle + ".pdf", "application/pdf",
                        DemoContent.slidesPdf(m.getTitle(), m.getSubject().getName()));
            case "CODE":
                return new FilePayload(safeTitle + ".txt", "text/plain; charset=UTF-8",
                        DemoContent.codeSample(m.getSubject().getShortName()).getBytes(StandardCharsets.UTF_8));
            case "ZIP":
                return new FilePayload(safeTitle + ".txt", "text/plain; charset=UTF-8",
                        DemoContent.zipListing(m.getTitle()).getBytes(StandardCharsets.UTF_8));
            default:
                return new FilePayload(safeTitle + ".pdf", "application/pdf",
                        DemoContent.notesPdf(m.getTitle(), m.getSubject().getName(), facultyName));
        }
    }

    public Map<String, Object> previewInfo(Long facultyId, Long materialId, String ctx) throws IOException {
        StudyMaterial m = materialDao.findById(materialId)
                .orElseThrow(() -> new IllegalArgumentException("Material not found."));
        boolean ownsSubject = m.getSubject().getFaculty().getId().equals(facultyId);
        boolean uploadedByMe = m.getUploadedBy() != null && m.getUploadedBy().getId().equals(facultyId);
        if (!ownsSubject && !uploadedByMe) {
            throw new SecurityException("Access denied.");
        }
        Path disk = m.getFilePath() == null ? null : Paths.get(m.getFilePath());
        String kind = PortalService.previewKind(disk != null && Files.isRegularFile(disk) ? disk : null, m.getFileType());
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("ok", true);
        out.put("kind", kind == null ? "other" : kind.toLowerCase(Locale.ROOT));
        out.put("title", m.getTitle());
        out.put("subject", m.getSubject().getCode() + " - " + m.getSubject().getName());
        out.put("type", m.getFileType());
        out.put("size", FacultyDashboardService.formatSize(m.getSizeMb()));
        out.put("by", m.getUploadedBy() != null ? m.getUploadedBy().getUser().getFullName() : "Faculty");
        out.put("at", m.getUploadedAt() == null ? "" : m.getUploadedAt().toLocalDate().format(DATE_FMT));
        out.put("downloadUrl", ctx + "/faculty/download?id=" + m.getId());
        out.put("previewUrl", ctx + "/faculty/download?inline=1&id=" + m.getId());
        return out;
    }

    // ------------------------------------------------------------------ Marks

    public MarksPageData marksPage(Long facultyId, Long subjectId, String examType) {
        MarksPageData data = new MarksPageData();
        String type = Validator.isBlank(examType) ? "CIE-I" : examType.trim();
        data.setSelectedExamType(type);
        data.setExamTypes(List.of("CIE-I", "CIE-II", "Mid-Sem", "End-Sem", "Lab"));

        List<Subject> subs = subjectDao.byFaculty(facultyId);
        List<SubjectRow> subRows = new ArrayList<>();
        List<Long> subIds = new ArrayList<>();
        Subject selected = null;
        for (Subject s : subs) {
            subIds.add(s.getId());
            SubjectRow r = new SubjectRow();
            r.setId(s.getId());
            r.setCode(s.getCode());
            r.setName(s.getName());
            r.setShortName(s.getShortName());
            subRows.add(r);
            if (subjectId != null && s.getId().equals(subjectId)) selected = s;
        }
        if (selected == null && !subs.isEmpty()) selected = subs.get(0);
        data.setSubjects(subRows);

        if (selected != null) {
            data.setSelectedSubjectId(selected.getId());
            data.setSelectedSubjectCode(selected.getCode());
            data.setSelectedSubjectName(selected.getName());

            List<Mark> existing = markDao.bySubjectAndType(selected.getId(), type);
            Map<Long, Mark> markByStudent = new HashMap<>();
            BigDecimal maxDefault = new BigDecimal("30");
            for (Mark m : existing) {
                markByStudent.put(m.getStudent().getId(), m);
                if (m.getMaximum() != null) maxDefault = m.getMaximum().stripTrailingZeros();
            }
            data.setDefaultMaximum(maxDefault.toPlainString());

            List<StudentMarkRow> rows = new ArrayList<>();
            for (Student st : enrollmentDao.studentsOf(selected.getId())) {
                Mark m = markByStudent.get(st.getId());
                StudentMarkRow sr = new StudentMarkRow();
                sr.setStudentId(st.getId());
                sr.setEnrollmentNo(st.getEnrollmentNo());
                sr.setFullName(st.getUser().getFullName());
                sr.setObtained(m == null ? "" : m.getObtained().stripTrailingZeros().toPlainString());
                sr.setMaximum(m == null ? "" : m.getMaximum().stripTrailingZeros().toPlainString());
                sr.setPublishedLabel(m == null || m.getPublishedOn() == null ? "Not published" : m.getPublishedOn().format(DATE_FMT));
                rows.add(sr);
            }
            data.setEntries(rows);
        } else {
            data.setDefaultMaximum("30");
            data.setEntries(Collections.emptyList());
        }

        List<Mark> recent = markDao.bySubjects(subIds);
        List<MarkHistoryRow> hist = new ArrayList<>();
        for (int i = 0; i < Math.min(20, recent.size()); i++) {
            Mark m = recent.get(i);
            MarkHistoryRow hr = new MarkHistoryRow();
            hr.setSubjectCode(m.getSubject().getCode());
            hr.setStudentEnroll(m.getStudent().getEnrollmentNo());
            hr.setStudentName(m.getStudent().getUser().getFullName());
            hr.setExamType(m.getExamType());
            hr.setScoreLabel(m.getObtained().stripTrailingZeros().toPlainString()
                    + " / " + m.getMaximum().stripTrailingZeros().toPlainString());
            hr.setPublishedLabel(m.getPublishedOn() == null ? "" : m.getPublishedOn().format(DATE_FMT));
            hist.add(hr);
        }
        data.setHistory(hist);
        return data;
    }

    public int publishMarks(Long facultyId, Long subjectId, String examType, BigDecimal maximum,
            Map<Long, BigDecimal> scoresByStudent) {
        if (Validator.isBlank(examType)) throw new IllegalArgumentException("Exam component is required.");
        if (maximum == null || maximum.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Maximum marks must be greater than zero.");
        }
        Subject sub = requireOwnedSubject(facultyId, subjectId);
        String type = examType.trim();

        Map<Long, BigDecimal> newEntries = new LinkedHashMap<>();
        int updated = 0;
        LocalDate today = LocalDate.now(props.zone());
        for (Map.Entry<Long, BigDecimal> e : scoresByStudent.entrySet()) {
            BigDecimal val = e.getValue();
            if (val.compareTo(BigDecimal.ZERO) < 0 || val.compareTo(maximum) > 0) {
                throw new IllegalArgumentException("Marks must be between 0 and " + maximum.toPlainString() + ".");
            }
            Optional<Mark> existing = markDao.find(e.getKey(), sub.getId(), type);
            if (existing.isPresent()) {
                Mark m = existing.get();
                m.setObtained(val);
                m.setMaximum(maximum);
                m.setPublishedOn(today);
                markDao.update(m);
                updated++;
            } else {
                newEntries.put(e.getKey(), val);
            }
        }
        int created = newEntries.isEmpty() ? 0 : facultyService.publishMarks(sub, type, maximum, newEntries);
        return created + updated;
    }

    // ------------------------------------------------------------------ Announcements

    public AnnouncementsPageData announcementsPage(Long facultyId) {
        AnnouncementsPageData data = new AnnouncementsPageData();
        List<Subject> subs = subjectDao.byFaculty(facultyId);
        List<SubjectRow> subRows = new ArrayList<>();
        for (Subject s : subs) {
            SubjectRow r = new SubjectRow();
            r.setId(s.getId());
            r.setCode(s.getCode());
            r.setName(s.getName());
            r.setShortName(s.getShortName());
            subRows.add(r);
        }
        data.setSubjects(subRows);

        List<NoticeRow> myRows = new ArrayList<>();
        for (Announcement a : announcementDao.byFaculty(facultyId)) {
            myRows.add(toNoticeRow(a));
        }
        List<NoticeRow> campusRows = new ArrayList<>();
        for (Announcement a : announcementDao.latest(20)) {
            campusRows.add(toNoticeRow(a));
        }
        data.setMyNotices(myRows);
        data.setCampusNotices(campusRows);
        return data;
    }

    public int postAnnouncement(Long facultyId, Long subjectIdOrNull, String title, String body, boolean important) {
        if (Validator.isBlank(title) || Validator.isBlank(body)) {
            throw new IllegalArgumentException("Title and message are required.");
        }
        Faculty faculty = requireFaculty(facultyId);
        Subject subject = subjectIdOrNull == null ? null : requireOwnedSubject(facultyId, subjectIdOrNull);
        return facultyService.postAnnouncement(faculty, subject, title.trim(), body.trim(), important);
    }

    public void deleteAnnouncement(Long facultyId, Long announcementId) {
        Announcement a = announcementDao.findById(announcementId)
                .orElseThrow(() -> new IllegalArgumentException("Announcement not found."));
        if (a.getPostedBy() == null || !a.getPostedBy().getId().equals(facultyId)) {
            throw new SecurityException("You can only delete announcements you posted.");
        }
        announcementDao.delete(a);
    }

    // ------------------------------------------------------------------ Timetable & Exams

    public TimetablePageData timetablePage(Long facultyId) {
        TimetablePageData data = new TimetablePageData();
        Map<String, List<ScheduleRow>> byDay = new LinkedHashMap<>();
        for (int dow = 1; dow <= 6; dow++) {
            String dayName = DayOfWeek.of(dow).getDisplayName(TextStyle.FULL, Locale.ENGLISH);
            byDay.put(dayName, new ArrayList<>());
        }
        for (TimetableSlot slot : timetableDao.forFaculty(facultyId)) {
            String dayName = DayOfWeek.of(slot.getDayOfWeek()).getDisplayName(TextStyle.FULL, Locale.ENGLISH);
            ScheduleRow sr = new ScheduleRow();
            sr.setSubjectCode(slot.getSubject().getCode());
            sr.setSubjectName(slot.getSubject().getName());
            sr.setTimeRange(slot.getStartTime().format(TIME_FMT) + " - " + slot.getEndTime().format(TIME_FMT));
            sr.setRoom(slot.getRoom());
            sr.setBlock(slot.getBlock() == null ? "" : slot.getBlock());
            sr.setTopic(slot.getTopic() == null ? "" : slot.getTopic());
            sr.setDayLabel(dayName);
            byDay.computeIfAbsent(dayName, k -> new ArrayList<>()).add(sr);
        }
        data.setByDay(byDay);

        LocalDate today = LocalDate.now(props.zone());
        List<ExamRow> examRows = new ArrayList<>();
        for (ExamSchedule ex : examDao.upcomingForFaculty(facultyId, today)) {
            ExamRow er = new ExamRow();
            er.setMonth(ex.getExamDate().format(MON_FMT).toUpperCase(Locale.ENGLISH));
            er.setDay(ex.getExamDate().format(DAY_FMT));
            er.setSubjectName(ex.getSubject().getName());
            er.setTimeRange(ex.getExamName() + " • " + ex.getStartTime().format(TIME_FMT) + "-" + ex.getEndTime().format(TIME_FMT));
            er.setCode(ex.getSubject().getCode());
            examRows.add(er);
        }
        data.setExams(examRows);
        return data;
    }

    // ------------------------------------------------------------------ Feedback Inbox

    public List<FeedbackRow> feedbackInbox(Long facultyId) {
        List<FeedbackRow> out = new ArrayList<>();
        for (Feedback fb : feedbackDao.forFaculty(facultyId, 100)) {
            FeedbackRow fr = new FeedbackRow();
            fr.setId(fb.getId());
            fr.setSubjectCode(fb.getSubject() != null ? fb.getSubject().getCode() : "General");
            fr.setStudentName(fb.getStudent().getUser().getFullName());
            fr.setCategory(fb.getCategory() == null ? "Course" : fb.getCategory());
            String msg = fb.getProcessedText() != null && !fb.getProcessedText().isBlank()
                    ? fb.getProcessedText() : fb.getRawText();
            fr.setMessage(msg);
            fr.setStatus(fb.getStatus().name());
            fr.setCreatedLabel(fb.getCreatedAt() == null ? "" : fb.getCreatedAt().toLocalDate().format(DATE_FMT));
            out.add(fr);
        }
        return out;
    }

    public void updateFeedbackStatus(Long facultyId, Long feedbackId, FeedbackStatus status) {
        Feedback fb = feedbackDao.findById(feedbackId)
                .orElseThrow(() -> new IllegalArgumentException("Feedback record not found."));
        if (fb.getFaculty() == null || !fb.getFaculty().getId().equals(facultyId)) {
            throw new SecurityException("Not assigned to this feedback.");
        }
        fb.setStatus(status);
        feedbackDao.update(fb);
    }

    // ------------------------------------------------------------------ Profile & Password

    public void updateProfile(Long facultyId, String cabin, String currentPassword, String newPassword) {
        Faculty f = requireFaculty(facultyId);
        if (cabin != null) {
            f.setCabin(cabin.trim());
            facultyDao.update(f);
        }
        if (!Validator.isBlank(newPassword)) {
            User u = f.getUser();
            if (Validator.isBlank(currentPassword) || !PasswordHasher.verify(currentPassword, u.getPasswordHash())) {
                throw new IllegalArgumentException("Current password is incorrect.");
            }
            if (!Validator.isStrongPassword(newPassword)) {
                throw new IllegalArgumentException("New password must be at least 8 characters and include a digit.");
            }
            u.setPasswordHash(PasswordHasher.hash(newPassword));
            userDao.update(u);
        }
    }

    // ------------------------------------------------------------------ Search

    public List<String> suggest(Long facultyId) {
        List<String> out = new ArrayList<>();
        for (Subject s : subjectDao.byFaculty(facultyId)) {
            out.add(s.getCode());
            out.add(s.getShortName());
        }
        out.addAll(List.of("Attendance", "Assignments", "Marks", "E-Content", "Timetable", "Announcements"));
        return out.stream().distinct().limit(8).toList();
    }

    public List<Map<String, String>> searchRows(Long facultyId, String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) return Collections.emptyList();
        List<Map<String, String>> out = new ArrayList<>();

        addPageMatch(out, q, "Attendance Register", "Mark or edit lecture attendance", "/faculty/attendance", "att attend present absent");
        addPageMatch(out, q, "Assignments & Grading", "Create tasks and grade submissions", "/faculty/assignments", "asgn assign grade homework");
        addPageMatch(out, q, "Marks Entry", "Publish CIE and exam scores", "/faculty/marks", "mark cie score grade result");
        addPageMatch(out, q, "E-Content Library", "Upload slides, PDFs and lab code", "/faculty/materials", "econtent material upload pdf slides");
        addPageMatch(out, q, "Teaching Timetable", "Weekly schedule and exam duty", "/faculty/timetable", "timetable schedule exam slot");
        addPageMatch(out, q, "Announcements", "Post class notices", "/faculty/announcements", "notice announce broadcast");
        addPageMatch(out, q, "Student Feedback", "Review feedback inbox", "/faculty/feedback", "feedback review inbox");

        for (Subject s : subjectDao.byFaculty(facultyId)) {
            if (containsAny(q, s.getCode(), s.getName(), s.getShortName())) {
                out.add(resultRow("Subject", s.getCode() + " • " + s.getName(),
                        "Sem " + s.getSemester() + " • " + s.getCredits() + " credits",
                        "/faculty/my-subjects?subjectId=" + s.getId(), s.getCategory(), "BLUE"));
            }
            for (Student st : enrollmentDao.studentsOf(s.getId())) {
                if (containsAny(q, st.getEnrollmentNo(), st.getUser().getFullName(), st.getUser().getEmail())) {
                    out.add(resultRow("Student", st.getUser().getFullName(),
                            st.getEnrollmentNo() + " • " + s.getCode(),
                            "/faculty/my-subjects?subjectId=" + s.getId(), "Sem " + st.getSemester(), "GREEN"));
                }
            }
        }
        for (Assignment a : assignmentDao.forFaculty(facultyId)) {
            if (containsAny(q, a.getTitle(), a.getSubject().getCode(), a.getDescription())) {
                out.add(resultRow("Assignment", a.getTitle(),
                        a.getSubject().getCode() + " • Due " + a.getDueAt().format(DT_FMT),
                        "/faculty/assignments?id=" + a.getId(), a.getMaxMarks() + " pts", "YELLOW"));
            }
        }
        for (StudyMaterial m : materialDao.byFaculty(facultyId)) {
            if (containsAny(q, m.getTitle(), m.getSubject().getCode(), m.getFileType())) {
                out.add(resultRow("Material", m.getTitle(),
                        m.getSubject().getCode() + " • " + m.getFileType(),
                        "/faculty/materials", FacultyDashboardService.formatSize(m.getSizeMb()), "BLUE"));
            }
        }
        return out.stream().limit(20).toList();
    }

    // ------------------------------------------------------------------ Helpers

    private static NoticeRow toNoticeRow(Announcement a) {
        NoticeRow nr = new NoticeRow();
        nr.setId(a.getId());
        nr.setTitle(a.getTitle());
        nr.setBody(a.getBody());
        nr.setSubjectCode(a.getSubject() != null ? a.getSubject().getCode() : "Campus-wide");
        nr.setAuthorName(a.getPostedBy() != null ? a.getPostedBy().getUser().getFullName() : "Administration");
        nr.setImportant(a.isImportant());
        nr.setCreatedLabel(a.getCreatedAt() == null ? "" : a.getCreatedAt().toLocalDate().format(DATE_FMT));
        return nr;
    }

    private static String normalizeFileType(String fileType) {
        if (fileType == null) return "PDF";
        switch (fileType.trim().toUpperCase(Locale.ROOT)) {
            case "SLIDES": case "CODE": case "ZIP": case "PDF":
                return fileType.trim().toUpperCase(Locale.ROOT);
            default:
                return "PDF";
        }
    }

    private static String defaultMime(String fileType) {
        switch (normalizeFileType(fileType)) {
            case "CODE": return "text/plain; charset=UTF-8";
            case "ZIP": return "application/zip";
            default: return "application/pdf";
        }
    }

    private static boolean containsAny(String q, String... values) {
        for (String v : values) {
            if (v != null && v.toLowerCase(Locale.ROOT).contains(q)) return true;
        }
        return false;
    }

    private static void addPageMatch(List<Map<String, String>> out, String q, String title, String sub, String href, String keys) {
        if (title.toLowerCase(Locale.ROOT).contains(q) || keys.contains(q)) {
            out.add(resultRow("Page", title, sub, href, "Faculty", "NONE"));
        }
    }

    private static Map<String, String> resultRow(String type, String title, String sub, String href, String badge, String tone) {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("type", type);
        m.put("title", title);
        m.put("sub", sub);
        m.put("href", href);
        m.put("badge", badge);
        m.put("tone", tone);
        return m;
    }

    // ------------------------------------------------------------------ Page Data DTOs

    public static class SubjectsPageData {
        private List<SubjectRow> subjects;
        private Long selectedSubjectId;
        private String selectedSubjectCode;
        private String selectedSubjectName;
        private int selectedSyllabusPct;
        private String selectedMeetingDays;
        private List<RosterStudentRow> roster;

        public List<SubjectRow> getSubjects() { return subjects; }
        public void setSubjects(List<SubjectRow> subjects) { this.subjects = subjects; }
        public Long getSelectedSubjectId() { return selectedSubjectId; }
        public void setSelectedSubjectId(Long selectedSubjectId) { this.selectedSubjectId = selectedSubjectId; }
        public String getSelectedSubjectCode() { return selectedSubjectCode; }
        public void setSelectedSubjectCode(String selectedSubjectCode) { this.selectedSubjectCode = selectedSubjectCode; }
        public String getSelectedSubjectName() { return selectedSubjectName; }
        public void setSelectedSubjectName(String selectedSubjectName) { this.selectedSubjectName = selectedSubjectName; }
        public int getSelectedSyllabusPct() { return selectedSyllabusPct; }
        public void setSelectedSyllabusPct(int selectedSyllabusPct) { this.selectedSyllabusPct = selectedSyllabusPct; }
        public String getSelectedMeetingDays() { return selectedMeetingDays; }
        public void setSelectedMeetingDays(String selectedMeetingDays) { this.selectedMeetingDays = selectedMeetingDays; }
        public List<RosterStudentRow> getRoster() { return roster; }
        public void setRoster(List<RosterStudentRow> roster) { this.roster = roster; }
    }

    public static class RosterStudentRow {
        private Long studentId;
        private String enrollmentNo;
        private String fullName;
        private String email;
        private String branchCode;
        private int semester;
        private long held;
        private long attended;
        private int pct;
        private String tone;

        public Long getStudentId() { return studentId; }
        public void setStudentId(Long studentId) { this.studentId = studentId; }
        public String getEnrollmentNo() { return enrollmentNo; }
        public void setEnrollmentNo(String enrollmentNo) { this.enrollmentNo = enrollmentNo; }
        public String getFullName() { return fullName; }
        public void setFullName(String fullName) { this.fullName = fullName; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getBranchCode() { return branchCode; }
        public void setBranchCode(String branchCode) { this.branchCode = branchCode; }
        public int getSemester() { return semester; }
        public void setSemester(int semester) { this.semester = semester; }
        public long getHeld() { return held; }
        public void setHeld(long held) { this.held = held; }
        public long getAttended() { return attended; }
        public void setAttended(long attended) { this.attended = attended; }
        public int getPct() { return pct; }
        public void setPct(int pct) { this.pct = pct; }
        public String getTone() { return tone; }
        public void setTone(String tone) { this.tone = tone; }
    }

    public static class AttendancePageData {
        private List<SubjectRow> subjects;
        private Long selectedSubjectId;
        private String selectedSubjectCode;
        private String selectedSubjectName;
        private String dateValue;
        private String dateLabel;
        private boolean alreadyMarked;
        private List<AttendanceEntryRow> entries;

        public List<SubjectRow> getSubjects() { return subjects; }
        public void setSubjects(List<SubjectRow> subjects) { this.subjects = subjects; }
        public Long getSelectedSubjectId() { return selectedSubjectId; }
        public void setSelectedSubjectId(Long selectedSubjectId) { this.selectedSubjectId = selectedSubjectId; }
        public String getSelectedSubjectCode() { return selectedSubjectCode; }
        public void setSelectedSubjectCode(String selectedSubjectCode) { this.selectedSubjectCode = selectedSubjectCode; }
        public String getSelectedSubjectName() { return selectedSubjectName; }
        public void setSelectedSubjectName(String selectedSubjectName) { this.selectedSubjectName = selectedSubjectName; }
        public String getDateValue() { return dateValue; }
        public void setDateValue(String dateValue) { this.dateValue = dateValue; }
        public String getDateLabel() { return dateLabel; }
        public void setDateLabel(String dateLabel) { this.dateLabel = dateLabel; }
        public boolean isAlreadyMarked() { return alreadyMarked; }
        public void setAlreadyMarked(boolean alreadyMarked) { this.alreadyMarked = alreadyMarked; }
        public List<AttendanceEntryRow> getEntries() { return entries; }
        public void setEntries(List<AttendanceEntryRow> entries) { this.entries = entries; }
    }

    public static class AttendanceEntryRow {
        private Long studentId;
        private String enrollmentNo;
        private String fullName;
        private long held;
        private long attended;
        private int pct;
        private String tone;
        private boolean present;

        public Long getStudentId() { return studentId; }
        public void setStudentId(Long studentId) { this.studentId = studentId; }
        public String getEnrollmentNo() { return enrollmentNo; }
        public void setEnrollmentNo(String enrollmentNo) { this.enrollmentNo = enrollmentNo; }
        public String getFullName() { return fullName; }
        public void setFullName(String fullName) { this.fullName = fullName; }
        public long getHeld() { return held; }
        public void setHeld(long held) { this.held = held; }
        public long getAttended() { return attended; }
        public void setAttended(long attended) { this.attended = attended; }
        public int getPct() { return pct; }
        public void setPct(int pct) { this.pct = pct; }
        public String getTone() { return tone; }
        public void setTone(String tone) { this.tone = tone; }
        public boolean isPresent() { return present; }
        public void setPresent(boolean present) { this.present = present; }
    }

    public static class AssignmentsPageData {
        private List<SubjectRow> subjects;
        private List<AssignmentItem> assignments;
        private Long selectedAssignmentId;
        private String selectedAssignmentTitle;
        private String selectedSubjectCode;
        private int selectedMaxMarks;
        private String defaultDueValue;
        private List<SubmissionItem> submissions;

        public List<SubjectRow> getSubjects() { return subjects; }
        public void setSubjects(List<SubjectRow> subjects) { this.subjects = subjects; }
        public List<AssignmentItem> getAssignments() { return assignments; }
        public void setAssignments(List<AssignmentItem> assignments) { this.assignments = assignments; }
        public Long getSelectedAssignmentId() { return selectedAssignmentId; }
        public void setSelectedAssignmentId(Long selectedAssignmentId) { this.selectedAssignmentId = selectedAssignmentId; }
        public String getSelectedAssignmentTitle() { return selectedAssignmentTitle; }
        public void setSelectedAssignmentTitle(String selectedAssignmentTitle) { this.selectedAssignmentTitle = selectedAssignmentTitle; }
        public String getSelectedSubjectCode() { return selectedSubjectCode; }
        public void setSelectedSubjectCode(String selectedSubjectCode) { this.selectedSubjectCode = selectedSubjectCode; }
        public int getSelectedMaxMarks() { return selectedMaxMarks; }
        public void setSelectedMaxMarks(int selectedMaxMarks) { this.selectedMaxMarks = selectedMaxMarks; }
        public String getDefaultDueValue() { return defaultDueValue; }
        public void setDefaultDueValue(String defaultDueValue) { this.defaultDueValue = defaultDueValue; }
        public List<SubmissionItem> getSubmissions() { return submissions; }
        public void setSubmissions(List<SubmissionItem> submissions) { this.submissions = submissions; }
    }

    public static class AssignmentItem {
        private Long id;
        private Long subjectId;
        private String subjectCode;
        private String subjectName;
        private String title;
        private String description;
        private String dueLabel;
        private int maxMarks;
        private boolean overdue;
        private long totalEnrolled;
        private long submittedCount;
        private long gradedCount;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public Long getSubjectId() { return subjectId; }
        public void setSubjectId(Long subjectId) { this.subjectId = subjectId; }
        public String getSubjectCode() { return subjectCode; }
        public void setSubjectCode(String subjectCode) { this.subjectCode = subjectCode; }
        public String getSubjectName() { return subjectName; }
        public void setSubjectName(String subjectName) { this.subjectName = subjectName; }
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        public String getDueLabel() { return dueLabel; }
        public void setDueLabel(String dueLabel) { this.dueLabel = dueLabel; }
        public int getMaxMarks() { return maxMarks; }
        public void setMaxMarks(int maxMarks) { this.maxMarks = maxMarks; }
        public boolean isOverdue() { return overdue; }
        public void setOverdue(boolean overdue) { this.overdue = overdue; }
        public long getTotalEnrolled() { return totalEnrolled; }
        public void setTotalEnrolled(long totalEnrolled) { this.totalEnrolled = totalEnrolled; }
        public long getSubmittedCount() { return submittedCount; }
        public void setSubmittedCount(long submittedCount) { this.submittedCount = submittedCount; }
        public long getGradedCount() { return gradedCount; }
        public void setGradedCount(long gradedCount) { this.gradedCount = gradedCount; }
    }

    public static class SubmissionItem {
        private Long submissionId;
        private Long studentId;
        private String enrollmentNo;
        private String studentName;
        private String submittedLabel;
        private String status;
        private String marksAwarded;
        private int maxMarks;

        public Long getSubmissionId() { return submissionId; }
        public void setSubmissionId(Long submissionId) { this.submissionId = submissionId; }
        public Long getStudentId() { return studentId; }
        public void setStudentId(Long studentId) { this.studentId = studentId; }
        public String getEnrollmentNo() { return enrollmentNo; }
        public void setEnrollmentNo(String enrollmentNo) { this.enrollmentNo = enrollmentNo; }
        public String getStudentName() { return studentName; }
        public void setStudentName(String studentName) { this.studentName = studentName; }
        public String getSubmittedLabel() { return submittedLabel; }
        public void setSubmittedLabel(String submittedLabel) { this.submittedLabel = submittedLabel; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getMarksAwarded() { return marksAwarded; }
        public void setMarksAwarded(String marksAwarded) { this.marksAwarded = marksAwarded; }
        public int getMaxMarks() { return maxMarks; }
        public void setMaxMarks(int maxMarks) { this.maxMarks = maxMarks; }
    }

    public static class MaterialsPageData {
        private List<SubjectRow> subjects;
        private List<MaterialItem> materials;

        public List<SubjectRow> getSubjects() { return subjects; }
        public void setSubjects(List<SubjectRow> subjects) { this.subjects = subjects; }
        public List<MaterialItem> getMaterials() { return materials; }
        public void setMaterials(List<MaterialItem> materials) { this.materials = materials; }
    }

    public static class MaterialItem {
        private Long id;
        private Long subjectId;
        private String subjectCode;
        private String subjectName;
        private String title;
        private String fileType;
        private String sizeLabel;
        private String icon;
        private String uploadedLabel;
        private String filePath;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public Long getSubjectId() { return subjectId; }
        public void setSubjectId(Long subjectId) { this.subjectId = subjectId; }
        public String getSubjectCode() { return subjectCode; }
        public void setSubjectCode(String subjectCode) { this.subjectCode = subjectCode; }
        public String getSubjectName() { return subjectName; }
        public void setSubjectName(String subjectName) { this.subjectName = subjectName; }
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        public String getFileType() { return fileType; }
        public void setFileType(String fileType) { this.fileType = fileType; }
        public String getSizeLabel() { return sizeLabel; }
        public void setSizeLabel(String sizeLabel) { this.sizeLabel = sizeLabel; }
        public String getIcon() { return icon; }
        public void setIcon(String icon) { this.icon = icon; }
        public String getUploadedLabel() { return uploadedLabel; }
        public void setUploadedLabel(String uploadedLabel) { this.uploadedLabel = uploadedLabel; }
        public String getFilePath() { return filePath; }
        public void setFilePath(String filePath) { this.filePath = filePath; }
    }

    public static class MarksPageData {
        private List<SubjectRow> subjects;
        private List<String> examTypes;
        private Long selectedSubjectId;
        private String selectedSubjectCode;
        private String selectedSubjectName;
        private String selectedExamType;
        private String defaultMaximum;
        private List<StudentMarkRow> entries;
        private List<MarkHistoryRow> history;

        public List<SubjectRow> getSubjects() { return subjects; }
        public void setSubjects(List<SubjectRow> subjects) { this.subjects = subjects; }
        public List<String> getExamTypes() { return examTypes; }
        public void setExamTypes(List<String> examTypes) { this.examTypes = examTypes; }
        public Long getSelectedSubjectId() { return selectedSubjectId; }
        public void setSelectedSubjectId(Long selectedSubjectId) { this.selectedSubjectId = selectedSubjectId; }
        public String getSelectedSubjectCode() { return selectedSubjectCode; }
        public void setSelectedSubjectCode(String selectedSubjectCode) { this.selectedSubjectCode = selectedSubjectCode; }
        public String getSelectedSubjectName() { return selectedSubjectName; }
        public void setSelectedSubjectName(String selectedSubjectName) { this.selectedSubjectName = selectedSubjectName; }
        public String getSelectedExamType() { return selectedExamType; }
        public void setSelectedExamType(String selectedExamType) { this.selectedExamType = selectedExamType; }
        public String getDefaultMaximum() { return defaultMaximum; }
        public void setDefaultMaximum(String defaultMaximum) { this.defaultMaximum = defaultMaximum; }
        public List<StudentMarkRow> getEntries() { return entries; }
        public void setEntries(List<StudentMarkRow> entries) { this.entries = entries; }
        public List<MarkHistoryRow> getHistory() { return history; }
        public void setHistory(List<MarkHistoryRow> history) { this.history = history; }
    }

    public static class StudentMarkRow {
        private Long studentId;
        private String enrollmentNo;
        private String fullName;
        private String obtained;
        private String maximum;
        private String publishedLabel;

        public Long getStudentId() { return studentId; }
        public void setStudentId(Long studentId) { this.studentId = studentId; }
        public String getEnrollmentNo() { return enrollmentNo; }
        public void setEnrollmentNo(String enrollmentNo) { this.enrollmentNo = enrollmentNo; }
        public String getFullName() { return fullName; }
        public void setFullName(String fullName) { this.fullName = fullName; }
        public String getObtained() { return obtained; }
        public void setObtained(String obtained) { this.obtained = obtained; }
        public String getMaximum() { return maximum; }
        public void setMaximum(String maximum) { this.maximum = maximum; }
        public String getPublishedLabel() { return publishedLabel; }
        public void setPublishedLabel(String publishedLabel) { this.publishedLabel = publishedLabel; }
    }

    public static class MarkHistoryRow {
        private String subjectCode;
        private String studentEnroll;
        private String studentName;
        private String examType;
        private String scoreLabel;
        private String publishedLabel;

        public String getSubjectCode() { return subjectCode; }
        public void setSubjectCode(String subjectCode) { this.subjectCode = subjectCode; }
        public String getStudentEnroll() { return studentEnroll; }
        public void setStudentEnroll(String studentEnroll) { this.studentEnroll = studentEnroll; }
        public String getStudentName() { return studentName; }
        public void setStudentName(String studentName) { this.studentName = studentName; }
        public String getExamType() { return examType; }
        public void setExamType(String examType) { this.examType = examType; }
        public String getScoreLabel() { return scoreLabel; }
        public void setScoreLabel(String scoreLabel) { this.scoreLabel = scoreLabel; }
        public String getPublishedLabel() { return publishedLabel; }
        public void setPublishedLabel(String publishedLabel) { this.publishedLabel = publishedLabel; }
    }

    public static class AnnouncementsPageData {
        private List<SubjectRow> subjects;
        private List<NoticeRow> myNotices;
        private List<NoticeRow> campusNotices;

        public List<SubjectRow> getSubjects() { return subjects; }
        public void setSubjects(List<SubjectRow> subjects) { this.subjects = subjects; }
        public List<NoticeRow> getMyNotices() { return myNotices; }
        public void setMyNotices(List<NoticeRow> myNotices) { this.myNotices = myNotices; }
        public List<NoticeRow> getCampusNotices() { return campusNotices; }
        public void setCampusNotices(List<NoticeRow> campusNotices) { this.campusNotices = campusNotices; }
    }

    public static class TimetablePageData {
        private Map<String, List<ScheduleRow>> byDay;
        private List<ExamRow> exams;

        public Map<String, List<ScheduleRow>> getByDay() { return byDay; }
        public void setByDay(Map<String, List<ScheduleRow>> byDay) { this.byDay = byDay; }
        public List<ExamRow> getExams() { return exams; }
        public void setExams(List<ExamRow> exams) { this.exams = exams; }
    }

    public static class FilePayload {
        private final String filename;
        private final String contentType;
        private final byte[] bytes;

        public FilePayload(String filename, String contentType, byte[] bytes) {
            this.filename = filename;
            this.contentType = contentType;
            this.bytes = bytes;
        }

        public String getFilename() { return filename; }
        public String getContentType() { return contentType; }
        public byte[] getBytes() { return bytes; }
    }
}
