package com.campusconnect.service;

import com.campusconnect.config.AppProperties;
import com.campusconnect.dao.AnnouncementDao;
import com.campusconnect.dao.AttendanceRecordDao;
import com.campusconnect.dao.EnrollmentDao;
import com.campusconnect.dao.FacultyDao;
import com.campusconnect.dao.FeedbackDao;
import com.campusconnect.dao.MarkDao;
import com.campusconnect.dao.StudentDao;
import com.campusconnect.dao.StudyMaterialDao;
import com.campusconnect.dao.SubjectDao;
import com.campusconnect.dao.UserDao;
import com.campusconnect.model.Announcement;
import com.campusconnect.model.AttendanceRecord;
import com.campusconnect.model.Faculty;
import com.campusconnect.model.Feedback;
import com.campusconnect.model.Mark;
import com.campusconnect.model.Student;
import com.campusconnect.model.StudyMaterial;
import com.campusconnect.model.Subject;
import com.campusconnect.model.User;
import com.campusconnect.model.enums.NotificationColor;
import com.campusconnect.model.enums.Role;
import com.campusconnect.util.PasswordHasher;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Operations used by the Swing faculty console. Every action also creates the matching BLUE notifications, so
 * what a teacher does on the desktop shows up as a pop-up in the student's portal within seconds.
 */
@Service
public class FacultyService {

    private final UserDao userDao;
    private final FacultyDao facultyDao;
    private final SubjectDao subjectDao;
    private final EnrollmentDao enrollmentDao;
    private final AnnouncementDao announcementDao;
    private final StudyMaterialDao materialDao;
    private final MarkDao markDao;
    private final AttendanceRecordDao attendanceDao;
    private final FeedbackDao feedbackDao;
    private final StudentDao studentDao;
    private final NotificationService notifications;
    private final AppProperties props;

    @Autowired
    public FacultyService(UserDao userDao, FacultyDao facultyDao, SubjectDao subjectDao, EnrollmentDao enrollmentDao,
                          AnnouncementDao announcementDao, StudyMaterialDao materialDao, MarkDao markDao,
                          AttendanceRecordDao attendanceDao, FeedbackDao feedbackDao, StudentDao studentDao,
                          NotificationService notifications, AppProperties props) {
        this.userDao = userDao;
        this.facultyDao = facultyDao;
        this.subjectDao = subjectDao;
        this.enrollmentDao = enrollmentDao;
        this.announcementDao = announcementDao;
        this.materialDao = materialDao;
        this.markDao = markDao;
        this.attendanceDao = attendanceDao;
        this.feedbackDao = feedbackDao;
        this.studentDao = studentDao;
        this.notifications = notifications;
        this.props = props;
    }

    public Optional<Faculty> authenticate(String email, String password) {
        Optional<User> u = userDao.findByEmail(email.trim());
        if (u.isEmpty() || u.get().getRole() != Role.FACULTY || !u.get().isActive()
                || !PasswordHasher.verify(password, u.get().getPasswordHash())) {
            return Optional.empty();
        }
        return facultyDao.findByUserId(u.get().getId());
    }

    public List<Subject> subjectsOf(Faculty f) {
        return subjectDao.byFaculty(f.getId());
    }

    public List<Student> studentsOf(Subject s) {
        return enrollmentDao.studentsOf(s.getId());
    }

    /** Posts a notice for one subject (or the whole campus when subject is null) and notifies the students (BLUE). */
    public int postAnnouncement(Faculty f, Subject subject, String title, String body, boolean important) {
        Announcement a = new Announcement();
        a.setTitle(title);
        a.setBody(body);
        a.setImportant(important);
        a.setSubject(subject);
        a.setPostedBy(f);
        a.setCreatedAt(LocalDateTime.now(props.zone()));
        announcementDao.save(a);
        List<Student> targets = subject == null ? studentDao.findAll() : studentsOf(subject);
        int n = 0;
        for (Student st : targets) {
            if (notifications.create(st, NotificationColor.BLUE, "NOTICE", title, body, "Read Notice", "/dashboard",
                    "ann-" + a.getId()) != null) {
                n++;
            }
        }
        return n;
    }

    public int uploadMaterial(Faculty f, Subject subject, String title, String fileType, BigDecimal sizeMb, String path) {
        StudyMaterial m = new StudyMaterial();
        m.setSubject(subject);
        m.setTitle(title);
        m.setFileType(fileType);
        m.setSizeMb(sizeMb);
        m.setUploadedBy(f);
        m.setUploadedAt(LocalDateTime.now(props.zone()));
        m.setFilePath(path);
        materialDao.save(m);
        int n = 0;
        for (Student st : studentsOf(subject)) {
            if (notifications.create(st, NotificationColor.BLUE, "MATERIAL", "New e-content: " + title,
                    "Uploaded for " + subject.getName() + " by " + f.getTitle() + " " + f.getUser().getFullName() + ".",
                    "Open E-Content", "/app/e-content", "mat-" + m.getId()) != null) {
                n++;
            }
        }
        return n;
    }

    /** Saves marks of one component for many students (studentId -> marks) and declares the result (BLUE). */
    public int publishMarks(Subject subject, String examType, BigDecimal maximum, Map<Long, BigDecimal> marks) {
        int n = 0;
        for (Map.Entry<Long, BigDecimal> e : marks.entrySet()) {
            Student st = studentDao.findById(e.getKey()).orElse(null);
            if (st == null) {
                continue;
            }
            Mark m = new Mark();
            m.setStudent(st);
            m.setSubject(subject);
            m.setExamType(examType);
            m.setObtained(e.getValue());
            m.setMaximum(maximum);
            m.setPublishedOn(LocalDate.now(props.zone()));
            markDao.save(m);
            notifications.create(st, NotificationColor.BLUE, "RESULT", examType + " result: " + subject.getShortName(),
                    "You scored " + e.getValue().stripTrailingZeros().toPlainString() + " / "
                            + maximum.stripTrailingZeros().toPlainString() + ".", "View Results", "/app/exams",
                    "result-" + examType + "-" + subject.getId());
            notifications.scanStudent(st, LocalDateTime.now(props.zone())); // poor-score warning if needed
            n++;
        }
        return n;
    }

    /** Saves one lecture's attendance (studentId -> present). Existing rows for that date are skipped. */
    public int markAttendance(Subject subject, LocalDate date, Map<Long, Boolean> present) {
        int saved = 0;
        for (Map.Entry<Long, Boolean> e : present.entrySet()) {
            if (attendanceDao.exists(e.getKey(), subject.getId(), date)) {
                continue;
            }
            Student st = studentDao.findById(e.getKey()).orElse(null);
            if (st == null) {
                continue;
            }
            AttendanceRecord r = new AttendanceRecord();
            r.setStudent(st);
            r.setSubject(subject);
            r.setLectureDate(date);
            r.setPresent(e.getValue());
            attendanceDao.save(r);
            saved++;
            notifications.scanStudent(st, LocalDateTime.now(props.zone())); // low-attendance alerts straight away
        }
        return saved;
    }

    public List<Feedback> inbox(Faculty f) {
        return feedbackDao.forFaculty(f.getId(), 100);
    }
}
