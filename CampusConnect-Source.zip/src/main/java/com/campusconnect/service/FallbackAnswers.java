package com.campusconnect.service;

import com.campusconnect.dto.DashboardView;
import com.campusconnect.dto.SubjectCard;
import java.util.Locale;

/**
 * Rule-based answers used when Gemini is unreachable or the free quota is used up - Sanjii never goes silent.
 * Everything comes from the student's own dashboard data.
 */
public final class FallbackAnswers {

    private FallbackAnswers() { }

    public static String answer(String question, DashboardView v) {
        String q = question.toLowerCase(Locale.ROOT);
        String name = v.getFirstName();

        if (has(q, "attend", "present", "bunk", "absent")) {
            StringBuilder sb = new StringBuilder("Hi " + name + ", your overall attendance is " + v.getAttendancePct()
                    + "% (minimum " + v.getMinAttendance() + "%).");
            for (SubjectCard s : v.getSubjects()) {
                if ("RED".equals(s.getStatus())) {
                    sb.append("\n- ").append(s.getShortName()).append(" is at ").append(s.getAttendancePct()).append("% (at risk)");
                }
            }
            return sb.append("\nDetails are on the Attendance & Performance page.").toString();
        }
        if (has(q, "hostel", "prc", "regularity", "exam fee", "fee", "fees", "payment", "pay ")) {
            StringBuilder sb = new StringBuilder();
            if (v.getFeesDueCount() == 0) {
                sb.append("Good news, ").append(name).append("! You have no unpaid fees right now. \uD83D\uDE0A");
            } else {
                sb.append("You have ").append(v.getFeesDueCount()).append(" unpaid fee(s) worth INR ").append(v.getFeesDueAmount()).append(".");
                if (v.getNextFeeTitle() != null) {
                    sb.append("\n- Next: ").append(v.getNextFeeTitle()).append(", due ").append(v.getNextFeeDue());
                }
            }
            sb.append(v.isHosteler() ? "\nYou are a hosteler (" + v.getHostelName() + "), so hostel fees apply to you."
                    : "\nYou are not a hosteler, so hostel fees do not apply.");
            return sb.append("\nPay on the Fees & Dues page (demo payment).").toString();
        }
        if (has(q, "assign", "submi", "due", "pending", "done", "late", "overdue", "task", "deadline")) {
            return name + ", you have submitted " + v.getSubmittedAssignments() + " of " + v.getTotalAssignments()
                    + " assignments and " + v.getPendingAssignments() + " are pending."
                    + (v.getTickerAssignmentTitle() == null ? "" : "\n- Next deadline: " + v.getTickerAssignmentTitle() + " - " + v.getTickerAssignment())
                    + "\nOpen Assignments to submit.";
        }
        if (has(q, "exam", "hall ticket", "mid")) {
            return v.getTickerExamName() == null ? "No upcoming exams are scheduled right now."
                    : v.getTickerExamName() + " starts in " + v.getTickerExam() + ". See the date sheet on the Timetable page.";
        }
        if (has(q, "cgpa", "sgpa", "grade", "result", "mark", "backlog")) {
            return "Your CGPA is " + v.getCgpa() + " and last semester SGPA was " + v.getPreviousSgpa() + ". You have "
                    + v.getBacklogs() + " backlog(s). Open Exams & Results for subject-wise marks.";
        }
        if (has(q, "notice", "announce", "news", "circular")) {
            return v.getNoticeTitle() == null ? "There are no new notices right now."
                    : "Latest notice: " + v.getNoticeTitle() + " - " + v.getNoticeText();
        }
        if (has(q, "material", "notes", "slides", "e-content", "econtent")) {
            return v.getMaterials() == null || v.getMaterials().isEmpty() ? "No study material has been uploaded yet."
                    : "Latest material: " + v.getMaterials().get(0).getTitle() + " (" + v.getMaterials().get(0).getSubjectName()
                    + "). Open E-Content to view \uD83D\uDC41 or download it.";
        }
        if (has(q, "next", "class", "lecture", "timetable", "schedule")) {
            return v.getNextLectureSubject() == null ? "I could not find an upcoming lecture."
                    : "Your next lecture is " + v.getNextLectureSubject() + " at " + v.getNextLectureTime() + " in "
                    + v.getNextLectureRoom() + ".";
        }
        return "I can help with your attendance, assignments, exams, marks, fees, hostel info, timetable and study material. "
                + "(My AI brain is busy, so I'm answering from your portal data.)";
    }

    private static boolean has(String q, String... words) {
        for (String w : words) {
            if (q.contains(w)) {
                return true;
            }
        }
        return false;
    }
}
