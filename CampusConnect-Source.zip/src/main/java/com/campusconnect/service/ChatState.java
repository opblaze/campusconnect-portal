package com.campusconnect.service;

import java.io.Serializable;
import java.util.HashSet;
import java.util.LinkedList;

/** Per-login-session state of the chatbot (kept in the HttpSession): rate limiting, pending feedback, seen alerts. */
public class ChatState implements Serializable {
    private static final long serialVersionUID = 1L;

    private final LinkedList<Long> recent = new LinkedList<>();
    private final HashSet<String> seen = new HashSet<>();
    private Long pendingFeedbackSubjectId;
    private boolean feedbackAsked;

    /** Sliding-window rate limit: at most {@code perMinute} messages per 60 seconds (Availability). */
    public synchronized boolean allow(int perMinute) {
        long now = System.currentTimeMillis();
        while (!recent.isEmpty() && now - recent.getFirst() > 60_000) {
            recent.removeFirst();
        }
        if (recent.size() >= perMinute) {
            return false;
        }
        recent.addLast(now);
        return true;
    }

    /** True the first time a key is offered, false afterwards. */
    public synchronized boolean firstTime(String key) {
        return seen.add(key);
    }

    public synchronized Long getPendingFeedbackSubjectId() { return pendingFeedbackSubjectId; }
    public synchronized void setPendingFeedbackSubjectId(Long id) { this.pendingFeedbackSubjectId = id; }
    public synchronized boolean isFeedbackAsked() { return feedbackAsked; }
    public synchronized void setFeedbackAsked(boolean v) { this.feedbackAsked = v; }
}
