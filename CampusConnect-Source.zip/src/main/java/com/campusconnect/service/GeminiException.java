package com.campusconnect.service;

/** Raised when the Gemini API cannot be used (no key, quota, network, blocked answer). Callers fall back gracefully. */
public class GeminiException extends Exception {
    private static final long serialVersionUID = 1L;

    public GeminiException(String message) {
        super(message);
    }

    public GeminiException(String message, Throwable cause) {
        super(message, cause);
    }
}
