package com.campusconnect.service;

import com.campusconnect.config.AppProperties;
import com.campusconnect.util.Validator;
import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.util.Properties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Sends HTML e-mail through SMTP (Gmail by default).
 *
 * Demo safety: when {@code mail.demo.redirect} is set, EVERY mail is delivered to that address instead of the
 * real recipient (a note inside the mail shows who it was meant for). Remove the property for real use.
 * When SMTP credentials are missing the service simply reports "not sent" - nothing crashes (Availability).
 */
@Service
public class EmailService {

    private final String user;
    private final String password;
    private final String host;
    private final int port;
    private final String redirect;

    @Autowired
    public EmailService(AppProperties p) {
        this.user = p.get("mail.smtp.user", "");
        this.password = p.get("mail.smtp.password", "");
        this.host = p.get("mail.smtp.host", "smtp.gmail.com");
        this.port = p.getInt("mail.smtp.port", 587);
        this.redirect = p.get("mail.demo.redirect", "");
    }

    public boolean isConfigured() {
        return !user.isBlank() && !password.isBlank();
    }

    /** @return true when the mail was handed to the SMTP server. */
    public boolean send(String to, String subject, String htmlBody, String replyTo) {
        if (!isConfigured()) {
            System.out.println("[mail] SMTP not configured - skipped: " + subject);
            return false;
        }
        try {
            String actualTo = redirect.isBlank() ? to : redirect;
            String body = redirect.isBlank() ? htmlBody
                    : "<p style=\"background:#fff4cc;padding:8px;border-radius:6px;font:13px sans-serif\">"
                    + "Demo mode - originally addressed to: <b>" + Validator.escapeHtml(to) + "</b></p>" + htmlBody;

            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", host);
            props.put("mail.smtp.port", String.valueOf(port));
            props.put("mail.smtp.connectiontimeout", "8000");
            props.put("mail.smtp.timeout", "10000");
            Session session = Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(user, password);
                }
            });
            MimeMessage msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(user, "Campus Connect"));
            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(actualTo));
            if (replyTo != null && !replyTo.isBlank()) {
                msg.setReplyTo(InternetAddress.parse(replyTo));
            }
            msg.setSubject(subject, "UTF-8");
            msg.setContent(body, "text/html; charset=UTF-8");
            Transport.send(msg);
            return true;
        } catch (MessagingException | java.io.UnsupportedEncodingException | RuntimeException ex) {
            System.err.println("[mail] sending failed: " + ex.getMessage()); // never log the password
            return false;
        }
    }
}
