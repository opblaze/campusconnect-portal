package com.campusconnect.service;

import com.campusconnect.config.AppProperties;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Background job: every few minutes it asks {@link NotificationService} to scan all students,
 * so BLUE / RED / ORANGE notifications appear without anyone clicking anything.
 * Started by Spring after construction and stopped cleanly when Tomcat shuts the application down.
 */
@Component
public class NotificationScheduler implements InitializingBean, DisposableBean {

    private final NotificationService notifications;
    private final AppProperties props;
    private ScheduledExecutorService executor;

    @Autowired
    public NotificationScheduler(NotificationService notifications, AppProperties props) {
        this.notifications = notifications;
        this.props = props;
    }

    @Override
    public void afterPropertiesSet() {
        if (!"true".equalsIgnoreCase(props.get("scheduler.enabled", "true"))) {
            return;
        }
        int minutes = Math.max(1, props.getInt("scheduler.minutes", 2));
        executor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "cc-notification-scheduler");
            t.setDaemon(true);
            return t;
        });
        executor.scheduleWithFixedDelay(() -> {
            try {
                notifications.scanAll();
            } catch (RuntimeException ex) {
                System.err.println("[notify] scheduler run failed: " + ex.getMessage()); // keep the job alive
            }
        }, 15, minutes * 60L, TimeUnit.SECONDS);
    }

    @Override
    public void destroy() {
        if (executor != null) {
            executor.shutdownNow();
        }
    }
}
