package com.campusconnect.service;

import com.campusconnect.config.AppProperties;
import com.campusconnect.dao.AnnouncementDao;
import com.campusconnect.dao.AssignmentDao;
import com.campusconnect.dao.AttendanceRecordDao;
import com.campusconnect.dao.EnrollmentDao;
import com.campusconnect.dao.ExamScheduleDao;
import com.campusconnect.dao.FeeRecordDao;
import com.campusconnect.dao.MarkDao;
import com.campusconnect.dao.StudentDao;
import com.campusconnect.dao.StudentNoteDao;
import com.campusconnect.dao.StudyMaterialDao;
import com.campusconnect.dao.SubmissionDao;
import com.campusconnect.dao.TimetableSlotDao;
import com.campusconnect.model.Announcement;
import com.campusconnect.model.Assignment;
import com.campusconnect.model.ExamSchedule;
import com.campusconnect.model.FeeRecord;
import com.campusconnect.model.Mark;
import com.campusconnect.model.Student;
import com.campusconnect.model.StudentNote;
import com.campusconnect.model.StudyMaterial;
import com.campusconnect.model.Subject;
import com.campusconnect.model.Submission;
import com.campusconnect.model.TimetableSlot;
import com.campusconnect.model.enums.NotificationColor;
import com.campusconnect.util.DemoContent;
import com.campusconnect.util.FeeStatus;
import com.campusconnect.util.Text;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Builds the data shown on the secondary portal pages (subjects, attendance, e-content, exams, assignments,
 * timetable, fees, search) and performs the student actions on them (submit an assignment, pay a fee).
 * Rows are returned as {@code Map<String,Object>} so JSP/EL can read them as {@code ${row.title}}.
 */
@Service
public class PortalService {

    private static final DateTimeFormatter WHEN = DateTimeFormatter.ofPattern("d MMM yyyy, hh:mm a", Locale.ENGLISH);
    private static final DateTimeFormatter HM = DateTimeFormatter.ofPattern("hh:mm a", Locale.ENGLISH);

    private final StudentDao studentDao;
    private final StudentNoteDao noteDao;
    private final EnrollmentDao enrollmentDao;
    private final AttendanceRecordDao attendanceDao;
    private final StudyMaterialDao materialDao;
    private final MarkDao markDao;
    private final ExamScheduleDao examDao;
    private final AssignmentDao assignmentDao;
    private final SubmissionDao submissionDao;
    private final TimetableSlotDao timetableDao;
    private final FeeRecordDao feeDao;
    private final AnnouncementDao announcementDao;
    private final AttendancePolicy policy;
    private final NotificationService notifications;
    private final AppProperties props;

    @Autowired
    public PortalService(StudentDao studentDao, StudentNoteDao noteDao, EnrollmentDao enrollmentDao, AttendanceRecordDao attendanceDao,
                         StudyMaterialDao materialDao, MarkDao markDao, ExamScheduleDao examDao,
                         AssignmentDao assignmentDao, SubmissionDao submissionDao, TimetableSlotDao timetableDao,
                         FeeRecordDao feeDao, AnnouncementDao announcementDao, AttendancePolicy policy,
                         NotificationService notifications, AppProperties props) {
        this.studentDao = studentDao;
        this.noteDao = noteDao;
        this.enrollmentDao = enrollmentDao;
        this.attendanceDao = attendanceDao;
        this.materialDao = materialDao;
        this.markDao = markDao;
        this.examDao = examDao;
        this.assignmentDao = assignmentDao;
        this.submissionDao = submissionDao;
        this.timetableDao = timetableDao;
        this.feeDao = feeDao;
        this.announcementDao = announcementDao;
        this.policy = policy;
        this.notifications = notifications;
        this.props = props;
    }

    // ------------------------------------------------------------------ attendance & performance
    public List<Map<String, Object>> attendanceRows(Long studentId) {
        Map<Long, long[]> att = attendanceDao.summaryByStudent(studentId);
        int min = policy.getMin();
        List<Map<String, Object>> rows = new ArrayList<>();
        for (Subject s : enrollmentDao.subjectsOf(studentId)) {
            long[] a = att.getOrDefault(s.getId(), new long[] {0, 0});
            double pct = a[0] == 0 ? 100.0 : a[1] * 100.0 / a[0];
            String status = policy.statusOf(pct);
            // classes to attend in a row to reach the minimum:  (attended + x) / (held + x) >= min/100
            long need = Math.max(0, (long) Math.ceil((min * a[0] - 100.0 * a[1]) / (100.0 - min)));
            // classes that can still be missed without dropping below the minimum
            long canMiss = pct >= min ? (long) Math.floor((100.0 * a[1] - min * a[0]) / min) : 0;
            rows.add(row("code", s.getCode(), "name", s.getName(), "abbr", s.getShortName(), "held", a[0],
                    "attended", a[1], "pct", Text.pct1(pct), "pctInt", Math.round(pct), "status", status,
                    "label", policy.labelOf(pct), "bar", status.equals("GREEN") ? "bg-emerald-500"
                            : status.equals("YELLOW") ? "bg-amber-400" : "bg-red-500",
                    "need", need, "canMiss", canMiss, "faculty", s.getFaculty().getTitle() + " "
                            + s.getFaculty().getUser().getFullName()));
        }
        return rows;
    }

    // ------------------------------------------------------------------ my subjects
    public List<Map<String, Object>> subjectRows(Long studentId) {
        List<Subject> subjects = enrollmentDao.subjectsOf(studentId);
        List<Long> ids = subjects.stream().map(Subject::getId).collect(Collectors.toList());
        Set<Long> done = submissionDao.submittedAssignmentIds(studentId);
        List<Assignment> assignments = assignmentDao.forSubjects(ids);
        List<StudyMaterial> materials = materialDao.latestForSubjects(ids, 500);
        List<Map<String, Object>> rows = new ArrayList<>();
        for (Subject s : subjects) {
            long pending = assignments.stream().filter(a -> a.getSubject().getId().equals(s.getId())
                    && !done.contains(a.getId())).count();
            long mats = materials.stream().filter(m -> m.getSubject().getId().equals(s.getId())).count();
            rows.add(row("id", s.getId(), "code", s.getCode(), "name", s.getName(), "abbr", s.getShortName(),
                    "credits", s.getCredits(), "category", s.getCategory(), "days", s.getMeetingDays().replace(",", " \u2022 "),
                    "syllabus", Text.pct1(s.getSyllabusCompletion().doubleValue()),
                    "faculty", s.getFaculty().getTitle() + " " + s.getFaculty().getUser().getFullName(),
                    "facultyEmail", s.getFaculty().getUser().getEmail(), "cabin", nz(s.getFaculty().getCabin()),
                    "pending", pending, "materials", mats));
        }
        return rows;
    }

    // ------------------------------------------------------------------ e-content (faculty material + my notes)
    /** A file that is served to the browser (inline preview or download). */
    public record FileData(String contentType, String fileName, byte[] bytes, Path path) { }

    public List<Map<String, Object>> materialRows(Long studentId, Long subjectFilter) {
        List<Long> ids = enrollmentDao.subjectsOf(studentId).stream().map(Subject::getId).collect(Collectors.toList());
        List<Map<String, Object>> rows = new ArrayList<>();
        for (StudyMaterial m : materialDao.latestForSubjects(ids, 200)) {
            if (subjectFilter != null && !m.getSubject().getId().equals(subjectFilter)) {
                continue;
            }
            rows.add(row("id", m.getId(), "src", "material", "title", m.getTitle(), "subject", m.getSubject().getName(),
                    "subjectId", m.getSubject().getId(), "type", m.getFileType(), "icon", iconFor(m.getFileType()),
                    "size", String.format(Locale.ROOT, "%.1f MB", m.getSizeMb().doubleValue()),
                    "by", m.getUploadedBy().getTitle() + " " + m.getUploadedBy().getUser().getFullName(),
                    "at", m.getUploadedAt().format(WHEN), "kind", previewKind(materialFile(m), m.getFileType())));
        }
        return rows;
    }

    /** Material the student may open (must belong to one of the student's subjects). */
    public Optional<StudyMaterial> materialFor(Long studentId, Long materialId) {
        return materialDao.findById(materialId).filter(m -> enrollmentDao.isEnrolled(studentId, m.getSubject().getId()));
    }

    public List<Map<String, Object>> noteRows(Long studentId) {
        List<Map<String, Object>> rows = new ArrayList<>();
        for (StudentNote n : noteDao.byStudent(studentId)) {
            rows.add(row("id", n.getId(), "src", "note", "title", n.getTitle(), "file", n.getFileName(),
                    "subject", n.getSubject() == null ? "General" : n.getSubject().getName(),
                    "size", n.getSizeKb() + " KB", "at", n.getUploadedAt().format(WHEN),
                    "kind", previewKind(notePath(n), null)));
        }
        return rows;
    }

    /** Saves the database record of an uploaded private note (the file itself is written by the servlet). */
    public StudentNote addNote(Long studentId, Long subjectId, String title, String originalName, String storedName, int sizeKb) {
        StudentNote n = new StudentNote();
        n.setStudent(studentDao.findById(studentId).orElseThrow());
        if (subjectId != null && enrollmentDao.isEnrolled(studentId, subjectId)) {
            enrollmentDao.subjectsOf(studentId).stream().filter(x -> x.getId().equals(subjectId)).findFirst().ifPresent(n::setSubject);
        }
        n.setTitle(title.length() > 200 ? title.substring(0, 200) : title);
        n.setFileName(originalName.length() > 200 ? originalName.substring(0, 200) : originalName);
        n.setStoredName(storedName);
        n.setSizeKb(Math.max(1, sizeKb));
        n.setUploadedAt(LocalDateTime.now(props.zone()));
        return noteDao.save(n);
    }

    /** A note of this student (owner check) - empty for somebody else's note. */
    public Optional<StudentNote> noteFor(Long studentId, Long noteId) {
        return noteDao.findById(noteId).filter(n -> n.getStudent().getId().equals(studentId));
    }

    /** Deletes a note record and returns it, so the caller can remove the file as well. */
    public Optional<StudentNote> deleteNote(Long studentId, Long noteId) {
        Optional<StudentNote> n = noteFor(studentId, noteId);
        n.ifPresent(noteDao::delete);
        return n;
    }

    // ---- files, preview and download
    public Path uploadDir() {
        return Paths.get(props.get("upload.dir", System.getProperty("user.home") + "/campusconnect-uploads")).toAbsolutePath().normalize();
    }

    private Path materialFile(StudyMaterial m) {
        String name = Paths.get(m.getFilePath()).getFileName().toString().replaceAll("[^A-Za-z0-9._-]", "_");
        Path f = uploadDir().resolve("materials").resolve(name).normalize();
        return Files.isRegularFile(f) && f.startsWith(uploadDir()) ? f : null;
    }

    private Path notePath(StudentNote n) {
        Path f = uploadDir().resolve("notes").resolve(n.getStoredName()).normalize();
        return Files.isRegularFile(f) && f.startsWith(uploadDir()) ? f : null;
    }

    /** pdf | image | text | none - how the browser can preview this file. */
    public static String previewKind(Path realFile, String demoType) {
        if (realFile == null) { // demo material generated on the fly
            String t = demoType == null ? "" : demoType.toUpperCase(Locale.ROOT);
            return t.equals("PDF") || t.equals("SLIDES") ? "pdf" : t.equals("CODE") || t.equals("ZIP") ? "text" : "none";
        }
        String n = realFile.getFileName().toString().toLowerCase(Locale.ROOT);
        String ext = n.contains(".") ? n.substring(n.lastIndexOf('.') + 1) : "";
        if (ext.equals("pdf")) return "pdf";
        if (Set.of("png", "jpg", "jpeg", "gif", "webp").contains(ext)) return "image";
        if (Set.of("txt", "java", "py", "sql", "csv", "md", "json", "xml", "c", "cpp", "js").contains(ext)) return "text";
        return "none";
    }

    private static String mimeOf(Path f) {
        String n = f.getFileName().toString().toLowerCase(Locale.ROOT);
        String ext = n.substring(n.lastIndexOf('.') + 1);
        switch (ext) {
            case "pdf": return "application/pdf";
            case "png": return "image/png";
            case "jpg": case "jpeg": return "image/jpeg";
            case "gif": return "image/gif";
            case "webp": return "image/webp";
            default: return "text/plain; charset=UTF-8";
        }
    }

    /** The file (real or generated demo) behind a material or a note; empty when the student may not open it. */
    public Optional<FileData> fileOf(Long studentId, String src, Long id) {
        try {
            if ("note".equals(src)) {
                Optional<StudentNote> n = noteFor(studentId, id);
                if (n.isEmpty() || notePath(n.get()) == null) {
                    return Optional.empty();
                }
                Path p = notePath(n.get());
                return Optional.of(new FileData(mimeOf(p), n.get().getFileName(), null, p));
            }
            Optional<StudyMaterial> m = materialFor(studentId, id);
            if (m.isEmpty()) {
                return Optional.empty();
            }
            Path real = materialFile(m.get());
            if (real != null) {
                return Optional.of(new FileData(mimeOf(real), real.getFileName().toString(), null, real));
            }
            return Optional.of(demoFile(m.get()));
        } catch (RuntimeException ex) {
            return Optional.empty();
        }
    }

    /** Demo files: the seed data has no real files, so a matching document is generated in memory. */
    private FileData demoFile(StudyMaterial m) {
        String base = m.getTitle().replaceAll("[^A-Za-z0-9._-]+", "_");
        String faculty = m.getUploadedBy().getTitle() + " " + m.getUploadedBy().getUser().getFullName();
        switch (m.getFileType() == null ? "" : m.getFileType().toUpperCase(Locale.ROOT)) {
            case "PDF":
                return new FileData("application/pdf", base + ".pdf", DemoContent.notesPdf(m.getTitle(), m.getSubject().getName(), faculty), null);
            case "SLIDES":
                return new FileData("application/pdf", base + ".pdf", DemoContent.slidesPdf(m.getTitle(), m.getSubject().getName()), null);
            case "CODE":
                return new FileData("text/plain; charset=UTF-8", base + ".txt",
                        DemoContent.codeSample(m.getSubject().getShortName()).getBytes(StandardCharsets.UTF_8), null);
            default:
                return new FileData("text/plain; charset=UTF-8", base + ".txt", DemoContent.zipListing(m.getTitle()).getBytes(StandardCharsets.UTF_8), null);
        }
    }

    /** Data for the preview window (title, details, which viewer to use, URLs). */
    public Optional<Map<String, Object>> previewInfo(Long studentId, String src, Long id) {
        if ("note".equals(src)) {
            return noteFor(studentId, id).map(n -> row("title", n.getTitle(), "subject", n.getSubject() == null ? "General" : n.getSubject().getName(),
                    "type", "NOTE", "size", n.getSizeKb() + " KB", "by", "You", "at", n.getUploadedAt().format(WHEN),
                    "kind", previewKind(notePath(n), null)));
        }
        return materialFor(studentId, id).map(m -> row("title", m.getTitle(), "subject", m.getSubject().getName(), "type", m.getFileType(),
                "size", String.format(Locale.ROOT, "%.1f MB", m.getSizeMb().doubleValue()),
                "by", m.getUploadedBy().getTitle() + " " + m.getUploadedBy().getUser().getFullName(), "at", m.getUploadedAt().format(WHEN),
                "kind", previewKind(materialFile(m), m.getFileType())));
    }

    // ------------------------------------------------------------------ exams & results
    public List<Map<String, Object>> markRows(Long studentId) {
        List<Map<String, Object>> rows = new ArrayList<>();
        for (Mark m : markDao.byStudent(studentId)) {
            double ratio = m.getObtained().doubleValue() * 100.0 / Math.max(1.0, m.getMaximum().doubleValue());
            String status = ratio >= 70 ? "GREEN" : ratio >= 40 ? "YELLOW" : "RED";
            rows.add(row("subject", m.getSubject().getName(), "abbr", m.getSubject().getShortName(), "type", m.getExamType(),
                    "obtained", m.getObtained().stripTrailingZeros().toPlainString(),
                    "maximum", m.getMaximum().stripTrailingZeros().toPlainString(), "pct", Text.pct0(ratio),
                    "status", status, "bar", status.equals("GREEN") ? "bg-emerald-500" : status.equals("YELLOW") ? "bg-amber-400" : "bg-red-500",
                    "on", m.getPublishedOn().toString()));
        }
        return rows;
    }

    public List<Map<String, Object>> examRows(Long studentId) {
        List<Long> ids = enrollmentDao.subjectsOf(studentId).stream().map(Subject::getId).collect(Collectors.toList());
        List<Map<String, Object>> rows = new ArrayList<>();
        for (ExamSchedule x : examDao.upcomingForSubjects(ids, LocalDate.now(props.zone()))) {
            rows.add(row("exam", x.getExamName(), "subject", x.getSubject().getName(), "code", x.getSubject().getCode(),
                    "date", x.getExamDate().format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.ENGLISH)),
                    "time", x.getStartTime().format(HM) + " \u2013 " + x.getEndTime().format(HM)));
        }
        return rows;
    }

    // ------------------------------------------------------------------ assignments
    public List<Map<String, Object>> assignmentRows(Long studentId) {
        LocalDateTime now = LocalDateTime.now(props.zone());
        List<Long> ids = enrollmentDao.subjectsOf(studentId).stream().map(Subject::getId).collect(Collectors.toList());
        Map<Long, Submission> subs = submissionDao.byStudent(studentId).stream()
                .collect(Collectors.toMap(s -> s.getAssignment().getId(), s -> s, (a, b) -> a));
        List<Map<String, Object>> rows = new ArrayList<>();
        for (Assignment a : assignmentDao.forSubjects(ids)) {
            Submission sub = subs.get(a.getId());
            String state = sub != null ? ("LATE".equals(sub.getStatus()) ? "LATE" : "DONE")
                    : a.getDueAt().isBefore(now) ? "OVERDUE" : "PENDING";
            rows.add(row("id", a.getId(), "title", a.getTitle(), "subject", a.getSubject().getName(),
                    "abbr", a.getSubject().getShortName(), "desc", nz(a.getDescription()), "due", a.getDueAt().format(WHEN),
                    "state", state, "marks", a.getMaxMarks(),
                    "submittedAt", sub == null ? "" : sub.getSubmittedAt().format(WHEN),
                    "canSubmit", sub == null));
        }
        // pending first (soonest deadline), finished last
        rows.sort((x, y) -> Boolean.compare(!(Boolean) x.get("canSubmit"), !(Boolean) y.get("canSubmit")));
        return rows;
    }

    /** Records a submission; returns an error text or null on success. */
    public String submitAssignment(Long studentId, Long assignmentId, String storedFileName) {
        Optional<Assignment> found = assignmentDao.findById(assignmentId);
        if (found.isEmpty() || !enrollmentDao.isEnrolled(studentId, found.get().getSubject().getId())) {
            return "That assignment does not exist.";
        }
        if (submissionDao.find(assignmentId, studentId).isPresent()) {
            return "You have already submitted this assignment.";
        }
        LocalDateTime now = LocalDateTime.now(props.zone());
        Submission s = new Submission();
        s.setAssignment(found.get());
        s.setStudent(studentDao.findById(studentId).orElseThrow());
        s.setSubmittedAt(now);
        s.setStatus(now.isAfter(found.get().getDueAt()) ? "LATE" : "ON_TIME");
        submissionDao.save(s);
        return null;
    }

    // ------------------------------------------------------------------ timetable
    /** day name -> slots of that day (Monday to Saturday). */
    public Map<String, List<Map<String, Object>>> weekGrid(Long studentId) {
        List<Long> ids = enrollmentDao.subjectsOf(studentId).stream().map(Subject::getId).collect(Collectors.toList());
        Map<String, List<Map<String, Object>>> grid = new LinkedHashMap<>();
        for (int d = 1; d <= 6; d++) {
            grid.put(DayOfWeek.of(d).getDisplayName(TextStyle.FULL, Locale.ENGLISH), new ArrayList<>());
        }
        for (TimetableSlot t : timetableDao.forSubjects(ids)) {
            if (t.getDayOfWeek() > 6) {
                continue;
            }
            grid.get(DayOfWeek.of(t.getDayOfWeek()).getDisplayName(TextStyle.FULL, Locale.ENGLISH)).add(
                    row("time", t.getStartTime().format(HM) + " \u2013 " + t.getEndTime().format(HM),
                            "subject", t.getSubject().getName(), "code", t.getSubject().getCode(), "room", t.getRoom(),
                            "block", nz(t.getBlock()), "faculty", t.getSubject().getFaculty().getTitle() + " "
                                    + t.getSubject().getFaculty().getUser().getFullName()));
        }
        return grid;
    }

    // ------------------------------------------------------------------ profile
    public Map<String, Object> profile(Long studentId) {
        Student st = studentDao.findById(studentId).orElseThrow();
        return row("name", st.getUser().getFullName(), "initials", Text.initials(st.getUser().getFullName()),
                "program", st.getProgram(), "branch", st.getBranchCode(), "gmail", st.getGmail() == null ? "" : st.getGmail(),
                "collegeEmail", st.getUser().getEmail(), "enrollment", st.getEnrollmentNo(), "hosteler", st.isHosteler(),
                "hostelName", st.getHostelName() == null ? "" : st.getHostelName(), "semester", "Semester " + st.getSemester(),
                "year", st.getAcademicYear(), "phone", st.getPhone() == null ? "" : st.getPhone());
    }

    // ------------------------------------------------------------------ fees (demo payments)
    private static final Set<String> PAY_METHODS = Set.of("UPI", "CARD", "NETBANKING");
    private static final SecureRandom RANDOM = new SecureRandom();

    /** Fees of the student with their status. Hostel fees are only listed for hostelers. */
    public List<Map<String, Object>> feeRows(Long studentId) {
        Student st = studentDao.findById(studentId).orElseThrow();
        LocalDate today = LocalDate.now(props.zone());
        List<Map<String, Object>> rows = new ArrayList<>();
        List<FeeRecord> fees = new ArrayList<>(feeDao.byStudent(studentId));
        fees.sort((x, y) -> x.isPaid() != y.isPaid() ? Boolean.compare(x.isPaid(), y.isPaid()) : x.getDueDate().compareTo(y.getDueDate()));
        for (FeeRecord f : fees) {
            if ("HOSTEL".equals(f.getCategory()) && !st.isHosteler()) {
                continue;
            }
            String state = FeeStatus.of(f, today);
            rows.add(row("id", f.getId(), "title", f.getTitle(), "category", f.getCategory(),
                    "categoryLabel", FeeStatus.categoryLabel(f.getCategory()), "amount", money(f.getAmount()),
                    "amountValue", f.getAmount(), "due", f.getDueDate().format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH)),
                    "state", state, "paidOn", f.getPaidOn() == null ? "" : f.getPaidOn().format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH)),
                    "receipt", f.getReceiptNo() == null ? "" : f.getReceiptNo(), "method", f.getPaymentMethod() == null ? "" : f.getPaymentMethod(),
                    "canPay", !f.isPaid()));
        }
        return rows;
    }

    /** Totals shown on top of the fees page. */
    public Map<String, Object> feeSummary(List<Map<String, Object>> rows) {
        BigDecimal due = BigDecimal.ZERO;
        BigDecimal paid = BigDecimal.ZERO;
        Map<String, Integer> counts = new TreeMap<>();
        for (Map<String, Object> r : rows) {
            String state = (String) r.get("state");
            BigDecimal amount = (BigDecimal) r.get("amountValue");
            counts.merge(state, 1, Integer::sum);
            if ("PAID".equals(state)) {
                paid = paid.add(amount);
            } else {
                due = due.add(amount);
            }
        }
        return row("totalDue", money(due), "totalPaid", money(paid), "paidCount", counts.getOrDefault("PAID", 0),
                "dueCount", counts.getOrDefault("DUE", 0), "pendingCount", counts.getOrDefault("PENDING", 0),
                "overdueCount", counts.getOrDefault("OVERDUE", 0));
    }

    /**
     * DEMO payment: marks the fee as paid and issues a receipt number. No real money moves and card / UPI details are never
     * sent to or stored on the server. A live system would call a payment gateway (Razorpay / PayU) and run this only from
     * the gateway's verified callback.
     *
     * @return the paid fee, or empty when the payment is not allowed (unknown fee, already paid, hostel fee of a non-hosteler,
     *         unsupported method)
     */
    public Optional<FeeRecord> payFee(Long studentId, Long feeId, String method) {
        if (method == null || !PAY_METHODS.contains(method.toUpperCase(Locale.ROOT))) {
            return Optional.empty();
        }
        Optional<FeeRecord> found = feeDao.findById(feeId);
        if (found.isEmpty() || !found.get().getStudent().getId().equals(studentId) || found.get().isPaid()) {
            return Optional.empty();
        }
        FeeRecord f = found.get();
        Student st = f.getStudent();
        if ("HOSTEL".equals(f.getCategory()) && !st.isHosteler()) {
            return Optional.empty();
        }
        LocalDate today = LocalDate.now(props.zone());
        f.setPaid(true);
        f.setPaidOn(today);
        f.setPaymentMethod(method.toUpperCase(Locale.ROOT));
        f.setReceiptNo("CC" + today.format(DateTimeFormatter.BASIC_ISO_DATE) + "-" + f.getId() + "-" + (1000 + RANDOM.nextInt(9000)));
        feeDao.update(f);
        notifications.create(st, NotificationColor.BLUE, "FEES", "Payment received: " + f.getTitle(),
                "INR " + money(f.getAmount()) + " was received (receipt " + f.getReceiptNo() + "). Thank you!", "View Receipt",
                "/app/receipt?id=" + f.getId(), "paid-" + f.getId());
        return Optional.of(f);
    }

    /** Data of a printable receipt - only for a paid fee of this student. */
    public Optional<Map<String, Object>> receipt(Long studentId, Long feeId) {
        return feeDao.findById(feeId).filter(f -> f.isPaid() && f.getStudent().getId().equals(studentId)).map(f -> {
            Student st = f.getStudent();
            return row("receipt", f.getReceiptNo() == null ? "CC-" + f.getId() : f.getReceiptNo(), "title", f.getTitle(),
                    "categoryLabel", FeeStatus.categoryLabel(f.getCategory()), "amount", money(f.getAmount()),
                    "paidOn", f.getPaidOn().format(DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.ENGLISH)),
                    "method", methodLabel(f.getPaymentMethod()), "name", st.getUser().getFullName(), "enrollment", st.getEnrollmentNo(),
                    "program", st.getProgram() + " (" + st.getBranchCode() + ")", "semester", "Semester " + st.getSemester() + ", " + st.getAcademicYear());
        });
    }

    static String methodLabel(String m) {
        if (m == null) return "Online (demo)";
        switch (m) {
            case "UPI": return "UPI (demo)";
            case "CARD": return "Debit / Credit card (demo)";
            case "NETBANKING": return "Net banking (demo)";
            default: return m;
        }
    }

    private static String money(BigDecimal v) {
        return String.format(Locale.forLanguageTag("en-IN"), "%,.2f", v).replace(".00", "");
    }

    // ------------------------------------------------------------------ live search
    /** Suggested keywords shown in the search box (the first four are the status words). */
    public static final List<String> KEYWORDS = List.of("pending", "done", "due", "late", "overdue", "paid", "assignments", "attendance",
            "exam", "fees", "hostel", "prc", "timetable", "notice", "material", "result", "syllabus", "faculty", "receipt", "backlog");

    private static final List<String[]> PAGES = List.of(
            new String[] {"Dashboard", "/dashboard", "home overview dashboard"},
            new String[] {"My Subjects", "/app/my-subjects", "subjects courses faculty syllabus"},
            new String[] {"Attendance & Performance", "/app/attendance", "attendance performance present absent backlog"},
            new String[] {"E-Content Materials", "/app/e-content", "material notes slides study upload download preview"},
            new String[] {"Exams & Results", "/app/exams", "exam result marks grade cgpa"},
            new String[] {"Assignments & Submissions", "/app/assignments", "assignment task submission upload"},
            new String[] {"Timetable", "/app/timetable", "timetable schedule lecture class"},
            new String[] {"Fees & Dues", "/app/fees", "fee fees payment pay hostel prc exam receipt due"},
            new String[] {"My Profile", "/app/profile", "profile name gmail enrollment hostel branch stream"},
            new String[] {"Campus Helpdesk", "/app/helpdesk", "help support query helpdesk"},
            new String[] {"Smart Notifications", "/app/notifications", "notification alert warning"});

    /** Keyword suggestions for what the student has typed so far. */
    public List<String> suggest(String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        String last = q.isEmpty() ? "" : q.substring(q.lastIndexOf(' ') + 1);
        List<String> out = new ArrayList<>();
        for (String k : KEYWORDS) {
            if (last.isEmpty() || k.startsWith(last)) {
                out.add(k);
            }
        }
        if (out.isEmpty() && !last.isEmpty()) {
            KEYWORDS.stream().filter(k -> k.contains(last)).forEach(out::add);
        }
        return out.size() > 12 ? out.subList(0, 12) : out;
    }

    /**
     * Live search over assignments, fees, material, exams, subjects, notices and pages.
     * Every word must match. Status words have a meaning:
     *   pending = not submitted / not paid yet     done = submitted or paid     due = due soon     late / overdue = deadline missed
     */
    public List<Map<String, Object>> searchRows(Long studentId, String query) {
        List<Map<String, Object>> out = new ArrayList<>();
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) {
            return out;
        }
        List<String> tokens = Arrays.stream(q.split("\\s+")).filter(t -> !t.isEmpty()).collect(Collectors.toList());
        LocalDateTime now = LocalDateTime.now(props.zone());

        for (Map<String, Object> a : assignmentRows(studentId)) {
            String state = (String) a.get("state");
            Set<String> words = new java.util.HashSet<>(List.of("assignment", "assignments", "task", "tasks", "submission"));
            switch (state) {
                case "PENDING": words.addAll(List.of("pending", "upcoming")); break;
                case "OVERDUE": words.addAll(List.of("overdue", "late", "pending", "due")); break;
                case "LATE": words.addAll(List.of("late", "done", "submitted")); break;
                default: words.addAll(List.of("done", "submitted", "completed")); break;
            }
            if ("PENDING".equals(state) && dueSoon((String) a.get("due"), now)) {
                words.add("due");
            }
            addIf(out, tokens, words, a.get("title") + " " + a.get("subject") + " " + a.get("abbr"), "Assignment",
                    (String) a.get("title"), a.get("subject") + " \u2022 due " + a.get("due"), "/app/assignments", state, toneOf(state));
        }
        for (Map<String, Object> f : feeRows(studentId)) {
            String state = (String) f.get("state");
            Set<String> words = new java.util.HashSet<>(List.of("fee", "fees", "payment", "pay", ((String) f.get("category")).toLowerCase(Locale.ROOT)));
            switch (state) {
                case "PAID": words.addAll(List.of("paid", "done", "receipt")); break;
                case "DUE": words.addAll(List.of("due", "pending")); break;
                case "PENDING": words.addAll(List.of("pending", "upcoming")); break;
                default: words.addAll(List.of("overdue", "late", "due", "pending")); break;
            }
            addIf(out, tokens, words, f.get("title") + " " + f.get("categoryLabel"), "Fee", (String) f.get("title"),
                    "\u20B9" + f.get("amount") + " \u2022 due " + f.get("due"), "/app/fees", state, toneOf(state));
        }
        for (Map<String, Object> m : materialRows(studentId, null)) {
            addIf(out, tokens, Set.of("material", "materials", "notes", "slides", "study", "content", "preview"),
                    m.get("title") + " " + m.get("subject") + " " + m.get("type"), "Material", (String) m.get("title"),
                    m.get("subject") + " \u2022 " + m.get("size"), "/app/e-content", (String) m.get("type"), "BLUE");
        }
        for (Map<String, Object> x : examRows(studentId)) {
            addIf(out, tokens, Set.of("exam", "exams", "test", "date"), x.get("subject") + " " + x.get("exam"), "Exam",
                    x.get("subject") + " - " + x.get("exam"), x.get("date") + " \u2022 " + x.get("time"), "/app/timetable", "EXAM", "YELLOW");
        }
        for (Map<String, Object> s : subjectRows(studentId)) {
            addIf(out, tokens, Set.of("subject", "subjects", "course", "syllabus", "faculty"),
                    s.get("name") + " " + s.get("code") + " " + s.get("abbr") + " " + s.get("faculty"), "Subject",
                    s.get("name") + " (" + s.get("code") + ")", (String) s.get("faculty"), "/app/my-subjects", (String) s.get("category"), "NONE");
        }
        for (Announcement an : announcementDao.latest(30)) {
            addIf(out, tokens, Set.of("notice", "notices", "announcement", "announcements", "news"), an.getTitle() + " " + an.getBody(),
                    "Notice", an.getTitle(), an.getBody().length() > 90 ? an.getBody().substring(0, 87) + "..." : an.getBody(),
                    "/dashboard", "NOTICE", "BLUE");
        }
        for (String[] pg : PAGES) {
            addIf(out, tokens, Set.of("page", "open", "go"), pg[0] + " " + pg[2], "Page", pg[0], "Open page", pg[1], "PAGE", "NONE");
        }
        out.sort((x, y) -> Integer.compare(rank(x, q), rank(y, q)));
        return out.size() > 15 ? new ArrayList<>(out.subList(0, 15)) : out;
    }

    /** Old full-page search: the same results, grouped by type. */
    public Map<String, List<Map<String, Object>>> search(Long studentId, String query) {
        Map<String, List<Map<String, Object>>> out = new java.util.LinkedHashMap<>();
        for (String g : List.of("Assignment", "Fee", "Material", "Exam", "Subject", "Notice", "Page")) {
            out.put(g, new ArrayList<>());
        }
        for (Map<String, Object> r : searchRows(studentId, query)) {
            out.get((String) r.get("type")).add(row("title", r.get("title"), "sub", r.get("sub"), "href", r.get("href")));
        }
        out.values().removeIf(List::isEmpty);
        return out;
    }

    private static void addIf(List<Map<String, Object>> out, List<String> tokens, Set<String> words, String haystack, String type,
                              String title, String sub, String href, String badge, String tone) {
        String h = haystack.toLowerCase(Locale.ROOT);
        for (String t : tokens) {
            boolean ok = words.contains(t) || h.contains(t);
            if (!ok) {
                return;
            }
        }
        out.add(row("type", type, "title", title, "sub", sub, "href", href, "badge", badge, "tone", tone));
    }

    private static int rank(Map<String, Object> r, String q) {
        int typeOrder = List.of("Assignment", "Fee", "Material", "Exam", "Subject", "Notice", "Page").indexOf((String) r.get("type"));
        boolean titleHit = ((String) r.get("title")).toLowerCase(Locale.ROOT).contains(q);
        return (titleHit ? 0 : 100) + typeOrder;
    }

    private static String toneOf(String state) {
        switch (state) {
            case "PAID": case "DONE": return "GREEN";
            case "DUE": case "LATE": return "YELLOW";
            case "OVERDUE": return "RED";
            default: return "BLUE";
        }
    }

    /** true when the due date text ("d MMM yyyy, hh:mm a") is within the next 7 days. */
    private static boolean dueSoon(String due, LocalDateTime now) {
        try {
            LocalDateTime d = LocalDateTime.parse(due, WHEN);
            return !d.isBefore(now) && d.isBefore(now.plusDays(7));
        } catch (RuntimeException ex) {
            return false;
        }
    }

    // ------------------------------------------------------------------ helpers
    private static boolean hit(String q, Object... fields) {
        for (Object f : fields) {
            if (f != null && f.toString().toLowerCase(Locale.ROOT).contains(q)) {
                return true;
            }
        }
        return false;
    }

    private static Map<String, Object> row(Object... kv) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) {
            m.put((String) kv[i], kv[i + 1]);
        }
        return m;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private static String iconFor(String t) {
        switch (t == null ? "" : t.toUpperCase(Locale.ROOT)) {
            case "PDF": return "picture_as_pdf";
            case "SLIDES": return "slideshow";
            case "CODE": return "terminal";
            default: return "folder_zip";
        }
    }
}
