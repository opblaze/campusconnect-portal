package com.campusconnect.service;

import com.campusconnect.config.AppProperties;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Thin client for the Gemini REST API (free-tier model gemini-2.5-flash by default).
 *
 * - The API key is read from app-local.properties or the GEMINI_API_KEY environment variable and is
 *   sent only server-side in a header; it never reaches the browser and is never logged.
 * - Calls have time-outs and one retry on quota / overload errors (Availability).
 */
@Component
public class GeminiClient {

    /** One earlier message of the conversation: role is "user" or "model". */
    public record Turn(String role, String text) { }

    private static final String DEFAULT_BASE = "https://generativelanguage.googleapis.com/v1beta/models/";

    private final String apiKey;
    private final String model;
    private final String base;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();

    @Autowired
    public GeminiClient(AppProperties p) {
        this.apiKey = p.get("gemini.api.key", "");
        this.model = p.get("gemini.model", "gemini-2.5-flash");
        this.base = p.get("gemini.base.url", DEFAULT_BASE); // only changed for tests / a proxy
    }

    /** "Thinking" can be switched off (budget 0) on 2.5 Flash / Flash-Lite only; other models reject the field. */
    private boolean supportsThinkingOff() {
        return model.startsWith("gemini-2.5-flash");
    }

    public boolean isConfigured() {
        return !apiKey.isBlank() && !apiKey.startsWith("PASTE");
    }

    /**
     * @param system      instructions that define what the model may talk about
     * @param history     previous turns (may be empty)
     * @param userText    the new user message / task
     * @param jsonOutput  true = ask for a strict JSON answer
     */
    public String generate(String system, List<Turn> history, String userText, double temperature,
                           int maxTokens, boolean jsonOutput) throws GeminiException {
        if (!isConfigured()) {
            throw new GeminiException("Gemini API key is not configured");
        }
        JsonObject body = new JsonObject();
        body.add("systemInstruction", content(null, system));
        JsonArray contents = new JsonArray();
        for (Turn t : history) {
            contents.add(content(t.role(), t.text()));
        }
        contents.add(content("user", userText));
        body.add("contents", contents);

        JsonObject cfg = new JsonObject();
        cfg.addProperty("temperature", temperature);
        cfg.addProperty("maxOutputTokens", maxTokens);
        if (jsonOutput) {
            cfg.addProperty("responseMimeType", "application/json");
        }
        if (supportsThinkingOff()) {
            JsonObject thinking = new JsonObject();
            thinking.addProperty("thinkingBudget", 0); // fast answers, fewer free-tier tokens
            cfg.add("thinkingConfig", thinking);
        }
        body.add("generationConfig", cfg);

        HttpRequest request = HttpRequest.newBuilder(URI.create(base + model + ":generateContent"))
                .timeout(Duration.ofSeconds(15))
                .header("Content-Type", "application/json")
                .header("x-goog-api-key", apiKey)
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();

        GeminiException last = null;
        for (int attempt = 0; attempt < 2; attempt++) {
            try {
                HttpResponse<String> resp = http.send(request, HttpResponse.BodyHandlers.ofString());
                int code = resp.statusCode();
                if (code == 200) {
                    return extractText(resp.body());
                }
                last = new GeminiException("Gemini returned HTTP " + code);
                if (code != 429 && code != 500 && code != 503) {
                    break; // not worth retrying (bad key, bad request ...)
                }
                Thread.sleep(1500);
            } catch (IOException ex) {
                last = new GeminiException("Gemini is unreachable: " + ex.getMessage(), ex);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
                throw new GeminiException("Interrupted", ex);
            }
        }
        throw last == null ? new GeminiException("Unknown Gemini failure") : last;
    }

    private static JsonObject content(String role, String text) {
        JsonObject c = new JsonObject();
        if (role != null) {
            c.addProperty("role", role);
        }
        JsonArray parts = new JsonArray();
        JsonObject part = new JsonObject();
        part.addProperty("text", text);
        parts.add(part);
        c.add("parts", parts);
        return c;
    }

    private static String extractText(String json) throws GeminiException {
        try {
            JsonObject root = JsonParser.parseString(json).getAsJsonObject();
            JsonArray cands = root.getAsJsonArray("candidates");
            if (cands == null || cands.isEmpty()) {
                throw new GeminiException("Gemini returned no answer (blocked or empty)");
            }
            JsonArray parts = cands.get(0).getAsJsonObject().getAsJsonObject("content").getAsJsonArray("parts");
            StringBuilder sb = new StringBuilder();
            for (JsonElement e : parts) {
                JsonElement t = e.getAsJsonObject().get("text");
                if (t != null) {
                    sb.append(t.getAsString());
                }
            }
            String out = sb.toString().trim();
            if (out.isEmpty()) {
                throw new GeminiException("Gemini returned an empty answer");
            }
            return out;
        } catch (RuntimeException ex) {
            throw new GeminiException("Unexpected Gemini response format", ex);
        }
    }
}
