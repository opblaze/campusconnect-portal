package com.campusconnect.service;

import com.campusconnect.config.AppProperties;
import com.campusconnect.dao.FacultyDao;
import com.campusconnect.dao.StudentDao;
import com.campusconnect.dao.UserDao;
import com.campusconnect.dto.SessionUser;
import com.campusconnect.model.Faculty;
import com.campusconnect.model.Student;
import com.campusconnect.model.User;
import com.campusconnect.model.enums.Role;
import com.campusconnect.util.PasswordHasher;
import com.campusconnect.util.Text;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Login logic: finds the account, verifies the password and protects against brute-force guessing.
 *
 * Security notes (Confidentiality / Availability):
 *  - the same generic error is returned for "unknown user" and "wrong password";
 *  - after N wrong attempts the login id is locked for a few minutes;
 *  - a dummy hash is checked for unknown ids so response time does not reveal which ids exist.
 */
@Service
public class AuthService {

    /** Outcome of a login attempt: either a SessionUser or an error message. */
    public static final class LoginResult {
        private final SessionUser user;
        private final String error;

        private LoginResult(SessionUser user, String error) {
            this.user = user;
            this.error = error;
        }

        public boolean isSuccess() { return user != null; }
        public SessionUser getUser() { return user; }
        public String getError() { return error; }
    }

    private static final class Attempts {
        int failures;
        Instant lockedUntil = Instant.EPOCH;
    }

    private static final String DUMMY_HASH = PasswordHasher.hash("not-a-real-password");

    private final UserDao userDao;
    private final StudentDao studentDao;
    private final FacultyDao facultyDao;
    private final int maxAttempts;
    private final Duration lockTime;
    private final Map<String, Attempts> attempts = new ConcurrentHashMap<>();

    @Autowired
    public AuthService(UserDao userDao, StudentDao studentDao, FacultyDao facultyDao, AppProperties props) {
        this.userDao = userDao;
        this.studentDao = studentDao;
        this.facultyDao = facultyDao;
        this.maxAttempts = props.getInt("login.max.attempts", 5);
        this.lockTime = Duration.ofMinutes(props.getInt("login.lock.minutes", 5));
    }

    public LoginResult login(String loginId, String password) {
        String key = loginId.trim().toLowerCase(Locale.ROOT);
        if (attempts.size() > 5000) {
            attempts.clear(); // someone is spraying random ids: never let this table grow without limit
        }
        Attempts a = attempts.computeIfAbsent(key, k -> new Attempts());

        synchronized (a) {
            if (Instant.now().isBefore(a.lockedUntil)) {
                long mins = Math.max(1, Duration.between(Instant.now(), a.lockedUntil).toMinutes() + 1);
                return new LoginResult(null, "Too many failed attempts. Try again in " + mins + " minute(s).");
            }
        }

        Optional<User> found = findUser(key);
        String hash = found.map(User::getPasswordHash).orElse(DUMMY_HASH);
        boolean ok = PasswordHasher.verify(password, hash) && found.isPresent() && found.get().isActive();

        if (!ok) {
            synchronized (a) {
                a.failures++;
                if (a.failures >= maxAttempts) {
                    a.failures = 0;
                    a.lockedUntil = Instant.now().plus(lockTime);
                }
            }
            return new LoginResult(null, "Invalid ID or password.");
        }

        attempts.remove(key);
        User user = found.get();
        user.setLastLoginAt(LocalDateTime.now());
        userDao.update(user);
        return new LoginResult(toSessionUser(user), null);
    }

    /** E-mail addresses contain '@'; anything else is treated as an enrollment number or employee code. */
    private Optional<User> findUser(String loginId) {
        if (loginId.contains("@")) {
            return userDao.findByEmail(loginId);
        }
        // Try enrollment number first (students)
        Optional<User> byEnrollment = studentDao.findByEnrollmentNo(loginId.toUpperCase(Locale.ROOT))
                .map(Student::getUser);
        if (byEnrollment.isPresent()) {
            return byEnrollment;
        }
        // Try employee code (faculty / admin)
        return facultyDao.findByEmployeeCode(loginId.toUpperCase(Locale.ROOT))
                .map(Faculty::getUser);
    }

    private SessionUser toSessionUser(User user) {
        SessionUser s = new SessionUser();
        s.setUserId(user.getId());
        s.setFullName(user.getFullName());
        s.setFirstName(Text.firstName(user.getFullName()));
        s.setInitials(Text.initials(user.getFullName()));
        s.setEmail(user.getEmail());
        s.setRole(user.getRole().name());
        s.setEnrollmentNo("");
        s.setBranchCode("");
        s.setSemesterLabel("");
        s.setAcademicYear("");
        s.setDepartment("");
        s.setDesignation("");
        s.setEmployeeCode("");
        if (user.getRole() == Role.STUDENT) {
            studentDao.findByUserId(user.getId()).ifPresent(st -> {
                s.setStudentId(st.getId());
                s.setEnrollmentNo(st.getEnrollmentNo());
                s.setBranchCode(st.getBranchCode());
                s.setSemesterLabel("Sem " + st.getSemester());
                s.setAcademicYear(st.getAcademicYear());
            });
        }
        if (user.getRole() == Role.FACULTY || user.getRole() == Role.ADMIN) {
            facultyDao.findByUserId(user.getId()).ifPresent(f -> {
                s.setFacultyId(f.getId());
                s.setDepartment(f.getDepartment());
                s.setDesignation(f.getDesignation());
                s.setEmployeeCode(f.getEmployeeCode());
            });
        }
        return s;
    }
}
