package com.campusconnect.service;

import com.campusconnect.config.AppProperties;
import com.campusconnect.dao.*;
import com.campusconnect.dto.AdminDashboardView.*;
import com.campusconnect.model.*;
import com.campusconnect.model.enums.FeedbackStatus;
import com.campusconnect.model.enums.NotificationColor;
import com.campusconnect.model.enums.Role;
import com.campusconnect.util.PasswordHasher;
import com.campusconnect.util.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Business logic backing every /admin/* control-panel page and action. */
@Service
public class AdminPortalService {

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH);

    private final UserDao userDao;
    private final StudentDao studentDao;
    private final FacultyDao facultyDao;
    private final SubjectDao subjectDao;
    private final EnrollmentDao enrollmentDao;
    private final FeeRecordDao feeDao;
    private final AnnouncementDao announcementDao;
    private final FeedbackDao feedbackDao;
    private final AttendanceRecordDao attendanceDao;
    private final NotificationDao notificationDao;
    private final AppProperties props;

    @Autowired
    public AdminPortalService(UserDao userDao, StudentDao studentDao, FacultyDao facultyDao,
            SubjectDao subjectDao, EnrollmentDao enrollmentDao, FeeRecordDao feeDao,
            AnnouncementDao announcementDao, FeedbackDao feedbackDao,
            AttendanceRecordDao attendanceDao, NotificationDao notificationDao, AppProperties props) {
        this.userDao = userDao;
        this.studentDao = studentDao;
        this.facultyDao = facultyDao;
        this.subjectDao = subjectDao;
        this.enrollmentDao = enrollmentDao;
        this.feeDao = feeDao;
        this.announcementDao = announcementDao;
        this.feedbackDao = feedbackDao;
        this.attendanceDao = attendanceDao;
        this.notificationDao = notificationDao;
        this.props = props;
    }

    // ------------------------------------------------------------------ Users

    public List<UserRow> usersPage(String roleFilter, String query) {
        List<User> users = userDao.allOrdered();
        Map<Long, String> codes = new HashMap<>();
        for (Student st : studentDao.allOrdered()) {
            codes.put(st.getUser().getId(), st.getEnrollmentNo() + " • Sem " + st.getSemester());
        }
        for (Faculty f : facultyDao.allOrdered()) {
            codes.put(f.getUser().getId(), f.getEmployeeCode() + " • " + f.getDepartment());
        }
        String rf = roleFilter == null ? "" : roleFilter.trim().toUpperCase(Locale.ROOT);
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);

        List<UserRow> rows = new ArrayList<>();
        for (User u : users) {
            if (!rf.isEmpty() && !rf.equals("ALL") && !u.getRole().name().equals(rf)) continue;
            String codeLabel = codes.getOrDefault(u.getId(), u.getRole() == Role.ADMIN ? "ADMIN" : "-");
            if (!q.isEmpty() && !containsAny(q, u.getFullName(), u.getEmail(), codeLabel, u.getRole().name())) continue;
            UserRow ur = new UserRow();
            ur.setId(u.getId());
            ur.setFullName(u.getFullName());
            ur.setEmail(u.getEmail());
            ur.setRole(u.getRole().name());
            ur.setActive(u.isActive());
            ur.setLastLoginLabel(u.getLastLoginAt() == null ? "Never" : u.getLastLoginAt().toLocalDate().format(DATE_FMT));
            ur.setCodeLabel(codeLabel);
            rows.add(ur);
        }
        return rows;
    }

    public void createUser(String fullName, String email, String roleStr, String password,
            String enrollmentNo, String program, String branchCode, int semester, String academicYear,
            boolean hosteler, String hostelName,
            String employeeCode, String title, String designation, String department, String cabin) {
        if (Validator.isBlank(fullName) || !Validator.isEmail(email)) {
            throw new IllegalArgumentException("Valid full name and institutional e-mail are required.");
        }
        if (!Validator.isStrongPassword(password)) {
            throw new IllegalArgumentException("Password must be at least 8 characters and contain a digit.");
        }
        Role role;
        try {
            role = Role.valueOf(roleStr.trim().toUpperCase(Locale.ROOT));
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid role.");
        }
        String cleanEmail = email.trim().toLowerCase(Locale.ROOT);
        if (userDao.findByEmail(cleanEmail).isPresent()) {
            throw new IllegalArgumentException("An account with this e-mail already exists.");
        }

        if (role == Role.STUDENT) {
            if (Validator.isBlank(enrollmentNo)) {
                throw new IllegalArgumentException("Enrollment number is required for students.");
            }
            String cleanEnroll = enrollmentNo.trim().toUpperCase(Locale.ROOT);
            if (studentDao.findByEnrollmentNo(cleanEnroll).isPresent()) {
                throw new IllegalArgumentException("Enrollment number already exists.");
            }
        } else if (role == Role.FACULTY) {
            if (Validator.isBlank(employeeCode)) {
                throw new IllegalArgumentException("Employee code is required for faculty.");
            }
            String cleanEmp = employeeCode.trim().toUpperCase(Locale.ROOT);
            if (facultyDao.findByEmployeeCode(cleanEmp).isPresent()) {
                throw new IllegalArgumentException("Employee code already exists.");
            }
        }

        User u = new User();
        u.setFullName(fullName.trim());
        u.setEmail(cleanEmail);
        u.setRole(role);
        u.setPasswordHash(PasswordHasher.hash(password));
        u.setActive(true);
        u.setCreatedAt(LocalDateTime.now(props.zone()));
        User savedUser = userDao.save(u);

        try {
            if (role == Role.STUDENT) {
                Student st = new Student();
                st.setUser(savedUser);
                st.setEnrollmentNo(enrollmentNo.trim().toUpperCase(Locale.ROOT));
                st.setProgram(Validator.isBlank(program) ? "B.Tech CSE" : program.trim());
                st.setBranchCode(Validator.isBlank(branchCode) ? "CS" : branchCode.trim().toUpperCase(Locale.ROOT));
                st.setSemester(Math.max(1, Math.min(8, semester)));
                st.setAcademicYear(Validator.isBlank(academicYear) ? "2026-27" : academicYear.trim());
                st.setCgpa(new BigDecimal("0.00"));
                st.setPreviousSgpa(new BigDecimal("0.00"));
                st.setEarnedCredits(0);
                st.setBacklogs(0);
                st.setHosteler(hosteler);
                st.setHostelName(hosteler && !Validator.isBlank(hostelName) ? hostelName.trim() : null);
                st.setSemesterStart(LocalDate.now(props.zone()).withDayOfMonth(1));
                st.setSemesterWeeks(16);
                Student savedSt = studentDao.save(st);
                LocalDate today = LocalDate.now(props.zone());
                for (Subject sub : subjectDao.bySemester(savedSt.getSemester())) {
                    if (!enrollmentDao.isEnrolled(savedSt.getId(), sub.getId())) {
                        Enrollment en = new Enrollment();
                        en.setStudent(savedSt);
                        en.setSubject(sub);
                        en.setEnrolledOn(today);
                        enrollmentDao.save(en);
                    }
                }
            } else if (role == Role.FACULTY) {
                Faculty f = new Faculty();
                f.setUser(savedUser);
                f.setEmployeeCode(employeeCode.trim().toUpperCase(Locale.ROOT));
                f.setTitle(Validator.isBlank(title) ? "Prof." : title.trim());
                f.setDesignation(Validator.isBlank(designation) ? "Assistant Professor" : designation.trim());
                f.setDepartment(Validator.isBlank(department) ? "Computer Engineering" : department.trim());
                f.setCabin(Validator.isBlank(cabin) ? null : cabin.trim());
                facultyDao.save(f);
            }
        } catch (RuntimeException ex) {
            userDao.delete(savedUser);
            throw ex;
        }
    }

    public boolean toggleUserActive(Long currentAdminUserId, Long targetUserId) {
        if (Objects.equals(currentAdminUserId, targetUserId)) {
            throw new IllegalArgumentException("You cannot deactivate your own active administrator account.");
        }
        User u = userDao.findById(targetUserId).orElseThrow(() -> new IllegalArgumentException("User not found."));
        u.setActive(!u.isActive());
        userDao.update(u);
        return u.isActive();
    }

    public void resetUserPassword(Long targetUserId, String newPassword) {
        if (!Validator.isStrongPassword(newPassword)) {
            throw new IllegalArgumentException("New password must be at least 8 characters and include a digit.");
        }
        User u = userDao.findById(targetUserId).orElseThrow(() -> new IllegalArgumentException("User not found."));
        u.setPasswordHash(PasswordHasher.hash(newPassword));
        userDao.update(u);
    }

    // ------------------------------------------------------------------ Students & Enrollments

    public StudentsPageData studentsPage(Integer semesterFilter, String query, Long selectedStudentId) {
        StudentsPageData data = new StudentsPageData();
        List<Student> all = studentDao.allOrdered();
        Map<Long, Long> enrollCounts = enrollmentDao.countByStudent();
        Map<Long, long[]> attMap = attendanceDao.overallByStudent();
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        int minPct = props.getInt("attendance.min", 75);
        int greenPct = props.getInt("attendance.green.min", 85);

        List<StudentAdminRow> rows = new ArrayList<>();
        Student selected = null;
        for (Student st : all) {
            if (selectedStudentId != null && st.getId().equals(selectedStudentId)) selected = st;
            if (semesterFilter != null && semesterFilter > 0 && st.getSemester() != semesterFilter) continue;
            if (!q.isEmpty() && !containsAny(q, st.getEnrollmentNo(), st.getUser().getFullName(),
                    st.getUser().getEmail(), st.getBranchCode(), st.getProgram())) continue;

            long[] att = attMap.getOrDefault(st.getId(), new long[]{0L, 0L});
            int pct = att[0] == 0 ? 100 : (int) Math.round((att[1] * 100.0) / att[0]);
            StudentAdminRow r = new StudentAdminRow();
            r.setStudentId(st.getId());
            r.setUserId(st.getUser().getId());
            r.setEnrollmentNo(st.getEnrollmentNo());
            r.setFullName(st.getUser().getFullName());
            r.setEmail(st.getUser().getEmail());
            r.setProgram(st.getProgram());
            r.setBranchCode(st.getBranchCode());
            r.setSemester(st.getSemester());
            r.setAcademicYear(st.getAcademicYear());
            r.setCgpa(st.getCgpa() == null ? "0.00" : st.getCgpa().toPlainString());
            r.setPhone(st.getPhone() == null ? "" : st.getPhone());
            r.setHosteler(st.isHosteler());
            r.setHostelName(st.getHostelName() == null ? "" : st.getHostelName());
            r.setActive(st.getUser().isActive());
            r.setEnrolledCount(enrollCounts.getOrDefault(st.getId(), 0L));
            r.setAttendancePct(att[0] == 0 ? -1 : pct);
            r.setAttendanceTone(att[0] == 0 ? "BLUE" : (pct >= greenPct ? "GREEN" : (pct >= minPct ? "YELLOW" : "RED")));
            rows.add(r);
        }
        if (selected == null && !rows.isEmpty()) {
            Long firstId = rows.get(0).getStudentId();
            selected = all.stream().filter(s -> s.getId().equals(firstId)).findFirst().orElse(null);
        }
        data.setStudents(rows);

        List<Subject> allSubjects = subjectDao.allOrdered();
        List<SubjectOption> subjectOpts = new ArrayList<>();
        for (Subject s : allSubjects) {
            SubjectOption o = new SubjectOption();
            o.setId(s.getId());
            o.setLabel(s.getCode() + " • " + s.getName() + " (Sem " + s.getSemester() + ")");
            subjectOpts.add(o);
        }
        data.setAllSubjects(subjectOpts);

        if (selected != null) {
            data.setSelectedStudentId(selected.getId());
            data.setSelectedStudentName(selected.getUser().getFullName());
            data.setSelectedStudentEnroll(selected.getEnrollmentNo());
            data.setSelectedSemester(selected.getSemester());
            data.setSelectedCgpa(selected.getCgpa() == null ? "0.00" : selected.getCgpa().toPlainString());
            data.setSelectedBranchCode(selected.getBranchCode());
            data.setSelectedHosteler(selected.isHosteler());
            data.setSelectedHostelName(selected.getHostelName() == null ? "" : selected.getHostelName());
            data.setSelectedPhone(selected.getPhone() == null ? "" : selected.getPhone());

            List<SubjectOption> enrolledOpts = new ArrayList<>();
            for (Subject s : enrollmentDao.subjectsOf(selected.getId())) {
                SubjectOption o = new SubjectOption();
                o.setId(s.getId());
                o.setLabel(s.getCode() + " • " + s.getName());
                enrolledOpts.add(o);
            }
            data.setEnrolledSubjects(enrolledOpts);
        } else {
            data.setEnrolledSubjects(Collections.emptyList());
        }
        return data;
    }

    public void updateStudent(Long studentId, int semester, BigDecimal cgpa, String branchCode,
            boolean hosteler, String hostelName, String phone) {
        Student st = studentDao.findById(studentId).orElseThrow(() -> new IllegalArgumentException("Student not found."));
        if (semester < 1 || semester > 8) throw new IllegalArgumentException("Semester must be between 1 and 8.");
        if (cgpa == null || cgpa.compareTo(BigDecimal.ZERO) < 0 || cgpa.compareTo(new BigDecimal("10.00")) > 0) {
            throw new IllegalArgumentException("CGPA must be between 0.00 and 10.00.");
        }
        st.setSemester(semester);
        st.setCgpa(cgpa.setScale(2, RoundingMode.HALF_UP));
        if (!Validator.isBlank(branchCode)) st.setBranchCode(branchCode.trim().toUpperCase(Locale.ROOT));
        st.setHosteler(hosteler);
        st.setHostelName(hosteler && !Validator.isBlank(hostelName) ? hostelName.trim() : null);
        st.setPhone(Validator.isBlank(phone) ? null : phone.trim());
        studentDao.update(st);
    }

    public void enrollStudent(Long studentId, Long subjectId) {
        Student st = studentDao.findById(studentId).orElseThrow(() -> new IllegalArgumentException("Student not found."));
        Subject sub = subjectDao.findById(subjectId).orElseThrow(() -> new IllegalArgumentException("Subject not found."));
        if (enrollmentDao.isEnrolled(studentId, subjectId)) {
            throw new IllegalArgumentException("Student is already enrolled in " + sub.getCode() + ".");
        }
        Enrollment e = new Enrollment();
        e.setStudent(st);
        e.setSubject(sub);
        e.setEnrolledOn(LocalDate.now(props.zone()));
        enrollmentDao.save(e);
    }

    public void unenrollStudent(Long studentId, Long subjectId) {
        enrollmentDao.removeEnrollment(studentId, subjectId);
    }

    // ------------------------------------------------------------------ Faculty Directory

    public List<FacultyAdminRow> facultyPage(String deptFilter, String query) {
        List<Faculty> list = facultyDao.allOrdered();
        List<Subject> allSubs = subjectDao.allOrdered();
        Map<Long, List<String>> subCodesByFac = new HashMap<>();
        for (Subject s : allSubs) {
            subCodesByFac.computeIfAbsent(s.getFaculty().getId(), k -> new ArrayList<>()).add(s.getCode());
        }
        String df = deptFilter == null ? "" : deptFilter.trim().toLowerCase(Locale.ROOT);
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);

        List<FacultyAdminRow> rows = new ArrayList<>();
        for (Faculty f : list) {
            if (!df.isEmpty() && !df.equals("all") && !f.getDepartment().toLowerCase(Locale.ROOT).equals(df)) continue;
            if (!q.isEmpty() && !containsAny(q, f.getEmployeeCode(), f.getUser().getFullName(),
                    f.getUser().getEmail(), f.getDepartment(), f.getDesignation())) continue;
            List<String> codes = subCodesByFac.getOrDefault(f.getId(), Collections.emptyList());
            FacultyAdminRow r = new FacultyAdminRow();
            r.setFacultyId(f.getId());
            r.setUserId(f.getUser().getId());
            r.setEmployeeCode(f.getEmployeeCode());
            r.setTitle(f.getTitle());
            r.setFullName(f.getUser().getFullName());
            r.setEmail(f.getUser().getEmail());
            r.setDesignation(f.getDesignation());
            r.setDepartment(f.getDepartment());
            r.setCabin(f.getCabin() == null ? "-" : f.getCabin());
            r.setActive(f.getUser().isActive());
            r.setSubjectCount(codes.size());
            r.setSubjectCodes(codes.isEmpty() ? "None assigned" : String.join(", ", codes));
            rows.add(r);
        }
        return rows;
    }

    // ------------------------------------------------------------------ Subjects & Curriculum

    public SubjectsAdminPageData subjectsPage(Integer semesterFilter) {
        SubjectsAdminPageData data = new SubjectsAdminPageData();
        Map<Long, Long> counts = enrollmentDao.countBySubject();
        List<SubjectAdminRow> rows = new ArrayList<>();
        for (Subject s : subjectDao.allOrdered()) {
            if (semesterFilter != null && semesterFilter > 0 && s.getSemester() != semesterFilter) continue;
            SubjectAdminRow r = new SubjectAdminRow();
            r.setId(s.getId());
            r.setCode(s.getCode());
            r.setName(s.getName());
            r.setShortName(s.getShortName());
            r.setCredits(s.getCredits());
            r.setCategory(s.getCategory());
            r.setSemester(s.getSemester());
            r.setFacultyId(s.getFaculty().getId());
            r.setFacultyName(s.getFaculty().getTitle() + " " + s.getFaculty().getUser().getFullName());
            r.setFacultyCode(s.getFaculty().getEmployeeCode());
            r.setEnrolledCount(counts.getOrDefault(s.getId(), 0L));
            r.setSyllabusPct(s.getSyllabusCompletion() == null ? 0 : s.getSyllabusCompletion().intValue());
            r.setMeetingDays(s.getMeetingDays());
            rows.add(r);
        }
        data.setSubjects(rows);

        List<FacultyOption> facOpts = new ArrayList<>();
        for (Faculty f : facultyDao.allOrdered()) {
            FacultyOption fo = new FacultyOption();
            fo.setId(f.getId());
            fo.setLabel(f.getTitle() + " " + f.getUser().getFullName() + " (" + f.getEmployeeCode() + ")");
            facOpts.add(fo);
        }
        data.setFacultyOptions(facOpts);
        return data;
    }

    public void createSubject(String code, String name, String shortName, int credits, String category,
            int semester, Long facultyId, String meetingDays) {
        if (Validator.isBlank(code) || Validator.isBlank(name) || Validator.isBlank(shortName)) {
            throw new IllegalArgumentException("Subject code, full name and short code are required.");
        }
        String cleanCode = code.trim().toUpperCase(Locale.ROOT);
        if (subjectDao.findByCode(cleanCode).isPresent()) {
            throw new IllegalArgumentException("Subject code " + cleanCode + " already exists.");
        }
        Faculty f = facultyDao.findById(facultyId).orElseThrow(() -> new IllegalArgumentException("Faculty is required."));
        Subject s = new Subject();
        s.setCode(cleanCode);
        s.setName(name.trim());
        s.setShortName(shortName.trim().toUpperCase(Locale.ROOT));
        s.setCredits(Math.max(1, Math.min(8, credits)));
        s.setCategory("LAB".equalsIgnoreCase(category) ? "LAB" : "CORE");
        s.setSemester(Math.max(1, Math.min(8, semester)));
        s.setFaculty(f);
        s.setSyllabusCompletion(BigDecimal.ZERO);
        s.setMeetingDays(Validator.isBlank(meetingDays) ? "MO,WE,FR" : meetingDays.trim().toUpperCase(Locale.ROOT));
        subjectDao.save(s);
    }

    public void assignFacultyToSubject(Long subjectId, Long facultyId) {
        Subject s = subjectDao.findById(subjectId).orElseThrow(() -> new IllegalArgumentException("Subject not found."));
        Faculty f = facultyDao.findById(facultyId).orElseThrow(() -> new IllegalArgumentException("Faculty not found."));
        s.setFaculty(f);
        subjectDao.update(s);
    }

    // ------------------------------------------------------------------ Fee Management

    public FeesAdminPageData feesPage(String statusFilter, String categoryFilter, String query) {
        FeesAdminPageData data = new FeesAdminPageData();
        LocalDate today = LocalDate.now(props.zone());
        String sf = statusFilter == null ? "" : statusFilter.trim().toUpperCase(Locale.ROOT);
        String cf = categoryFilter == null ? "" : categoryFilter.trim().toUpperCase(Locale.ROOT);
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);

        BigDecimal collected = BigDecimal.ZERO;
        BigDecimal pending = BigDecimal.ZERO;
        BigDecimal overdue = BigDecimal.ZERO;
        int unpaidCount = 0, overdueCount = 0;

        List<FeeAdminRow> rows = new ArrayList<>();
        for (FeeRecord f : feeDao.allOrdered()) {
            BigDecimal amt = f.getAmount() == null ? BigDecimal.ZERO : f.getAmount();
            boolean isOverdue = !f.isPaid() && f.getDueDate() != null && f.getDueDate().isBefore(today);
            if (f.isPaid()) {
                collected = collected.add(amt);
            } else {
                unpaidCount++;
                pending = pending.add(amt);
                if (isOverdue) {
                    overdueCount++;
                    overdue = overdue.add(amt);
                }
            }
            String stLabel = f.isPaid() ? "PAID" : (isOverdue ? "OVERDUE" : "PENDING");
            if (!sf.isEmpty() && !sf.equals("ALL") && !stLabel.equals(sf)) continue;
            if (!cf.isEmpty() && !cf.equals("ALL") && !f.getCategory().equalsIgnoreCase(cf)) continue;
            if (!q.isEmpty() && !containsAny(q, f.getTitle(), f.getStudent().getEnrollmentNo(),
                    f.getStudent().getUser().getFullName(), f.getReceiptNo())) continue;

            FeeAdminRow r = new FeeAdminRow();
            r.setId(f.getId());
            r.setStudentId(f.getStudent().getId());
            r.setEnrollmentNo(f.getStudent().getEnrollmentNo());
            r.setStudentName(f.getStudent().getUser().getFullName());
            r.setBranchSem(f.getStudent().getBranchCode() + " • Sem " + f.getStudent().getSemester());
            r.setTitle(f.getTitle());
            r.setCategory(f.getCategory());
            r.setAmountLabel(AdminDashboardService.formatInr(amt));
            r.setDueDateLabel(f.getDueDate() == null ? "-" : f.getDueDate().format(DATE_FMT));
            r.setStatus(stLabel);
            r.setTone(f.isPaid() ? "GREEN" : (isOverdue ? "RED" : "YELLOW"));
            r.setPaid(f.isPaid());
            r.setPaidOnLabel(f.getPaidOn() == null ? "-" : f.getPaidOn().format(DATE_FMT));
            r.setReceiptNo(f.getReceiptNo() == null ? "-" : f.getReceiptNo());
            r.setPaymentMethod(f.getPaymentMethod() == null ? "-" : f.getPaymentMethod());
            rows.add(r);
        }

        BigDecimal billed = collected.add(pending);
        int pct = billed.compareTo(BigDecimal.ZERO) == 0 ? 0
                : collected.multiply(BigDecimal.valueOf(100)).divide(billed, 0, RoundingMode.HALF_UP).intValue();
        data.setCollectedLabel(AdminDashboardService.formatInr(collected));
        data.setPendingLabel(AdminDashboardService.formatInr(pending));
        data.setOverdueLabel(AdminDashboardService.formatInr(overdue));
        data.setTotalBilledLabel(AdminDashboardService.formatInr(billed));
        data.setCollectionPct(pct);
        data.setUnpaidCount(unpaidCount);
        data.setOverdueCount(overdueCount);
        data.setFees(rows);

        List<StudentOption> studentOpts = new ArrayList<>();
        for (Student st : studentDao.allOrdered()) {
            StudentOption so = new StudentOption();
            so.setId(st.getId());
            so.setLabel(st.getEnrollmentNo() + " • " + st.getUser().getFullName());
            studentOpts.add(so);
        }
        data.setStudentOptions(studentOpts);
        return data;
    }

    public void createFee(Long studentId, String title, String category, BigDecimal amount, LocalDate dueDate) {
        if (Validator.isBlank(title)) throw new IllegalArgumentException("Fee title is required.");
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Amount must be greater than zero.");
        }
        if (dueDate == null) throw new IllegalArgumentException("Due date is required.");
        Student st = studentDao.findById(studentId).orElseThrow(() -> new IllegalArgumentException("Student not found."));
        String cat = category == null ? "TUITION" : category.trim().toUpperCase(Locale.ROOT);
        if (!List.of("TUITION", "HOSTEL", "EXAM", "PRC").contains(cat)) cat = "TUITION";

        FeeRecord f = new FeeRecord();
        f.setStudent(st);
        f.setTitle(title.trim());
        f.setCategory(cat);
        f.setAmount(amount.setScale(2, RoundingMode.HALF_UP));
        f.setDueDate(dueDate);
        f.setPaid(false);
        FeeRecord saved = feeDao.save(f);

        Notification n = new Notification();
        n.setStudent(st);
        n.setColor(NotificationColor.ORANGE);
        n.setCategory("FEE");
        n.setTitle("New fee demand: " + saved.getTitle());
        n.setMessage(AdminDashboardService.formatInr(saved.getAmount()) + " due by " + dueDate.format(DATE_FMT));
        n.setActionLabel("View fees");
        n.setActionUrl("/app/fees");
        n.setDedupeKey("fee-new-" + saved.getId() + "-" + st.getId());
        n.setCreatedAt(LocalDateTime.now(props.zone()));
        n.setPopupShown(false);
        n.setEmailSent(false);
        try {
            notificationDao.save(n);
        } catch (RuntimeException ignored) {
            // Safe if duplicate key
        }
    }

    public void markFeePaid(Long feeId, String paymentMethod) {
        FeeRecord f = feeDao.findById(feeId).orElseThrow(() -> new IllegalArgumentException("Fee record not found."));
        if (f.isPaid()) return;
        f.setPaid(true);
        f.setPaidOn(LocalDate.now(props.zone()));
        f.setPaymentMethod(Validator.isBlank(paymentMethod) ? "Admin Counter" : paymentMethod.trim());
        f.setReceiptNo("MU-ADM-" + feeId + "-" + (System.currentTimeMillis() % 10000));
        feeDao.update(f);
    }

    // ------------------------------------------------------------------ Announcements

    public AnnouncementsAdminPageData announcementsPage() {
        AnnouncementsAdminPageData data = new AnnouncementsAdminPageData();
        List<NoticeRow> rows = new ArrayList<>();
        for (Announcement a : announcementDao.latest(50)) {
            NoticeRow nr = new NoticeRow();
            nr.setId(a.getId());
            nr.setTitle(a.getTitle());
            nr.setBody(a.getBody());
            nr.setSubjectCode(a.getSubject() != null ? a.getSubject().getCode() : "Campus-wide");
            nr.setAuthorName(a.getPostedBy() != null ? a.getPostedBy().getUser().getFullName() : "Administration");
            nr.setImportant(a.isImportant());
            nr.setCreatedLabel(a.getCreatedAt() == null ? "" : a.getCreatedAt().toLocalDate().format(DATE_FMT));
            rows.add(nr);
        }
        data.setNotices(rows);

        List<SubjectOption> subjectOpts = new ArrayList<>();
        for (Subject s : subjectDao.allOrdered()) {
            SubjectOption o = new SubjectOption();
            o.setId(s.getId());
            o.setLabel(s.getCode() + " • " + s.getName());
            subjectOpts.add(o);
        }
        data.setSubjectOptions(subjectOpts);
        return data;
    }

    public int postAnnouncement(Long subjectIdOrNull, String title, String body, boolean important, boolean notifyStudents) {
        if (Validator.isBlank(title) || Validator.isBlank(body)) {
            throw new IllegalArgumentException("Notice title and message body are required.");
        }
        Subject sub = subjectIdOrNull == null ? null
                : subjectDao.findById(subjectIdOrNull).orElseThrow(() -> new IllegalArgumentException("Subject not found."));
        LocalDateTime now = LocalDateTime.now(props.zone());
        Announcement a = new Announcement();
        a.setTitle(title.trim());
        a.setBody(body.trim());
        a.setImportant(important);
        a.setSubject(sub);
        a.setPostedBy(null);
        a.setCreatedAt(now);
        a.setExpiresAt(now.plusDays(30));
        Announcement saved = announcementDao.save(a);

        int sent = 0;
        if (notifyStudents) {
            List<Student> recipients = sub != null ? enrollmentDao.studentsOf(sub.getId()) : studentDao.allOrdered();
            for (Student st : recipients) {
                if (!st.getUser().isActive()) continue;
                Notification n = new Notification();
                n.setStudent(st);
                n.setColor(important ? NotificationColor.RED : NotificationColor.BLUE);
                n.setCategory("ANNOUNCEMENT");
                n.setTitle((important ? "Important: " : "") + saved.getTitle());
                n.setMessage(saved.getBody().length() > 240 ? saved.getBody().substring(0, 237) + "..." : saved.getBody());
                n.setActionLabel("View notices");
                n.setActionUrl("/app/notifications");
                n.setDedupeKey("adm-notice-" + saved.getId() + "-" + st.getId());
                n.setCreatedAt(now);
                n.setPopupShown(false);
                n.setEmailSent(false);
                try {
                    notificationDao.save(n);
                    sent++;
                } catch (RuntimeException ignored) {
                    // Ignore dedupe collisions
                }
            }
        }
        return sent;
    }

    public void deleteAnnouncement(Long id) {
        announcementDao.deleteById(id);
    }

    // ------------------------------------------------------------------ Feedback & Helpdesk

    public FeedbackAdminPageData feedbackPage(String statusFilter) {
        FeedbackAdminPageData data = new FeedbackAdminPageData();
        String sf = statusFilter == null ? "" : statusFilter.trim().toUpperCase(Locale.ROOT);
        int cNew = 0, cSent = 0, cRej = 0;
        List<FeedbackRow> rows = new ArrayList<>();
        for (Feedback fb : feedbackDao.latestAll(150)) {
            if (fb.getStatus() == FeedbackStatus.NEW) cNew++;
            else if (fb.getStatus() == FeedbackStatus.SENT) cSent++;
            else cRej++;
            if (!sf.isEmpty() && !sf.equals("ALL") && !fb.getStatus().name().equals(sf)) continue;

            FeedbackRow fr = new FeedbackRow();
            fr.setId(fb.getId());
            fr.setStudentName(fb.getStudent().getUser().getFullName());
            fr.setStudentEnroll(fb.getStudent().getEnrollmentNo());
            fr.setSubjectCode(fb.getSubject() != null ? fb.getSubject().getCode() : "General");
            fr.setFacultyName(fb.getFaculty() != null ? fb.getFaculty().getUser().getFullName() : "Campus Admin");
            fr.setCategory(fb.getCategory() == null ? "General" : fb.getCategory());
            fr.setStatus(fb.getStatus().name());
            String msg = fb.getProcessedText() != null && !fb.getProcessedText().isBlank()
                    ? fb.getProcessedText() : fb.getRawText();
            fr.setMessage(msg);
            fr.setCreatedLabel(fb.getCreatedAt() == null ? "" : fb.getCreatedAt().toLocalDate().format(DATE_FMT));
            rows.add(fr);
        }
        data.setFeedbacks(rows);
        data.setNewCount(cNew);
        data.setSentCount(cSent);
        data.setRejectedCount(cRej);
        return data;
    }

    public void updateFeedbackStatus(Long feedbackId, FeedbackStatus status) {
        Feedback fb = feedbackDao.findById(feedbackId)
                .orElseThrow(() -> new IllegalArgumentException("Feedback record not found."));
        fb.setStatus(status);
        if (status == FeedbackStatus.SENT && fb.getEmailedAt() == null) {
            fb.setEmailedAt(LocalDateTime.now(props.zone()));
        }
        feedbackDao.update(fb);
    }

    // ------------------------------------------------------------------ Profile

    public void updateAdminPassword(Long userId, String fullName, String currentPassword, String newPassword) {
        User u = userDao.findById(userId).orElseThrow(() -> new IllegalArgumentException("User not found."));
        if (!Validator.isBlank(fullName)) {
            u.setFullName(fullName.trim());
        }
        if (!Validator.isBlank(newPassword)) {
            if (Validator.isBlank(currentPassword) || !PasswordHasher.verify(currentPassword, u.getPasswordHash())) {
                throw new IllegalArgumentException("Current password is incorrect.");
            }
            if (!Validator.isStrongPassword(newPassword)) {
                throw new IllegalArgumentException("New password must be at least 8 characters and include a digit.");
            }
            u.setPasswordHash(PasswordHasher.hash(newPassword));
        }
        userDao.update(u);
    }

    // ------------------------------------------------------------------ Search

    public List<String> suggest() {
        return List.of("Users", "Students", "Faculty", "Subjects", "Fees", "Overdue", "Announcements", "Feedback");
    }

    public List<Map<String, String>> searchRows(String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) return Collections.emptyList();
        List<Map<String, String>> out = new ArrayList<>();

        addPageMatch(out, q, "User Accounts", "Create accounts, toggle status, reset passwords", "/admin/users", "user account password role login");
        addPageMatch(out, q, "Student Directory", "Enrollments, semester and CGPA", "/admin/students", "student enroll cgpa hostel");
        addPageMatch(out, q, "Faculty Directory", "Teaching staff and departments", "/admin/faculty", "faculty teacher professor staff");
        addPageMatch(out, q, "Subject Catalog", "Course setup and faculty allocation", "/admin/subjects", "subject course syllabus curriculum");
        addPageMatch(out, q, "Fee Ledger", "Billing, dues and receipt tracking", "/admin/fees", "fee tuition overdue receipt payment");
        addPageMatch(out, q, "Announcements", "Broadcast campus-wide notices", "/admin/announcements", "announce notice broadcast");
        addPageMatch(out, q, "Feedback & Helpdesk", "Review student grievances", "/admin/feedback", "feedback helpdesk ticket");

        for (Student st : studentDao.allOrdered()) {
            if (containsAny(q, st.getEnrollmentNo(), st.getUser().getFullName(), st.getUser().getEmail(), st.getBranchCode())) {
                out.add(resultRow("Student", st.getUser().getFullName(),
                        st.getEnrollmentNo() + " • " + st.getBranchCode() + " Sem " + st.getSemester(),
                        "/admin/students?id=" + st.getId(), st.getUser().isActive() ? "Active" : "Inactive",
                        st.getUser().isActive() ? "GREEN" : "RED"));
            }
        }
        for (Faculty f : facultyDao.allOrdered()) {
            if (containsAny(q, f.getEmployeeCode(), f.getUser().getFullName(), f.getDepartment(), f.getDesignation())) {
                out.add(resultRow("Faculty", f.getTitle() + " " + f.getUser().getFullName(),
                        f.getEmployeeCode() + " • " + f.getDepartment(),
                        "/admin/faculty?q=" + f.getEmployeeCode(), "Faculty", "BLUE"));
            }
        }
        for (Subject s : subjectDao.allOrdered()) {
            if (containsAny(q, s.getCode(), s.getName(), s.getShortName())) {
                out.add(resultRow("Subject", s.getCode() + " • " + s.getName(),
                        "Sem " + s.getSemester() + " • " + s.getFaculty().getUser().getFullName(),
                        "/admin/subjects?semester=" + s.getSemester(), s.getCategory(), "BLUE"));
            }
        }
        for (FeeRecord f : feeDao.allOrdered()) {
            if (containsAny(q, f.getTitle(), f.getCategory(), f.getStudent().getEnrollmentNo(), f.getReceiptNo())) {
                out.add(resultRow("Fee", f.getTitle() + " (" + f.getStudent().getEnrollmentNo() + ")",
                        AdminDashboardService.formatInr(f.getAmount()) + " • " + (f.isPaid() ? "Paid" : "Unpaid"),
                        "/admin/fees?q=" + f.getStudent().getEnrollmentNo(),
                        f.isPaid() ? "Paid" : "Due", f.isPaid() ? "GREEN" : "YELLOW"));
            }
        }
        return out.stream().limit(25).toList();
    }

    // ------------------------------------------------------------------ Helpers

    private static boolean containsAny(String q, String... values) {
        for (String v : values) {
            if (v != null && v.toLowerCase(Locale.ROOT).contains(q)) return true;
        }
        return false;
    }

    private static void addPageMatch(List<Map<String, String>> out, String q, String title, String sub, String href, String keys) {
        if (title.toLowerCase(Locale.ROOT).contains(q) || keys.contains(q)) {
            out.add(resultRow("Page", title, sub, href, "Admin", "NONE"));
        }
    }

    private static Map<String, String> resultRow(String type, String title, String sub, String href, String badge, String tone) {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("type", type);
        m.put("title", title);
        m.put("sub", sub);
        m.put("href", href);
        m.put("badge", badge);
        m.put("tone", tone);
        return m;
    }

    // ------------------------------------------------------------------ Page Data DTOs

    public static class StudentsPageData {
        private List<StudentAdminRow> students;
        private List<SubjectOption> allSubjects;
        private Long selectedStudentId;
        private String selectedStudentName;
        private String selectedStudentEnroll;
        private int selectedSemester;
        private String selectedCgpa;
        private String selectedBranchCode;
        private boolean selectedHosteler;
        private String selectedHostelName;
        private String selectedPhone;
        private List<SubjectOption> enrolledSubjects;

        public List<StudentAdminRow> getStudents() { return students; }
        public void setStudents(List<StudentAdminRow> students) { this.students = students; }
        public List<SubjectOption> getAllSubjects() { return allSubjects; }
        public void setAllSubjects(List<SubjectOption> allSubjects) { this.allSubjects = allSubjects; }
        public Long getSelectedStudentId() { return selectedStudentId; }
        public void setSelectedStudentId(Long selectedStudentId) { this.selectedStudentId = selectedStudentId; }
        public String getSelectedStudentName() { return selectedStudentName; }
        public void setSelectedStudentName(String selectedStudentName) { this.selectedStudentName = selectedStudentName; }
        public String getSelectedStudentEnroll() { return selectedStudentEnroll; }
        public void setSelectedStudentEnroll(String selectedStudentEnroll) { this.selectedStudentEnroll = selectedStudentEnroll; }
        public int getSelectedSemester() { return selectedSemester; }
        public void setSelectedSemester(int selectedSemester) { this.selectedSemester = selectedSemester; }
        public String getSelectedCgpa() { return selectedCgpa; }
        public void setSelectedCgpa(String selectedCgpa) { this.selectedCgpa = selectedCgpa; }
        public String getSelectedBranchCode() { return selectedBranchCode; }
        public void setSelectedBranchCode(String selectedBranchCode) { this.selectedBranchCode = selectedBranchCode; }
        public boolean isSelectedHosteler() { return selectedHosteler; }
        public void setSelectedHosteler(boolean selectedHosteler) { this.selectedHosteler = selectedHosteler; }
        public String getSelectedHostelName() { return selectedHostelName; }
        public void setSelectedHostelName(String selectedHostelName) { this.selectedHostelName = selectedHostelName; }
        public String getSelectedPhone() { return selectedPhone; }
        public void setSelectedPhone(String selectedPhone) { this.selectedPhone = selectedPhone; }
        public List<SubjectOption> getEnrolledSubjects() { return enrolledSubjects; }
        public void setEnrolledSubjects(List<SubjectOption> enrolledSubjects) { this.enrolledSubjects = enrolledSubjects; }
    }

    public static class StudentAdminRow {
        private Long studentId;
        private Long userId;
        private String enrollmentNo;
        private String fullName;
        private String email;
        private String program;
        private String branchCode;
        private int semester;
        private String academicYear;
        private String cgpa;
        private String phone;
        private boolean hosteler;
        private String hostelName;
        private boolean active;
        private long enrolledCount;
        private int attendancePct;
        private String attendanceTone;

        public Long getStudentId() { return studentId; }
        public void setStudentId(Long studentId) { this.studentId = studentId; }
        public Long getUserId() { return userId; }
        public void setUserId(Long userId) { this.userId = userId; }
        public String getEnrollmentNo() { return enrollmentNo; }
        public void setEnrollmentNo(String enrollmentNo) { this.enrollmentNo = enrollmentNo; }
        public String getFullName() { return fullName; }
        public void setFullName(String fullName) { this.fullName = fullName; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getProgram() { return program; }
        public void setProgram(String program) { this.program = program; }
        public String getBranchCode() { return branchCode; }
        public void setBranchCode(String branchCode) { this.branchCode = branchCode; }
        public int getSemester() { return semester; }
        public void setSemester(int semester) { this.semester = semester; }
        public String getAcademicYear() { return academicYear; }
        public void setAcademicYear(String academicYear) { this.academicYear = academicYear; }
        public String getCgpa() { return cgpa; }
        public void setCgpa(String cgpa) { this.cgpa = cgpa; }
        public String getPhone() { return phone; }
        public void setPhone(String phone) { this.phone = phone; }
        public boolean isHosteler() { return hosteler; }
        public void setHosteler(boolean hosteler) { this.hosteler = hosteler; }
        public String getHostelName() { return hostelName; }
        public void setHostelName(String hostelName) { this.hostelName = hostelName; }
        public boolean isActive() { return active; }
        public void setActive(boolean active) { this.active = active; }
        public long getEnrolledCount() { return enrolledCount; }
        public void setEnrolledCount(long enrolledCount) { this.enrolledCount = enrolledCount; }
        public int getAttendancePct() { return attendancePct; }
        public void setAttendancePct(int attendancePct) { this.attendancePct = attendancePct; }
        public String getAttendanceTone() { return attendanceTone; }
        public void setAttendanceTone(String attendanceTone) { this.attendanceTone = attendanceTone; }
    }

    public static class FacultyAdminRow {
        private Long facultyId;
        private Long userId;
        private String employeeCode;
        private String title;
        private String fullName;
        private String email;
        private String designation;
        private String department;
        private String cabin;
        private boolean active;
        private int subjectCount;
        private String subjectCodes;

        public Long getFacultyId() { return facultyId; }
        public void setFacultyId(Long facultyId) { this.facultyId = facultyId; }
        public Long getUserId() { return userId; }
        public void setUserId(Long userId) { this.userId = userId; }
        public String getEmployeeCode() { return employeeCode; }
        public void setEmployeeCode(String employeeCode) { this.employeeCode = employeeCode; }
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        public String getFullName() { return fullName; }
        public void setFullName(String fullName) { this.fullName = fullName; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getDesignation() { return designation; }
        public void setDesignation(String designation) { this.designation = designation; }
        public String getDepartment() { return department; }
        public void setDepartment(String department) { this.department = department; }
        public String getCabin() { return cabin; }
        public void setCabin(String cabin) { this.cabin = cabin; }
        public boolean isActive() { return active; }
        public void setActive(boolean active) { this.active = active; }
        public int getSubjectCount() { return subjectCount; }
        public void setSubjectCount(int subjectCount) { this.subjectCount = subjectCount; }
        public String getSubjectCodes() { return subjectCodes; }
        public void setSubjectCodes(String subjectCodes) { this.subjectCodes = subjectCodes; }
    }

    public static class SubjectsAdminPageData {
        private List<SubjectAdminRow> subjects;
        private List<FacultyOption> facultyOptions;

        public List<SubjectAdminRow> getSubjects() { return subjects; }
        public void setSubjects(List<SubjectAdminRow> subjects) { this.subjects = subjects; }
        public List<FacultyOption> getFacultyOptions() { return facultyOptions; }
        public void setFacultyOptions(List<FacultyOption> facultyOptions) { this.facultyOptions = facultyOptions; }
    }

    public static class SubjectAdminRow {
        private Long id;
        private String code;
        private String name;
        private String shortName;
        private int credits;
        private String category;
        private int semester;
        private Long facultyId;
        private String facultyName;
        private String facultyCode;
        private long enrolledCount;
        private int syllabusPct;
        private String meetingDays;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getCode() { return code; }
        public void setCode(String code) { this.code = code; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getShortName() { return shortName; }
        public void setShortName(String shortName) { this.shortName = shortName; }
        public int getCredits() { return credits; }
        public void setCredits(int credits) { this.credits = credits; }
        public String getCategory() { return category; }
        public void setCategory(String category) { this.category = category; }
        public int getSemester() { return semester; }
        public void setSemester(int semester) { this.semester = semester; }
        public Long getFacultyId() { return facultyId; }
        public void setFacultyId(Long facultyId) { this.facultyId = facultyId; }
        public String getFacultyName() { return facultyName; }
        public void setFacultyName(String facultyName) { this.facultyName = facultyName; }
        public String getFacultyCode() { return facultyCode; }
        public void setFacultyCode(String facultyCode) { this.facultyCode = facultyCode; }
        public long getEnrolledCount() { return enrolledCount; }
        public void setEnrolledCount(long enrolledCount) { this.enrolledCount = enrolledCount; }
        public int getSyllabusPct() { return syllabusPct; }
        public void setSyllabusPct(int syllabusPct) { this.syllabusPct = syllabusPct; }
        public String getMeetingDays() { return meetingDays; }
        public void setMeetingDays(String meetingDays) { this.meetingDays = meetingDays; }
    }

    public static class FeesAdminPageData {
        private String collectedLabel;
        private String pendingLabel;
        private String overdueLabel;
        private String totalBilledLabel;
        private int collectionPct;
        private int unpaidCount;
        private int overdueCount;
        private List<FeeAdminRow> fees;
        private List<StudentOption> studentOptions;

        public String getCollectedLabel() { return collectedLabel; }
        public void setCollectedLabel(String collectedLabel) { this.collectedLabel = collectedLabel; }
        public String getPendingLabel() { return pendingLabel; }
        public void setPendingLabel(String pendingLabel) { this.pendingLabel = pendingLabel; }
        public String getOverdueLabel() { return overdueLabel; }
        public void setOverdueLabel(String overdueLabel) { this.overdueLabel = overdueLabel; }
        public String getTotalBilledLabel() { return totalBilledLabel; }
        public void setTotalBilledLabel(String totalBilledLabel) { this.totalBilledLabel = totalBilledLabel; }
        public int getCollectionPct() { return collectionPct; }
        public void setCollectionPct(int collectionPct) { this.collectionPct = collectionPct; }
        public int getUnpaidCount() { return unpaidCount; }
        public void setUnpaidCount(int unpaidCount) { this.unpaidCount = unpaidCount; }
        public int getOverdueCount() { return overdueCount; }
        public void setOverdueCount(int overdueCount) { this.overdueCount = overdueCount; }
        public List<FeeAdminRow> getFees() { return fees; }
        public void setFees(List<FeeAdminRow> fees) { this.fees = fees; }
        public List<StudentOption> getStudentOptions() { return studentOptions; }
        public void setStudentOptions(List<StudentOption> studentOptions) { this.studentOptions = studentOptions; }
    }

    public static class FeeAdminRow {
        private Long id;
        private Long studentId;
        private String enrollmentNo;
        private String studentName;
        private String branchSem;
        private String title;
        private String category;
        private String amountLabel;
        private String dueDateLabel;
        private String status;
        private String tone;
        private boolean paid;
        private String paidOnLabel;
        private String receiptNo;
        private String paymentMethod;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public Long getStudentId() { return studentId; }
        public void setStudentId(Long studentId) { this.studentId = studentId; }
        public String getEnrollmentNo() { return enrollmentNo; }
        public void setEnrollmentNo(String enrollmentNo) { this.enrollmentNo = enrollmentNo; }
        public String getStudentName() { return studentName; }
        public void setStudentName(String studentName) { this.studentName = studentName; }
        public String getBranchSem() { return branchSem; }
        public void setBranchSem(String branchSem) { this.branchSem = branchSem; }
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        public String getCategory() { return category; }
        public void setCategory(String category) { this.category = category; }
        public String getAmountLabel() { return amountLabel; }
        public void setAmountLabel(String amountLabel) { this.amountLabel = amountLabel; }
        public String getDueDateLabel() { return dueDateLabel; }
        public void setDueDateLabel(String dueDateLabel) { this.dueDateLabel = dueDateLabel; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getTone() { return tone; }
        public void setTone(String tone) { this.tone = tone; }
        public boolean isPaid() { return paid; }
        public void setPaid(boolean paid) { this.paid = paid; }
        public String getPaidOnLabel() { return paidOnLabel; }
        public void setPaidOnLabel(String paidOnLabel) { this.paidOnLabel = paidOnLabel; }
        public String getReceiptNo() { return receiptNo; }
        public void setReceiptNo(String receiptNo) { this.receiptNo = receiptNo; }
        public String getPaymentMethod() { return paymentMethod; }
        public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }
    }

    public static class AnnouncementsAdminPageData {
        private List<NoticeRow> notices;
        private List<SubjectOption> subjectOptions;

        public List<NoticeRow> getNotices() { return notices; }
        public void setNotices(List<NoticeRow> notices) { this.notices = notices; }
        public List<SubjectOption> getSubjectOptions() { return subjectOptions; }
        public void setSubjectOptions(List<SubjectOption> subjectOptions) { this.subjectOptions = subjectOptions; }
    }

    public static class FeedbackAdminPageData {
        private List<FeedbackRow> feedbacks;
        private int newCount;
        private int sentCount;
        private int rejectedCount;

        public List<FeedbackRow> getFeedbacks() { return feedbacks; }
        public void setFeedbacks(List<FeedbackRow> feedbacks) { this.feedbacks = feedbacks; }
        public int getNewCount() { return newCount; }
        public void setNewCount(int newCount) { this.newCount = newCount; }
        public int getSentCount() { return sentCount; }
        public void setSentCount(int sentCount) { this.sentCount = sentCount; }
        public int getRejectedCount() { return rejectedCount; }
        public void setRejectedCount(int rejectedCount) { this.rejectedCount = rejectedCount; }
    }

    public static class SubjectOption {
        private Long id;
        private String label;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getLabel() { return label; }
        public void setLabel(String label) { this.label = label; }
    }

    public static class FacultyOption {
        private Long id;
        private String label;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getLabel() { return label; }
        public void setLabel(String label) { this.label = label; }
    }

    public static class StudentOption {
        private Long id;
        private String label;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getLabel() { return label; }
        public void setLabel(String label) { this.label = label; }
    }
}

