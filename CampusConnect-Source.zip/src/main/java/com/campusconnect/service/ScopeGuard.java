package com.campusconnect.service;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * First line of defence of the chatbot (runs BEFORE Gemini is called, so blocked questions cost no quota and
 * can never leak anything). The Gemini system prompt is the second line of defence.
 *
 * Blocked categories
 *   UNETHICAL      hacking, cracking, malware, cheating, weapons ...
 *   PROGRAMMING    "write / debug / solve code" requests in any language
 *   GENERAL        weather, news, sports, entertainment, trivia and any "what is / explain ..." knowledge question that
 *                  has nothing to do with the student's portal data
 *   INJECTION      attempts to read or change the assistant's instructions
 *   OTHER_STUDENT  questions about someone else's records
 */
public final class ScopeGuard {

    public enum Verdict { OK, OUT_OF_SCOPE, UNETHICAL, PROGRAMMING, GENERAL, INJECTION, OTHER_STUDENT }

    /** The one polite refusal used for every out-of-scope category. */
    public static final String REFUSAL = "I'm sorry, I'm only able to assist with campus and academic-related topics. "
            + "For other queries, please use a general-purpose assistant. \uD83D\uDE0A";

    private static final int F = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;

    private static final Pattern INJECTION = Pattern.compile(
            "(ignore|disregard|forget|override|bypass).{0,40}(instruction|prompt|rule|restriction|previous|above)"
                    + "|system\\s*prompt|developer\\s*mode|jailbreak|\\bDAN\\b|pretend (to be|you are)|you are now"
                    + "|reveal.{0,30}(prompt|key|password|secret|instruction)|(api|secret|access)\\s*key|act as (?!a student)", F);

    private static final Pattern UNETHICAL = Pattern.compile(
            "\\b(hack(ing|ed|er|ers|s)?|crack(ing)? (the |a |any )?(password|wifi|wi-fi|account|software|license)|exploit(ing)?|"
                    + "malware|ransomware|keylogger|ddos|phishing|spoof(ing)?|steal(ing)?|forge(d|ry)?|brute ?force|reverse shell|"
                    + "bypass (the )?(security|login|authentication|password|admin|attendance)|sql injection (attack|payload)|"
                    + "cheat(ing)? (in|on|during)|leak(ing)? (the )?(question )?paper|fake (certificate|marksheet|id|degree)|"
                    + "dark ?web|weapon|bomb|explosive|illegal|drugs?|suicide|kill)\\b"
                    + "|root access|virus (code|program)", F);

    private static final Pattern PROGRAMMING = Pattern.compile(
            // "write / create / debug ... code | program | script ..."
            "\\b(write|create|generate|make|build|develop|debug|fix|implement|solve|complete|code|program)\\b.{0,35}"
                    + "\\b(program|programme|code|script|algorithm|website|web ?page|html|css|javascript|python|java|c\\+\\+|c#|php|sql|kotlin|"
                    + "linked ?list|bubble ?sort|binary ?search|loop|array|regex)\\b"
                    // "python program", "java code", "sql syntax" ...
                    + "|\\b(python|java|javascript|c\\+\\+|c#|php|sql|kotlin|typescript|golang|rust)\\s+(program|programs|code|script|function|snippet|syntax|tutorial|exercise|question|loop)\\b"
                    // "how do I code / implement / compile ..."
                    + "|\\bhow (do|to|can|should) (i|we|you)?\\s*(code|program|implement|compile|debug)\\b"
                    // "error in my code"
                    + "|\\b(error|exception|bug|stack ?trace|syntax error)\\b.{0,30}\\b(code|program|script)\\b"
                    // "code for / of / to ..." but not "course code for ..."
                    + "|(?<!course )(?<!subject )(?<!paper )(?<!branch )(?<!hall ticket )(?<!enrollment )(?<!pin )(?<!zip )\\b(source )?code (for|of|to)\\b"
                    + "|\\b(leetcode|hackerrank|codechef|codeforces|stack ?overflow|copilot|chatgpt)\\b"
                    // Hinglish
                    + "|\\b(code|program|script)\\s+(likh|likho|bana|banao)", F);

    private static final Pattern GENERAL = Pattern.compile(
            "\\b(weather|forecast|temperature outside|rain today|humidity|joke|riddle|poem|song|lyrics|movie|web series|netflix|cricket|ipl|"
                    + "football|fifa|nba|olympics|stock price|share price|bitcoin|crypto|horoscope|astrology|recipe|gold price|petrol price|"
                    + "exchange rate|(world|breaking|sports|political|tech|india) news|capital of|president of|prime minister|"
                    + "who (invented|discovered|won|wrote|painted|founded)|population of|tell me a story)\\b", F);

    /** Hindi / Gujarati / Hinglish equivalents (no \b here: word boundaries do not work for these scripts). */
    private static final Pattern OUT_OF_SCOPE_LOCAL = Pattern.compile(
            "(mausam|\u092e\u094c\u0938\u092e|\u0939\u0935\u093e\u092e\u093e\u0928|\u0ab9\u0ab5\u0abe\u0aae\u0abe\u0aa8|chutkula|\u091a\u0941\u091f\u0915\u0941\u0932\u093e|\u0a9c\u0acb\u0a95|"
                    + "\u0915\u0935\u093f\u0924\u093e|\u0917\u093e\u0928\u093e|\u0a97\u0ac0\u0aa4|\u092b\u093f\u0932\u094d\u092e|\u0aab\u0abf\u0ab2\u0acd\u0aae|"
                    + "\u0915\u094d\u0930\u093f\u0915\u0947\u091f|\u0a95\u0acd\u0ab0\u0abf\u0a95\u0ac7\u0a9f|\u0939\u0948\u0915|\u0ab9\u0ac7\u0a95)", F);

    private static final Pattern OTHERS = Pattern.compile(
            "(other|another|some ?one else'?s?|classmate'?s?|friend'?s?|his|her|their) (student'?s? )?"
                    + "(marks|attendance|cgpa|sgpa|result|fees?|password|phone|email|address)"
                    + "|(marks|attendance|cgpa|result|password|phone|email) of (?!my\\b|mine\\b)", F);

    private static final Pattern ENROLLMENT = Pattern.compile("\\b\\d{9}\\b");

    /** A knowledge question: starts with a question word / "explain ...". */
    private static final Pattern KNOWLEDGE_QUESTION = Pattern.compile(
            "^(what|who|whom|whose|where|when|why|how|which|define|explain|describe|tell me about|meaning of|difference between|"
                    + "name|list|give me (an )?example|is it true|can you explain|do you know|what's|whats)\\b", F);

    /** Words that make a question a portal / campus question. */
    private static final Pattern PORTAL_WORDS = Pattern.compile(
            "\\b(my|mine|attendance|present|absent|assignment|assignments|submission|submissions|submit|submitted|deadline|due|pending|done|late|overdue|"
                    + "exam|exams|examination|hall ticket|timetable|time table|schedule|class|classes|lecture|lectures|lab|labs|practical|faculty|professor|"
                    + "prof|hod|notice|notices|announcement|announcements|notification|notifications|alert|alerts|material|materials|notes|slides|"
                    + "e-?content|result|results|marks|grade|grades|cgpa|sgpa|gpa|backlog|backlogs|fee|fees|payment|pay|paid|receipt|hostel|hosteler|"
                    + "prc|tuition|semester|sem|syllabus|subject|subjects|course|courses|portal|campus|college|university|marwadi|helpdesk|profile|"
                    + "enrollment|enrolment|login|password|account|theme|dark mode|chat|sanjii|cie|mid|credits?|regulation|rule|rules|policy|"
                    + "database security|computer network|advance java|python programming|probability|data structure|statistics|"
                    + "ajt|cnf|dbs|pps|search|download|upload|preview|dashboard)\\b", F);

    private ScopeGuard() { }

    public static Verdict check(String message, String ownEnrollmentNo) {
        String m = message.trim();
        if (INJECTION.matcher(m).find()) {
            return Verdict.INJECTION;
        }
        Matcher e = ENROLLMENT.matcher(m);
        while (e.find()) {
            if (!e.group().equals(ownEnrollmentNo)) {
                return Verdict.OTHER_STUDENT;
            }
        }
        if (OTHERS.matcher(m).find()) {
            return Verdict.OTHER_STUDENT;
        }
        if (UNETHICAL.matcher(m).find()) {
            return Verdict.UNETHICAL;
        }
        if (PROGRAMMING.matcher(m).find()) {
            return Verdict.PROGRAMMING;
        }
        if (GENERAL.matcher(m).find() || OUT_OF_SCOPE_LOCAL.matcher(m).find()) {
            return Verdict.GENERAL;
        }
        // a knowledge question that mentions nothing from the student's portal world
        String lower = m.toLowerCase(Locale.ROOT);
        if (KNOWLEDGE_QUESTION.matcher(lower).find() && !PORTAL_WORDS.matcher(lower).find()) {
            return Verdict.GENERAL;
        }
        return Verdict.OK;
    }

    /** Text shown to the student for a verdict. */
    public static String refusal(Verdict v) {
        switch (v) {
            case INJECTION:
                return "I can't share or change my internal instructions or settings. I'm here to help with your Campus "
                        + "Connect portal - attendance, marks, assignments, timetable, exams, fees and study material. \uD83D\uDE0A";
            case OTHER_STUDENT:
                return "For privacy reasons I can only talk about your own records. Ask me about your attendance, marks, "
                        + "assignments, timetable, exams or fees. \uD83D\uDE0A";
            default:
                return REFUSAL;
        }
    }
}
