package com.campusconnect.service;

import com.campusconnect.config.AppProperties;
import com.campusconnect.dao.*;
import com.campusconnect.dto.ExamRow;
import com.campusconnect.dto.FacultyDashboardView;
import com.campusconnect.dto.FacultyDashboardView.*;
import com.campusconnect.dto.MaterialRow;
import com.campusconnect.model.*;
import com.campusconnect.util.Text;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Builds the complete view model for the faculty dashboard home page. */
@Service
public class FacultyDashboardService {

    private static final DateTimeFormatter TODAY_FMT = DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.ENGLISH);
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH);
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter MON_FMT = DateTimeFormatter.ofPattern("MMM", Locale.ENGLISH);
    private static final DateTimeFormatter DAY_FMT = DateTimeFormatter.ofPattern("dd");

    private final FacultyDao facultyDao;
    private final SubjectDao subjectDao;
    private final EnrollmentDao enrollmentDao;
    private final AssignmentDao assignmentDao;
    private final SubmissionDao submissionDao;
    private final StudyMaterialDao materialDao;
    private final TimetableSlotDao timetableDao;
    private final ExamScheduleDao examDao;
    private final AnnouncementDao announcementDao;
    private final FeedbackDao feedbackDao;
    private final AppProperties props;

    @Autowired
    public FacultyDashboardService(FacultyDao facultyDao, SubjectDao subjectDao, EnrollmentDao enrollmentDao,
            AssignmentDao assignmentDao, SubmissionDao submissionDao, StudyMaterialDao materialDao,
            TimetableSlotDao timetableDao, ExamScheduleDao examDao, AnnouncementDao announcementDao,
            FeedbackDao feedbackDao, AppProperties props) {
        this.facultyDao = facultyDao;
        this.subjectDao = subjectDao;
        this.enrollmentDao = enrollmentDao;
        this.assignmentDao = assignmentDao;
        this.submissionDao = submissionDao;
        this.materialDao = materialDao;
        this.timetableDao = timetableDao;
        this.examDao = examDao;
        this.announcementDao = announcementDao;
        this.feedbackDao = feedbackDao;
        this.props = props;
    }

    public FacultyDashboardView build(Long facultyId) {
        Faculty faculty = facultyDao.findById(facultyId)
                .orElseThrow(() -> new IllegalStateException("Faculty profile not found: " + facultyId));

        LocalDate today = LocalDate.now(props.zone());
        FacultyDashboardView v = new FacultyDashboardView();
        v.setFullName(faculty.getUser().getFullName());
        v.setFirstName(Text.firstName(faculty.getUser().getFullName()));
        v.setTitle(faculty.getTitle());
        v.setDesignation(faculty.getDesignation());
        v.setDepartment(faculty.getDepartment());
        v.setEmployeeCode(faculty.getEmployeeCode());
        v.setCabin(faculty.getCabin() == null ? "Not assigned" : faculty.getCabin());
        v.setEmail(faculty.getUser().getEmail());
        v.setTodayLabel(today.format(TODAY_FMT));

        List<Subject> subjects = subjectDao.byFaculty(facultyId);
        Map<Long, Long> countsBySubject = enrollmentDao.countBySubject();

        int core = 0;
        int lab = 0;
        double syllabusSum = 0;
        List<Long> subjectIds = new ArrayList<>();
        Set<Long> uniqueStudentIds = new HashSet<>();
        List<SubjectRow> subjectRows = new ArrayList<>();

        for (Subject s : subjects) {
            subjectIds.add(s.getId());
            if ("LAB".equalsIgnoreCase(s.getCategory())) {
                lab++;
            } else {
                core++;
            }
            for (Student st : enrollmentDao.studentsOf(s.getId())) {
                uniqueStudentIds.add(st.getId());
            }
            int pct = s.getSyllabusCompletion() == null ? 0
                    : s.getSyllabusCompletion().setScale(0, RoundingMode.HALF_UP).intValue();
            syllabusSum += pct;

            SubjectRow row = new SubjectRow();
            row.setId(s.getId());
            row.setCode(s.getCode());
            row.setName(s.getName());
            row.setShortName(s.getShortName());
            row.setCredits(s.getCredits());
            row.setCategory(s.getCategory());
            row.setSemester(s.getSemester());
            row.setEnrolledCount(countsBySubject.getOrDefault(s.getId(), 0L));
            row.setSyllabusPct(pct);
            row.setMeetingDays(s.getMeetingDays());
            subjectRows.add(row);
        }

        v.setSubjects(subjectRows);
        v.setSubjectCount(subjects.size());
        v.setCoreCount(core);
        v.setLabCount(lab);
        v.setTotalStudents(uniqueStudentIds.size());
        v.setAvgSyllabusPct(subjects.isEmpty() ? 0 : (int) Math.round(syllabusSum / subjects.size()));

        List<Assignment> assignments = assignmentDao.forFaculty(facultyId);
        v.setTotalAssignments(assignments.size());

        List<Submission> submissions = submissionDao.bySubjects(subjectIds);
        int pendingSubs = 0;
        for (Submission sub : submissions) {
            if (!"GRADED".equalsIgnoreCase(sub.getStatus())) {
                pendingSubs++;
            }
        }
        v.setPendingSubmissions(pendingSubs);

        int todayDow = today.getDayOfWeek().getValue();
        List<TimetableSlot> slots = timetableDao.forFaculty(facultyId);
        List<ScheduleRow> todayRows = new ArrayList<>();
        for (TimetableSlot slot : slots) {
            if (slot.getDayOfWeek() == todayDow) {
                ScheduleRow sr = new ScheduleRow();
                sr.setSubjectCode(slot.getSubject().getCode());
                sr.setSubjectName(slot.getSubject().getName());
                sr.setTimeRange(slot.getStartTime().format(TIME_FMT) + " - " + slot.getEndTime().format(TIME_FMT));
                sr.setRoom(slot.getRoom());
                sr.setBlock(slot.getBlock() == null ? "" : slot.getBlock());
                sr.setTopic(slot.getTopic() == null ? "" : slot.getTopic());
                sr.setDayLabel(today.getDayOfWeek().name());
                todayRows.add(sr);
            }
        }
        v.setTodaySchedule(todayRows);
        v.setTodayClassCount(todayRows.size());

        List<ExamSchedule> exams = examDao.upcomingForFaculty(facultyId, today);
        List<ExamRow> examRows = new ArrayList<>();
        for (int i = 0; i < Math.min(5, exams.size()); i++) {
            ExamSchedule ex = exams.get(i);
            ExamRow er = new ExamRow();
            er.setMonth(ex.getExamDate().format(MON_FMT).toUpperCase(Locale.ENGLISH));
            er.setDay(ex.getExamDate().format(DAY_FMT));
            er.setSubjectName(ex.getSubject().getName());
            er.setTimeRange(ex.getExamName() + " • " + ex.getStartTime().format(TIME_FMT) + "-" + ex.getEndTime().format(TIME_FMT));
            er.setCode(ex.getSubject().getCode());
            examRows.add(er);
        }
        v.setUpcomingExams(examRows);

        List<StudyMaterial> mats = materialDao.byFaculty(facultyId);
        v.setTotalMaterials(mats.size());
        List<MaterialRow> matRows = new ArrayList<>();
        for (int i = 0; i < Math.min(5, mats.size()); i++) {
            StudyMaterial m = mats.get(i);
            MaterialRow mr = new MaterialRow();
            mr.setId(m.getId());
            mr.setTitle(m.getTitle());
            mr.setSubjectName(m.getSubject().getCode() + " • " + m.getSubject().getShortName());
            mr.setSizeLabel(formatSize(m.getSizeMb()) + " • " + m.getFileType());
            mr.setIcon(materialIcon(m.getFileType()));
            matRows.add(mr);
        }
        v.setRecentMaterials(matRows);

        List<Feedback> fbList = feedbackDao.forFaculty(facultyId, 20);
        v.setFeedbackCount(fbList.size());
        List<FeedbackRow> fbRows = new ArrayList<>();
        for (int i = 0; i < Math.min(5, fbList.size()); i++) {
            Feedback fb = fbList.get(i);
            FeedbackRow fr = new FeedbackRow();
            fr.setId(fb.getId());
            fr.setSubjectCode(fb.getSubject() != null ? fb.getSubject().getCode() : "General");
            fr.setStudentName(fb.getStudent().getUser().getFullName());
            fr.setCategory(fb.getCategory() == null ? "Course" : fb.getCategory());
            String msg = fb.getProcessedText() != null && !fb.getProcessedText().isBlank()
                    ? fb.getProcessedText() : fb.getRawText();
            fr.setMessage(msg);
            fr.setStatus(fb.getStatus().name());
            fr.setCreatedLabel(fb.getCreatedAt() == null ? "" : fb.getCreatedAt().toLocalDate().format(DATE_FMT));
            fbRows.add(fr);
        }
        v.setRecentFeedback(fbRows);

        List<Announcement> announcements = announcementDao.latest(6);
        List<NoticeRow> noticeRows = new ArrayList<>();
        for (Announcement a : announcements) {
            NoticeRow nr = new NoticeRow();
            nr.setId(a.getId());
            nr.setTitle(a.getTitle());
            nr.setBody(a.getBody());
            nr.setSubjectCode(a.getSubject() != null ? a.getSubject().getCode() : "Campus-wide");
            nr.setAuthorName(a.getPostedBy() != null ? a.getPostedBy().getUser().getFullName() : "Administration");
            nr.setImportant(a.isImportant());
            nr.setCreatedLabel(a.getCreatedAt() == null ? "" : a.getCreatedAt().toLocalDate().format(DATE_FMT));
            noticeRows.add(nr);
        }
        v.setNotices(noticeRows);
        return v;
    }

    public static String materialIcon(String fileType) {
        if (fileType == null) return "description";
        switch (fileType.toUpperCase(Locale.ROOT)) {
            case "SLIDES": return "co_present";
            case "CODE": return "code";
            case "ZIP": return "folder_zip";
            default: return "picture_as_pdf";
        }
    }

    public static String formatSize(BigDecimal sizeMb) {
        if (sizeMb == null) return "0.0 MB";
        return sizeMb.setScale(1, RoundingMode.HALF_UP) + " MB";
    }
}

