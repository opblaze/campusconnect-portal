package com.campusconnect.service;

import com.campusconnect.config.AppProperties;
import com.campusconnect.dao.AnnouncementDao;
import com.campusconnect.dao.AssignmentDao;
import com.campusconnect.dao.AttendanceRecordDao;
import com.campusconnect.dao.DataAccessException;
import com.campusconnect.dao.EnrollmentDao;
import com.campusconnect.dao.FeeRecordDao;
import com.campusconnect.dao.MarkDao;
import com.campusconnect.dao.NotificationDao;
import com.campusconnect.dao.StudentDao;
import com.campusconnect.dao.StudyMaterialDao;
import com.campusconnect.dao.SubmissionDao;
import com.campusconnect.model.Announcement;
import com.campusconnect.model.Assignment;
import com.campusconnect.model.FeeRecord;
import com.campusconnect.model.Mark;
import com.campusconnect.model.Notification;
import com.campusconnect.model.Student;
import com.campusconnect.model.StudyMaterial;
import com.campusconnect.model.Subject;
import com.campusconnect.model.enums.NotificationColor;
import com.campusconnect.util.Validator;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * The smart-notification engine.
 *
 *   BLUE   general news    : new study material, published results, notices / day-off announcements
 *   RED    urgent          : assignment due within 12 hours, very low attendance, fee due within 2 days
 *   ORANGE warning         : low / borderline attendance, assignment due in 72 h or overdue, poor marks
 *
 * {@link #scanAll()} is called by {@link NotificationScheduler}. Every rule uses a "dedupe key" so the same alert
 * is never created twice (database unique constraint student_id + dedupe_key).
 */
@Service
public class NotificationService {

    private final NotificationDao notificationDao;
    private final StudentDao studentDao;
    private final EnrollmentDao enrollmentDao;
    private final AttendanceRecordDao attendanceDao;
    private final AssignmentDao assignmentDao;
    private final SubmissionDao submissionDao;
    private final MarkDao markDao;
    private final StudyMaterialDao materialDao;
    private final AnnouncementDao announcementDao;
    private final FeeRecordDao feeDao;
    private final AttendancePolicy policy;
    private final EmailService email;
    private final AppProperties props;

    @Autowired
    public NotificationService(NotificationDao notificationDao, StudentDao studentDao, EnrollmentDao enrollmentDao,
                               AttendanceRecordDao attendanceDao, AssignmentDao assignmentDao,
                               SubmissionDao submissionDao, MarkDao markDao, StudyMaterialDao materialDao,
                               AnnouncementDao announcementDao, FeeRecordDao feeDao, AttendancePolicy policy,
                               EmailService email, AppProperties props) {
        this.notificationDao = notificationDao;
        this.studentDao = studentDao;
        this.enrollmentDao = enrollmentDao;
        this.attendanceDao = attendanceDao;
        this.assignmentDao = assignmentDao;
        this.submissionDao = submissionDao;
        this.markDao = markDao;
        this.materialDao = materialDao;
        this.announcementDao = announcementDao;
        this.feeDao = feeDao;
        this.policy = policy;
        this.email = email;
        this.props = props;
    }

    // ------------------------------------------------------------------ creation
    /** Creates a notification unless one with the same dedupe key exists. Returns null when skipped. */
    public Notification create(Student st, NotificationColor color, String category, String title, String message,
                               String actionLabel, String actionUrl, String dedupeKey) {
        if (dedupeKey != null && notificationDao.findByDedupe(st.getId(), dedupeKey).isPresent()) {
            return null;
        }
        Notification n = new Notification();
        n.setStudent(st);
        n.setColor(color);
        n.setCategory(category);
        n.setTitle(cut(title, 200));
        n.setMessage(cut(message, 1000));
        n.setActionLabel(actionLabel);
        n.setActionUrl(actionUrl);
        n.setDedupeKey(dedupeKey);
        n.setCreatedAt(LocalDateTime.now(props.zone()));
        n.setPopupShown(false);
        n.setEmailSent(false);
        try {
            return notificationDao.save(n);
        } catch (DataAccessException ex) {
            return null; // a parallel scan created it first (unique constraint) - fine
        }
    }

    // ------------------------------------------------------------------ student-facing helpers
    public List<Notification> list(Long studentId, NotificationColor color, boolean unreadOnly, int limit) {
        return notificationDao.filtered(studentId, color, unreadOnly, limit);
    }

    public int unread(Long studentId) {
        return notificationDao.countUnread(studentId);
    }

    /** Notifications that should pop up now; they are flagged so each one pops up only once. */
    public List<Notification> takePopups(Long studentId) {
        List<Notification> list = notificationDao.unshownPopups(studentId);
        list.forEach(n -> notificationDao.markPopupShown(n.getId()));
        return list;
    }

    public boolean markRead(Long studentId, Long id) {
        return notificationDao.markRead(studentId, id);
    }

    public int markAllRead(Long studentId) {
        return notificationDao.markAllRead(studentId);
    }

    // ------------------------------------------------------------------ scheduler entry points
    /** Runs every rule for every student, then sends pending RED e-mails. */
    public void scanAll() {
        LocalDateTime now = LocalDateTime.now(props.zone());
        int created = 0;
        for (Student st : studentDao.findAll()) {
            try {
                created += scanStudent(st, now);
            } catch (RuntimeException ex) {
                System.err.println("[notify] scan failed for student " + st.getId() + ": " + ex.getMessage());
            }
        }
        sendRedEmails();
        if (created > 0) {
            System.out.println("[notify] " + created + " new notification(s) created");
        }
    }

    /** Applies all rules to one student; returns how many notifications were created. */
    public int scanStudent(Student st, LocalDateTime now) {
        int count = 0;
        List<Subject> subjects = enrollmentDao.subjectsOf(st.getId());
        if (subjects.isEmpty()) {
            return 0;
        }
        List<Long> ids = subjects.stream().map(Subject::getId).collect(Collectors.toList());

        // ---- attendance: RED when very low, ORANGE when low or borderline ----
        Map<Long, long[]> att = attendanceDao.summaryByStudent(st.getId());
        for (Subject s : subjects) {
            long[] a = att.get(s.getId());
            if (a == null || a[0] < 5) {
                continue; // not enough lectures to judge
            }
            double pct = a[1] * 100.0 / a[0];
            String shown = String.format(Locale.ROOT, "%.0f", pct);
            if (pct < policy.getCritical()) {
                count += add(create(st, NotificationColor.RED, "ATTENDANCE",
                        "Very low attendance in " + s.getShortName() + " (" + shown + "%)",
                        "You are far below the " + policy.getMin() + "% minimum. Attend every upcoming class and meet "
                                + s.getFaculty().getTitle() + " " + s.getFaculty().getUser().getFullName() + " today.",
                        "View Attendance", "/app/attendance", "att-red-" + s.getId()));
            } else if (pct < policy.getMin()) {
                count += add(create(st, NotificationColor.ORANGE, "ATTENDANCE",
                        "Low attendance in " + s.getShortName() + " (" + shown + "%)",
                        "You are below the " + policy.getMin() + "% minimum. Attend the next classes to recover.",
                        "View Attendance", "/app/attendance", "att-low-" + s.getId()));
            } else if (pct < policy.getBorderlineMax()) {
                count += add(create(st, NotificationColor.ORANGE, "ATTENDANCE",
                        "Attendance close to the limit in " + s.getShortName() + " (" + shown + "%)",
                        "A few more absences will push you below " + policy.getMin() + "%.",
                        "View Attendance", "/app/attendance", "att-border-" + s.getId()));
            }
        }

        // ---- assignments: RED < 12 h, ORANGE < 72 h or overdue ----
        Set<Long> done = submissionDao.submittedAssignmentIds(st.getId());
        for (Assignment a : assignmentDao.forSubjects(ids)) {
            if (done.contains(a.getId())) {
                continue;
            }
            long minutes = Duration.between(now, a.getDueAt()).toMinutes();
            if (minutes < 0) {
                if (minutes > -14 * 24 * 60) { // ignore very old history
                    count += add(create(st, NotificationColor.ORANGE, "ASSIGNMENT",
                            a.getTitle() + " is overdue",
                            "The deadline has passed. Submit it now or inform your faculty.",
                            "Open Assignments", "/app/assignments", "late-" + a.getId()));
                }
            } else if (minutes <= 12 * 60) {
                count += add(create(st, NotificationColor.RED, "ASSIGNMENT",
                        a.getTitle() + " is due in " + Math.max(1, minutes / 60) + " hour(s)",
                        "Urgent: this submission closes within 12 hours.",
                        "Upload Submission", "/app/assignments", "due12-" + a.getId()));
            } else if (minutes <= 72 * 60) {
                count += add(create(st, NotificationColor.ORANGE, "ASSIGNMENT",
                        a.getTitle() + " is pending",
                        "Due on " + a.getDueAt().toLocalDate() + " at " + a.getDueAt().toLocalTime() + ". You have not submitted it yet.",
                        "Upload Submission", "/app/assignments", "asg-" + a.getId()));
            }
        }

        // ---- marks: poor score warning (below 40 %), result declaration (BLUE) ----
        List<Mark> marks = markDao.byStudent(st.getId());
        for (Mark m : marks) {
            double ratio = m.getObtained().doubleValue() / Math.max(1.0, m.getMaximum().doubleValue());
            if (ratio < 0.40) {
                count += add(create(st, NotificationColor.ORANGE, "SCORE",
                        "Poor score in " + m.getSubject().getShortName() + " (" + m.getExamType() + ")",
                        "You scored " + m.getObtained().stripTrailingZeros().toPlainString() + " out of "
                                + m.getMaximum().stripTrailingZeros().toPlainString() + ". Ask your faculty for guidance.",
                        "View Results", "/app/exams", "lowmark-" + m.getId()));
            }
        }
        LocalDate today = now.toLocalDate();
        List<String> newResultTypes = marks.stream().filter(m -> !m.getPublishedOn().isBefore(today.minusDays(7)))
                .map(Mark::getExamType).distinct().collect(Collectors.toList());
        for (String type : newResultTypes) {
            count += add(create(st, NotificationColor.BLUE, "RESULT", type + " results declared",
                    "Your " + type + " scores are now available.", "View Results", "/app/exams", "result-" + type));
        }

        // ---- BLUE: new study material (last 48 h) ----
        for (StudyMaterial m : materialDao.latestForSubjects(ids, 10)) {
            if (m.getUploadedAt().isAfter(now.minusHours(48))) {
                count += add(create(st, NotificationColor.BLUE, "MATERIAL",
                        "New e-content: " + m.getTitle(),
                        "Uploaded for " + m.getSubject().getName() + " by " + m.getUploadedBy().getTitle() + " "
                                + m.getUploadedBy().getUser().getFullName() + ".",
                        "Open E-Content", "/app/e-content", "mat-" + m.getId()));
            }
        }

        // ---- BLUE: notices and day-off announcements (last 7 days) ----
        for (Announcement a : announcementDao.latest(10)) {
            if (a.getCreatedAt().isAfter(now.minusDays(7)) && (a.getSubject() == null || ids.contains(a.getSubject().getId()))) {
                count += add(create(st, NotificationColor.BLUE, "NOTICE", a.getTitle(), a.getBody(),
                        "Read Notice", "/dashboard", "ann-" + a.getId()));
            }
        }

        // ---- fees: RED when due within 2 days, ORANGE when overdue ----
        for (FeeRecord f : feeDao.byStudent(st.getId())) {
            if (f.isPaid() || ("HOSTEL".equals(f.getCategory()) && !st.isHosteler())) {
                continue; // paid, or a hostel fee for a student who is not a hosteler
            }
            long daysLeft = java.time.temporal.ChronoUnit.DAYS.between(today, f.getDueDate());
            if (daysLeft < 0) {
                count += add(create(st, NotificationColor.ORANGE, "FEES", f.getTitle() + " is overdue",
                        "Late surcharge may apply. Please pay immediately.", "Pay Now", "/app/fees", "feeover-" + f.getId()));
            } else if (daysLeft <= 2) {
                count += add(create(st, NotificationColor.RED, "FEES", f.getTitle() + " due in " + daysLeft + " day(s)",
                        "Outstanding amount INR " + f.getAmount().toPlainString() + " must be cleared before hall ticket validation.",
                        "Pay Now", "/app/fees", "fee-" + f.getId()));
            }
        }
        return count;
    }

    // ------------------------------------------------------------------ e-mail copy of RED alerts
    private void sendRedEmails() {
        if (!email.isConfigured()) {
            return;
        }
        for (Notification n : notificationDao.unemailedRed()) {
            String html = template(n.getColor(), n.getTitle(), n.getMessage(), n.getStudent().getUser().getFullName());
            if (email.send(n.getStudent().getUser().getEmail(), "[URGENT] " + n.getTitle(), html, null)) {
                notificationDao.markEmailed(n.getId());
            }
        }
    }

    /** Coloured HTML mail template that mirrors the in-portal BLUE / RED / ORANGE templates. */
    public static String template(NotificationColor color, String title, String message, String name) {
        String bg = color == NotificationColor.RED ? "#b91c1c" : color == NotificationColor.ORANGE ? "#d97706" : "#0f4c81";
        return "<div style=\"font-family:Arial,sans-serif;max-width:560px;margin:auto;border:1px solid #e5e7eb;border-radius:12px;overflow:hidden\">"
                + "<div style=\"background:" + bg + ";color:#fff;padding:14px 18px;font-size:13px;letter-spacing:1px\">CAMPUS CONNECT &bull; "
                + color.name() + " ALERT</div><div style=\"padding:18px\"><p>Hi " + Validator.escapeHtml(name) + ",</p>"
                + "<h3 style=\"margin:0 0 8px\">" + Validator.escapeHtml(title) + "</h3><p>" + Validator.escapeHtml(message)
                + "</p></div><div style=\"background:#f3f4f6;padding:10px 18px;font-size:12px;color:#6b7280\">"
                + "Marwadi University - Campus Connect</div></div>";
    }

    private int add(Notification n) {
        return n == null ? 0 : 1;
    }

    private static String cut(String s, int max) {
        return s == null ? "" : s.length() <= max ? s : s.substring(0, max - 1) + "\u2026";
    }
}
