package com.campusconnect.service;

import com.campusconnect.config.AppProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * One place that decides which colour an attendance percentage gets.
 * The thresholds come from app.properties so they can be changed without touching code.
 *
 *   GREEN  >= 85 %      good performance
 *   YELLOW 75 - 84.9 %  mild attention
 *   RED    <  75 %      attention / risk
 *
 * Notification colours (used by the Phase-2 scheduler):
 *   < 65 %  -> RED alert (very low), 65-74.9 % -> ORANGE warning, 75-79.9 % -> ORANGE "borderline" warning
 */
@Component
public class AttendancePolicy {

    public static final String GREEN = "GREEN";
    public static final String YELLOW = "YELLOW";
    public static final String RED = "RED";

    private final int greenMin;
    private final int min;
    private final int borderlineMax;
    private final int critical;

    @Autowired
    public AttendancePolicy(AppProperties p) {
        this.greenMin = p.getInt("attendance.green.min", 85);
        this.min = p.getInt("attendance.min", 75);
        this.borderlineMax = p.getInt("attendance.borderline.max", 80);
        this.critical = p.getInt("attendance.critical", 65);
    }

    /** UI status colour for a percentage. */
    public String statusOf(double pct) {
        if (pct >= greenMin) {
            return GREEN;
        }
        return pct >= min ? YELLOW : RED;
    }

    /** Short label shown on the chip next to the percentage. */
    public String labelOf(double pct) {
        if (pct >= greenMin) {
            return "Safe";
        }
        if (pct >= borderlineMax) {
            return "Watch";
        }
        if (pct >= min) {
            return "Borderline";
        }
        return pct < critical ? "Critical" : "At risk";
    }

    public int getMin() { return min; }
    public int getCritical() { return critical; }
    public int getBorderlineMax() { return borderlineMax; }
}
