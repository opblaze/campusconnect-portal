package com.campusconnect.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Root Spring configuration. Component scanning finds every @Repository, @Service and
 * @Component below and wires them together (constructor injection with @Autowired).
 */
@Configuration
@ComponentScan(basePackages = {"com.campusconnect.config", "com.campusconnect.dao", "com.campusconnect.service"})
public class AppConfig {
}
