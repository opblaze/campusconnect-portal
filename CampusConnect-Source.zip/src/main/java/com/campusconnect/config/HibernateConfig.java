package com.campusconnect.config;

import com.campusconnect.model.EntityRegistry;
import java.util.Properties;
import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Builds the single Hibernate SessionFactory for the whole application.
 * Spring creates it once at start-up and injects it into every DAO (dependency injection).
 * Connection pooling is done by HikariCP, which Hibernate picks up automatically.
 */
@Configuration
public class HibernateConfig {

    @Bean(destroyMethod = "close")
    public SessionFactory sessionFactory(AppProperties p) {
        Properties h = new Properties();

        // --- JDBC connection (MySQL / XAMPP) ---
        h.put("jakarta.persistence.jdbc.driver", p.get("db.driver", "com.mysql.cj.jdbc.Driver"));
        h.put("jakarta.persistence.jdbc.url", p.get("db.url",
                "jdbc:mysql://localhost:3306/campusconnect?useSSL=false&allowPublicKeyRetrieval=true"
                        + "&characterEncoding=UTF-8&serverTimezone=Asia/Kolkata"));
        h.put("jakarta.persistence.jdbc.user", p.get("db.user", "root"));
        h.put("jakarta.persistence.jdbc.password", p.get("db.password", ""));

        // --- connection pool (HikariCP) ---
        h.put("hibernate.connection.provider_class", "org.hibernate.hikaricp.internal.HikariCPConnectionProvider");
        h.put("hibernate.hikari.maximumPoolSize", String.valueOf(p.getInt("db.pool.size", 10)));
        h.put("hibernate.hikari.minimumIdle", "2");

        // optional: force a dialect (e.g. org.hibernate.dialect.MariaDBDialect for XAMPP); empty = auto-detect
        String dialect = p.get("db.dialect", "");
        if (!dialect.isEmpty()) {
            h.put("hibernate.dialect", dialect);
        }

        // --- behaviour ---
        // none = schema comes from sql/01_schema.sql.  Use "validate" to make Hibernate check the tables.
        h.put("hibernate.hbm2ddl.auto", p.get("hibernate.hbm2ddl", "none"));
        h.put("hibernate.show_sql", p.get("hibernate.show_sql", "false"));
        h.put("hibernate.format_sql", "true");

        org.hibernate.cfg.Configuration cfg = new org.hibernate.cfg.Configuration();
        cfg.setProperties(h);
        for (Class<?> entity : EntityRegistry.ALL) {
            cfg.addAnnotatedClass(entity);
        }
        return cfg.buildSessionFactory();
    }
}
