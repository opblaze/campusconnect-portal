package com.campusconnect.config;

import java.io.IOException;
import java.io.InputStream;
import java.time.ZoneId;
import java.util.Properties;
import org.springframework.stereotype.Component;

/**
 * Central place for configuration values.
 *
 * Lookup order (first match wins):
 *   1. environment variable  (db.url  ->  DB_URL)
 *   2. JVM system property   (-Ddb.url=...)
 *   3. app-local.properties  (your private file, ignored by Git - put secrets here)
 *   4. app.properties        (safe defaults that are committed to Git)
 */
@Component
public class AppProperties {

    private final Properties props = new Properties();

    public AppProperties() {
        load("app.properties");
        load("app-local.properties"); // optional, overrides the defaults
    }

    private void load(String name) {
        try (InputStream in = AppProperties.class.getClassLoader().getResourceAsStream(name)) {
            if (in != null) {
                props.load(in);
            }
        } catch (IOException ex) {
            throw new IllegalStateException("Cannot read " + name, ex);
        }
    }

    public String get(String key, String defaultValue) {
        String env = System.getenv(key.toUpperCase().replace('.', '_'));
        if (env != null && !env.isBlank()) {
            return env.trim();
        }
        String sys = System.getProperty(key);
        if (sys != null && !sys.isBlank()) {
            return sys.trim();
        }
        String value = props.getProperty(key);
        return (value == null || value.isBlank()) ? defaultValue : value.trim();
    }

    public int getInt(String key, int defaultValue) {
        try {
            return Integer.parseInt(get(key, String.valueOf(defaultValue)));
        } catch (NumberFormatException ex) {
            return defaultValue;
        }
    }

    /** Time zone used for "now", deadlines and the day/night theme. */
    public ZoneId zone() {
        return ZoneId.of(get("app.timezone", "Asia/Kolkata"));
    }
}
