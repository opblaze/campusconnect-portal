package com.campusconnect.dao;

import java.util.List;
import java.util.Optional;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.Student;

/** Student profiles. Inherits full CRUD from {@link BaseDao}; the methods below are custom HQL finders. */
@Repository
public class StudentDao extends BaseDao<Student, Long> {

    @Autowired
    public StudentDao(SessionFactory sessionFactory) {
        super(sessionFactory, Student.class);
    }

    /** The student profile that belongs to a login account. */
    public Optional<Student> findByUserId(Long userId) {
        return read(s -> s.createQuery("from Student st where st.user.id = :uid", Student.class)
                .setParameter("uid", userId)
                .uniqueResultOptional());
    }

    /** Lookup by enrollment number - students may log in with it instead of an e-mail. */
    public Optional<Student> findByEnrollmentNo(String enrollmentNo) {
        return read(s -> s.createQuery("from Student st where st.enrollmentNo = :n", Student.class)
                .setParameter("n", enrollmentNo)
                .uniqueResultOptional());
    }

    /** All student profiles ordered by enrollment number. */
    public List<Student> allOrdered() {
        return read(s -> s.createQuery("from Student st order by st.enrollmentNo", Student.class)
                .getResultList());
    }
}
