package com.campusconnect.dao;

import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.FeeRecord;

/** Fee instalments. Inherits full CRUD from {@link BaseDao}; extra finders below. */
@Repository
public class FeeRecordDao extends BaseDao<FeeRecord, Long> {

    @Autowired
    public FeeRecordDao(SessionFactory sessionFactory) {
        super(sessionFactory, FeeRecord.class);
    }

    public List<FeeRecord> byStudent(Long studentId) {
        return read(s -> s.createQuery("from FeeRecord f where f.student.id = :sid order by f.dueDate desc", FeeRecord.class)
                .setParameter("sid", studentId).getResultList());
    }

    /** All fee records across the institute, unpaid first then newest due date. */
    public List<FeeRecord> allOrdered() {
        return read(s -> s.createQuery("from FeeRecord f order by f.paid asc, f.dueDate desc", FeeRecord.class)
                .getResultList());
    }
}
