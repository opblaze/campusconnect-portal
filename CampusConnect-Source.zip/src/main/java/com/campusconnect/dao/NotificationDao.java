package com.campusconnect.dao;

import java.util.List;
import java.util.Optional;
import java.time.LocalDateTime;
import com.campusconnect.model.enums.NotificationColor;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.Notification;

/** Smart notifications. Inherits full CRUD from {@link BaseDao}; the methods below are custom HQL finders. */
@Repository
public class NotificationDao extends BaseDao<Notification, Long> {

    @Autowired
    public NotificationDao(SessionFactory sessionFactory) {
        super(sessionFactory, Notification.class);
    }

    /** Number of unread notifications - shown on the bell icon. */
    public int countUnread(Long studentId) {
        return read(s -> s.createQuery(
                "select count(n) from Notification n where n.student.id = :sid and n.readAt is null", Long.class)
                .setParameter("sid", studentId)
                .getSingleResult()).intValue();
    }

    /** Newest notifications of a student. */
    public List<Notification> latest(Long studentId, int limit) {
        return read(s -> s.createQuery(
                "from Notification n where n.student.id = :sid order by n.createdAt desc", Notification.class)
                .setParameter("sid", studentId)
                .setMaxResults(limit)
                .getResultList());
    }

    /** Used by the scheduler: has this alert already been created for this student? */
    public Optional<Notification> findByDedupe(Long studentId, String key) {
        return read(s -> s.createQuery(
                "from Notification n where n.student.id = :sid and n.dedupeKey = :k", Notification.class)
                .setParameter("sid", studentId).setParameter("k", key).uniqueResultOptional());
    }

    /** Notification centre list; colour and unreadOnly are optional filters. */
    public List<Notification> filtered(Long studentId, NotificationColor color, boolean unreadOnly, int limit) {
        return read(s -> {
            StringBuilder hql = new StringBuilder("from Notification n where n.student.id = :sid");
            if (color != null) {
                hql.append(" and n.color = :c");
            }
            if (unreadOnly) {
                hql.append(" and n.readAt is null");
            }
            hql.append(" order by n.createdAt desc");
            org.hibernate.query.Query<Notification> q = s.createQuery(hql.toString(), Notification.class)
                    .setParameter("sid", studentId);
            if (color != null) {
                q.setParameter("c", color);
            }
            return q.setMaxResults(limit).getResultList();
        });
    }

    /** Notifications whose pop-up has not been shown yet. */
    public List<Notification> unshownPopups(Long studentId) {
        return read(s -> s.createQuery(
                "from Notification n where n.student.id = :sid and n.popupShown = false order by n.createdAt",
                Notification.class).setParameter("sid", studentId).setMaxResults(5).getResultList());
    }

    /** RED alerts that still need their e-mail copy. */
    public List<Notification> unemailedRed() {
        return read(s -> s.createQuery(
                "from Notification n where n.color = :c and n.emailSent = false order by n.createdAt",
                Notification.class).setParameter("c", NotificationColor.RED).setMaxResults(50).getResultList());
    }

    /** Marks one notification as read (only if it belongs to the student - confidentiality). */
    public boolean markRead(Long studentId, Long id) {
        return inTx(s -> s.createMutationQuery(
                "update Notification n set n.readAt = :t where n.id = :id and n.student.id = :sid and n.readAt is null")
                .setParameter("t", LocalDateTime.now()).setParameter("id", id).setParameter("sid", studentId)
                .executeUpdate() > 0);
    }

    public int markAllRead(Long studentId) {
        return inTx(s -> s.createMutationQuery(
                "update Notification n set n.readAt = :t where n.student.id = :sid and n.readAt is null")
                .setParameter("t", LocalDateTime.now()).setParameter("sid", studentId).executeUpdate());
    }

    public void markPopupShown(Long id) {
        inTx(s -> s.createMutationQuery("update Notification n set n.popupShown = true where n.id = :id")
                .setParameter("id", id).executeUpdate());
    }

    public void markEmailed(Long id) {
        inTx(s -> s.createMutationQuery("update Notification n set n.emailSent = true where n.id = :id")
                .setParameter("id", id).executeUpdate());
    }
}
