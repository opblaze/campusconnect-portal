package com.campusconnect.dao;

import java.util.List;
import java.util.Optional;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.User;

/** Accounts. Inherits full CRUD from {@link BaseDao}; the methods below are custom HQL finders. */
@Repository
public class UserDao extends BaseDao<User, Long> {

    @Autowired
    public UserDao(SessionFactory sessionFactory) {
        super(sessionFactory, User.class);
    }

    /** Case-insensitive lookup by e-mail (used by the login form). */
    public Optional<User> findByEmail(String email) {
        return read(s -> s.createQuery("from User u where lower(u.email) = :e", User.class)
                .setParameter("e", email.toLowerCase())
                .uniqueResultOptional());
    }

    /** All accounts ordered newest first for admin management. */
    public List<User> allOrdered() {
        return read(s -> s.createQuery("from User u order by u.id desc", User.class)
                .getResultList());
    }
}
