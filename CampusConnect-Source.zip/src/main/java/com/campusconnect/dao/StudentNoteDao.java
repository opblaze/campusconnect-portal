package com.campusconnect.dao;

import com.campusconnect.model.StudentNote;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/** Private study notes uploaded by students. Inherits full CRUD from {@link BaseDao}. */
@Repository
public class StudentNoteDao extends BaseDao<StudentNote, Long> {

    @Autowired
    public StudentNoteDao(SessionFactory sessionFactory) {
        super(sessionFactory, StudentNote.class);
    }

    /** All notes of one student, newest first. */
    public List<StudentNote> byStudent(Long studentId) {
        return read(s -> s.createQuery("from StudentNote n where n.student.id = :sid order by n.uploadedAt desc", StudentNote.class)
                .setParameter("sid", studentId).getResultList());
    }
}
