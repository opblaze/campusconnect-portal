package com.campusconnect.dao;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.Mark;

/** Marks. Inherits full CRUD from {@link BaseDao}; the methods below are custom HQL finders. */
@Repository
public class MarkDao extends BaseDao<Mark, Long> {

    @Autowired
    public MarkDao(SessionFactory sessionFactory) {
        super(sessionFactory, Mark.class);
    }

    /** Marks of a student for one evaluation component, e.g. "CIE-I". */
    public List<Mark> byStudentAndType(Long studentId, String examType) {
        return read(s -> s.createQuery(
                "from Mark m where m.student.id = :sid and m.examType = :t", Mark.class)
                .setParameter("sid", studentId)
                .setParameter("t", examType)
                .getResultList());
    }

    /** Average marks of the whole class for a component (null when nothing is published). */
    public Double classAverage(String examType) {
        return read(s -> s.createQuery(
                "select avg(m.obtained) from Mark m where m.examType = :t", Double.class)
                .setParameter("t", examType)
                .getSingleResult());
    }

    public List<Mark> byStudent(Long studentId) {
        return read(s -> s.createQuery("from Mark m where m.student.id = :sid order by m.publishedOn desc", Mark.class)
                .setParameter("sid", studentId).getResultList());
    }

    /** Marks for a subject and exam type (faculty marks view). */
    public List<Mark> bySubjectAndType(Long subjectId, String examType) {
        return read(s -> s.createQuery(
                "from Mark m where m.subject.id = :sub and m.examType = :t order by m.student.enrollmentNo",
                Mark.class)
                .setParameter("sub", subjectId).setParameter("t", examType).getResultList());
    }

    /** Marks published across a faculty member's subjects. */
    public List<Mark> bySubjects(Collection<Long> subjectIds) {
        if (subjectIds.isEmpty()) {
            return Collections.emptyList();
        }
        return read(s -> s.createQuery(
                "from Mark m where m.subject.id in :ids order by m.publishedOn desc, m.student.enrollmentNo",
                Mark.class)
                .setParameter("ids", subjectIds).getResultList());
    }

    /** Lookup single mark record for upsert on republish. */
    public Optional<Mark> find(Long studentId, Long subjectId, String examType) {
        return read(s -> s.createQuery(
                "from Mark m where m.student.id = :sid and m.subject.id = :sub and m.examType = :t",
                Mark.class)
                .setParameter("sid", studentId).setParameter("sub", subjectId).setParameter("t", examType)
                .setMaxResults(1).uniqueResultOptional());
    }
}
