package com.campusconnect.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.campusconnect.model.Subject;
import com.campusconnect.model.Student;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.Enrollment;

/** Subject registrations. Inherits full CRUD from {@link BaseDao}; the methods below are custom HQL finders. */
@Repository
public class EnrollmentDao extends BaseDao<Enrollment, Long> {

    @Autowired
    public EnrollmentDao(SessionFactory sessionFactory) {
        super(sessionFactory, Enrollment.class);
    }

    /** All subjects a student is registered for, ordered by course code. */
    public List<Subject> subjectsOf(Long studentId) {
        return read(s -> s.createQuery(
                "select e.subject from Enrollment e where e.student.id = :sid order by e.subject.code",
                Subject.class)
                .setParameter("sid", studentId)
                .getResultList());
    }

    /** Students registered for a subject (faculty tools). */
    public List<Student> studentsOf(Long subjectId) {
        return read(s -> s.createQuery(
                "select e.student from Enrollment e where e.subject.id = :id order by e.student.enrollmentNo",
                Student.class).setParameter("id", subjectId).getResultList());
    }

    public boolean isEnrolled(Long studentId, Long subjectId) {
        return read(s -> s.createQuery(
                "select count(e) from Enrollment e where e.student.id = :a and e.subject.id = :b", Long.class)
                .setParameter("a", studentId).setParameter("b", subjectId).getSingleResult() > 0);
    }

    /** Enrolled student counts grouped by subject id. */
    public Map<Long, Long> countBySubject() {
        return read(s -> {
            List<Object[]> rows = s.createQuery(
                    "select e.subject.id, count(e.id) from Enrollment e group by e.subject.id", Object[].class)
                    .getResultList();
            Map<Long, Long> out = new HashMap<>();
            for (Object[] r : rows) {
                out.put(((Number) r[0]).longValue(), ((Number) r[1]).longValue());
            }
            return out;
        });
    }

    /** Enrolled subject counts grouped by student id. */
    public Map<Long, Long> countByStudent() {
        return read(s -> {
            List<Object[]> rows = s.createQuery(
                    "select e.student.id, count(e.id) from Enrollment e group by e.student.id", Object[].class)
                    .getResultList();
            Map<Long, Long> out = new HashMap<>();
            for (Object[] r : rows) {
                out.put(((Number) r[0]).longValue(), ((Number) r[1]).longValue());
            }
            return out;
        });
    }

    /** Drop a student's registration from a subject. */
    public int removeEnrollment(Long studentId, Long subjectId) {
        return inTx(s -> s.createMutationQuery(
                "delete from Enrollment e where e.student.id = :sid and e.subject.id = :subId")
                .setParameter("sid", studentId).setParameter("subId", subjectId).executeUpdate());
    }
}
