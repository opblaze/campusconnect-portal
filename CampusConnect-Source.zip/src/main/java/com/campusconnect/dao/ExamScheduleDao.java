package com.campusconnect.dao;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.ExamSchedule;

/** Exam date sheet. Inherits full CRUD from {@link BaseDao}; the methods below are custom HQL finders. */
@Repository
public class ExamScheduleDao extends BaseDao<ExamSchedule, Long> {

    @Autowired
    public ExamScheduleDao(SessionFactory sessionFactory) {
        super(sessionFactory, ExamSchedule.class);
    }

    /** Exams of the given subjects on or after a date, soonest first. */
    public List<ExamSchedule> upcomingForSubjects(Collection<Long> subjectIds, LocalDate from) {
        if (subjectIds.isEmpty()) {
            return Collections.emptyList();
        }
        return read(s -> s.createQuery(
                "from ExamSchedule x where x.subject.id in :ids and x.examDate >= :d order by x.examDate, x.startTime",
                ExamSchedule.class)
                .setParameter("ids", subjectIds)
                .setParameter("d", from)
                .getResultList());
    }

    /** Upcoming exams for subjects taught by a faculty member. */
    public List<ExamSchedule> upcomingForFaculty(Long facultyId, LocalDate from) {
        return read(s -> s.createQuery(
                "from ExamSchedule x where x.subject.faculty.id = :fid and x.examDate >= :d order by x.examDate, x.startTime",
                ExamSchedule.class)
                .setParameter("fid", facultyId)
                .setParameter("d", from)
                .getResultList());
    }
}
