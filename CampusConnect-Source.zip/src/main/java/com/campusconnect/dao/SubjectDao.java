package com.campusconnect.dao;

import java.util.List;
import java.util.Optional;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.Subject;

/** Courses. Inherits full CRUD from {@link BaseDao}; extra finders below. */
@Repository
public class SubjectDao extends BaseDao<Subject, Long> {

    @Autowired
    public SubjectDao(SessionFactory sessionFactory) {
        super(sessionFactory, Subject.class);
    }

    public List<Subject> byFaculty(Long facultyId) {
        return read(s -> s.createQuery("from Subject s where s.faculty.id = :f order by s.code", Subject.class)
                .setParameter("f", facultyId).getResultList());
    }

    /** All subjects for a semester. */
    public List<Subject> bySemester(int semester) {
        return read(s -> s.createQuery("from Subject s where s.semester = :sem order by s.code", Subject.class)
                .setParameter("sem", semester).getResultList());
    }

    /** All subjects ordered by code. */
    public List<Subject> allOrdered() {
        return read(s -> s.createQuery("from Subject s order by s.code", Subject.class).getResultList());
    }

    /** Exact course code lookup. */
    public Optional<Subject> findByCode(String code) {
        return read(s -> s.createQuery("from Subject s where upper(s.code) = :c", Subject.class)
                .setParameter("c", code.toUpperCase()).uniqueResultOptional());
    }
}
