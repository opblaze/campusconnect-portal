package com.campusconnect.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 * Generic CRUD base class used by every DAO.
 *
 * C - {@link #save(Object)}
 * R - {@link #findById(Serializable)}, {@link #findAll()}, {@link #count()}
 * U - {@link #update(Object)}
 * D - {@link #delete(Object)}, {@link #deleteById(Serializable)}
 *
 * Exception handling: every method opens a short-lived Session, commits on success,
 * rolls back on failure and rethrows a {@link DataAccessException}.
 */
public abstract class BaseDao<T, ID extends Serializable> {

    protected final SessionFactory sessionFactory;
    private final Class<T> entityClass;

    protected BaseDao(SessionFactory sessionFactory, Class<T> entityClass) {
        this.sessionFactory = sessionFactory;
        this.entityClass = entityClass;
    }

    /** CREATE - inserts a new row and returns the entity with its generated id. */
    public T save(T entity) {
        return inTx(s -> {
            s.persist(entity);
            return entity;
        });
    }

    /** READ - one row by primary key. */
    public Optional<T> findById(ID id) {
        return read(s -> Optional.ofNullable(s.find(entityClass, id)));
    }

    /** READ - every row of the table. */
    public List<T> findAll() {
        return read(s -> s.createQuery("from " + entityClass.getSimpleName(), entityClass).getResultList());
    }

    /** READ - number of rows. */
    public long count() {
        return read(s -> s.createQuery("select count(e) from " + entityClass.getSimpleName() + " e", Long.class)
                .getSingleResult());
    }

    /** UPDATE - copies the state of a detached entity into the database. */
    public T update(T entity) {
        return inTx(s -> s.merge(entity));
    }

    /** DELETE - removes the row that belongs to the given entity. */
    public void delete(T entity) {
        inTx(s -> {
            s.remove(s.contains(entity) ? entity : s.merge(entity));
            return null;
        });
    }

    /** DELETE - removes by primary key; returns false when the row did not exist. */
    public boolean deleteById(ID id) {
        return inTx(s -> {
            T found = s.find(entityClass, id);
            if (found == null) {
                return false;
            }
            s.remove(found);
            return true;
        });
    }

    // ------------------------------------------------------------ helpers
    /** Runs read-only work in its own Session (no transaction needed). */
    protected <R> R read(Function<Session, R> work) {
        try (Session session = sessionFactory.openSession()) {
            return work.apply(session);
        } catch (RuntimeException ex) {
            throw wrap(ex);
        }
    }

    /** Runs write work inside a transaction: commit on success, rollback on any exception. */
    protected <R> R inTx(Function<Session, R> work) {
        Session session = null;
        Transaction tx = null;
        try {
            session = sessionFactory.openSession();
            tx = session.beginTransaction();
            R result = work.apply(session);
            tx.commit();
            return result;
        } catch (RuntimeException ex) {
            if (tx != null && tx.isActive()) {
                try {
                    tx.rollback();
                } catch (RuntimeException ignored) {
                    // the original failure is more useful than a failed rollback
                }
            }
            throw wrap(ex);
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }

    private DataAccessException wrap(RuntimeException ex) {
        if (ex instanceof DataAccessException) {
            return (DataAccessException) ex;
        }
        return new DataAccessException("Database operation failed on " + entityClass.getSimpleName()
                + ": " + ex.getMessage(), ex);
    }
}
