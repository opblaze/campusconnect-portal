package com.campusconnect.dao;

/**
 * Unchecked wrapper for every database failure.
 * The DAO layer converts Hibernate/JDBC exceptions into this one type, so the
 * service and web layers never depend on Hibernate classes (clean layering).
 */
public class DataAccessException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public DataAccessException(String message, Throwable cause) {
        super(message, cause);
    }
}
