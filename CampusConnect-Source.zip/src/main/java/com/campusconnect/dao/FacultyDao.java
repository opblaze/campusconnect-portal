package com.campusconnect.dao;

import java.util.List;
import java.util.Optional;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.Faculty;

/** Teaching staff. Inherits full CRUD from {@link BaseDao}; extra finders below. */
@Repository
public class FacultyDao extends BaseDao<Faculty, Long> {

    @Autowired
    public FacultyDao(SessionFactory sessionFactory) {
        super(sessionFactory, Faculty.class);
    }

    public Optional<Faculty> findByUserId(Long userId) {
        return read(s -> s.createQuery("from Faculty f where f.user.id = :uid", Faculty.class)
                .setParameter("uid", userId).uniqueResultOptional());
    }

    /** Lookup by employee code (faculty / admin login). */
    public Optional<Faculty> findByEmployeeCode(String code) {
        return read(s -> s.createQuery("from Faculty f where f.employeeCode = :c", Faculty.class)
                .setParameter("c", code).uniqueResultOptional());
    }

    /** All faculty, ordered by department then name. */
    public List<Faculty> allOrdered() {
        return read(s -> s.createQuery("from Faculty f order by f.department, f.user.fullName", Faculty.class)
                .getResultList());
    }
}
