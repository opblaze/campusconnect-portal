package com.campusconnect.dao;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Optional;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.Submission;

/** Assignment submissions. Inherits full CRUD from {@link BaseDao}; the methods below are custom HQL finders. */
@Repository
public class SubmissionDao extends BaseDao<Submission, Long> {

    @Autowired
    public SubmissionDao(SessionFactory sessionFactory) {
        super(sessionFactory, Submission.class);
    }

    /** Ids of the assignments this student has already submitted. */
    public Set<Long> submittedAssignmentIds(Long studentId) {
        return read(s -> new HashSet<>(s.createQuery(
                "select sub.assignment.id from Submission sub where sub.student.id = :sid", Long.class)
                .setParameter("sid", studentId)
                .getResultList()));
    }

    public List<Submission> byStudent(Long studentId) {
        return read(s -> s.createQuery("from Submission x where x.student.id = :sid", Submission.class)
                .setParameter("sid", studentId).getResultList());
    }

    public Optional<Submission> find(Long assignmentId, Long studentId) {
        return read(s -> s.createQuery(
                "from Submission x where x.assignment.id = :a and x.student.id = :sid", Submission.class)
                .setParameter("a", assignmentId).setParameter("sid", studentId).uniqueResultOptional());
    }

    /** All submissions for an assignment (faculty grading view). */
    public List<Submission> byAssignment(Long assignmentId) {
        return read(s -> s.createQuery(
                "from Submission x where x.assignment.id = :aid order by x.submittedAt desc", Submission.class)
                .setParameter("aid", assignmentId).getResultList());
    }

    /** All submissions across a set of subjects. */
    public List<Submission> bySubjects(Collection<Long> subjectIds) {
        if (subjectIds.isEmpty()) {
            return Collections.emptyList();
        }
        return read(s -> s.createQuery(
                "from Submission x where x.assignment.subject.id in :ids order by x.submittedAt desc",
                Submission.class)
                .setParameter("ids", subjectIds).getResultList());
    }

    /** Submission counts per assignmentId. */
    public Map<Long, Long> countByAssignment() {
        return read(s -> {
            List<Object[]> rows = s.createQuery(
                    "select x.assignment.id, count(x.id) from Submission x group by x.assignment.id",
                    Object[].class).getResultList();
            Map<Long, Long> out = new HashMap<>();
            for (Object[] r : rows) {
                out.put(((Number) r[0]).longValue(), ((Number) r[1]).longValue());
            }
            return out;
        });
    }
}
