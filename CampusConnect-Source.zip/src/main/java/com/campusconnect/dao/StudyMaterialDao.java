package com.campusconnect.dao;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.StudyMaterial;

/** E-content files. Inherits full CRUD from {@link BaseDao}; the methods below are custom HQL finders. */
@Repository
public class StudyMaterialDao extends BaseDao<StudyMaterial, Long> {

    @Autowired
    public StudyMaterialDao(SessionFactory sessionFactory) {
        super(sessionFactory, StudyMaterial.class);
    }

    /** Newest uploads for the given subjects. */
    public List<StudyMaterial> latestForSubjects(Collection<Long> subjectIds, int limit) {
        if (subjectIds.isEmpty()) {
            return Collections.emptyList();
        }
        return read(s -> s.createQuery(
                "from StudyMaterial m where m.subject.id in :ids order by m.uploadedAt desc", StudyMaterial.class)
                .setParameter("ids", subjectIds)
                .setMaxResults(limit)
                .getResultList());
    }

    /** All materials uploaded by a faculty member or for their subjects. */
    public List<StudyMaterial> byFaculty(Long facultyId) {
        return read(s -> s.createQuery(
                "from StudyMaterial m where m.subject.faculty.id = :fid or m.uploadedBy.id = :fid order by m.uploadedAt desc",
                StudyMaterial.class)
                .setParameter("fid", facultyId)
                .getResultList());
    }

    /** Materials for a single subject, newest first. */
    public List<StudyMaterial> bySubject(Long subjectId) {
        return read(s -> s.createQuery(
                "from StudyMaterial m where m.subject.id = :sid order by m.uploadedAt desc",
                StudyMaterial.class)
                .setParameter("sid", subjectId)
                .getResultList());
    }
}
