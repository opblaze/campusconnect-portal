package com.campusconnect.dao;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.Assignment;

/** Assignments. Inherits full CRUD from {@link BaseDao}; the methods below are custom HQL finders. */
@Repository
public class AssignmentDao extends BaseDao<Assignment, Long> {

    @Autowired
    public AssignmentDao(SessionFactory sessionFactory) {
        super(sessionFactory, Assignment.class);
    }

    /** Assignments of the given subjects, earliest deadline first. */
    public List<Assignment> forSubjects(Collection<Long> subjectIds) {
        if (subjectIds.isEmpty()) {
            return Collections.emptyList();
        }
        return read(s -> s.createQuery(
                "from Assignment a where a.subject.id in :ids order by a.dueAt", Assignment.class)
                .setParameter("ids", subjectIds)
                .getResultList());
    }

    /** Assignments created for subjects taught by a faculty member, newest first. */
    public List<Assignment> forFaculty(Long facultyId) {
        return read(s -> s.createQuery(
                "from Assignment a where a.subject.faculty.id = :fid order by a.dueAt desc", Assignment.class)
                .setParameter("fid", facultyId)
                .getResultList());
    }

    /** All assignments, newest deadline first. */
    public List<Assignment> allOrdered() {
        return read(s -> s.createQuery("from Assignment a order by a.dueAt desc", Assignment.class)
                .getResultList());
    }
}
