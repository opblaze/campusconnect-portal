package com.campusconnect.dao;

import java.time.LocalDateTime;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.Announcement;

/** Notices. Inherits full CRUD from {@link BaseDao}; the methods below are custom HQL finders. */
@Repository
public class AnnouncementDao extends BaseDao<Announcement, Long> {

    @Autowired
    public AnnouncementDao(SessionFactory sessionFactory) {
        super(sessionFactory, Announcement.class);
    }

    /** Newest notices that have not expired yet. */
    public List<Announcement> latestActive(LocalDateTime now, int limit) {
        return read(s -> s.createQuery(
                "from Announcement a where a.expiresAt is null or a.expiresAt > :now order by a.createdAt desc",
                Announcement.class)
                .setParameter("now", now)
                .setMaxResults(limit)
                .getResultList());
    }

    /** All notices, newest first (notification centre / search). */
    public List<Announcement> latest(int limit) {
        return read(s -> s.createQuery("from Announcement a order by a.createdAt desc", Announcement.class)
                .setMaxResults(limit).getResultList());
    }

    /** Notices posted by a specific faculty member. */
    public List<Announcement> byFaculty(Long facultyId) {
        return read(s -> s.createQuery(
                "from Announcement a where a.postedBy.id = :fid order by a.createdAt desc", Announcement.class)
                .setParameter("fid", facultyId).getResultList());
    }
}
