package com.campusconnect.dao;

import java.util.Collections;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.ChatMessage;

/** Chat history. Inherits full CRUD from {@link BaseDao}; extra finders below. */
@Repository
public class ChatMessageDao extends BaseDao<ChatMessage, Long> {

    @Autowired
    public ChatMessageDao(SessionFactory sessionFactory) {
        super(sessionFactory, ChatMessage.class);
    }

    /** Last messages of a student's conversation, oldest first. */
    public List<ChatMessage> recent(Long studentId, int limit) {
        List<ChatMessage> list = read(s -> s.createQuery(
                "from ChatMessage m where m.student.id = :sid order by m.createdAt desc, m.id desc", ChatMessage.class)
                .setParameter("sid", studentId).setMaxResults(limit).getResultList());
        Collections.reverse(list);
        return list;
    }
}
