package com.campusconnect.dao;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.TimetableSlot;

/** Weekly timetable. Inherits full CRUD from {@link BaseDao}; the methods below are custom HQL finders. */
@Repository
public class TimetableSlotDao extends BaseDao<TimetableSlot, Long> {

    @Autowired
    public TimetableSlotDao(SessionFactory sessionFactory) {
        super(sessionFactory, TimetableSlot.class);
    }

    /** Every weekly slot of the given subjects. */
    public List<TimetableSlot> forSubjects(Collection<Long> subjectIds) {
        if (subjectIds.isEmpty()) {
            return Collections.emptyList();
        }
        return read(s -> s.createQuery(
                "from TimetableSlot t where t.subject.id in :ids order by t.dayOfWeek, t.startTime", TimetableSlot.class)
                .setParameter("ids", subjectIds)
                .getResultList());
    }

    /** Weekly teaching schedule for a faculty member's subjects. */
    public List<TimetableSlot> forFaculty(Long facultyId) {
        return read(s -> s.createQuery(
                "from TimetableSlot t where t.subject.faculty.id = :fid order by t.dayOfWeek, t.startTime",
                TimetableSlot.class)
                .setParameter("fid", facultyId)
                .getResultList());
    }
}
