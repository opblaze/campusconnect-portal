package com.campusconnect.dao;

import java.util.List;
import java.util.Optional;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.Feedback;

/** Student feedback. Inherits full CRUD from {@link BaseDao}; extra finders below. */
@Repository
public class FeedbackDao extends BaseDao<Feedback, Long> {

    @Autowired
    public FeedbackDao(SessionFactory sessionFactory) {
        super(sessionFactory, Feedback.class);
    }

    /** Newest feedback of a student (decides when the bot asks again). */
    public Optional<Feedback> newestOf(Long studentId) {
        return read(s -> s.createQuery("from Feedback f where f.student.id = :sid order by f.createdAt desc", Feedback.class)
                .setParameter("sid", studentId).setMaxResults(1).uniqueResultOptional());
    }

    /** Feedback mailed to one faculty member (faculty console inbox). */
    public List<Feedback> forFaculty(Long facultyId, int limit) {
        return read(s -> s.createQuery("from Feedback f where f.faculty.id = :fid order by f.createdAt desc", Feedback.class)
                .setParameter("fid", facultyId).setMaxResults(limit).getResultList());
    }

    /** Which subjects did this student already review recently? */
    public List<Long> reviewedSubjectIds(Long studentId, java.time.LocalDateTime since) {
        return read(s -> s.createQuery(
                "select f.subject.id from Feedback f where f.student.id = :sid and f.subject is not null and f.createdAt > :t",
                Long.class).setParameter("sid", studentId).setParameter("t", since).getResultList());
    }

    /** Latest feedback items across the institute (admin helpdesk & review). */
    public List<Feedback> latestAll(int limit) {
        return read(s -> s.createQuery("from Feedback f order by f.createdAt desc", Feedback.class)
                .setMaxResults(limit).getResultList());
    }
}
