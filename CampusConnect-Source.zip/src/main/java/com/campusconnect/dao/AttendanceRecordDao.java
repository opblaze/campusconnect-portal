package com.campusconnect.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.time.LocalDate;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.campusconnect.model.AttendanceRecord;

/** Lecture attendance. Inherits full CRUD from {@link BaseDao}; the methods below are custom HQL finders. */
@Repository
public class AttendanceRecordDao extends BaseDao<AttendanceRecord, Long> {

    @Autowired
    public AttendanceRecordDao(SessionFactory sessionFactory) {
        super(sessionFactory, AttendanceRecord.class);
    }

    /**
     * Attendance summary per subject for one student.
     * Result: subjectId -> {lecturesHeld, lecturesAttended}.
     */
    public Map<Long, long[]> summaryByStudent(Long studentId) {
        return read(s -> {
            List<Object[]> rows = s.createQuery(
                    "select a.subject.id, count(a.id), sum(case when a.present = true then 1 else 0 end) "
                            + "from AttendanceRecord a where a.student.id = :sid group by a.subject.id",
                    Object[].class)
                    .setParameter("sid", studentId)
                    .getResultList();
            Map<Long, long[]> out = new HashMap<>();
            for (Object[] r : rows) {
                long held = ((Number) r[1]).longValue();
                long attended = r[2] == null ? 0 : ((Number) r[2]).longValue();
                out.put(((Number) r[0]).longValue(), new long[] {held, attended});
            }
            return out;
        });
    }

    /** Faculty tool: has attendance for this student/subject/date been saved already? */
    public boolean exists(Long studentId, Long subjectId, LocalDate date) {
        return read(s -> s.createQuery(
                "select count(a) from AttendanceRecord a where a.student.id = :a and a.subject.id = :b and a.lectureDate = :d",
                Long.class).setParameter("a", studentId).setParameter("b", subjectId).setParameter("d", date)
                .getSingleResult() > 0);
    }

    /**
     * Attendance summary per student for one subject (faculty view).
     * Result: studentId -> {lecturesHeld, lecturesAttended}.
     */
    public Map<Long, long[]> summaryBySubject(Long subjectId) {
        return read(s -> {
            List<Object[]> rows = s.createQuery(
                    "select a.student.id, count(a.id), sum(case when a.present = true then 1 else 0 end) "
                            + "from AttendanceRecord a where a.subject.id = :sid group by a.student.id",
                    Object[].class)
                    .setParameter("sid", subjectId)
                    .getResultList();
            Map<Long, long[]> out = new HashMap<>();
            for (Object[] r : rows) {
                long held = ((Number) r[1]).longValue();
                long attended = r[2] == null ? 0 : ((Number) r[2]).longValue();
                out.put(((Number) r[0]).longValue(), new long[] {held, attended});
            }
            return out;
        });
    }

    /** Attendance records for a subject on a specific date. */
    public List<AttendanceRecord> bySubjectAndDate(Long subjectId, LocalDate date) {
        return read(s -> s.createQuery(
                "from AttendanceRecord a where a.subject.id = :sid and a.lectureDate = :d",
                AttendanceRecord.class)
                .setParameter("sid", subjectId).setParameter("d", date).getResultList());
    }

    /** Single attendance entry lookup for create/update toggles. */
    public Optional<AttendanceRecord> findOne(Long studentId, Long subjectId, LocalDate date) {
        return read(s -> s.createQuery(
                "from AttendanceRecord a where a.student.id = :st and a.subject.id = :sub and a.lectureDate = :d",
                AttendanceRecord.class)
                .setParameter("st", studentId).setParameter("sub", subjectId).setParameter("d", date)
                .uniqueResultOptional());
    }

    /** Per-student overall attendance totals: studentId -> {lecturesHeld, lecturesAttended}. */
    public Map<Long, long[]> overallByStudent() {
        return read(s -> {
            List<Object[]> rows = s.createQuery(
                    "select a.student.id, count(a.id), sum(case when a.present = true then 1 else 0 end) "
                            + "from AttendanceRecord a group by a.student.id",
                    Object[].class)
                    .getResultList();
            Map<Long, long[]> out = new HashMap<>();
            for (Object[] r : rows) {
                long held = ((Number) r[1]).longValue();
                long attended = r[2] == null ? 0 : ((Number) r[2]).longValue();
                out.put(((Number) r[0]).longValue(), new long[] {held, attended});
            }
            return out;
        });
    }
}
