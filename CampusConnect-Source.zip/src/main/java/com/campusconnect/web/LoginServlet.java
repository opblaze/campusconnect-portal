package com.campusconnect.web;

import com.campusconnect.config.AppProperties;
import com.campusconnect.dao.DataAccessException;
import com.campusconnect.service.AuthService;
import com.campusconnect.util.Validator;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

/**
 * GET  /login  - shows the sign-in page.
 * POST /login  - validates the form, authenticates and starts a fresh session.
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private static final String VIEW = "/WEB-INF/views/login.jsp";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession existing = req.getSession(false);
        if (existing != null && existing.getAttribute(AuthFilter.SESSION_USER) != null) {
            resp.sendRedirect(req.getContextPath() + "/dashboard"); // already signed in
            return;
        }
        req.setAttribute("csrf", Csrf.token(req.getSession(true)));
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");

        // 1. CSRF check
        if (!Csrf.isValid(req)) {
            fail(req, resp, "Your session expired. Please try again.", "");
            return;
        }

        // 2. Server-side form validation
        String loginId = req.getParameter("loginId");
        String password = req.getParameter("password");
        if (Validator.isBlank(loginId) || Validator.isBlank(password)) {
            fail(req, resp, "Please enter both your ID and password.", loginId);
            return;
        }
        if (!Validator.isValidLoginId(loginId)) {
            fail(req, resp, "Enter a valid enrollment number or institutional e-mail.", loginId);
            return;
        }
        if (!Validator.isValidPassword(password)) {
            fail(req, resp, "Password must be 6 to 100 characters.", loginId);
            return;
        }

        // 3. Authenticate through the service layer
        try {
            AuthService.LoginResult result = AppContextListener.bean(AuthService.class).login(loginId, password);
            if (!result.isSuccess()) {
                fail(req, resp, result.getError(), loginId);
                return;
            }

            // 4. Session management: drop the old session (prevents session fixation) and start a new one
            HttpSession old = req.getSession(false);
            if (old != null) {
                old.invalidate();
            }
            HttpSession session = req.getSession(true);
            session.setAttribute(AuthFilter.SESSION_USER, result.getUser());
            AppProperties props = AppContextListener.bean(AppProperties.class);
            boolean remember = "on".equals(req.getParameter("remember"));
            int seconds = remember ? props.getInt("session.remember.days", 14) * 24 * 3600
                    : props.getInt("session.timeout.minutes", 30) * 60;
            session.setMaxInactiveInterval(seconds);
            resp.sendRedirect(req.getContextPath() + "/dashboard");
        } catch (DataAccessException | IllegalStateException ex) {
            log("Database/start-up error during login", ex);
            fail(req, resp, "The portal database is not reachable right now. Please try again shortly.", loginId);
        }
    }

    /** Re-displays the login page with an error and keeps what the user typed (except the password). */
    private void fail(HttpServletRequest req, HttpServletResponse resp, String message, String loginId)
            throws ServletException, IOException {
        req.setAttribute("error", message);
        req.setAttribute("loginId", loginId == null ? "" : loginId.trim());
        req.setAttribute("csrf", Csrf.token(req.getSession(true)));
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }
}
