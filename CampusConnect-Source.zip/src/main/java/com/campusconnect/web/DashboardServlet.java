package com.campusconnect.web;

import com.campusconnect.dao.DataAccessException;
import com.campusconnect.dto.DashboardView;
import com.campusconnect.dto.SessionUser;
import com.campusconnect.service.DashboardService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/** GET /dashboard - builds the student dashboard through the service layer and forwards to the JSP. */
@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        SessionUser user = (SessionUser) req.getSession().getAttribute(AuthFilter.SESSION_USER);
        req.setAttribute("csrf", Csrf.token(req.getSession()));
        req.setAttribute("activePage", "dashboard");

        if (user.isAdmin()) {
            com.campusconnect.dto.AdminDashboardView ad = AppContextListener
                    .bean(com.campusconnect.service.AdminDashboardService.class)
                    .build(user.getUserId());
            req.setAttribute("ad", ad);
            req.setAttribute("todayLabel", ad.getTodayLabel());
            req.getRequestDispatcher("/WEB-INF/views/admin-dashboard.jsp").forward(req, resp);
            return;
        }
        if (user.isFaculty() && user.getFacultyId() != null) {
            com.campusconnect.dto.FacultyDashboardView fd = AppContextListener
                    .bean(com.campusconnect.service.FacultyDashboardService.class)
                    .build(user.getFacultyId());
            req.setAttribute("fd", fd);
            req.setAttribute("todayLabel", fd.getTodayLabel());
            req.getRequestDispatcher("/WEB-INF/views/faculty-dashboard.jsp").forward(req, resp);
            return;
        }
        if (user.getStudentId() == null) {
            req.setAttribute("pageTitle", "Account setup incomplete");
            req.setAttribute("pageNote", "No student or faculty profile is linked to this account.");
            req.getRequestDispatcher("/WEB-INF/views/stub.jsp").forward(req, resp);
            return;
        }
        try {
            DashboardView view = AppContextListener.bean(DashboardService.class).build(user.getStudentId());
            req.setAttribute("d", view);
            req.setAttribute("activePage", "dashboard");
            req.setAttribute("csrf", Csrf.token(req.getSession()));
            req.getRequestDispatcher("/WEB-INF/views/dashboard.jsp").forward(req, resp);
        } catch (DataAccessException | IllegalStateException ex) {
            log("Dashboard failed for user " + user.getUserId(), ex);
            req.setAttribute("errorMessage", "We could not load your dashboard. Please try again in a moment.");
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            req.getRequestDispatcher("/WEB-INF/views/error.jsp").forward(req, resp);
        }
    }
}
