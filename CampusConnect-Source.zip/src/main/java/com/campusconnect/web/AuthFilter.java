package com.campusconnect.web;

import com.campusconnect.dto.SessionUser;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Session management gate: every protected URL passes through here.
 * No valid session -> redirect to the login page. Protected pages are also marked
 * "no-store" so the browser Back button cannot show private data after logout.
 */
@WebFilter(urlPatterns = {"/dashboard", "/app/*", "/faculty/*", "/admin/*", "/api/*"})
public class AuthFilter implements Filter {

    public static final String SESSION_USER = "ccUser";

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        HttpSession session = request.getSession(false);
        SessionUser user = session == null ? null : (SessionUser) session.getAttribute(SESSION_USER);

        if (user == null) {
            if (request.getRequestURI().startsWith(request.getContextPath() + "/api/")) {
                response.sendError(HttpServletResponse.SC_UNAUTHORIZED); // AJAX callers get 401, not HTML
            } else {
                response.sendRedirect(request.getContextPath() + "/login");
            }
            return;
        }
        String path = request.getRequestURI().substring(request.getContextPath().length());
        if (path.startsWith("/admin") && !user.isAdmin()) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        if (path.startsWith("/faculty") && (!user.isFaculty() || user.getFacultyId() == null)) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        if (path.startsWith("/app") && (!user.isStudent() || user.getStudentId() == null)) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        chain.doFilter(req, res);
    }
}
