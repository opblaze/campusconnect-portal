package com.campusconnect.web;

import com.campusconnect.dao.DataAccessException;
import com.campusconnect.dto.SessionUser;
import com.campusconnect.service.PortalService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * GET /api/search?q=...  - JSON for the live search box in the top bar:
 * {"suggestions": [keywords...], "results": [{type,title,sub,href,badge,tone}...]}.
 * The student id always comes from the session; the query is limited to 60 characters.
 */
@WebServlet("/api/search")
public class SearchApiServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        SessionUser u = (SessionUser) req.getSession().getAttribute(AuthFilter.SESSION_USER);
        String q = req.getParameter("q") == null ? "" : req.getParameter("q").trim();
        if (q.length() > 60) {
            q = q.substring(0, 60);
        }
        try {
            Map<String, Object> out = new LinkedHashMap<>();
            if (u.isAdmin()) {
                com.campusconnect.service.AdminPortalService admin = AppContextListener
                        .bean(com.campusconnect.service.AdminPortalService.class);
                out.put("suggestions", admin.suggest());
                out.put("results", admin.searchRows(q));
            } else if (u.isFaculty() && u.getFacultyId() != null) {
                com.campusconnect.service.FacultyPortalService fac = AppContextListener
                        .bean(com.campusconnect.service.FacultyPortalService.class);
                out.put("suggestions", fac.suggest(u.getFacultyId()));
                out.put("results", fac.searchRows(u.getFacultyId(), q));
            } else if (u.getStudentId() != null) {
                PortalService portal = AppContextListener.bean(PortalService.class);
                out.put("suggestions", portal.suggest(q));
                out.put("results", portal.searchRows(u.getStudentId(), q));
            } else {
                resp.sendError(HttpServletResponse.SC_FORBIDDEN);
                return;
            }
            Json.write(resp, 200, out);
        } catch (DataAccessException | IllegalStateException ex) {
            log("search failed", ex);
            Json.write(resp, 503, Map.of("suggestions", java.util.List.of(), "results", java.util.List.of()));
        }
    }
}
