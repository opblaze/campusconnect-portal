package com.campusconnect.web;

import com.campusconnect.config.AppProperties;
import com.campusconnect.dto.SessionUser;
import com.campusconnect.model.Faculty;
import com.campusconnect.model.enums.FeedbackStatus;
import com.campusconnect.service.FacultyPortalService;
import com.campusconnect.service.FacultyPortalService.FilePayload;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Handles all /faculty/* routes for the Faculty Web Portal. */
@WebServlet("/faculty/*")
@MultipartConfig(maxFileSize = 15 * 1024 * 1024, maxRequestSize = 20 * 1024 * 1024)
public class FacultyServlet extends HttpServlet {

    private static final DateTimeFormatter TODAY_FMT = DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.ENGLISH);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        SessionUser user = (SessionUser) req.getSession().getAttribute(AuthFilter.SESSION_USER);
        if (user == null || !user.isFaculty() || user.getFacultyId() == null) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        Long fid = user.getFacultyId();
        FacultyPortalService svc = AppContextListener.bean(FacultyPortalService.class);
        String path = req.getPathInfo() == null ? "/my-subjects" : req.getPathInfo();

        if ("/preview-info".equals(path)) {
            Long id = parseLong(req.getParameter("id"));
            if (id == null) {
                resp.sendError(HttpServletResponse.SC_BAD_REQUEST);
                return;
            }
            try {
                Json.write(resp, 200, svc.previewInfo(fid, id, req.getContextPath()));
            } catch (SecurityException se) {
                resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            } catch (IllegalArgumentException iae) {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
            return;
        }

        if ("/download".equals(path)) {
            Long id = parseLong(req.getParameter("id"));
            if (id == null) {
                resp.sendError(HttpServletResponse.SC_BAD_REQUEST);
                return;
            }
            try {
                FilePayload fp = svc.loadMaterialFile(fid, id);
                boolean inline = "1".equals(req.getParameter("inline"));
                resp.setContentType(fp.getContentType());
                resp.setHeader("X-Content-Type-Options", "nosniff");
                String disp = inline ? "inline" : "attachment";
                String encoded = URLEncoder.encode(fp.getFilename(), StandardCharsets.UTF_8).replace("+", "%20");
                resp.setHeader("Content-Disposition", disp + "; filename=\"" + encoded + "\"");
                resp.setContentLength(fp.getBytes().length);
                resp.getOutputStream().write(fp.getBytes());
            } catch (SecurityException se) {
                resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            } catch (IllegalArgumentException iae) {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
            return;
        }

        prepareShell(req);
        switch (path) {
            case "/":
            case "/my-subjects": {
                Long subjectId = parseLong(req.getParameter("subjectId"));
                req.setAttribute("activePage", "subjects");
                req.setAttribute("data", svc.subjectsPage(fid, subjectId));
                req.getRequestDispatcher("/WEB-INF/views/faculty/subjects.jsp").forward(req, resp);
                return;
            }
            case "/attendance": {
                Long subjectId = parseLong(req.getParameter("subjectId"));
                LocalDate date = parseDate(req.getParameter("date"));
                req.setAttribute("activePage", "attendance");
                req.setAttribute("data", svc.attendancePage(fid, subjectId, date));
                req.getRequestDispatcher("/WEB-INF/views/faculty/attendance.jsp").forward(req, resp);
                return;
            }
            case "/assignments": {
                Long subjectId = parseLong(req.getParameter("subjectId"));
                Long asgnId = parseLong(req.getParameter("id"));
                req.setAttribute("activePage", "assignments");
                req.setAttribute("filterSubjectId", subjectId);
                req.setAttribute("data", svc.assignmentsPage(fid, subjectId, asgnId));
                req.getRequestDispatcher("/WEB-INF/views/faculty/assignments.jsp").forward(req, resp);
                return;
            }
            case "/materials": {
                Long subjectId = parseLong(req.getParameter("subjectId"));
                req.setAttribute("activePage", "materials");
                req.setAttribute("filterSubjectId", subjectId);
                req.setAttribute("data", svc.materialsPage(fid, subjectId));
                req.getRequestDispatcher("/WEB-INF/views/faculty/materials.jsp").forward(req, resp);
                return;
            }
            case "/marks": {
                Long subjectId = parseLong(req.getParameter("subjectId"));
                String examType = req.getParameter("examType");
                req.setAttribute("activePage", "marks");
                req.setAttribute("data", svc.marksPage(fid, subjectId, examType));
                req.getRequestDispatcher("/WEB-INF/views/faculty/marks.jsp").forward(req, resp);
                return;
            }
            case "/announcements": {
                req.setAttribute("activePage", "announcements");
                req.setAttribute("data", svc.announcementsPage(fid));
                req.getRequestDispatcher("/WEB-INF/views/faculty/announcements.jsp").forward(req, resp);
                return;
            }
            case "/timetable": {
                req.setAttribute("activePage", "timetable");
                req.setAttribute("data", svc.timetablePage(fid));
                req.getRequestDispatcher("/WEB-INF/views/faculty/timetable.jsp").forward(req, resp);
                return;
            }
            case "/feedback": {
                req.setAttribute("activePage", "feedback");
                req.setAttribute("feedbacks", svc.feedbackInbox(fid));
                req.getRequestDispatcher("/WEB-INF/views/faculty/feedback.jsp").forward(req, resp);
                return;
            }
            case "/profile": {
                Faculty f = svc.requireFaculty(fid);
                req.setAttribute("activePage", "profile");
                req.setAttribute("faculty", f);
                req.getRequestDispatcher("/WEB-INF/views/faculty/profile.jsp").forward(req, resp);
                return;
            }
            case "/search": {
                String q = req.getParameter("q") == null ? "" : req.getParameter("q").trim();
                req.setAttribute("activePage", "search");
                req.setAttribute("query", q);
                req.setAttribute("results", svc.searchRows(fid, q));
                req.setAttribute("suggestions", svc.suggest(fid));
                req.getRequestDispatcher("/WEB-INF/views/faculty/search.jsp").forward(req, resp);
                return;
            }
            default:
                resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        SessionUser user = (SessionUser) req.getSession().getAttribute(AuthFilter.SESSION_USER);
        if (user == null || !user.isFaculty() || user.getFacultyId() == null) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        String path = req.getPathInfo() == null ? "" : req.getPathInfo();

        if (!Csrf.isValid(req)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        Long fid = user.getFacultyId();
        FacultyPortalService svc = AppContextListener.bean(FacultyPortalService.class);
        String ctx = req.getContextPath();

        try {
            switch (path) {
                case "/subjects/syllabus": {
                    Long subjectId = parseLong(req.getParameter("subjectId"));
                    int pct = parseInt(req.getParameter("syllabusPct"), 0);
                    String days = req.getParameter("meetingDays");
                    svc.updateSyllabus(fid, subjectId, pct, days);
                    req.getSession().setAttribute("flashOk", "Syllabus progress updated.");
                    resp.sendRedirect(ctx + "/faculty/my-subjects?subjectId=" + subjectId);
                    return;
                }
                case "/attendance/save": {
                    Long subjectId = parseLong(req.getParameter("subjectId"));
                    LocalDate date = parseDate(req.getParameter("date"));
                    Set<Long> presentIds = new HashSet<>();
                    String[] selected = req.getParameterValues("presentIds");
                    if (selected != null) {
                        for (String val : selected) {
                            Long sid = parseLong(val);
                            if (sid != null) presentIds.add(sid);
                        }
                    }
                    int count = svc.saveAttendance(fid, subjectId, date, presentIds);
                    req.getSession().setAttribute("flashOk",
                            "Attendance saved for " + count + " student(s) on " + date + ".");
                    resp.sendRedirect(ctx + "/faculty/attendance?subjectId=" + subjectId + "&date=" + date);
                    return;
                }
                case "/assignments/create": {
                    Long subjectId = parseLong(req.getParameter("subjectId"));
                    String title = req.getParameter("title");
                    String desc = req.getParameter("description");
                    LocalDateTime dueAt = parseDateTime(req.getParameter("dueAt"));
                    int maxMarks = parseInt(req.getParameter("maxMarks"), 20);
                    var created = svc.createAssignment(fid, subjectId, title, desc, dueAt, maxMarks);
                    req.getSession().setAttribute("flashOk", "Assignment \"" + created.getTitle() + "\" created.");
                    resp.sendRedirect(ctx + "/faculty/assignments?id=" + created.getId());
                    return;
                }
                case "/assignments/grade": {
                    Long assignmentId = parseLong(req.getParameter("assignmentId"));
                    Long submissionId = parseLong(req.getParameter("submissionId"));
                    BigDecimal marks = parseDecimal(req.getParameter("marks"));
                    svc.gradeSubmission(fid, submissionId, marks);
                    req.getSession().setAttribute("flashOk", "Submission graded (" + marks + ").");
                    resp.sendRedirect(ctx + "/faculty/assignments?id=" + assignmentId);
                    return;
                }
                case "/materials/upload": {
                    Long subjectId = parseLong(req.getParameter("subjectId"));
                    String title = req.getParameter("title");
                    String fileType = req.getParameter("fileType");
                    String manualPath = req.getParameter("manualPath");
                    Part part = req.getPart("file");
                    InputStream stream = null;
                    String origName = null;
                    long size = 0;
                    if (part != null && part.getSize() > 0) {
                        stream = part.getInputStream();
                        origName = part.getSubmittedFileName();
                        size = part.getSize();
                    }
                    try (InputStream in = stream) {
                        int notified = svc.uploadMaterial(fid, subjectId, title, fileType, origName, in, size, manualPath);
                        req.getSession().setAttribute("flashOk",
                                "Material uploaded and " + notified + " student(s) notified.");
                    }
                    resp.sendRedirect(ctx + "/faculty/materials");
                    return;
                }
                case "/materials/delete": {
                    Long id = parseLong(req.getParameter("materialId"));
                    svc.deleteMaterial(fid, id);
                    req.getSession().setAttribute("flashOk", "Study material deleted.");
                    resp.sendRedirect(ctx + "/faculty/materials");
                    return;
                }
                case "/marks/save": {
                    Long subjectId = parseLong(req.getParameter("subjectId"));
                    String examType = req.getParameter("examType");
                    BigDecimal maximum = parseDecimal(req.getParameter("maximum"));
                    Map<Long, BigDecimal> scores = new LinkedHashMap<>();
                    for (Map.Entry<String, String[]> e : req.getParameterMap().entrySet()) {
                        if (e.getKey().startsWith("score_") && e.getValue().length > 0) {
                            String raw = e.getValue()[0];
                            if (raw != null && !raw.trim().isEmpty()) {
                                Long stId = parseLong(e.getKey().substring("score_".length()));
                                BigDecimal val = parseDecimal(raw);
                                if (stId != null && val != null) {
                                    scores.put(stId, val);
                                }
                            }
                        }
                    }
                    if (scores.isEmpty()) {
                        throw new IllegalArgumentException("Enter marks for at least one student before saving.");
                    }
                    int count = svc.publishMarks(fid, subjectId, examType, maximum, scores);
                    req.getSession().setAttribute("flashOk",
                            "Published " + examType + " marks for " + count + " student(s).");
                    resp.sendRedirect(ctx + "/faculty/marks?subjectId=" + subjectId
                            + "&examType=" + URLEncoder.encode(examType, StandardCharsets.UTF_8));
                    return;
                }
                case "/announcements/post": {
                    String subParam = req.getParameter("subjectId");
                    Long subjectId = (subParam == null || subParam.isBlank()) ? null : parseLong(subParam);
                    String title = req.getParameter("title");
                    String body = req.getParameter("body");
                    boolean important = "on".equals(req.getParameter("important")) || "true".equals(req.getParameter("important"));
                    int notified = svc.postAnnouncement(fid, subjectId, title, body, important);
                    req.getSession().setAttribute("flashOk",
                            "Announcement posted and " + notified + " student(s) notified.");
                    resp.sendRedirect(ctx + "/faculty/announcements");
                    return;
                }
                case "/announcements/delete": {
                    Long id = parseLong(req.getParameter("announcementId"));
                    svc.deleteAnnouncement(fid, id);
                    req.getSession().setAttribute("flashOk", "Announcement deleted.");
                    resp.sendRedirect(ctx + "/faculty/announcements");
                    return;
                }
                case "/feedback/status": {
                    Long id = parseLong(req.getParameter("feedbackId"));
                    FeedbackStatus st = FeedbackStatus.valueOf(req.getParameter("status"));
                    svc.updateFeedbackStatus(fid, id, st);
                    req.getSession().setAttribute("flashOk", "Feedback status updated to " + st + ".");
                    resp.sendRedirect(ctx + "/faculty/feedback");
                    return;
                }
                case "/profile/update": {
                    String cabin = req.getParameter("cabin");
                    String currentPw = req.getParameter("currentPassword");
                    String newPw = req.getParameter("newPassword");
                    svc.updateProfile(fid, cabin, currentPw, newPw);
                    req.getSession().setAttribute("flashOk", "Profile updated successfully.");
                    resp.sendRedirect(ctx + "/faculty/profile");
                    return;
                }
                default:
                    resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception ex) {
            req.getSession().setAttribute("flashErr", ex.getMessage() == null ? "Action failed." : ex.getMessage());
            String referer = req.getHeader("Referer");
            if (referer != null && referer.contains("/faculty/")) {
                resp.sendRedirect(referer);
            } else {
                resp.sendRedirect(ctx + "/dashboard");
            }
        }
    }

    private void prepareShell(HttpServletRequest req) {
        HttpSession s = req.getSession();
        req.setAttribute("csrf", Csrf.token(s));
        req.setAttribute("flashOk", s.getAttribute("flashOk"));
        req.setAttribute("flashErr", s.getAttribute("flashErr"));
        s.removeAttribute("flashOk");
        s.removeAttribute("flashErr");
        AppProperties props = AppContextListener.bean(AppProperties.class);
        req.setAttribute("todayLabel", LocalDate.now(props.zone()).format(TODAY_FMT));
    }

    private static Long parseLong(String s) {
        if (s == null || s.isBlank()) return null;
        try { return Long.parseLong(s.trim()); } catch (NumberFormatException e) { return null; }
    }

    private static int parseInt(String s, int def) {
        if (s == null || s.isBlank()) return def;
        try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return def; }
    }

    private static BigDecimal parseDecimal(String s) {
        if (s == null || s.isBlank()) return null;
        try { return new BigDecimal(s.trim()); } catch (NumberFormatException e) { return null; }
    }

    private static LocalDate parseDate(String s) {
        if (s == null || s.isBlank()) return null;
        try { return LocalDate.parse(s.trim()); } catch (Exception e) { return null; }
    }

    private static LocalDateTime parseDateTime(String s) {
        if (s == null || s.isBlank()) return null;
        try { return LocalDateTime.parse(s.trim()); } catch (Exception e) { return null; }
    }
}
