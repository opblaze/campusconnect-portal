package com.campusconnect.web;

import com.campusconnect.dao.StudentDao;
import com.campusconnect.service.EmailService;
import com.campusconnect.service.GeminiClient;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * GET /health - quick self-test for setup problems. Shows only yes/no values (no secrets, no stack traces):
 * is the application up, can it reach the database, are the Gemini key and e-mail settings present?
 */
@WebServlet("/health")
public class HealthServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("application", "up");
        boolean dbUp = false;
        try {
            out.put("students_in_database", AppContextListener.bean(StudentDao.class).count());
            dbUp = true;
        } catch (RuntimeException ex) {
            log("health: database check failed", ex);
            out.put("hint", "Database not reachable or schema missing: start MySQL, import sql/01_schema.sql and 02_seed.sql, "
                    + "check db.url/db.user/db.password. Details are in the Tomcat log.");
        }
        out.put("database", dbUp ? "ok" : "DOWN");
        try {
            out.put("gemini_key_configured", AppContextListener.bean(GeminiClient.class).isConfigured());
            out.put("smtp_configured", AppContextListener.bean(EmailService.class).isConfigured());
        } catch (RuntimeException ex) {
            out.put("gemini_key_configured", "unknown");
            out.put("smtp_configured", "unknown");
        }
        Json.write(resp, dbUp ? 200 : 503, out);
    }
}
