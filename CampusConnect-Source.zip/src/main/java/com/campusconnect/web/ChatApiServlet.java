package com.campusconnect.web;

import com.campusconnect.dao.DataAccessException;
import com.campusconnect.dto.SessionUser;
import com.campusconnect.service.ChatService;
import com.campusconnect.service.ChatState;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Map;

/**
 * JSON API of the chatbot widget.
 *   POST /api/chat/send       message=...   -> {reply, blocked}
 *   GET  /api/chat/proactive               -> alerts / warnings / feedback question pushed by the bot
 *   GET  /api/chat/history                 -> last messages of the conversation
 */
@WebServlet("/api/chat/*")
public class ChatApiServlet extends HttpServlet {

    private static final String STATE = "ccChatState";

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        SessionUser u = user(req, resp);
        if (u == null) {
            return;
        }
        if (!"/send".equals(req.getPathInfo())) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        if (!Csrf.isValid(req)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        req.setCharacterEncoding("UTF-8");
        try {
            ChatService.Reply r = AppContextListener.bean(ChatService.class)
                    .handle(u, req.getParameter("message"), state(req));
            Json.write(resp, 200, Map.of("reply", r.text(), "blocked", r.blocked()));
        } catch (DataAccessException | IllegalStateException ex) {
            log("chat failed", ex);
            Json.write(resp, 200, Map.of("reply", "Sorry, I could not process that right now. Please try again.", "blocked", false));
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        SessionUser u = user(req, resp);
        if (u == null) {
            return;
        }
        ChatService chat = AppContextListener.bean(ChatService.class);
        String path = req.getPathInfo() == null ? "" : req.getPathInfo();
        try {
            if ("/proactive".equals(path)) {
                Json.write(resp, 200, Map.of("messages", chat.proactive(u, state(req))));
            } else if ("/history".equals(path)) {
                Json.write(resp, 200, Map.of("messages", chat.history(u)));
            } else {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (DataAccessException | IllegalStateException ex) {
            log("chat failed", ex);
            Json.write(resp, 200, Map.of("messages", java.util.List.of()));
        }
    }

    /** Only students have a chat; faculty get 403. */
    private SessionUser user(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        SessionUser u = (SessionUser) req.getSession().getAttribute(AuthFilter.SESSION_USER);
        if (u == null || u.getStudentId() == null) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return null;
        }
        return u;
    }

    private ChatState state(HttpServletRequest req) {
        HttpSession s = req.getSession();
        ChatState st = (ChatState) s.getAttribute(STATE);
        if (st == null) {
            st = new ChatState();
            s.setAttribute(STATE, st);
        }
        return st;
    }
}
