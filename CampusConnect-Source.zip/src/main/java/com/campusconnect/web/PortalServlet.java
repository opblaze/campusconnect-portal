package com.campusconnect.web;

import com.campusconnect.config.AppProperties;
import com.campusconnect.dao.DataAccessException;
import com.campusconnect.dao.StudentDao;
import com.campusconnect.dto.DashboardView;
import com.campusconnect.dto.SessionUser;
import com.campusconnect.model.FeeRecord;
import com.campusconnect.model.Notification;
import com.campusconnect.model.Student;
import com.campusconnect.model.StudentNote;
import com.campusconnect.model.enums.NotificationColor;
import com.campusconnect.service.DashboardService;
import com.campusconnect.service.FeedbackService;
import com.campusconnect.service.NotificationService;
import com.campusconnect.service.PortalService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Front controller for all sidebar pages:  GET /app/{page}  and the matching POST actions.
 *
 *   my-subjects, attendance, e-content (+ my notes upload), exams, assignments (+ upload), timetable,
 *   fees (+ demo payment), receipt, profile, helpdesk (+ query), notifications, search,
 *   preview / preview-info / download (study material and notes)
 *
 * Every request passes AuthFilter first; the student id comes from the session only.
 */
@WebServlet("/app/*")
@MultipartConfig(maxFileSize = 5 * 1024 * 1024, maxRequestSize = 6 * 1024 * 1024)
public class PortalServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static final Set<String> ALLOWED_EXT = Set.of("pdf", "zip", "doc", "docx", "txt", "java", "png", "jpg",
            "jpeg", "ppt", "pptx", "xlsx", "csv", "sql", "md", "py");

    private static final Map<String, String> TITLES = Map.ofEntries(
            Map.entry("my-subjects", "My Subjects"), Map.entry("attendance", "Attendance & Performance"),
            Map.entry("e-content", "E-Content Materials"), Map.entry("exams", "Exams & Results"),
            Map.entry("assignments", "Assignments & Submissions"), Map.entry("timetable", "Timetable"),
            Map.entry("fees", "Fees & Dues"), Map.entry("helpdesk", "Campus Helpdesk"),
            Map.entry("notifications", "Smart Notifications"), Map.entry("search", "Search"),
            Map.entry("profile", "My Profile"), Map.entry("receipt", "Fee Receipt"));

    // ================================================================== GET
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        SessionUser u = (SessionUser) req.getSession().getAttribute(AuthFilter.SESSION_USER);
        if (u.getStudentId() == null) {
            resp.sendRedirect(req.getContextPath() + "/dashboard");
            return;
        }
        String page = req.getPathInfo() == null ? "" : req.getPathInfo().replace("/", "");
        PortalService portal = AppContextListener.bean(PortalService.class);
        Long sid = u.getStudentId();
        try {
            String view;
            switch (page) {
                case "my-subjects":
                    req.setAttribute("rows", portal.subjectRows(sid));
                    view = "subjects";
                    break;
                case "attendance":
                    req.setAttribute("rows", portal.attendanceRows(sid));
                    req.setAttribute("marks", portal.markRows(sid));
                    view = "attendance";
                    break;
                case "e-content":
                    Long filter = parseLong(req.getParameter("subject"));
                    req.setAttribute("rows", portal.materialRows(sid, filter));
                    req.setAttribute("notes", portal.noteRows(sid));
                    req.setAttribute("subjectFilter", filter);
                    view = "econtent";
                    break;
                case "exams":
                    req.setAttribute("marks", portal.markRows(sid));
                    req.setAttribute("exams", portal.examRows(sid));
                    view = "exams";
                    break;
                case "assignments":
                    req.setAttribute("rows", portal.assignmentRows(sid));
                    view = "assignments";
                    break;
                case "timetable":
                    req.setAttribute("grid", portal.weekGrid(sid));
                    req.setAttribute("exams", portal.examRows(sid));
                    view = "timetable";
                    break;
                case "fees":
                    List<Map<String, Object>> fees = portal.feeRows(sid);
                    req.setAttribute("rows", fees);
                    req.setAttribute("sum", portal.feeSummary(fees));
                    view = "fees";
                    break;
                case "receipt":
                    Long rid = parseLong(req.getParameter("id"));
                    Optional<Map<String, Object>> receipt = rid == null ? Optional.empty() : portal.receipt(sid, rid);
                    if (receipt.isEmpty()) {
                        resp.sendError(HttpServletResponse.SC_NOT_FOUND);
                        return;
                    }
                    req.setAttribute("r", receipt.get());
                    view = "receipt";
                    break;
                case "profile":
                    req.setAttribute("p", portal.profile(sid));
                    view = "profile";
                    break;
                case "helpdesk":
                    view = "helpdesk";
                    break;
                case "notifications":
                    notificationsPage(req, sid);
                    view = "notifications";
                    break;
                case "search":
                    String q = req.getParameter("q");
                    req.setAttribute("q", q == null ? "" : q.trim());
                    req.setAttribute("results", portal.search(sid, q));
                    view = "search";
                    break;
                case "preview":
                    serveFile(req, resp, portal, sid, true);
                    return;
                case "download":
                    serveFile(req, resp, portal, sid, false);
                    return;
                case "preview-info":
                    previewInfo(req, resp, portal, sid);
                    return;
                default:
                    resp.sendError(HttpServletResponse.SC_NOT_FOUND);
                    return;
            }
            shell(req, sid, page);
            req.getRequestDispatcher("/WEB-INF/views/" + view + ".jsp").forward(req, resp);
        } catch (DataAccessException | IllegalStateException ex) {
            log("Page " + page + " failed", ex);
            req.setAttribute("errorMessage", "We could not load this page. Please try again in a moment.");
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            req.getRequestDispatcher("/WEB-INF/views/error.jsp").forward(req, resp);
        }
    }

    // ================================================================== POST (Post/Redirect/Get, or JSON for fetch())
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        boolean ajax = "fetch".equals(req.getHeader("X-Requested-With"));
        if (!Csrf.isValid(req)) {
            if (ajax) {
                Json.write(resp, 403, Map.of("ok", false, "message", "Your session expired. Please reload the page."));
            } else {
                resp.sendError(HttpServletResponse.SC_FORBIDDEN, "Invalid form token");
            }
            return;
        }
        SessionUser u = (SessionUser) req.getSession().getAttribute(AuthFilter.SESSION_USER);
        if (u.getStudentId() == null) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        req.setCharacterEncoding("UTF-8");
        String page = req.getPathInfo() == null ? "" : req.getPathInfo().replace("/", "");
        PortalService portal = AppContextListener.bean(PortalService.class);
        Long sid = u.getStudentId();
        String redirectTo = page;
        try {
            switch (page) {
                case "assignments":
                    flash(req, submit(req, portal, sid));
                    break;
                case "fees":
                    if (pay(req, resp, portal, sid, ajax)) {
                        return; // JSON answer already written
                    }
                    break;
                case "notes":
                    flash(req, notes(req, portal, sid));
                    redirectTo = "e-content";
                    break;
                case "helpdesk":
                    Student st = AppContextListener.bean(StudentDao.class).findById(sid).orElseThrow();
                    String result = AppContextListener.bean(FeedbackService.class).submit(st, null, req.getParameter("message"));
                    req.getSession().setAttribute("flashOk", result);
                    break;
                default:
                    resp.sendError(HttpServletResponse.SC_NOT_FOUND);
                    return;
            }
        } catch (DataAccessException | IllegalStateException ex) {
            log("Action " + page + " failed", ex);
            if (ajax) {
                Json.write(resp, 500, Map.of("ok", false, "message", "Something went wrong. Please try again."));
                return;
            }
            flash(req, "Something went wrong. Please try again (the file may be larger than 5 MB).");
            redirectTo = "notes".equals(page) ? "e-content" : page;
        }
        resp.sendRedirect(req.getContextPath() + "/app/" + redirectTo);
    }

    // ================================================================== actions
    /** DEMO payment. Card / UPI details never reach the server - only the chosen method. Returns true when JSON was written. */
    private boolean pay(HttpServletRequest req, HttpServletResponse resp, PortalService portal, Long sid, boolean ajax) throws IOException {
        Long feeId = parseLong(req.getParameter("feeId"));
        Optional<FeeRecord> paid = feeId == null ? Optional.empty() : portal.payFee(sid, feeId, req.getParameter("method"));
        if (ajax) {
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("ok", paid.isPresent());
            if (paid.isPresent()) {
                out.put("receipt", paid.get().getReceiptNo());
                out.put("receiptUrl", req.getContextPath() + "/app/receipt?id=" + paid.get().getId());
                out.put("message", "Payment successful");
            } else {
                out.put("message", "This payment could not be completed (already paid, not applicable to you, or an invalid method).");
            }
            Json.write(resp, paid.isPresent() ? 200 : 400, out);
            return true;
        }
        if (paid.isPresent()) {
            req.getSession().setAttribute("flashOk", "Payment recorded (demo gateway). Receipt " + paid.get().getReceiptNo() + ".");
        } else {
            flash(req, "This payment could not be completed.");
        }
        return false;
    }

    /** Validates and stores the uploaded file, then records the submission. Returns an error text or null. */
    private String submit(HttpServletRequest req, PortalService portal, Long studentId) throws IOException, ServletException {
        Long assignmentId = parseLong(req.getParameter("assignmentId"));
        Part part = req.getPart("file");
        if (assignmentId == null || part == null || part.getSize() == 0) {
            return "Please choose a file to upload.";
        }
        String original = Paths.get(part.getSubmittedFileName() == null ? "file" : part.getSubmittedFileName()).getFileName().toString();
        if (!extensionAllowed(original)) {
            return "File type not allowed. Allowed: " + String.join(", ", new java.util.TreeSet<>(ALLOWED_EXT)) + ".";
        }
        String safe = original.replaceAll("[^A-Za-z0-9._-]", "_");
        Path dir = portal.uploadDir().resolve("submissions");
        Files.createDirectories(dir);
        Path target = dir.resolve(studentId + "-" + assignmentId + "-" + safe).normalize();
        if (!target.startsWith(dir)) {
            return "Invalid file name.";
        }
        try (InputStream in = part.getInputStream()) {
            Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
        }
        String error = portal.submitAssignment(studentId, assignmentId, target.getFileName().toString());
        if (error == null) {
            req.getSession().setAttribute("flashOk", "Submission uploaded successfully.");
        }
        return error;
    }

    /** "My notes": private study files of the student (upload / delete). Returns an error text or null. */
    private String notes(HttpServletRequest req, PortalService portal, Long studentId) throws IOException, ServletException {
        Path dir = portal.uploadDir().resolve("notes");
        if ("delete".equals(req.getParameter("action"))) {
            Long id = parseLong(req.getParameter("id"));
            Optional<StudentNote> gone = id == null ? Optional.empty() : portal.deleteNote(studentId, id);
            gone.ifPresent(n -> {
                try {
                    Files.deleteIfExists(dir.resolve(n.getStoredName()).normalize());
                } catch (IOException ignored) {
                    // the database record is gone; a leftover file is harmless
                }
            });
            req.getSession().setAttribute("flashOk", gone.isPresent() ? "Note deleted." : "Note not found.");
            return null;
        }
        Part part = req.getPart("file");
        if (part == null || part.getSize() == 0) {
            return "Please choose a file to upload.";
        }
        String original = Paths.get(part.getSubmittedFileName() == null ? "file" : part.getSubmittedFileName()).getFileName().toString();
        if (!extensionAllowed(original)) {
            return "File type not allowed. Allowed: " + String.join(", ", new java.util.TreeSet<>(ALLOWED_EXT)) + ".";
        }
        String title = req.getParameter("title") == null || req.getParameter("title").isBlank() ? original : req.getParameter("title").trim();
        String stored = studentId + "-" + Long.toString(System.nanoTime(), 36) + "-" + original.replaceAll("[^A-Za-z0-9._-]", "_");
        Files.createDirectories(dir);
        Path target = dir.resolve(stored).normalize();
        if (!target.startsWith(dir)) {
            return "Invalid file name.";
        }
        try (InputStream in = part.getInputStream()) {
            Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
        }
        portal.addNote(studentId, parseLong(req.getParameter("subjectId")), title, original, stored, (int) (part.getSize() / 1024));
        req.getSession().setAttribute("flashOk", "Note uploaded. Use the eye button to preview it.");
        return null;
    }

    /** Streams a material / note: inline for the preview window, as attachment for download. */
    private void serveFile(HttpServletRequest req, HttpServletResponse resp, PortalService portal, Long sid, boolean inline) throws IOException {
        String src = "note".equals(req.getParameter("src")) ? "note" : "material";
        Long id = parseLong(req.getParameter("id"));
        Optional<PortalService.FileData> f = id == null ? Optional.empty() : portal.fileOf(sid, src, id);
        if (f.isEmpty()) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        String name = f.get().fileName().replaceAll("[^A-Za-z0-9._-]", "_");
        String type = f.get().contentType();
        resp.setHeader("X-Content-Type-Options", "nosniff");
        resp.setHeader("Cache-Control", "private, max-age=60");
        if (inline) {
            resp.setContentType(type);
            resp.setHeader("Content-Disposition", "inline; filename=\"" + name + "\"");
            if (!type.startsWith("application/pdf")) {
                resp.setHeader("Content-Security-Policy", "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; sandbox");
            }
        } else {
            resp.setContentType(f.get().path() != null && !type.startsWith("image/") && !type.startsWith("application/pdf") && !type.startsWith("text/")
                    ? "application/octet-stream" : type);
            resp.setHeader("Content-Disposition", "attachment; filename=\"" + name + "\"");
        }
        if (f.get().bytes() != null) {
            resp.getOutputStream().write(f.get().bytes());
        } else {
            Files.copy(f.get().path(), resp.getOutputStream());
        }
    }

    private void previewInfo(HttpServletRequest req, HttpServletResponse resp, PortalService portal, Long sid) throws IOException {
        String src = "note".equals(req.getParameter("src")) ? "note" : "material";
        Long id = parseLong(req.getParameter("id"));
        Optional<Map<String, Object>> info = id == null ? Optional.empty() : portal.previewInfo(sid, src, id);
        if (info.isEmpty()) {
            Json.write(resp, 404, Map.of("ok", false, "message", "File not found"));
            return;
        }
        Map<String, Object> out = new LinkedHashMap<>(info.get());
        String base = req.getContextPath() + "/app/";
        out.put("ok", true);
        out.put("previewUrl", base + "preview?src=" + src + "&id=" + id);
        out.put("downloadUrl", base + "download?src=" + src + "&id=" + id);
        Json.write(resp, 200, out);
    }

    // ================================================================== helpers
    private static boolean extensionAllowed(String fileName) {
        String ext = fileName.contains(".") ? fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT) : "";
        return ALLOWED_EXT.contains(ext);
    }

    private void notificationsPage(HttpServletRequest req, Long sid) {
        NotificationService svc = AppContextListener.bean(NotificationService.class);
        String f = req.getParameter("f") == null ? "all" : req.getParameter("f").toLowerCase(Locale.ROOT);
        List<Notification> all = svc.list(sid, null, false, 200);
        int red = 0;
        int orange = 0;
        int blue = 0;
        int unread = 0;
        for (Notification n : all) {
            if (n.getColor() == NotificationColor.RED) {
                red++;
            } else if (n.getColor() == NotificationColor.ORANGE) {
                orange++;
            } else {
                blue++;
            }
            if (n.getReadAt() == null) {
                unread++;
            }
        }
        List<Map<String, Object>> items = new ArrayList<>();
        for (Notification n : all) {
            boolean keep = f.equals("all") || (f.equals("unread") && n.getReadAt() == null)
                    || (f.equals("red") && n.getColor() == NotificationColor.RED)
                    || (f.equals("orange") && n.getColor() == NotificationColor.ORANGE)
                    || (f.equals("blue") && n.getColor() == NotificationColor.BLUE);
            if (keep) {
                items.add(NotificationApiServlet.toMap(n));
            }
        }
        req.setAttribute("items", items);
        req.setAttribute("filter", f);
        req.setAttribute("cAll", all.size());
        req.setAttribute("cRed", red);
        req.setAttribute("cOrange", orange);
        req.setAttribute("cBlue", blue);
        req.setAttribute("cUnread", unread);
    }

    /** Values every page of the shell needs: summary (bell, semester, date ...), CSRF token, one-time flash message. */
    private void shell(HttpServletRequest req, Long sid, String page) {
        DashboardView d = AppContextListener.bean(DashboardService.class).build(sid);
        req.setAttribute("d", d);
        req.setAttribute("pageTitle", TITLES.getOrDefault(page, "Campus Connect"));
        req.setAttribute("activePage", page.equals("notifications") ? "dashboard" : page.equals("receipt") ? "fees" : page);
        req.setAttribute("csrf", Csrf.token(req.getSession()));
        HttpSession s = req.getSession();
        req.setAttribute("flashOk", s.getAttribute("flashOk"));
        req.setAttribute("flashErr", s.getAttribute("flashErr"));
        s.removeAttribute("flashOk");
        s.removeAttribute("flashErr");
    }

    private void flash(HttpServletRequest req, String error) {
        if (error != null) {
            req.getSession().setAttribute("flashErr", error);
        }
    }

    private static Long parseLong(String s) {
        try {
            return s == null || s.isBlank() ? null : Long.valueOf(s.trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }
}
