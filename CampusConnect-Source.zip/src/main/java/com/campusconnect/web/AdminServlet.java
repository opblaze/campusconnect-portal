package com.campusconnect.web;

import com.campusconnect.config.AppProperties;
import com.campusconnect.dto.SessionUser;
import com.campusconnect.model.enums.FeedbackStatus;
import com.campusconnect.service.AdminPortalService;
import com.campusconnect.util.Text;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Handles all /admin/* routes for the Administrator Control Panel. */
@WebServlet("/admin/*")
public class AdminServlet extends HttpServlet {

    private static final DateTimeFormatter TODAY_FMT = DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.ENGLISH);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        SessionUser user = (SessionUser) req.getSession().getAttribute(AuthFilter.SESSION_USER);
        if (user == null || !user.isAdmin()) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        AdminPortalService svc = AppContextListener.bean(AdminPortalService.class);
        String path = req.getPathInfo() == null ? "/users" : req.getPathInfo();
        prepareShell(req);

        switch (path) {
            case "/":
            case "/users": {
                String role = req.getParameter("role");
                String q = req.getParameter("q");
                req.setAttribute("activePage", "users");
                req.setAttribute("roleFilter", role == null ? "ALL" : role);
                req.setAttribute("query", q == null ? "" : q);
                req.setAttribute("users", svc.usersPage(role, q));
                req.getRequestDispatcher("/WEB-INF/views/admin/users.jsp").forward(req, resp);
                return;
            }
            case "/students": {
                Integer sem = parseIntObj(req.getParameter("semester"));
                String q = req.getParameter("q");
                Long selectedId = parseLong(req.getParameter("id"));
                req.setAttribute("activePage", "students");
                req.setAttribute("semFilter", sem == null ? 0 : sem);
                req.setAttribute("query", q == null ? "" : q);
                req.setAttribute("data", svc.studentsPage(sem, q, selectedId));
                req.getRequestDispatcher("/WEB-INF/views/admin/students.jsp").forward(req, resp);
                return;
            }
            case "/faculty": {
                String dept = req.getParameter("dept");
                String q = req.getParameter("q");
                req.setAttribute("activePage", "faculty");
                req.setAttribute("deptFilter", dept == null ? "ALL" : dept);
                req.setAttribute("query", q == null ? "" : q);
                req.setAttribute("facultyList", svc.facultyPage(dept, q));
                req.getRequestDispatcher("/WEB-INF/views/admin/faculty-list.jsp").forward(req, resp);
                return;
            }
            case "/subjects": {
                Integer sem = parseIntObj(req.getParameter("semester"));
                req.setAttribute("activePage", "subjects");
                req.setAttribute("semFilter", sem == null ? 0 : sem);
                req.setAttribute("data", svc.subjectsPage(sem));
                req.getRequestDispatcher("/WEB-INF/views/admin/subjects.jsp").forward(req, resp);
                return;
            }
            case "/fees": {
                String status = req.getParameter("status");
                String cat = req.getParameter("category");
                String q = req.getParameter("q");
                req.setAttribute("activePage", "fees");
                req.setAttribute("statusFilter", status == null ? "ALL" : status);
                req.setAttribute("catFilter", cat == null ? "ALL" : cat);
                req.setAttribute("query", q == null ? "" : q);
                req.setAttribute("data", svc.feesPage(status, cat, q));
                req.getRequestDispatcher("/WEB-INF/views/admin/fees.jsp").forward(req, resp);
                return;
            }
            case "/announcements": {
                req.setAttribute("activePage", "announcements");
                req.setAttribute("data", svc.announcementsPage());
                req.getRequestDispatcher("/WEB-INF/views/admin/announcements.jsp").forward(req, resp);
                return;
            }
            case "/feedback": {
                String status = req.getParameter("status");
                req.setAttribute("activePage", "feedback");
                req.setAttribute("statusFilter", status == null ? "ALL" : status);
                req.setAttribute("data", svc.feedbackPage(status));
                req.getRequestDispatcher("/WEB-INF/views/admin/feedback.jsp").forward(req, resp);
                return;
            }
            case "/profile": {
                req.setAttribute("activePage", "profile");
                req.getRequestDispatcher("/WEB-INF/views/admin/profile.jsp").forward(req, resp);
                return;
            }
            case "/search": {
                String q = req.getParameter("q") == null ? "" : req.getParameter("q").trim();
                req.setAttribute("activePage", "search");
                req.setAttribute("query", q);
                req.setAttribute("results", svc.searchRows(q));
                req.setAttribute("suggestions", svc.suggest());
                req.getRequestDispatcher("/WEB-INF/views/admin/search.jsp").forward(req, resp);
                return;
            }
            default:
                resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        SessionUser user = (SessionUser) req.getSession().getAttribute(AuthFilter.SESSION_USER);
        if (user == null || !user.isAdmin()) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        if (!Csrf.isValid(req)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        AdminPortalService svc = AppContextListener.bean(AdminPortalService.class);
        String path = req.getPathInfo() == null ? "" : req.getPathInfo();
        String ctx = req.getContextPath();

        try {
            switch (path) {
                case "/users/create": {
                    boolean hosteler = "on".equals(req.getParameter("hosteler")) || "true".equals(req.getParameter("hosteler"));
                    svc.createUser(
                            req.getParameter("fullName"),
                            req.getParameter("email"),
                            req.getParameter("role"),
                            req.getParameter("password"),
                            req.getParameter("enrollmentNo"),
                            req.getParameter("program"),
                            req.getParameter("branchCode"),
                            parseInt(req.getParameter("semester"), 3),
                            req.getParameter("academicYear"),
                            hosteler,
                            req.getParameter("hostelName"),
                            req.getParameter("employeeCode"),
                            req.getParameter("title"),
                            req.getParameter("designation"),
                            req.getParameter("department"),
                            req.getParameter("cabin"));
                    req.getSession().setAttribute("flashOk", "User account created successfully.");
                    resp.sendRedirect(ctx + "/admin/users");
                    return;
                }
                case "/users/toggle": {
                    Long targetId = parseLong(req.getParameter("userId"));
                    boolean active = svc.toggleUserActive(user.getUserId(), targetId);
                    req.getSession().setAttribute("flashOk", "Account " + (active ? "activated." : "deactivated."));
                    resp.sendRedirect(ctx + "/admin/users");
                    return;
                }
                case "/users/reset-password": {
                    Long targetId = parseLong(req.getParameter("userId"));
                    svc.resetUserPassword(targetId, req.getParameter("newPassword"));
                    req.getSession().setAttribute("flashOk", "Password reset successfully.");
                    resp.sendRedirect(ctx + "/admin/users");
                    return;
                }
                case "/students/update": {
                    Long studentId = parseLong(req.getParameter("studentId"));
                    int sem = parseInt(req.getParameter("semester"), 3);
                    BigDecimal cgpa = parseDecimal(req.getParameter("cgpa"));
                    boolean hosteler = "on".equals(req.getParameter("hosteler")) || "true".equals(req.getParameter("hosteler"));
                    svc.updateStudent(studentId, sem, cgpa, req.getParameter("branchCode"),
                            hosteler, req.getParameter("hostelName"), req.getParameter("phone"));
                    req.getSession().setAttribute("flashOk", "Student academic profile updated.");
                    resp.sendRedirect(ctx + "/admin/students?id=" + studentId);
                    return;
                }
                case "/students/enroll": {
                    Long studentId = parseLong(req.getParameter("studentId"));
                    Long subjectId = parseLong(req.getParameter("subjectId"));
                    svc.enrollStudent(studentId, subjectId);
                    req.getSession().setAttribute("flashOk", "Student enrolled in subject.");
                    resp.sendRedirect(ctx + "/admin/students?id=" + studentId);
                    return;
                }
                case "/students/unenroll": {
                    Long studentId = parseLong(req.getParameter("studentId"));
                    Long subjectId = parseLong(req.getParameter("subjectId"));
                    svc.unenrollStudent(studentId, subjectId);
                    req.getSession().setAttribute("flashOk", "Subject enrollment removed.");
                    resp.sendRedirect(ctx + "/admin/students?id=" + studentId);
                    return;
                }
                case "/subjects/create": {
                    svc.createSubject(
                            req.getParameter("code"),
                            req.getParameter("name"),
                            req.getParameter("shortName"),
                            parseInt(req.getParameter("credits"), 4),
                            req.getParameter("category"),
                            parseInt(req.getParameter("semester"), 3),
                            parseLong(req.getParameter("facultyId")),
                            req.getParameter("meetingDays"));
                    req.getSession().setAttribute("flashOk", "Subject added to catalog.");
                    resp.sendRedirect(ctx + "/admin/subjects");
                    return;
                }
                case "/subjects/assign-faculty": {
                    Long subjectId = parseLong(req.getParameter("subjectId"));
                    Long facultyId = parseLong(req.getParameter("facultyId"));
                    svc.assignFacultyToSubject(subjectId, facultyId);
                    req.getSession().setAttribute("flashOk", "Subject faculty updated.");
                    resp.sendRedirect(ctx + "/admin/subjects");
                    return;
                }
                case "/fees/create": {
                    Long studentId = parseLong(req.getParameter("studentId"));
                    BigDecimal amount = parseDecimal(req.getParameter("amount"));
                    LocalDate due = parseDate(req.getParameter("dueDate"));
                    svc.createFee(studentId, req.getParameter("title"), req.getParameter("category"), amount, due);
                    req.getSession().setAttribute("flashOk", "Fee demand created and student notified.");
                    resp.sendRedirect(ctx + "/admin/fees");
                    return;
                }
                case "/fees/mark-paid": {
                    Long feeId = parseLong(req.getParameter("feeId"));
                    svc.markFeePaid(feeId, req.getParameter("paymentMethod"));
                    req.getSession().setAttribute("flashOk", "Fee marked as PAID and receipt issued.");
                    resp.sendRedirect(ctx + "/admin/fees");
                    return;
                }
                case "/announcements/post": {
                    String subStr = req.getParameter("subjectId");
                    Long subjectId = (subStr == null || subStr.isBlank()) ? null : parseLong(subStr);
                    boolean important = "on".equals(req.getParameter("important")) || "true".equals(req.getParameter("important"));
                    boolean notify = "on".equals(req.getParameter("notifyStudents")) || "true".equals(req.getParameter("notifyStudents"));
                    int sent = svc.postAnnouncement(subjectId, req.getParameter("title"), req.getParameter("body"), important, notify);
                    req.getSession().setAttribute("flashOk",
                            "Notice published" + (notify ? " (" + sent + " students notified)." : "."));
                    resp.sendRedirect(ctx + "/admin/announcements");
                    return;
                }
                case "/announcements/delete": {
                    svc.deleteAnnouncement(parseLong(req.getParameter("announcementId")));
                    req.getSession().setAttribute("flashOk", "Announcement removed.");
                    resp.sendRedirect(ctx + "/admin/announcements");
                    return;
                }
                case "/feedback/status": {
                    Long fbId = parseLong(req.getParameter("feedbackId"));
                    FeedbackStatus status = FeedbackStatus.valueOf(req.getParameter("status"));
                    svc.updateFeedbackStatus(fbId, status);
                    req.getSession().setAttribute("flashOk", "Feedback marked " + status + ".");
                    resp.sendRedirect(ctx + "/admin/feedback");
                    return;
                }
                case "/profile/update": {
                    String fullName = req.getParameter("fullName");
                    svc.updateAdminPassword(user.getUserId(), fullName,
                            req.getParameter("currentPassword"), req.getParameter("newPassword"));
                    if (fullName != null && !fullName.isBlank()) {
                        user.setFullName(fullName.trim());
                        user.setFirstName(Text.firstName(fullName.trim()));
                        user.setInitials(Text.initials(fullName.trim()));
                    }
                    req.getSession().setAttribute("flashOk", "Administrator profile saved.");
                    resp.sendRedirect(ctx + "/admin/profile");
                    return;
                }
                default:
                    resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception ex) {
            req.getSession().setAttribute("flashErr", ex.getMessage() == null ? "Operation failed." : ex.getMessage());
            String referer = req.getHeader("Referer");
            if (referer != null && referer.contains("/admin/")) {
                resp.sendRedirect(referer);
            } else {
                resp.sendRedirect(ctx + "/dashboard");
            }
        }
    }

    private void prepareShell(HttpServletRequest req) {
        HttpSession s = req.getSession();
        req.setAttribute("csrf", Csrf.token(s));
        req.setAttribute("flashOk", s.getAttribute("flashOk"));
        req.setAttribute("flashErr", s.getAttribute("flashErr"));
        s.removeAttribute("flashOk");
        s.removeAttribute("flashErr");
        AppProperties props = AppContextListener.bean(AppProperties.class);
        req.setAttribute("todayLabel", LocalDate.now(props.zone()).format(TODAY_FMT));
    }

    private static Long parseLong(String s) {
        if (s == null || s.isBlank()) return null;
        try { return Long.parseLong(s.trim()); } catch (NumberFormatException e) { return null; }
    }

    private static Integer parseIntObj(String s) {
        if (s == null || s.isBlank()) return null;
        try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return null; }
    }

    private static int parseInt(String s, int def) {
        if (s == null || s.isBlank()) return def;
        try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return def; }
    }

    private static BigDecimal parseDecimal(String s) {
        if (s == null || s.isBlank()) return null;
        try { return new BigDecimal(s.trim()); } catch (NumberFormatException e) { return null; }
    }

    private static LocalDate parseDate(String s) {
        if (s == null || s.isBlank()) return null;
        try { return LocalDate.parse(s.trim()); } catch (Exception e) { return null; }
    }
}

