package com.campusconnect.web;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * CSRF protection: every state-changing form carries a random token that is also stored in the session.
 * A malicious site cannot read the token, so it cannot forge a valid POST (Integrity).
 */
public final class Csrf {

    private static final String KEY = "ccCsrf";
    private static final SecureRandom RANDOM = new SecureRandom();

    private Csrf() { }

    /** Returns the session's token, creating it on first use. */
    public static String token(HttpSession session) {
        String t = (String) session.getAttribute(KEY);
        if (t == null) {
            byte[] b = new byte[24];
            RANDOM.nextBytes(b);
            t = Base64.getUrlEncoder().withoutPadding().encodeToString(b);
            session.setAttribute(KEY, t);
        }
        return t;
    }

    /** True when the submitted "csrf" field matches the session token. */
    public static boolean isValid(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        String expected = session == null ? null : (String) session.getAttribute(KEY);
        String actual = request.getHeader("X-CSRF-Token");
        if (actual == null) {
            actual = request.getParameter("csrf");
        }
        return expected != null && actual != null
                && MessageDigest.isEqual(expected.getBytes(), actual.getBytes());
    }
}
