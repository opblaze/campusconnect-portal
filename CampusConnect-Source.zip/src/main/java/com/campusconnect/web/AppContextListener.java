package com.campusconnect.web;

import com.campusconnect.config.AppConfig;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Starts the Spring container when Tomcat starts the web application and closes it on shutdown.
 * Servlets (which Tomcat creates itself) fetch their services from here: {@code AppContextListener.bean(Foo.class)}.
 *
 * Resilience: if the database is not reachable at start-up (for example XAMPP MySQL is not started yet) the web
 * application still deploys and shows a friendly error page; the container is started again automatically on a
 * later request (at most every 10 seconds), so you do not have to redeploy after starting MySQL.
 */
@WebListener
public class AppContextListener implements ServletContextListener {

    private static final Object LOCK = new Object();
    private static final long RETRY_MS = 10_000;

    private static volatile AnnotationConfigApplicationContext context;
    private static volatile Throwable startupError;
    private static volatile long lastAttempt;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        start();
        if (context != null) {
            sce.getServletContext().log("Campus Connect: Spring context started with "
                    + context.getBeanDefinitionCount() + " beans");
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        synchronized (LOCK) {
            if (context != null) {
                context.close(); // also closes the Hibernate SessionFactory and its connection pool
                context = null;
            }
        }
    }

    /** Dependency lookup for classes that Spring does not create itself (servlets, filters). */
    public static <T> T bean(Class<T> type) {
        if (context == null && System.currentTimeMillis() - lastAttempt > RETRY_MS) {
            start(); // second chance, e.g. after the database was started
        }
        AnnotationConfigApplicationContext c = context;
        if (c == null) {
            throw new IllegalStateException("Campus Connect could not start: " + rootMessage(startupError));
        }
        return c.getBean(type);
    }

    private static void start() {
        synchronized (LOCK) {
            if (context != null) {
                return;
            }
            lastAttempt = System.currentTimeMillis();
            try {
                context = new AnnotationConfigApplicationContext(AppConfig.class);
                startupError = null;
            } catch (RuntimeException ex) {
                startupError = ex;
                System.err.println("[Campus Connect] START-UP FAILED: " + rootMessage(ex)
                        + "\n  -> Is MySQL running? Were sql/01_schema.sql and sql/02_seed.sql imported? "
                        + "Check db.url / db.user / db.password in app.properties (or app-local.properties).");
            }
        }
    }

    private static String rootMessage(Throwable t) {
        if (t == null) {
            return "unknown reason";
        }
        Throwable root = t;
        while (root.getCause() != null && root.getCause() != root) {
            root = root.getCause();
        }
        return root.getClass().getSimpleName() + ": " + root.getMessage();
    }
}
