package com.campusconnect.web;

import com.campusconnect.dao.DataAccessException;
import com.campusconnect.dto.SessionUser;
import com.campusconnect.model.Notification;
import com.campusconnect.model.enums.NotificationColor;
import com.campusconnect.service.NotificationService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * JSON API used by the pop-up script in every page.
 *   GET  /api/notifications/popups   -> new notifications to show as toasts (each is returned only once)
 *   GET  /api/notifications/count    -> unread number for the bell badge
 *   POST /api/notifications/read     -> id=<n>   mark one notification as read
 *   POST /api/notifications/read-all -> mark all as read
 * The student id always comes from the session, never from the request (Confidentiality).
 */
@WebServlet("/api/notifications/*")
public class NotificationApiServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        SessionUser u = (SessionUser) req.getSession().getAttribute(AuthFilter.SESSION_USER);
        if (u.getStudentId() == null) {
            Json.write(resp, 200, Map.of("items", List.of(), "unread", 0));
            return;
        }
        NotificationService svc = AppContextListener.bean(NotificationService.class);
        String path = req.getPathInfo() == null ? "" : req.getPathInfo();
        try {
            if ("/count".equals(path)) {
                Json.write(resp, 200, Map.of("unread", svc.unread(u.getStudentId())));
            } else if ("/popups".equals(path)) {
                List<Map<String, Object>> items = new ArrayList<>();
                for (Notification n : svc.takePopups(u.getStudentId())) {
                    items.add(toMap(n));
                }
                Json.write(resp, 200, Map.of("items", items, "unread", svc.unread(u.getStudentId())));
            } else {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (DataAccessException | IllegalStateException ex) {
            Json.write(resp, 503, Map.of("error", "temporarily unavailable"));
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (!Csrf.isValid(req)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        SessionUser u = (SessionUser) req.getSession().getAttribute(AuthFilter.SESSION_USER);
        if (u.getStudentId() == null) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        NotificationService svc = AppContextListener.bean(NotificationService.class);
        String path = req.getPathInfo() == null ? "" : req.getPathInfo();
        try {
            if ("/read-all".equals(path)) {
                Json.write(resp, 200, Map.of("updated", svc.markAllRead(u.getStudentId())));
            } else if ("/read".equals(path)) {
                long id = Long.parseLong(req.getParameter("id"));
                Json.write(resp, 200, Map.of("updated", svc.markRead(u.getStudentId(), id) ? 1 : 0));
            } else {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (NumberFormatException ex) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST);
        } catch (DataAccessException | IllegalStateException ex) {
            Json.write(resp, 503, Map.of("error", "temporarily unavailable"));
        }
    }

    static Map<String, Object> toMap(Notification n) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", n.getId());
        m.put("color", n.getColor().name());
        m.put("category", n.getCategory());
        m.put("title", n.getTitle());
        m.put("message", n.getMessage());
        m.put("actionLabel", n.getActionLabel());
        m.put("actionUrl", n.getActionUrl());
        m.put("at", n.getCreatedAt().format(DateTimeFormatter.ofPattern("d MMM, hh:mm a", Locale.ENGLISH)));
        m.put("read", n.getReadAt() != null);
        return m;
    }
}
