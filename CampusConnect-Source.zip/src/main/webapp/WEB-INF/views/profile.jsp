<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>
<div class="flex items-center gap-space-sm">
  <span class="p-2 rounded-lg bg-primary-container text-on-primary flex"><span class="material-symbols-outlined">account_circle</span></span>
  <div><h1 class="font-headline-lg text-headline-lg text-on-surface font-bold">My Profile</h1>
  <p class="font-body-sm text-body-sm text-on-surface-variant">Your details as registered with the university</p></div>
</div>
<div class="bg-surface-container-lowest rounded-2xl shadow-sm overflow-hidden max-w-3xl">
  <div class="p-space-lg bg-gradient-to-r from-primary-container to-primary text-on-primary flex items-center gap-space-md">
    <div class="w-20 h-20 rounded-2xl bg-white/15 flex items-center justify-center font-display-lg text-display-lg"><c:out value="${p.initials}"/></div>
    <div><div class="font-headline-lg text-headline-lg font-bold"><c:out value="${p.name}"/></div>
    <div class="font-body-md text-body-md opacity-90"><c:out value="${p.semester}"/> &bull; Academic year <c:out value="${p.year}"/></div></div>
  </div>
  <dl class="grid grid-cols-1 sm:grid-cols-2 gap-px bg-outline-variant/30">
    <div class="bg-surface-container-lowest p-space-md"><dt class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Full Name</dt><dd id="pf-name" class="font-body-lg text-body-lg text-on-surface font-semibold"><c:out value="${p.name}"/></dd></div>
    <div class="bg-surface-container-lowest p-space-md"><dt class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Stream / Branch</dt><dd id="pf-branch" class="font-body-lg text-body-lg text-on-surface font-semibold"><c:out value="${p.program}"/> (<c:out value="${p.branch}"/>)</dd></div>
    <div class="bg-surface-container-lowest p-space-md"><dt class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Gmail Address</dt><dd id="pf-gmail" class="font-body-lg text-body-lg text-on-surface font-semibold break-all"><c:choose><c:when test="${not empty p.gmail}"><c:out value="${p.gmail}"/></c:when><c:otherwise><span class="text-on-surface-variant">Not added</span></c:otherwise></c:choose></dd></div>
    <div class="bg-surface-container-lowest p-space-md"><dt class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Enrollment Number</dt><dd id="pf-enroll" class="font-body-lg text-body-lg text-on-surface font-semibold"><c:out value="${p.enrollment}"/></dd></div>
    <div class="bg-surface-container-lowest p-space-md"><dt class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Hosteler Status</dt>
      <dd id="pf-hosteler" class="font-body-lg text-body-lg font-semibold"><c:choose>
        <c:when test="${p.hosteler}"><span class="px-space-sm py-0.5 rounded bg-secondary-container text-on-secondary-container">Yes</span></c:when>
        <c:otherwise><span class="px-space-sm py-0.5 rounded bg-surface-container text-on-surface-variant">No</span></c:otherwise></c:choose></dd></div>
    <c:if test="${p.hosteler}"><div class="bg-surface-container-lowest p-space-md"><dt class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Hostel Name</dt><dd id="pf-hostel" class="font-body-lg text-body-lg text-on-surface font-semibold"><c:out value="${p.hostelName}"/></dd></div></c:if>
    <div class="bg-surface-container-lowest p-space-md"><dt class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">University E-mail</dt><dd class="font-body-md text-body-md text-on-surface break-all"><c:out value="${p.collegeEmail}"/></dd></div>
    <c:if test="${not empty p.phone}"><div class="bg-surface-container-lowest p-space-md"><dt class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Phone</dt><dd class="font-body-md text-body-md text-on-surface"><c:out value="${p.phone}"/></dd></div></c:if>
  </dl>
</div>
<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>
