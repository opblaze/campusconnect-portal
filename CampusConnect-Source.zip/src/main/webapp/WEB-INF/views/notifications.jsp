<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm"><div class="flex items-center gap-space-sm"><span class="p-2 rounded-lg bg-primary-container text-on-primary flex"><span class="material-symbols-outlined">notifications</span></span><div><h1 class="font-headline-lg text-headline-lg text-on-surface font-bold">Smart Notifications</h1><p class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${cUnread}"/> unread of <c:out value="${cAll}"/></p></div></div><button type="button" id="mark-all" class="px-space-md py-space-xs rounded-lg bg-surface-container text-primary font-label-md text-label-md font-semibold flex items-center gap-1"><span class="material-symbols-outlined text-base">done_all</span>Mark all read</button></div>

<div class="flex flex-wrap gap-space-xs">
<c:forEach var="t" items="${['all|All|cAll','unread|Unread|cUnread','red|Urgent (red)|cRed','orange|Warnings (orange)|cOrange','blue|General (blue)|cBlue']}"><c:set var="p" value="${fn:split(t,'|')}"/>
<a href="${ctx}/app/notifications?f=${p[0]}" class="px-space-md py-1 rounded-full font-label-md text-label-md font-semibold ${filter eq p[0] ? 'bg-primary-container text-on-primary' : 'bg-surface-container text-on-surface-variant hover:text-on-surface'}"><c:out value="${p[1]}"/> (<c:out value="${requestScope[p[2]]}"/>)</a></c:forEach></div>
<div class="flex flex-col gap-space-sm">
<c:if test="${empty items}"><div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm text-on-surface-variant">Nothing here.</div></c:if>
<c:forEach var="n" items="${items}"><div data-nid="${n.id}" class="rounded-xl border-l-4 p-space-md shadow-sm ${n.color eq 'RED' ? 'border-red-600 bg-red-50 dark:bg-red-950/40' : (n.color eq 'ORANGE' ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/40' : 'border-blue-600 bg-blue-50 dark:bg-blue-950/40')} ${n.read ? 'opacity-70' : ''}">
<div class="flex items-center justify-between gap-2"><div class="flex items-center gap-space-xs"><span class="px-2 py-0.5 rounded text-[10px] font-bold tracking-wider text-white ${n.color eq 'RED' ? 'bg-red-600' : (n.color eq 'ORANGE' ? 'bg-amber-500' : 'bg-blue-600')}">${n.color eq 'RED' ? 'URGENT' : (n.color eq 'ORANGE' ? 'WARNING' : 'UPDATE')}</span><span class="font-label-sm text-label-sm text-on-surface-variant"><c:out value="${n.category}"/> &bull; <c:out value="${n.at}"/></span></div>
<c:if test="${not n.read}"><button type="button" class="mark-one font-label-sm text-label-sm text-primary font-semibold" data-id="${n.id}">Mark read</button></c:if></div>
<h2 class="font-label-lg text-label-lg font-semibold text-on-surface mt-1"><c:out value="${n.title}"/></h2>
<p class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${n.message}"/></p>
<c:if test="${not empty n.actionUrl}"><a href="${ctx}<c:out value='${n.actionUrl}'/>" class="inline-block mt-space-xs px-space-md py-1 rounded-lg bg-primary-container text-on-primary font-label-sm text-label-sm font-semibold"><c:out value="${n.actionLabel}"/></a></c:if></div></c:forEach></div>
<script>
(function () {
  var CSRF = '<c:out value="${csrf}"/>', CTX = '${ctx}';
  function post(u, p) { return fetch(CTX + u, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-CSRF-Token': CSRF }, body: new URLSearchParams(p || {}).toString() }); }
  document.querySelectorAll('.mark-one').forEach(function (b) { b.addEventListener('click', function () { post('/api/notifications/read', { id: b.dataset.id }).then(function () { location.reload(); }); }); });
  document.getElementById('mark-all').addEventListener('click', function () { post('/api/notifications/read-all').then(function () { location.reload(); }); });
})();
</script>
<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>
