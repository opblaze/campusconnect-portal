<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<c:set var="ccUser" value="${sessionScope.ccUser}"/>
<!DOCTYPE html>
<html lang="en">
<head><title><c:out value="${pageTitle}"/> - Campus Connect</title><%@ include file="/WEB-INF/jspf/head.jspf" %></head>
<body class="bg-background font-body-md text-body-md text-on-surface antialiased">
<%@ include file="/WEB-INF/jspf/header.jspf" %>
<%@ include file="/WEB-INF/jspf/sidebar.jspf" %>
<div class="lg:pl-64"><main class="w-full min-h-screen pt-16 px-margin py-space-lg lg:px-margin-desktop bg-surface">
  <div class="mt-space-xl bg-surface-container-lowest rounded-2xl p-space-2xl shadow-sm text-center max-w-2xl mx-auto">
    <span class="material-symbols-outlined text-5xl text-primary">construction</span>
    <h1 class="font-headline-lg text-headline-lg text-on-surface font-bold mt-space-sm"><c:out value="${pageTitle}"/></h1>
    <p class="font-body-md text-body-md text-on-surface-variant mt-1"><c:out value="${pageNote}"/></p>
    <a href="${ctx}/dashboard" class="inline-block mt-space-md px-space-lg py-space-sm rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold">Back to Dashboard</a>
  </div>
</main></div>
<%@ include file="/WEB-INF/jspf/widgets.jspf" %>
</body>
</html>
