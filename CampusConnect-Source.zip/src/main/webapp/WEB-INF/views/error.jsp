<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" isErrorPage="true" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<!DOCTYPE html>
<html lang="en">
<head><title>Something went wrong - Campus Connect</title><%@ include file="/WEB-INF/jspf/head.jspf" %></head>
<body class="bg-background font-body-md text-body-md text-on-surface antialiased">
<main class="min-h-screen flex items-center justify-center p-space-lg bg-surface">
  <div class="bg-surface-container-lowest rounded-2xl p-space-2xl shadow-xl text-center max-w-lg">
    <span class="material-symbols-outlined text-5xl text-error">error</span>
    <h1 class="font-headline-lg text-headline-lg font-bold mt-space-sm">Something went wrong</h1>
    <p class="font-body-md text-body-md text-on-surface-variant mt-1"><c:out value="${empty errorMessage ? 'The page you asked for is not available.' : errorMessage}"/></p>
    <a href="${ctx}/dashboard" class="inline-block mt-space-md px-space-lg py-space-sm rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold">Go to Dashboard</a>
  </div>
</main>
</body>
</html>
