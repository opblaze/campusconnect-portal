<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Faculty Dashboard"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<!-- Hero welcome banner -->
<section class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-[0_2px_12px_rgba(15,76,129,0.06)] flex flex-col md:flex-row md:items-center justify-between gap-space-md">
  <div class="flex flex-col gap-1">
    <div class="flex items-center gap-2 flex-wrap">
      <span class="px-2.5 py-0.5 rounded-full bg-primary-container/15 text-primary font-label-sm text-label-sm font-bold uppercase tracking-wider">Faculty Portal</span>
      <span class="px-2.5 py-0.5 rounded-full bg-surface-container-low text-on-surface-variant font-label-sm text-label-sm font-semibold"><c:out value="${fd.employeeCode}"/></span>
      <span class="px-2.5 py-0.5 rounded-full bg-surface-container-low text-on-surface-variant font-label-sm text-label-sm"><c:out value="${fd.department}"/></span>
    </div>
    <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface mt-1">Welcome, <c:out value="${fd.title}"/> <c:out value="${fd.fullName}"/></h1>
    <p class="font-body-md text-body-md text-on-surface-variant"><c:out value="${fd.designation}"/> &bull; Cabin: <strong class="text-on-surface"><c:out value="${fd.cabin}"/></strong> &bull; <c:out value="${fd.todayLabel}"/></p>
  </div>
  <div class="flex flex-wrap gap-2">
    <a href="${ctx}/faculty/attendance" class="px-4 py-2.5 rounded-xl bg-primary-container text-on-primary font-label-md text-label-md font-semibold flex items-center gap-2 hover:opacity-95 transition"><span class="material-symbols-outlined text-lg">fact_check</span>Mark Attendance</a>
    <a href="${ctx}/faculty/assignments" class="px-4 py-2.5 rounded-xl bg-surface-container text-on-surface font-label-md text-label-md font-semibold flex items-center gap-2 hover:bg-surface-container-high transition"><span class="material-symbols-outlined text-lg text-primary">add_task</span>New Assignment</a>
    <a href="${ctx}/faculty/materials" class="px-4 py-2.5 rounded-xl bg-surface-container text-on-surface font-label-md text-label-md font-semibold flex items-center gap-2 hover:bg-surface-container-high transition"><span class="material-symbols-outlined text-lg text-primary">upload_file</span>Upload Material</a>
    <a href="${ctx}/faculty/marks" class="px-4 py-2.5 rounded-xl bg-surface-container text-on-surface font-label-md text-label-md font-semibold flex items-center gap-2 hover:bg-surface-container-high transition"><span class="material-symbols-outlined text-lg text-primary">grading</span>Publish Marks</a>
  </div>
</section>

<!-- 4 KPI Cards -->
<section class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-space-md">
  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] flex flex-col justify-between gap-space-sm">
    <div class="flex items-center justify-between">
      <span class="font-label-md text-label-md text-on-surface-variant font-semibold">Assigned Subjects</span>
      <span class="w-10 h-10 rounded-xl bg-primary-container/15 text-primary flex items-center justify-center"><span class="material-symbols-outlined">menu_book</span></span>
    </div>
    <div class="font-display-lg text-display-lg font-bold text-on-surface"><c:out value="${fd.subjectCount}"/></div>
    <div class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${fd.coreCount}"/> Core &bull; <c:out value="${fd.labCount}"/> Lab &bull; Avg syllabus <c:out value="${fd.avgSyllabusPct}"/>%</div>
  </div>

  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] flex flex-col justify-between gap-space-sm">
    <div class="flex items-center justify-between">
      <span class="font-label-md text-label-md text-on-surface-variant font-semibold">Enrolled Students</span>
      <span class="w-10 h-10 rounded-xl bg-secondary-container text-on-secondary-container flex items-center justify-center"><span class="material-symbols-outlined">groups</span></span>
    </div>
    <div class="font-display-lg text-display-lg font-bold text-on-surface"><c:out value="${fd.totalStudents}"/></div>
    <div class="font-body-sm text-body-sm text-on-surface-variant">Unique learners across your courses</div>
  </div>

  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] flex flex-col justify-between gap-space-sm">
    <div class="flex items-center justify-between">
      <span class="font-label-md text-label-md text-on-surface-variant font-semibold">Pending Grading</span>
      <span class="w-10 h-10 rounded-xl ${fd.pendingSubmissions > 0 ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200' : 'bg-secondary-container text-on-secondary-container'} flex items-center justify-center"><span class="material-symbols-outlined">pending_actions</span></span>
    </div>
    <div class="font-display-lg text-display-lg font-bold text-on-surface"><c:out value="${fd.pendingSubmissions}"/></div>
    <div class="font-body-sm text-body-sm text-on-surface-variant">Across <c:out value="${fd.totalAssignments}"/> active assignment(s)</div>
  </div>

  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] flex flex-col justify-between gap-space-sm">
    <div class="flex items-center justify-between">
      <span class="font-label-md text-label-md text-on-surface-variant font-semibold">Today's Lectures</span>
      <span class="w-10 h-10 rounded-xl bg-primary-container/15 text-primary flex items-center justify-center"><span class="material-symbols-outlined">schedule</span></span>
    </div>
    <div class="font-display-lg text-display-lg font-bold text-on-surface"><c:out value="${fd.todayClassCount}"/></div>
    <div class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${fd.totalMaterials}"/> materials &bull; <c:out value="${fd.feedbackCount}"/> feedback item(s)</div>
  </div>
</section>

<!-- Assigned Subjects Grid -->
<section class="flex flex-col gap-space-md">
  <div class="flex items-center justify-between">
    <h2 class="font-headline-md text-headline-md font-bold text-on-surface">My Teaching Subjects</h2>
    <a href="${ctx}/faculty/my-subjects" class="font-label-md text-label-md text-primary font-semibold hover:underline">Manage subjects &amp; rosters &rarr;</a>
  </div>
  <c:choose>
    <c:when test="${empty fd.subjects}">
      <div class="bg-surface-container-lowest rounded-2xl p-space-lg text-center text-on-surface-variant">No subjects assigned yet. Contact an administrator to allocate courses.</div>
    </c:when>
    <c:otherwise>
      <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-space-md">
        <c:forEach items="${fd.subjects}" var="s">
          <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] flex flex-col justify-between gap-space-md">
            <div>
              <div class="flex items-center justify-between gap-2">
                <span class="px-2.5 py-0.5 rounded-md bg-primary-container/15 text-primary font-label-sm text-label-sm font-bold"><c:out value="${s.code}"/></span>
                <span class="px-2.5 py-0.5 rounded-md bg-surface-container-low text-on-surface-variant font-label-sm text-label-sm font-semibold"><c:out value="${s.category}"/> &bull; Sem <c:out value="${s.semester}"/></span>
              </div>
              <h3 class="font-headline-sm text-headline-sm font-bold text-on-surface mt-2"><c:out value="${s.name}"/></h3>
              <p class="font-body-sm text-body-sm text-on-surface-variant mt-1"><c:out value="${s.enrolledCount}"/> students &bull; <c:out value="${s.credits}"/> credits &bull; <c:out value="${s.meetingDays}"/></p>
            </div>
            <div>
              <div class="flex items-center justify-between font-label-sm text-label-sm mb-1">
                <span class="text-on-surface-variant">Syllabus Coverage</span>
                <span class="font-bold text-on-surface"><c:out value="${s.syllabusPct}"/>%</span>
              </div>
              <div class="w-full h-2 rounded-full bg-surface-container overflow-hidden">
                <div class="h-full bg-primary-container rounded-full" style="width:${s.syllabusPct}%"></div>
              </div>
              <div class="flex flex-wrap gap-2 mt-3 pt-3 border-t border-outline-variant/30">
                <a href="${ctx}/faculty/attendance?subjectId=${s.id}" class="px-3 py-1.5 rounded-lg bg-surface-container text-primary font-label-sm text-label-sm font-semibold hover:bg-surface-container-high">Attendance</a>
                <a href="${ctx}/faculty/marks?subjectId=${s.id}" class="px-3 py-1.5 rounded-lg bg-surface-container text-on-surface font-label-sm text-label-sm font-semibold hover:bg-surface-container-high">Marks</a>
                <a href="${ctx}/faculty/my-subjects?subjectId=${s.id}" class="px-3 py-1.5 rounded-lg bg-surface-container text-on-surface font-label-sm text-label-sm font-semibold hover:bg-surface-container-high">Roster</a>
              </div>
            </div>
          </div>
        </c:forEach>
      </div>
    </c:otherwise>
  </c:choose>
</section>

<!-- Main 2-column operational panels -->
<section class="grid grid-cols-1 xl:grid-cols-2 gap-space-lg">
  <!-- Left column: Today schedule & Recent Materials -->
  <div class="flex flex-col gap-space-lg">
    <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
      <div class="flex items-center justify-between mb-space-md">
        <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Today's Teaching Schedule</h2>
        <a href="${ctx}/faculty/timetable" class="font-label-sm text-label-sm text-primary font-semibold hover:underline">Full timetable &rarr;</a>
      </div>
      <c:choose>
        <c:when test="${empty fd.todaySchedule}">
          <p class="font-body-sm text-body-sm text-on-surface-variant py-4 text-center">No lectures scheduled for today.</p>
        </c:when>
        <c:otherwise>
          <div class="flex flex-col gap-2">
            <c:forEach items="${fd.todaySchedule}" var="slot">
              <div class="p-space-sm rounded-xl bg-surface-container-low flex items-center justify-between gap-3">
                <div>
                  <div class="font-label-md text-label-md font-bold text-on-surface"><c:out value="${slot.subjectCode}"/> &bull; <c:out value="${slot.subjectName}"/></div>
                  <div class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${slot.room}"/> <c:if test="${not empty slot.block}">(<c:out value="${slot.block}"/>)</c:if> <c:if test="${not empty slot.topic}">&bull; <c:out value="${slot.topic}"/></c:if></div>
                </div>
                <span class="px-2.5 py-1 rounded-lg bg-primary-container/15 text-primary font-label-sm text-label-sm font-semibold shrink-0"><c:out value="${slot.timeRange}"/></span>
              </div>
            </c:forEach>
          </div>
        </c:otherwise>
      </c:choose>
    </div>

    <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
      <div class="flex items-center justify-between mb-space-md">
        <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Recent E-Content Uploads</h2>
        <a href="${ctx}/faculty/materials" class="font-label-sm text-label-sm text-primary font-semibold hover:underline">Manage files &rarr;</a>
      </div>
      <c:choose>
        <c:when test="${empty fd.recentMaterials}">
          <p class="font-body-sm text-body-sm text-on-surface-variant py-4 text-center">No materials uploaded yet.</p>
        </c:when>
        <c:otherwise>
          <div class="flex flex-col gap-2">
            <c:forEach items="${fd.recentMaterials}" var="m">
              <div class="p-space-sm rounded-xl bg-surface-container-low flex items-center justify-between gap-3">
                <div class="flex items-center gap-3 min-w-0">
                  <span class="w-9 h-9 rounded-lg bg-primary-container/15 text-primary flex items-center justify-center shrink-0"><span class="material-symbols-outlined text-lg"><c:out value="${m.icon}"/></span></span>
                  <div class="min-w-0">
                    <div class="font-label-md text-label-md font-semibold text-on-surface truncate"><c:out value="${m.title}"/></div>
                    <div class="font-body-sm text-body-sm text-on-surface-variant truncate"><c:out value="${m.subjectName}"/> &bull; <c:out value="${m.sizeLabel}"/></div>
                  </div>
                </div>
                <div class="flex items-center gap-1 shrink-0">
                  <button type="button" data-preview-id="${m.id}" data-preview-src="material" title="Preview" class="p-1.5 rounded-lg hover:bg-surface-container-high text-primary"><span class="material-symbols-outlined text-lg">visibility</span></button>
                  <a href="${ctx}/faculty/download?id=${m.id}" title="Download" class="p-1.5 rounded-lg hover:bg-surface-container-high text-on-surface-variant"><span class="material-symbols-outlined text-lg">download</span></a>
                </div>
              </div>
            </c:forEach>
          </div>
        </c:otherwise>
      </c:choose>
    </div>
  </div>

  <!-- Right column: Upcoming exams, Notices & Feedback -->
  <div class="flex flex-col gap-space-lg">
    <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
      <div class="flex items-center justify-between mb-space-md">
        <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Upcoming Exams</h2>
        <a href="${ctx}/faculty/marks" class="font-label-sm text-label-sm text-primary font-semibold hover:underline">Marks entry &rarr;</a>
      </div>
      <c:choose>
        <c:when test="${empty fd.upcomingExams}">
          <p class="font-body-sm text-body-sm text-on-surface-variant py-4 text-center">No upcoming exams for your subjects.</p>
        </c:when>
        <c:otherwise>
          <div class="flex flex-col gap-2">
            <c:forEach items="${fd.upcomingExams}" var="ex">
              <div class="p-space-sm rounded-xl bg-surface-container-low flex items-center gap-3">
                <div class="w-12 h-12 rounded-xl bg-primary-container text-on-primary flex flex-col items-center justify-center shrink-0">
                  <span class="font-label-sm text-[10px] uppercase leading-none"><c:out value="${ex.month}"/></span>
                  <span class="font-headline-sm text-headline-sm font-bold leading-tight"><c:out value="${ex.day}"/></span>
                </div>
                <div class="min-w-0">
                  <div class="font-label-md text-label-md font-bold text-on-surface truncate"><c:out value="${ex.code}"/> &bull; <c:out value="${ex.subjectName}"/></div>
                  <div class="font-body-sm text-body-sm text-on-surface-variant truncate"><c:out value="${ex.timeRange}"/></div>
                </div>
              </div>
            </c:forEach>
          </div>
        </c:otherwise>
      </c:choose>
    </div>

    <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
      <div class="flex items-center justify-between mb-space-md">
        <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Recent Notices &amp; Feedback</h2>
        <div class="flex gap-3">
          <a href="${ctx}/faculty/announcements" class="font-label-sm text-label-sm text-primary font-semibold hover:underline">Notices</a>
          <a href="${ctx}/faculty/feedback" class="font-label-sm text-label-sm text-primary font-semibold hover:underline">Feedback</a>
        </div>
      </div>
      <div class="flex flex-col gap-2">
        <c:forEach items="${fd.notices}" var="n" end="2">
          <div class="p-space-sm rounded-xl bg-surface-container-low">
            <div class="flex items-center justify-between gap-2">
              <span class="font-label-md text-label-md font-semibold text-on-surface"><c:out value="${n.title}"/></span>
              <c:if test="${n.important}"><span class="px-2 py-0.5 rounded bg-error-container text-on-error-container font-label-sm text-label-sm font-bold">Important</span></c:if>
            </div>
            <p class="font-body-sm text-body-sm text-on-surface-variant mt-1 line-clamp-2"><c:out value="${n.body}"/></p>
            <div class="font-label-sm text-label-sm text-on-surface-variant mt-1"><c:out value="${n.subjectCode}"/> &bull; <c:out value="${n.authorName}"/> &bull; <c:out value="${n.createdLabel}"/></div>
          </div>
        </c:forEach>
        <c:forEach items="${fd.recentFeedback}" var="fb" end="1">
          <div class="p-space-sm rounded-xl border border-outline-variant/40">
            <div class="flex items-center justify-between gap-2">
              <span class="font-label-md text-label-md font-semibold text-on-surface"><c:out value="${fb.studentName}"/> (<c:out value="${fb.subjectCode}"/>)</span>
              <span class="px-2 py-0.5 rounded bg-surface-container text-on-surface-variant font-label-sm text-label-sm font-semibold"><c:out value="${fb.status}"/></span>
            </div>
            <p class="font-body-sm text-body-sm text-on-surface-variant mt-1"><c:out value="${fb.message}"/></p>
          </div>
        </c:forEach>
      </div>
    </div>
  </div>
</section>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

