<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm"><div class="flex items-center gap-space-sm"><span class="p-2 rounded-lg bg-primary-container text-on-primary flex"><span class="material-symbols-outlined">search</span></span><div><h1 class="font-headline-lg text-headline-lg text-on-surface font-bold">Search</h1><p class="font-body-sm text-body-sm text-on-surface-variant">Results for "<c:out value="${q}"/>"</p></div></div></div>

<c:forEach var="g" items="${results}"><div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm"><h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-space-xs"><c:out value="${g.key}"/> (<c:out value="${fn:length(g.value)}"/>)</h2>
<c:if test="${empty g.value}"><p class="text-on-surface-variant font-body-sm">No matches.</p></c:if>
<c:forEach var="r" items="${g.value}"><a href="${ctx}<c:out value='${r.href}'/>" class="block p-space-sm rounded-lg hover:bg-surface-container"><div class="font-semibold text-on-surface"><c:out value="${r.title}"/></div><div class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${r.sub}"/></div></a></c:forEach></div></c:forEach>
<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>
