<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm">
  <div class="flex items-center gap-space-sm">
    <span class="p-2 rounded-lg bg-primary-container text-on-primary flex"><span class="material-symbols-outlined">folder_shared</span></span>
    <div><h1 class="font-headline-lg text-headline-lg text-on-surface font-bold">E-Content Materials</h1>
    <p class="font-body-sm text-body-sm text-on-surface-variant">Preview <span class="material-symbols-outlined text-sm align-middle">visibility</span>, download or upload your own notes</p></div>
  </div>
  <div class="flex items-center gap-space-sm">
    <form method="get" action="${ctx}/app/e-content" class="m-0"><select name="subject" onchange="this.form.submit()" class="px-space-md py-space-xs rounded-lg bg-surface-container-low text-on-surface font-body-sm text-body-sm"><option value="">All subjects</option><c:forEach var="s" items="${d.subjects}"><option value="${s.id}" ${subjectFilter == s.id ? 'selected' : ''}><c:out value="${s.name}"/></option></c:forEach></select></form>
    <button type="button" id="open-upload" class="px-space-md py-space-xs rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold flex items-center gap-1"><span class="material-symbols-outlined text-base">upload_file</span>Upload</button>
  </div>
</div>

<%-- ================= material uploaded by faculty ================= --%>
<div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm flex flex-col gap-space-xs" id="material-list">
  <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-space-xs">Course material from your faculty</h2>
  <c:if test="${empty rows}"><p class="text-on-surface-variant font-body-md">No material found.</p></c:if>
  <c:forEach var="m" items="${rows}">
    <div class="mat-row flex items-center justify-between gap-space-sm p-space-sm rounded-xl hover:bg-surface-container transition-colors">
      <div class="flex items-center gap-space-sm min-w-0">
        <span class="p-2 rounded-lg bg-surface-container-low text-primary"><span class="material-symbols-outlined"><c:out value="${m.icon}"/></span></span>
        <div class="min-w-0"><div class="font-label-lg text-label-lg font-semibold text-on-surface truncate"><c:out value="${m.title}"/></div>
        <div class="font-body-sm text-body-sm text-on-surface-variant truncate"><c:out value="${m.subject}"/> &bull; <c:out value="${m.size}"/> &bull; <c:out value="${m.by}"/> &bull; <c:out value="${m.at}"/></div></div>
      </div>
      <div class="flex items-center gap-1 shrink-0">
        <button type="button" data-preview-src="material" data-preview-id="${m.id}" title="View" aria-label="View <c:out value='${m.title}'/>" class="eye-btn p-2 rounded-lg bg-surface-container text-primary hover:bg-surface-container-high"><span class="material-symbols-outlined text-xl">visibility</span></button>
        <a href="${ctx}/app/download?src=material&amp;id=${m.id}" title="Download" aria-label="Download <c:out value='${m.title}'/>" class="p-2 rounded-lg bg-primary-container text-on-primary flex"><span class="material-symbols-outlined text-xl">download</span></a>
      </div>
    </div>
  </c:forEach>
</div>

<%-- ================= my private notes ================= --%>
<div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm flex flex-col gap-space-xs" id="notes-list">
  <div class="flex items-center justify-between mb-space-xs">
    <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">My notes <span class="font-body-sm text-body-sm text-on-surface-variant font-normal">(private - only you can see them)</span></h2>
    <button type="button" id="open-upload-2" class="px-space-md py-1 rounded-lg bg-surface-container text-primary font-label-md text-label-md font-semibold flex items-center gap-1"><span class="material-symbols-outlined text-base">add</span>Upload note</button>
  </div>
  <c:if test="${empty notes}"><p class="text-on-surface-variant font-body-md">You have not uploaded any notes yet. Use the <b>Upload</b> button to add PDFs, images, text or code files (max 5 MB).</p></c:if>
  <c:forEach var="n" items="${notes}">
    <div class="note-row flex items-center justify-between gap-space-sm p-space-sm rounded-xl hover:bg-surface-container transition-colors">
      <div class="flex items-center gap-space-sm min-w-0">
        <span class="p-2 rounded-lg bg-surface-container-low text-secondary"><span class="material-symbols-outlined">sticky_note_2</span></span>
        <div class="min-w-0"><div class="font-label-lg text-label-lg font-semibold text-on-surface truncate"><c:out value="${n.title}"/></div>
        <div class="font-body-sm text-body-sm text-on-surface-variant truncate"><c:out value="${n.subject}"/> &bull; <c:out value="${n.file}"/> &bull; <c:out value="${n.size}"/> &bull; <c:out value="${n.at}"/></div></div>
      </div>
      <div class="flex items-center gap-1 shrink-0">
        <button type="button" data-preview-src="note" data-preview-id="${n.id}" title="View" aria-label="View note" class="eye-btn p-2 rounded-lg bg-surface-container text-primary hover:bg-surface-container-high"><span class="material-symbols-outlined text-xl">visibility</span></button>
        <a href="${ctx}/app/download?src=note&amp;id=${n.id}" title="Download" aria-label="Download note" class="p-2 rounded-lg bg-primary-container text-on-primary flex"><span class="material-symbols-outlined text-xl">download</span></a>
        <form method="post" action="${ctx}/app/notes" enctype="multipart/form-data" class="m-0" onsubmit="return confirm('Delete this note?')">
          <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="${n.id}">
          <button type="submit" title="Delete" aria-label="Delete note" class="p-2 rounded-lg bg-surface-container text-error hover:bg-surface-container-high"><span class="material-symbols-outlined text-xl">delete</span></button></form>
      </div>
    </div>
  </c:forEach>
</div>

<%-- ================= upload window ================= --%>
<div id="upload-modal" class="hidden fixed inset-0 z-[90] bg-black/60 items-center justify-center p-3" role="dialog" aria-modal="true" aria-labelledby="upload-title">
  <form method="post" action="${ctx}/app/notes" enctype="multipart/form-data" class="bg-surface-container-lowest rounded-2xl shadow-2xl w-[min(96vw,480px)] p-space-lg flex flex-col gap-space-sm" onsubmit="return this.file.files.length > 0 || (alert('Please choose a file first.'), false)">
    <div class="flex items-center justify-between"><h2 id="upload-title" class="font-headline-sm text-headline-sm font-bold text-on-surface">Upload a note</h2>
      <button type="button" id="close-upload" class="p-1.5 rounded-lg hover:bg-surface-container text-on-surface-variant" aria-label="Close"><span class="material-symbols-outlined">close</span></button></div>
    <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"><input type="hidden" name="action" value="upload">
    <label class="font-label-md text-label-md text-on-surface" for="up-title">Title</label>
    <input id="up-title" name="title" maxlength="150" placeholder="e.g. AJT Unit 4 summary" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface font-body-md text-body-md outline-none focus:ring-2 focus:ring-primary-container/30">
    <label class="font-label-md text-label-md text-on-surface" for="up-sub">Subject (optional)</label>
    <select id="up-sub" name="subjectId" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface font-body-md text-body-md outline-none"><option value="">General</option><c:forEach var="s" items="${d.subjects}"><option value="${s.id}"><c:out value="${s.name}"/></option></c:forEach></select>
    <label class="font-label-md text-label-md text-on-surface" for="up-file">File (PDF, image, text, code, Office - max 5 MB)</label>
    <input id="up-file" type="file" name="file" class="font-body-sm text-body-sm text-on-surface-variant">
    <div class="flex justify-end gap-space-sm mt-space-sm"><button type="button" id="cancel-upload" class="px-space-md py-1.5 rounded-lg bg-surface-container text-on-surface-variant font-label-md text-label-md font-semibold">Cancel</button>
    <button type="submit" class="px-space-md py-1.5 rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold flex items-center gap-1"><span class="material-symbols-outlined text-base">upload</span>Upload</button></div>
  </form>
</div>
<script>
(function () {
  var m = document.getElementById('upload-modal');
  function openM() { m.classList.remove('hidden'); m.classList.add('flex'); }
  function closeM() { m.classList.add('hidden'); m.classList.remove('flex'); }
  ['open-upload', 'open-upload-2'].forEach(function (id) { document.getElementById(id).addEventListener('click', openM); });
  ['close-upload', 'cancel-upload'].forEach(function (id) { document.getElementById(id).addEventListener('click', closeM); });
  m.addEventListener('click', function (e) { if (e.target === m) { closeM(); } });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { closeM(); } });
})();
</script>
<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>
