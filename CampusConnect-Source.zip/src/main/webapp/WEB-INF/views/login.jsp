<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Sign In - Campus Connect</title>
<%@ include file="/WEB-INF/jspf/head.jspf" %>
</head>
<body class="bg-background font-body-md text-body-md text-on-surface antialiased"><main class="min-h-screen w-full flex items-center justify-center p-space-lg bg-surface"><div class="flex flex-col w-full">
<div class="w-full max-w-7xl mx-auto my-auto overflow-hidden rounded-xl shadow-xl bg-surface-container-lowest grid grid-cols-1 lg:grid-cols-12 min-h-[760px]">
<!-- Left Column: Branding Showcase -->
<div class="lg:col-span-5 relative flex flex-col justify-between p-space-xl lg:p-space-2xl bg-gradient-to-br from-primary via-primary-container to-tertiary-container text-on-primary overflow-hidden">
<!-- Ambient Geometry & Watermark -->
<div class="absolute -right-20 -top-20 w-96 h-96 rounded-full bg-secondary-container/10 blur-3xl pointer-events-none"></div>
<div class="absolute -left-16 bottom-10 w-80 h-80 rounded-full bg-tertiary-fixed/15 blur-2xl pointer-events-none"></div>
<div class="absolute inset-0 opacity-5 pointer-events-none flex items-center justify-center">
<svg class="w-full h-full text-surface-container-lowest fill-current" viewBox="0 0 200 200">
<polygon points="100,10 190,60 190,160 100,210 10,160 10,60"></polygon>
<polygon points="100,35 165,70 165,145 100,180 35,145 35,70"></polygon>
<circle cx="100" cy="100" r="30"></circle>
</svg>
</div>
<!-- Top Branding -->
<div class="relative z-10">
<div class="flex items-center gap-space-sm mb-space-lg">
<img src="${ctx}/assets/img/marwadi-logo.png" alt="Marwadi University" class="h-14 w-auto object-contain mb-3 bg-white p-2 rounded-lg shadow-sm">
<div>
<div class="font-headline-sm text-headline-sm text-surface-container-lowest tracking-tight">MARWADI UNIVERSITY</div>
<div class="font-label-sm text-label-sm uppercase tracking-widest text-secondary-fixed">Campus Connect Digital Ecosystem</div>
</div>
</div>
<div class="inline-flex items-center gap-space-xs px-space-sm py-space-xs rounded-full bg-surface-container-lowest/15 backdrop-blur text-secondary-fixed font-label-md text-label-md mb-space-md">
<span class="material-symbols-outlined text-base">verified</span>
          NAAC Grade A++ Accredited • NIRF Top 15
        </div>
<h1 class="font-display-lg text-display-lg font-bold leading-tight text-surface-container-lowest tracking-tight">
          Unified Academic &amp; Research Gateway.
        </h1>
<p class="mt-space-sm font-body-md text-body-md text-surface-container-high/90 max-w-sm">
          Seamlessly manage coursework, live schedules, AI-assisted study spaces, and semester grade registries in one unified platform.
        </p>
</div>
<!-- Center Feature Metric Cards -->
<div class="relative z-10 grid grid-cols-2 gap-space-sm my-space-lg">
<div class="p-space-md rounded-lg bg-surface-container-lowest/10 backdrop-blur-md">
<div class="font-headline-lg text-headline-lg font-bold text-surface-container-lowest">15,400+</div>
<div class="font-body-sm text-body-sm text-surface-container-high/80">Active Scholars</div>
</div>
<div class="p-space-md rounded-lg bg-surface-container-lowest/10 backdrop-blur-md">
<div class="font-headline-lg text-headline-lg font-bold text-secondary-fixed">99.8%</div>
<div class="font-body-sm text-body-sm text-surface-container-high/80">Portal Uptime</div>
</div>
</div>
<!-- Student Testimonial Micro-Card -->
<div class="relative z-10 p-space-md rounded-lg bg-surface-container-lowest/15 backdrop-blur-md">
<div class="flex items-center gap-space-sm mb-space-xs">
<div class="w-10 h-10 rounded-full bg-secondary-fixed text-on-secondary-fixed flex items-center justify-center font-label-lg text-label-lg font-bold shadow">AD</div>
<div>
<div class="font-label-lg text-label-lg text-surface-container-lowest">Aanya Deshmukh</div>
<div class="font-body-sm text-body-sm text-surface-container-high/80">B.Tech CSE, 6th Sem • Magna Cum Laude</div>
</div>
</div>
<p class="font-body-sm text-body-sm text-surface-container-high italic">
          “Accessing continuous evaluations, attendance forecasting, and IEEE journal repositories has never been this effortless.”
        </p>
</div>
<!-- Accreditation Footer Badges -->
<div class="relative z-10 pt-space-md flex items-center justify-between font-label-sm text-label-sm text-surface-container-high/70">
<span class="flex items-center gap-space-xs">
<span class="material-symbols-outlined text-sm">lock</span> ISO 27001 Certified
        </span>
<span class="">•</span>
<span class="">AICTE &amp; UGC Recognized</span>
<span class="">•</span>
<span class="">Est. 1984</span>
</div>
</div>
<!-- Right Column: Interactive Tabbed Form Canvas -->
<div class="lg:col-span-7 p-space-lg lg:p-space-2xl flex flex-col justify-between bg-surface-container-lowest">
<!-- Top Bar: Quick Status & Network Status -->
<div class="flex items-center justify-between pb-space-md">
<div class="flex items-center gap-space-xs text-secondary font-label-md text-label-md">
<span class="w-2 h-2 rounded-full bg-secondary animate-pulse"></span>
          Academic Session 2026-27 Live
        </div>
<div class="flex items-center gap-space-sm font-label-sm text-label-sm text-on-surface-variant"><button type="button" data-theme-toggle onclick="ccTheme.toggle()" class="p-1 rounded-lg hover:bg-surface-container-high"><span data-theme-icon class="material-symbols-outlined text-xl">brightness_auto</span></button>
<span class="material-symbols-outlined text-base text-primary">support_agent</span>
          Helpdesk: <span class="font-semibold text-primary">ext. 4402</span>
</div>
</div>
<!-- Segmented Control Tabs -->
<div class="w-full">

<!-- TAB 1: STUDENT LOGIN -->
<div class="space-y-space-md transition-opacity duration-200" id="panel-login">
<div>
<h2 class="font-headline-lg text-headline-lg font-bold text-on-surface">Sign In to Campus Connect</h2>
<p class="font-body-md text-body-md text-on-surface-variant mt-0.5">Enter your institutional enrollment credentials to access your academic dashboard.</p>
</div>
<!-- Single Sign-on Google Workspace -->
<button class="w-full py-2.5 px-space-md rounded-lg bg-surface-container text-on-surface hover:bg-surface-variant transition flex items-center justify-center gap-space-sm font-label-lg text-label-lg" type="button" onclick="alert('University Workspace sign-in is not enabled in this build. Use your enrollment number and password.')">
<svg class="w-5 h-5" viewBox="0 0 24 24">
<path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"></path>
<path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"></path>
<path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#FBBC05"></path>
<path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#EA4335"></path>
</svg>
            Continue with University Workspace
          </button>
<div class="relative flex items-center justify-center my-space-xs">
<div class="w-full h-px bg-surface-container-high"></div>
<span class="absolute bg-surface-container-lowest px-space-sm font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">or institutional id</span>
</div>
<c:if test="${not empty error}"><div role="alert" class="p-space-sm rounded-lg bg-error-container text-on-error-container flex items-start gap-space-sm"><span class="material-symbols-outlined text-xl">error</span><div class="font-body-sm text-body-sm font-medium"><c:out value="${error}"/></div></div></c:if>
<form id="login-form" class="space-y-space-md" method="post" action="${ctx}/login" novalidate onsubmit="return ccValidateLogin(this)"> <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"> <div> <label class="block font-label-md text-label-md text-on-surface font-medium mb-1" for="login-id"> Enrollment No. / University ID </label> <div class="relative"> <span class="material-symbols-outlined absolute left-3 top-2.5 text-on-surface-variant text-xl">badge</span> <input class="w-full pl-10 pr-4 py-2.5 rounded-lg bg-surface-container-low text-on-surface font-body-md text-body-md placeholder:text-on-surface-variant/60 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-container/30" id="login-id" name="loginId" maxlength="150" autocomplete="username" value="<c:out value='${loginId}'/>" placeholder="e.g., DEMO-STU-001, DEMO-FAC-001 or user@example.invalid" required type="text"> </div> <p id="err-id" class="hidden mt-1 font-label-sm text-label-sm text-error"></p> </div> <div> <div class="flex items-center justify-between mb-1"> <label class="font-label-md text-label-md text-on-surface font-medium" for="login-password"> Portal Password </label> <a class="font-label-sm text-label-sm text-primary hover:underline font-semibold" href="javascript:void(0)" onclick="alert('Please contact the Campus Helpdesk (ext. 4402) to reset your password.')"> Forgot Password? </a> </div> <div class="relative"> <span class="material-symbols-outlined absolute left-3 top-2.5 text-on-surface-variant text-xl">key</span> <input class="w-full pl-10 pr-10 py-2.5 rounded-lg bg-surface-container-low text-on-surface font-body-md text-body-md placeholder:text-on-surface-variant/60 shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-container/30" id="login-password" name="password" maxlength="100" autocomplete="current-password" placeholder="••••••••••••" required type="password"> <button class="absolute right-3 top-2.5 text-on-surface-variant hover:text-on-surface" onclick="togglePasswordVisibility('login-password', this)" type="button" aria-label="Show password"> <span class="material-symbols-outlined text-xl">visibility</span> </button> </div> <p id="err-pw" class="hidden mt-1 font-label-sm text-label-sm text-error"></p> </div> <div class="p-space-sm rounded-lg bg-surface-container-low flex items-start gap-space-sm"> <span class="material-symbols-outlined text-secondary text-xl mt-0.5">phonelink_lock</span> <div class="flex-1"> <div class="font-label-md text-label-md font-semibold text-on-surface">Secure Session Protection</div> <div class="font-body-sm text-body-sm text-on-surface-variant">Passwords are stored as salted hashes, and your session expires automatically after inactivity.</div> </div> </div> <div class="flex items-center justify-between"> <label class="flex items-center gap-space-xs cursor-pointer select-none"> <input checked name="remember" class="w-4 h-4 rounded text-primary focus:ring-0 cursor-pointer accent-primary" type="checkbox"> <span class="font-body-sm text-body-sm text-on-surface">Remember this secure device for 14 days</span> </label> </div> <button class="w-full py-3 rounded-lg bg-primary hover:bg-on-primary-fixed text-on-primary font-label-lg text-label-lg transition shadow-md flex items-center justify-center gap-space-xs font-semibold" type="submit"> <span class="material-symbols-outlined text-xl">domain_verification</span> Sign In to Campus Connect </button> </form>
</div>
<!-- TAB 2: NEW STUDENT REGISTRATION -->

</div>
<!-- Footer & Trust Badges -->
<div class="pt-space-lg mt-space-md bg-surface-container-low/50 -mx-space-lg lg:-mx-space-2xl -mb-space-lg lg:-mb-space-2xl p-space-md flex flex-wrap items-center justify-between gap-space-sm">
<div class="flex items-center gap-space-sm text-on-surface-variant font-label-sm text-label-sm">
<span class="flex items-center gap-1 text-secondary font-medium">
<span class="material-symbols-outlined text-base">verified_user</span>
            256-Bit SSL Encrypted
          </span>
<span class="">•</span>
<span class="">Marwadi University IT Services</span>
</div>
<div class="flex items-center gap-space-md font-label-sm text-label-sm text-on-surface-variant">
<a class="hover:text-primary transition" href="javascript:void(0)">Privacy Policy</a>
<a class="hover:text-primary transition" href="javascript:void(0)">Terms of Service</a>
<a class="hover:text-primary transition" href="javascript:void(0)">System Status</a>
</div>
</div>
</div>
</div>
</div>
<script>
/* togglePasswordVisibility: show / hide the typed password */
function togglePasswordVisibility(fieldId, btn) {
  var f = document.getElementById(fieldId), icon = btn.querySelector('.material-symbols-outlined');
  if (f.type === 'password') { f.type = 'text'; icon.textContent = 'visibility_off'; }
  else { f.type = 'password'; icon.textContent = 'visibility'; }
}
/* Client-side form validation (the servlet validates again - never trust the browser alone) */
function ccValidateLogin(form) {
  var id = form.loginId.value.trim(), pw = form.password.value, ok = true;
  var emailRe = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/, enrollRe = /^[A-Za-z0-9-]{6,20}$/;
  function show(el, msg) { var e = document.getElementById(el); e.textContent = msg; e.classList.toggle('hidden', !msg); }
  show('err-id', ''); show('err-pw', '');
  if (!id) { show('err-id', 'Enter your enrollment number, employee ID or e-mail.'); ok = false; }
  else if (!emailRe.test(id) && !enrollRe.test(id)) { show('err-id', 'Enter a valid enrollment number, employee ID or institutional e-mail.'); ok = false; }
  if (pw.length < 6) { show('err-pw', 'Password must be at least 6 characters.'); ok = false; }
  return ok;
}
</script></main>

</body>
</html>
