<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Admin Search"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<div>
  <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface">Global Admin Search</h1>
  <p class="font-body-sm text-body-sm text-on-surface-variant">Search across students, faculty, courses, fees and admin workflows.</p>
</div>

<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <form method="get" action="${ctx}/admin/search" class="flex gap-3">
    <input type="text" name="q" value="<c:out value='${query}'/>" placeholder="Search enrollment, employee ID, fee receipt, course..." class="flex-1 px-4 py-2.5 rounded-xl bg-surface-container-low text-on-surface border border-outline-variant/40"/>
    <button type="submit" class="px-5 py-2.5 rounded-xl bg-primary-container text-on-primary font-label-md text-label-md font-semibold">Search</button>
  </form>
  <div class="flex flex-wrap gap-2 mt-3">
    <c:forEach items="${suggestions}" var="sug">
      <a href="${ctx}/admin/search?q=<c:out value='${sug}'/>" class="px-3 py-1 rounded-full bg-surface-container text-on-surface font-label-sm text-label-sm font-semibold hover:bg-surface-container-high"><c:out value="${sug}"/></a>
    </c:forEach>
  </div>
</section>

<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <c:choose>
    <c:when test="${empty query}">
      <p class="font-body-sm text-body-sm text-on-surface-variant py-6 text-center">Enter a keyword above or click a filter chip.</p>
    </c:when>
    <c:when test="${empty results}">
      <p class="font-body-sm text-body-sm text-on-surface-variant py-6 text-center">No results matched "<c:out value="${query}"/>".</p>
    </c:when>
    <c:otherwise>
      <div class="flex flex-col gap-2">
        <c:forEach items="${results}" var="r">
          <a href="${ctx}${r.href}" class="p-space-sm rounded-xl bg-surface-container-low hover:bg-surface-container transition flex items-center justify-between gap-3">
            <div>
              <div class="font-label-sm text-label-sm font-bold text-primary uppercase"><c:out value="${r.type}"/></div>
              <div class="font-label-lg text-label-lg font-bold text-on-surface"><c:out value="${r.title}"/></div>
              <div class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${r.sub}"/></div>
            </div>
            <span class="px-2.5 py-1 rounded-lg bg-surface-container-lowest text-on-surface font-label-sm text-label-sm font-semibold shrink-0"><c:out value="${r.badge}"/></span>
          </a>
        </c:forEach>
      </div>
    </c:otherwise>
  </c:choose>
</section>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

