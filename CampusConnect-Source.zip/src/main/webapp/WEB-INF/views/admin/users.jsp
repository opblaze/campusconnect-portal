<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="User Accounts"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<div>
  <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface">User Account Management</h1>
  <p class="font-body-sm text-body-sm text-on-surface-variant">Create student, faculty or admin logins, suspend/reactivate accounts, and reset credentials.</p>
</div>

<!-- Create User Form -->
<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-3">Create New User Account</h2>
  <form method="post" action="${ctx}/admin/users/create" class="flex flex-col gap-4">
    <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <div class="flex flex-col gap-1">
        <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="uName">Full Name</label>
        <input id="uName" name="fullName" type="text" required maxlength="120" placeholder="e.g. Aarav Patel" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"/>
      </div>
      <div class="flex flex-col gap-1">
        <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="uEmail">Institutional Email</label>
        <input id="uEmail" name="email" type="email" required maxlength="150" placeholder="user@example.invalid" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"/>
      </div>
      <div class="flex flex-col gap-1">
        <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="uRole">Role</label>
        <select id="uRole" name="role" onchange="ccRoleFields()" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40">
          <option value="STUDENT">Student</option>
          <option value="FACULTY">Faculty</option>
          <option value="ADMIN">Administrator</option>
        </select>
      </div>
      <div class="flex flex-col gap-1">
        <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="uPass">Initial Password</label>
        <input id="uPass" name="password" type="password" required minlength="8" placeholder="8+ chars with digit" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"/>
      </div>
    </div>

    <!-- Student-specific fields -->
    <div id="cc-student-fields" class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3 p-3 rounded-xl bg-surface-container-low">
      <input name="enrollmentNo" type="text" maxlength="20" placeholder="Enrollment No (e.g. DEMO-STU-004)" class="px-3 py-2 rounded-lg bg-surface-container-lowest text-on-surface border border-outline-variant/40"/>
      <input name="program" type="text" maxlength="80" value="B.Tech CSE" placeholder="Program" class="px-3 py-2 rounded-lg bg-surface-container-lowest text-on-surface border border-outline-variant/40"/>
      <input name="branchCode" type="text" maxlength="20" value="CS" placeholder="Branch (CS)" class="px-3 py-2 rounded-lg bg-surface-container-lowest text-on-surface border border-outline-variant/40"/>
      <input name="semester" type="number" min="1" max="8" value="3" placeholder="Sem" class="px-3 py-2 rounded-lg bg-surface-container-lowest text-on-surface border border-outline-variant/40"/>
      <input name="academicYear" type="text" maxlength="20" value="2026-27" placeholder="Academic Year" class="px-3 py-2 rounded-lg bg-surface-container-lowest text-on-surface border border-outline-variant/40"/>
      <div class="flex items-center gap-2">
        <input id="uHostel" name="hosteler" type="checkbox" value="true" class="w-4 h-4 accent-primary"/>
        <label for="uHostel" class="font-body-sm text-body-sm">Hosteler</label>
        <input name="hostelName" type="text" maxlength="80" placeholder="Hostel" class="w-24 px-2 py-1.5 rounded-lg bg-surface-container-lowest text-on-surface border border-outline-variant/40 text-xs"/>
      </div>
    </div>

    <!-- Faculty-specific fields -->
    <div id="cc-faculty-fields" class="hidden grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3 p-3 rounded-xl bg-surface-container-low">
      <input name="employeeCode" type="text" maxlength="20" placeholder="Employee Code (e.g. MU-F109)" class="px-3 py-2 rounded-lg bg-surface-container-lowest text-on-surface border border-outline-variant/40"/>
      <input name="title" type="text" maxlength="10" value="Prof." placeholder="Title (Dr./Prof.)" class="px-3 py-2 rounded-lg bg-surface-container-lowest text-on-surface border border-outline-variant/40"/>
      <input name="designation" type="text" maxlength="60" value="Assistant Professor" placeholder="Designation" class="px-3 py-2 rounded-lg bg-surface-container-lowest text-on-surface border border-outline-variant/40"/>
      <input name="department" type="text" maxlength="80" value="Computer Engineering" placeholder="Department" class="px-3 py-2 rounded-lg bg-surface-container-lowest text-on-surface border border-outline-variant/40"/>
      <input name="cabin" type="text" maxlength="40" placeholder="Cabin (e.g. MA-208)" class="px-3 py-2 rounded-lg bg-surface-container-lowest text-on-surface border border-outline-variant/40"/>
    </div>

    <div>
      <button type="submit" class="px-5 py-2.5 rounded-xl bg-primary-container text-on-primary font-label-md text-label-md font-semibold">Create Account</button>
    </div>
  </form>
</section>

<!-- Filter + Users Table -->
<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <form method="get" action="${ctx}/admin/users" class="flex flex-wrap items-center justify-between gap-3 mb-4">
    <div class="flex flex-wrap gap-1.5">
      <c:forTokens items="ALL,STUDENT,FACULTY,ADMIN" delims="," var="rf">
        <a href="${ctx}/admin/users?role=${rf}&q=<c:out value='${query}'/>" class="px-3 py-1.5 rounded-lg font-label-sm text-label-sm font-semibold ${roleFilter eq rf ? 'bg-primary-container text-on-primary' : 'bg-surface-container text-on-surface-variant'}"><c:out value="${rf}"/></a>
      </c:forTokens>
    </div>
    <div class="flex gap-2">
      <input type="hidden" name="role" value="<c:out value='${roleFilter}'/>"/>
      <input type="text" name="q" value="<c:out value='${query}'/>" placeholder="Filter by name, email, code..." class="px-3 py-1.5 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40 text-sm"/>
      <button type="submit" class="px-3 py-1.5 rounded-lg bg-primary-container text-on-primary font-label-sm text-label-sm font-semibold">Filter</button>
    </div>
  </form>

  <div class="overflow-x-auto">
    <table class="w-full text-left border-collapse">
      <thead>
        <tr class="border-b border-outline-variant/40 font-label-sm text-label-sm text-on-surface-variant uppercase">
          <th class="py-2.5 px-3">Account</th>
          <th class="py-2.5 px-3">Role / ID</th>
          <th class="py-2.5 px-3">Status</th>
          <th class="py-2.5 px-3">Last Login</th>
          <th class="py-2.5 px-3">Actions</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-outline-variant/20 font-body-sm text-body-sm">
        <c:forEach items="${users}" var="u">
          <tr>
            <td class="py-2.5 px-3">
              <div class="font-semibold text-on-surface"><c:out value="${u.fullName}"/></div>
              <div class="text-xs text-on-surface-variant"><c:out value="${u.email}"/></div>
            </td>
            <td class="py-2.5 px-3">
              <span class="px-2 py-0.5 rounded font-label-sm text-label-sm font-bold ${u.role eq 'ADMIN' ? 'bg-primary-container text-on-primary' : (u.role eq 'FACULTY' ? 'bg-secondary-container text-on-secondary-container' : 'bg-surface-container text-on-surface')}"><c:out value="${u.role}"/></span>
              <div class="text-xs text-on-surface-variant mt-0.5"><c:out value="${u.codeLabel}"/></div>
            </td>
            <td class="py-2.5 px-3">
              <span class="px-2 py-0.5 rounded font-label-sm text-label-sm font-bold ${u.active ? 'bg-secondary-container text-on-secondary-container' : 'bg-error-container text-on-error-container'}"><c:out value="${u.active ? 'ACTIVE' : 'SUSPENDED'}"/></span>
            </td>
            <td class="py-2.5 px-3 text-on-surface-variant"><c:out value="${u.lastLoginLabel}"/></td>
            <td class="py-2.5 px-3">
              <div class="flex flex-wrap items-center gap-2">
                <form method="post" action="${ctx}/admin/users/toggle" class="m-0">
                  <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
                  <input type="hidden" name="userId" value="${u.id}"/>
                  <button type="submit" class="px-2.5 py-1 rounded-lg bg-surface-container text-on-surface font-label-sm text-label-sm font-semibold hover:bg-surface-container-high"><c:out value="${u.active ? 'Suspend' : 'Activate'}"/></button>
                </form>
                <form method="post" action="${ctx}/admin/users/reset-password" class="flex items-center gap-1 m-0">
                  <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
                  <input type="hidden" name="userId" value="${u.id}"/>
                  <input type="password" name="newPassword" minlength="8" required placeholder="New pass" class="w-28 px-2 py-1 rounded bg-surface-container-low border border-outline-variant/40 text-xs"/>
                  <button type="submit" class="px-2.5 py-1 rounded-lg bg-primary-container text-on-primary font-label-sm text-label-sm font-semibold">Reset</button>
                </form>
              </div>
            </td>
          </tr>
        </c:forEach>
      </tbody>
    </table>
  </div>
</section>

<script>
function ccRoleFields() {
  var r = document.getElementById('uRole').value;
  document.getElementById('cc-student-fields').classList.toggle('hidden', r !== 'STUDENT');
  document.getElementById('cc-faculty-fields').classList.toggle('hidden', r !== 'FACULTY');
}
</script>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

