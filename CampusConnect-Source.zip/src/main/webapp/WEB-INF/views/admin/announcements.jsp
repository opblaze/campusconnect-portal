<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Broadcast Announcements"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<div>
  <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface">Campus Announcements &amp; Broadcasts</h1>
  <p class="font-body-sm text-body-sm text-on-surface-variant">Publish official institutional notices across Campus Connect and push student alerts.</p>
</div>

<!-- Broadcast Form -->
<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-3">Publish Institutional Notice</h2>
  <form method="post" action="${ctx}/admin/announcements/post" class="flex flex-col gap-4">
    <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div class="flex flex-col gap-1">
        <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant">Target Scope</label>
        <select name="subjectId" class="px-3 py-2 rounded-lg bg-surface-container-low border border-outline-variant/40">
          <option value="">All Students (Campus-wide)</option>
          <c:forEach items="${data.subjectOptions}" var="so">
            <option value="${so.id}"><c:out value="${so.label}"/></option>
          </c:forEach>
        </select>
      </div>
      <div class="md:col-span-2 flex flex-col gap-1">
        <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant">Title</label>
        <input name="title" type="text" required maxlength="150" placeholder="e.g. Revised Mid-Semester Exam Fee Window" class="px-3 py-2 rounded-lg bg-surface-container-low border border-outline-variant/40"/>
      </div>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant">Announcement Body</label>
      <textarea name="body" rows="3" required maxlength="1500" placeholder="Enter official notice details..." class="px-3 py-2 rounded-lg bg-surface-container-low border border-outline-variant/40"></textarea>
    </div>
    <div class="flex flex-wrap items-center justify-between gap-3">
      <div class="flex flex-wrap gap-4">
        <label class="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" name="important" value="true" class="w-4 h-4 accent-primary"/>
          <span class="text-sm font-medium">Urgent / Important</span>
        </label>
        <label class="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" name="notifyStudents" value="true" checked class="w-4 h-4 accent-primary"/>
          <span class="text-sm font-medium">Send push notifications to students</span>
        </label>
      </div>
      <button type="submit" class="px-5 py-2.5 rounded-xl bg-primary-container text-on-primary font-label-md text-label-md font-semibold flex items-center gap-2"><span class="material-symbols-outlined text-lg">campaign</span>Broadcast Notice</button>
    </div>
  </form>
</section>

<!-- Existing Notices -->
<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-3">Published Notices</h2>
  <div class="flex flex-col gap-3">
    <c:forEach items="${data.notices}" var="n">
      <div class="p-space-md rounded-xl bg-surface-container-low flex flex-col sm:flex-row sm:items-start justify-between gap-3">
        <div>
          <div class="flex items-center gap-2 flex-wrap">
            <span class="px-2 py-0.5 rounded bg-primary-container/15 text-primary font-label-sm text-label-sm font-bold"><c:out value="${n.subjectCode}"/></span>
            <c:if test="${n.important}"><span class="px-2 py-0.5 rounded bg-error-container text-on-error-container font-label-sm text-label-sm font-bold">Important</span></c:if>
            <span class="font-label-sm text-label-sm text-on-surface-variant"><c:out value="${n.authorName}"/> &bull; <c:out value="${n.createdLabel}"/></span>
          </div>
          <h3 class="font-label-lg text-label-lg font-bold text-on-surface mt-1"><c:out value="${n.title}"/></h3>
          <p class="font-body-sm text-body-sm text-on-surface-variant mt-1"><c:out value="${n.body}"/></p>
        </div>
        <form method="post" action="${ctx}/admin/announcements/delete" class="m-0 shrink-0">
          <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
          <input type="hidden" name="announcementId" value="${n.id}"/>
          <button type="submit" class="px-3 py-1.5 rounded-lg bg-error-container text-on-error-container font-label-sm text-label-sm font-semibold">Delete</button>
        </form>
      </div>
    </c:forEach>
  </div>
</section>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

