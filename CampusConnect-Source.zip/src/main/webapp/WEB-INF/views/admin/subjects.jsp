<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Subject Catalog"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<div>
  <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface">Subject Catalog &amp; Allocation</h1>
  <p class="font-body-sm text-body-sm text-on-surface-variant">Register courses into semesters and assign or reassign teaching faculty.</p>
</div>

<!-- Create Subject -->
<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-3">Add New Subject</h2>
  <form method="post" action="${ctx}/admin/subjects/create" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 items-end">
    <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm text-on-surface-variant font-semibold">Course Code</label>
      <input name="code" type="text" required maxlength="20" placeholder="e.g. CS309" class="px-3 py-2 rounded-lg bg-surface-container-low border border-outline-variant/40"/>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm text-on-surface-variant font-semibold">Course Name</label>
      <input name="name" type="text" required maxlength="120" placeholder="e.g. Distributed Systems" class="px-3 py-2 rounded-lg bg-surface-container-low border border-outline-variant/40"/>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm text-on-surface-variant font-semibold">Short Name</label>
      <input name="shortName" type="text" required maxlength="20" placeholder="e.g. DSYS" class="px-3 py-2 rounded-lg bg-surface-container-low border border-outline-variant/40"/>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm text-on-surface-variant font-semibold">Assigned Faculty</label>
      <select name="facultyId" required class="px-3 py-2 rounded-lg bg-surface-container-low border border-outline-variant/40">
        <c:forEach items="${data.facultyOptions}" var="fo">
          <option value="${fo.id}"><c:out value="${fo.label}"/></option>
        </c:forEach>
      </select>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm text-on-surface-variant font-semibold">Credits</label>
      <input name="credits" type="number" min="1" max="8" value="4" class="px-3 py-2 rounded-lg bg-surface-container-low border border-outline-variant/40"/>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm text-on-surface-variant font-semibold">Category</label>
      <select name="category" class="px-3 py-2 rounded-lg bg-surface-container-low border border-outline-variant/40">
        <option value="CORE">CORE</option>
        <option value="LAB">LAB</option>
      </select>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm text-on-surface-variant font-semibold">Semester</label>
      <input name="semester" type="number" min="1" max="8" value="3" class="px-3 py-2 rounded-lg bg-surface-container-low border border-outline-variant/40"/>
    </div>
    <button type="submit" class="px-4 py-2.5 rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold">Add Subject</button>
  </form>
</section>

<!-- Subjects Table -->
<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <div class="flex flex-wrap items-center justify-between gap-2 mb-4">
    <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Curriculum Catalog</h2>
    <div class="flex flex-wrap gap-1.5">
      <a href="${ctx}/admin/subjects" class="px-3 py-1 rounded-lg font-label-sm text-label-sm font-semibold ${semFilter eq 0 ? 'bg-primary-container text-on-primary' : 'bg-surface-container text-on-surface-variant'}">All</a>
      <c:forEach begin="1" end="8" var="sm">
        <a href="${ctx}/admin/subjects?semester=${sm}" class="px-3 py-1 rounded-lg font-label-sm text-label-sm font-semibold ${semFilter eq sm ? 'bg-primary-container text-on-primary' : 'bg-surface-container text-on-surface-variant'}">Sem ${sm}</a>
      </c:forEach>
    </div>
  </div>
  <div class="overflow-x-auto">
    <table class="w-full text-left border-collapse">
      <thead>
        <tr class="border-b border-outline-variant/40 font-label-sm text-label-sm text-on-surface-variant uppercase">
          <th class="py-2.5 px-3">Subject</th>
          <th class="py-2.5 px-3">Sem / Type</th>
          <th class="py-2.5 px-3">Enrolled</th>
          <th class="py-2.5 px-3">Syllabus</th>
          <th class="py-2.5 px-3">Assigned Faculty</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-outline-variant/20 font-body-sm text-body-sm">
        <c:forEach items="${data.subjects}" var="s">
          <tr>
            <td class="py-2.5 px-3">
              <div class="font-bold text-primary"><c:out value="${s.code}"/> &bull; <c:out value="${s.shortName}"/></div>
              <div class="font-semibold text-on-surface"><c:out value="${s.name}"/></div>
            </td>
            <td class="py-2.5 px-3">Sem <c:out value="${s.semester}"/> &bull; <c:out value="${s.category}"/> (<c:out value="${s.credits}"/> cr)</td>
            <td class="py-2.5 px-3 font-mono font-semibold"><c:out value="${s.enrolledCount}"/></td>
            <td class="py-2.5 px-3 font-mono"><c:out value="${s.syllabusPct}"/>%</td>
            <td class="py-2.5 px-3">
              <form method="post" action="${ctx}/admin/subjects/assign-faculty" class="flex items-center gap-2 m-0">
                <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
                <input type="hidden" name="subjectId" value="${s.id}"/>
                <select name="facultyId" class="px-2.5 py-1.5 rounded-lg bg-surface-container-low border border-outline-variant/40 text-xs">
                  <c:forEach items="${data.facultyOptions}" var="fo">
                    <option value="${fo.id}" ${fo.id eq s.facultyId ? 'selected' : ''}><c:out value="${fo.label}"/></option>
                  </c:forEach>
                </select>
                <button type="submit" class="px-3 py-1.5 rounded-lg bg-surface-container text-primary font-label-sm text-label-sm font-semibold hover:bg-surface-container-high">Assign</button>
              </form>
            </td>
          </tr>
        </c:forEach>
      </tbody>
    </table>
  </div>
</section>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

