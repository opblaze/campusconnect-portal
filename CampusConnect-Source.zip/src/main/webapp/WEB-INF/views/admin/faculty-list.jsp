<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Faculty Directory"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<div class="flex flex-wrap items-center justify-between gap-2">
  <div>
    <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface">Faculty Directory</h1>
    <p class="font-body-sm text-body-sm text-on-surface-variant">Institutional teaching roster, departments, cabin assignments and course load.</p>
  </div>
  <a href="${ctx}/admin/users?role=FACULTY" class="px-4 py-2 rounded-xl bg-primary-container text-on-primary font-label-md text-label-md font-semibold">+ Add Faculty User</a>
</div>

<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <form method="get" action="${ctx}/admin/faculty" class="flex flex-wrap gap-3">
    <input type="text" name="q" value="<c:out value='${query}'/>" placeholder="Search by employee code, name, department..." class="flex-1 min-w-[220px] px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"/>
    <button type="submit" class="px-4 py-2 rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold">Search</button>
  </form>
</section>

<section class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-space-md">
  <c:forEach items="${facultyList}" var="f">
    <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] flex flex-col justify-between gap-3">
      <div>
        <div class="flex items-center justify-between gap-2">
          <span class="px-2.5 py-0.5 rounded bg-primary-container/15 text-primary font-mono font-bold text-xs"><c:out value="${f.employeeCode}"/></span>
          <span class="px-2 py-0.5 rounded font-label-sm text-label-sm font-bold ${f.active ? 'bg-secondary-container text-on-secondary-container' : 'bg-error-container text-on-error-container'}"><c:out value="${f.active ? 'ACTIVE' : 'SUSPENDED'}"/></span>
        </div>
        <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mt-2"><c:out value="${f.title}"/> <c:out value="${f.fullName}"/></h2>
        <p class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${f.designation}"/> &bull; <c:out value="${f.department}"/></p>
        <p class="font-body-sm text-body-sm text-on-surface-variant mt-1"><c:out value="${f.email}"/> &bull; Cabin: <strong class="text-on-surface"><c:out value="${f.cabin}"/></strong></p>
      </div>
      <div class="pt-3 border-t border-outline-variant/30 font-body-sm text-body-sm">
        <span class="text-on-surface-variant">Teaching (<c:out value="${f.subjectCount}"/>):</span>
        <strong class="text-on-surface"><c:out value="${f.subjectCodes}"/></strong>
      </div>
    </div>
  </c:forEach>
</section>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

