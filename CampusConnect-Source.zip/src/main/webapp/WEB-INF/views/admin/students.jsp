<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Student Directory"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<div>
  <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface">Student Directory &amp; Enrollments</h1>
  <p class="font-body-sm text-body-sm text-on-surface-variant">Inspect student standing, edit academic details, and manage subject enrollments.</p>
</div>

<!-- Filter Bar -->
<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <form method="get" action="${ctx}/admin/students" class="flex flex-wrap items-center gap-3">
    <select name="semester" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40">
      <option value="0" ${semFilter eq 0 ? 'selected' : ''}>All Semesters</option>
      <c:forEach begin="1" end="8" var="s">
        <option value="${s}" ${semFilter eq s ? 'selected' : ''}>Semester ${s}</option>
      </c:forEach>
    </select>
    <input type="text" name="q" value="<c:out value='${query}'/>" placeholder="Search by enrollment no, name, branch..." class="flex-1 min-w-[200px] px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"/>
    <button type="submit" class="px-4 py-2 rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold">Apply</button>
  </form>
</section>

<!-- Two-column Directory + Selected Student Inspector -->
<section class="grid grid-cols-1 xl:grid-cols-12 gap-space-lg">
  <div class="xl:col-span-7 bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] overflow-x-auto">
    <table class="w-full text-left border-collapse">
      <thead>
        <tr class="border-b border-outline-variant/40 font-label-sm text-label-sm text-on-surface-variant uppercase">
          <th class="py-2 px-2">Student</th>
          <th class="py-2 px-2">Branch / Sem</th>
          <th class="py-2 px-2">CGPA</th>
          <th class="py-2 px-2">Subjects</th>
          <th class="py-2 px-2">Attendance</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-outline-variant/20 font-body-sm text-body-sm">
        <c:forEach items="${data.students}" var="st">
          <tr class="${st.studentId eq data.selectedStudentId ? 'bg-primary-container/10' : 'hover:bg-surface-container-low/60'}">
            <td class="py-2.5 px-2">
              <a href="${ctx}/admin/students?id=${st.studentId}&semester=${semFilter}&q=<c:out value='${query}'/>" class="font-semibold text-primary hover:underline"><c:out value="${st.fullName}"/></a>
              <div class="text-xs font-mono text-on-surface-variant"><c:out value="${st.enrollmentNo}"/></div>
            </td>
            <td class="py-2.5 px-2"><c:out value="${st.branchCode}"/> &bull; Sem <c:out value="${st.semester}"/></td>
            <td class="py-2.5 px-2 font-mono font-bold"><c:out value="${st.cgpa}"/></td>
            <td class="py-2.5 px-2 font-mono"><c:out value="${st.enrolledCount}"/></td>
            <td class="py-2.5 px-2">
              <c:choose>
                <c:when test="${st.attendancePct < 0}"><span class="text-on-surface-variant">No data</span></c:when>
                <c:otherwise><span class="px-2 py-0.5 rounded font-label-sm text-label-sm font-bold ${st.attendanceTone eq 'RED' ? 'bg-error-container text-on-error-container' : (st.attendanceTone eq 'YELLOW' ? 'bg-amber-100 text-amber-800' : 'bg-secondary-container text-on-secondary-container')}"><c:out value="${st.attendancePct}"/>%</span></c:otherwise>
              </c:choose>
            </td>
          </tr>
        </c:forEach>
      </tbody>
    </table>
  </div>

  <div class="xl:col-span-5 flex flex-col gap-space-md">
    <c:choose>
      <c:when test="${empty data.selectedStudentId}">
        <div class="bg-surface-container-lowest rounded-2xl p-space-lg text-center text-on-surface-variant">Select a student from the table to edit details or manage enrollments.</div>
      </c:when>
      <c:otherwise>
        <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
          <div class="mb-3">
            <span class="font-mono font-bold text-primary text-xs"><c:out value="${data.selectedStudentEnroll}"/></span>
            <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface"><c:out value="${data.selectedStudentName}"/></h2>
          </div>
          <form method="post" action="${ctx}/admin/students/update" class="grid grid-cols-2 gap-3">
            <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
            <input type="hidden" name="studentId" value="${data.selectedStudentId}"/>
            <div class="flex flex-col gap-1">
              <label class="font-label-sm text-label-sm text-on-surface-variant">Semester</label>
              <input name="semester" type="number" min="1" max="8" value="${data.selectedSemester}" class="px-3 py-1.5 rounded-lg bg-surface-container-low border border-outline-variant/40"/>
            </div>
            <div class="flex flex-col gap-1">
              <label class="font-label-sm text-label-sm text-on-surface-variant">CGPA</label>
              <input name="cgpa" type="number" step="0.01" min="0" max="10" value="<c:out value='${data.selectedCgpa}'/>" class="px-3 py-1.5 rounded-lg bg-surface-container-low border border-outline-variant/40"/>
            </div>
            <div class="flex flex-col gap-1">
              <label class="font-label-sm text-label-sm text-on-surface-variant">Branch Code</label>
              <input name="branchCode" type="text" maxlength="20" value="<c:out value='${data.selectedBranchCode}'/>" class="px-3 py-1.5 rounded-lg bg-surface-container-low border border-outline-variant/40"/>
            </div>
            <div class="flex flex-col gap-1">
              <label class="font-label-sm text-label-sm text-on-surface-variant">Phone</label>
              <input name="phone" type="text" maxlength="20" value="<c:out value='${data.selectedPhone}'/>" class="px-3 py-1.5 rounded-lg bg-surface-container-low border border-outline-variant/40"/>
            </div>
            <div class="col-span-2 flex items-center gap-3">
              <label class="flex items-center gap-2"><input type="checkbox" name="hosteler" value="true" ${data.selectedHosteler ? 'checked' : ''} class="accent-primary"/> <span class="text-sm">Hosteler</span></label>
              <input name="hostelName" type="text" maxlength="80" value="<c:out value='${data.selectedHostelName}'/>" placeholder="Hostel Name" class="flex-1 px-3 py-1.5 rounded-lg bg-surface-container-low border border-outline-variant/40 text-sm"/>
            </div>
            <button type="submit" class="col-span-2 px-4 py-2 rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold">Save Academic Profile</button>
          </form>
        </div>

        <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] flex flex-col gap-3">
          <h3 class="font-headline-sm text-headline-sm font-bold text-on-surface">Subject Enrollments</h3>
          <form method="post" action="${ctx}/admin/students/enroll" class="flex gap-2">
            <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
            <input type="hidden" name="studentId" value="${data.selectedStudentId}"/>
            <select name="subjectId" class="flex-1 px-2.5 py-1.5 rounded-lg bg-surface-container-low border border-outline-variant/40 text-sm">
              <c:forEach items="${data.allSubjects}" var="sub">
                <option value="${sub.id}"><c:out value="${sub.label}"/></option>
              </c:forEach>
            </select>
            <button type="submit" class="px-3 py-1.5 rounded-lg bg-primary-container text-on-primary font-label-sm text-label-sm font-semibold">Enroll</button>
          </form>
          <div class="flex flex-col gap-1.5">
            <c:forEach items="${data.enrolledSubjects}" var="es">
              <div class="p-2 rounded-lg bg-surface-container-low flex items-center justify-between gap-2 text-sm">
                <span class="truncate"><c:out value="${es.label}"/></span>
                <form method="post" action="${ctx}/admin/students/unenroll" class="m-0">
                  <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
                  <input type="hidden" name="studentId" value="${data.selectedStudentId}"/>
                  <input type="hidden" name="subjectId" value="${es.id}"/>
                  <button type="submit" class="px-2 py-0.5 rounded bg-error-container text-on-error-container font-label-sm text-label-sm font-semibold">Drop</button>
                </form>
              </div>
            </c:forEach>
          </div>
        </div>
      </c:otherwise>
    </c:choose>
  </div>
</section>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

