<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Fee Management"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<div>
  <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface">Fee Ledger &amp; Collections</h1>
  <p class="font-body-sm text-body-sm text-on-surface-variant">Issue student fee demands, track collections and record counter payments.</p>
</div>

<!-- KPI Summary -->
<section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-space-md">
  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <div class="font-label-sm text-label-sm text-on-surface-variant font-semibold">Total Billed</div>
    <div class="font-headline-lg text-headline-lg font-bold text-on-surface mt-1"><c:out value="${data.totalBilledLabel}"/></div>
    <div class="font-body-sm text-body-sm text-on-surface-variant mt-1"><c:out value="${data.collectionPct}"/>% collected</div>
  </div>
  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <div class="font-label-sm text-label-sm text-on-surface-variant font-semibold">Collected Revenue</div>
    <div class="font-headline-lg text-headline-lg font-bold text-secondary mt-1"><c:out value="${data.collectedLabel}"/></div>
  </div>
  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <div class="font-label-sm text-label-sm text-on-surface-variant font-semibold">Pending Dues (<c:out value="${data.unpaidCount}"/>)</div>
    <div class="font-headline-lg text-headline-lg font-bold text-on-surface mt-1"><c:out value="${data.pendingLabel}"/></div>
  </div>
  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <div class="font-label-sm text-label-sm text-on-surface-variant font-semibold">Overdue Dues (<c:out value="${data.overdueCount}"/>)</div>
    <div class="font-headline-lg text-headline-lg font-bold text-error mt-1"><c:out value="${data.overdueLabel}"/></div>
  </div>
</section>

<!-- Issue Fee Demand -->
<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-3">Create Fee Demand</h2>
  <form method="post" action="${ctx}/admin/fees/create" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3 items-end">
    <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm text-on-surface-variant font-semibold">Student</label>
      <select name="studentId" required class="px-3 py-2 rounded-lg bg-surface-container-low border border-outline-variant/40">
        <c:forEach items="${data.studentOptions}" var="st">
          <option value="${st.id}"><c:out value="${st.label}"/></option>
        </c:forEach>
      </select>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm text-on-surface-variant font-semibold">Fee Title</label>
      <input name="title" type="text" required maxlength="150" placeholder="e.g. Semester 4 Tuition" class="px-3 py-2 rounded-lg bg-surface-container-low border border-outline-variant/40"/>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm text-on-surface-variant font-semibold">Category</label>
      <select name="category" class="px-3 py-2 rounded-lg bg-surface-container-low border border-outline-variant/40">
        <option value="TUITION">TUITION</option>
        <option value="HOSTEL">HOSTEL</option>
        <option value="EXAM">EXAM</option>
        <option value="PRC">PRC</option>
      </select>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm text-on-surface-variant font-semibold">Amount (&#8377;)</label>
      <input name="amount" type="number" min="1" step="1" required placeholder="45000" class="px-3 py-2 rounded-lg bg-surface-container-low border border-outline-variant/40"/>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm text-on-surface-variant font-semibold">Due Date</label>
      <div class="flex gap-2">
        <input name="dueDate" type="date" required class="flex-1 px-3 py-2 rounded-lg bg-surface-container-low border border-outline-variant/40"/>
        <button type="submit" class="px-4 py-2 rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold shrink-0">Issue</button>
      </div>
    </div>
  </form>
</section>

<!-- Filter + Ledger Table -->
<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <form method="get" action="${ctx}/admin/fees" class="flex flex-wrap items-center justify-between gap-3 mb-4">
    <div class="flex flex-wrap gap-1.5">
      <c:forTokens items="ALL,PAID,PENDING,OVERDUE" delims="," var="sf">
        <a href="${ctx}/admin/fees?status=${sf}&category=${catFilter}&q=<c:out value='${query}'/>" class="px-3 py-1 rounded-lg font-label-sm text-label-sm font-semibold ${statusFilter eq sf ? 'bg-primary-container text-on-primary' : 'bg-surface-container text-on-surface-variant'}"><c:out value="${sf}"/></a>
      </c:forTokens>
    </div>
    <div class="flex gap-2">
      <input type="hidden" name="status" value="<c:out value='${statusFilter}'/>"/>
      <select name="category" class="px-2.5 py-1.5 rounded-lg bg-surface-container-low border border-outline-variant/40 text-sm">
        <option value="ALL" ${catFilter eq 'ALL' ? 'selected' : ''}>All Categories</option>
        <option value="TUITION" ${catFilter eq 'TUITION' ? 'selected' : ''}>TUITION</option>
        <option value="HOSTEL" ${catFilter eq 'HOSTEL' ? 'selected' : ''}>HOSTEL</option>
        <option value="EXAM" ${catFilter eq 'EXAM' ? 'selected' : ''}>EXAM</option>
        <option value="PRC" ${catFilter eq 'PRC' ? 'selected' : ''}>PRC</option>
      </select>
      <input type="text" name="q" value="<c:out value='${query}'/>" placeholder="Search enrollment, receipt..." class="px-3 py-1.5 rounded-lg bg-surface-container-low border border-outline-variant/40 text-sm"/>
      <button type="submit" class="px-3 py-1.5 rounded-lg bg-primary-container text-on-primary font-label-sm text-label-sm font-semibold">Filter</button>
    </div>
  </form>

  <div class="overflow-x-auto">
    <table class="w-full text-left border-collapse">
      <thead>
        <tr class="border-b border-outline-variant/40 font-label-sm text-label-sm text-on-surface-variant uppercase">
          <th class="py-2.5 px-3">Student</th>
          <th class="py-2.5 px-3">Fee Head</th>
          <th class="py-2.5 px-3">Amount</th>
          <th class="py-2.5 px-3">Due / Paid On</th>
          <th class="py-2.5 px-3">Status</th>
          <th class="py-2.5 px-3">Action / Receipt</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-outline-variant/20 font-body-sm text-body-sm">
        <c:forEach items="${data.fees}" var="f">
          <tr>
            <td class="py-2.5 px-3">
              <div class="font-semibold text-on-surface"><c:out value="${f.studentName}"/></div>
              <div class="text-xs font-mono text-on-surface-variant"><c:out value="${f.enrollmentNo}"/> &bull; <c:out value="${f.branchSem}"/></div>
            </td>
            <td class="py-2.5 px-3">
              <div class="font-semibold text-on-surface"><c:out value="${f.title}"/></div>
              <div class="text-xs text-on-surface-variant"><c:out value="${f.category}"/></div>
            </td>
            <td class="py-2.5 px-3 font-mono font-bold text-on-surface"><c:out value="${f.amountLabel}"/></td>
            <td class="py-2.5 px-3 text-on-surface-variant">
              <div>Due: <c:out value="${f.dueDateLabel}"/></div>
              <c:if test="${f.paid}"><div class="text-xs">Paid: <c:out value="${f.paidOnLabel}"/></div></c:if>
            </td>
            <td class="py-2.5 px-3">
              <span class="px-2 py-0.5 rounded font-label-sm text-label-sm font-bold ${f.tone eq 'GREEN' ? 'bg-secondary-container text-on-secondary-container' : (f.tone eq 'RED' ? 'bg-error-container text-on-error-container' : 'bg-amber-100 text-amber-800')}"><c:out value="${f.status}"/></span>
            </td>
            <td class="py-2.5 px-3">
              <c:choose>
                <c:when test="${f.paid}">
                  <div class="font-mono text-xs text-on-surface"><c:out value="${f.receiptNo}"/></div>
                  <div class="text-xs text-on-surface-variant"><c:out value="${f.paymentMethod}"/></div>
                </c:when>
                <c:otherwise>
                  <form method="post" action="${ctx}/admin/fees/mark-paid" class="flex items-center gap-1.5 m-0">
                    <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
                    <input type="hidden" name="feeId" value="${f.id}"/>
                    <select name="paymentMethod" class="px-2 py-1 rounded bg-surface-container-low border border-outline-variant/40 text-xs">
                      <option value="Admin Counter">Counter</option>
                      <option value="UPI">UPI</option>
                      <option value="NEFT">NEFT</option>
                      <option value="Card">Card</option>
                    </select>
                    <button type="submit" class="px-2.5 py-1 rounded-lg bg-secondary-container text-on-secondary-container font-label-sm text-label-sm font-bold">Mark Paid</button>
                  </form>
                </c:otherwise>
              </c:choose>
            </td>
          </tr>
        </c:forEach>
      </tbody>
    </table>
  </div>
</section>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

