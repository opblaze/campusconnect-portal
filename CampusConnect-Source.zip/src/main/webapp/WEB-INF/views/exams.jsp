<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm"><div class="flex items-center gap-space-sm"><span class="p-2 rounded-lg bg-primary-container text-on-primary flex"><span class="material-symbols-outlined">grade</span></span><div><h1 class="font-headline-lg text-headline-lg text-on-surface font-bold">Exams &amp; Results</h1><p class="font-body-sm text-body-sm text-on-surface-variant">CGPA <c:out value="${d.cgpa}"/> &bull; previous SGPA <c:out value="${d.previousSgpa}"/> &bull; backlogs: <c:out value="${d.backlogs}"/></p></div></div></div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-space-md">
<div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm lg:col-span-2"><h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-space-sm">Published results</h2>
<c:if test="${empty marks}"><p class="text-on-surface-variant">No results published yet.</p></c:if>
<div class="flex flex-col gap-space-sm"><c:forEach var="m" items="${marks}"><div class="p-space-sm rounded-lg bg-surface-container-low"><div class="flex justify-between flex-wrap gap-1"><span class="font-semibold text-on-surface"><c:out value="${m.subject}"/> <span class="text-on-surface-variant">(<c:out value="${m.type}"/>)</span></span><span class="font-bold"><c:out value="${m.obtained}"/> / <c:out value="${m.maximum}"/> &bull; <c:out value="${m.pct}"/>%</span></div>
<div class="w-full h-2 rounded-full bg-surface-container-high overflow-hidden mt-1"><div class="h-full rounded-full ${m.bar}" style="width:${m.pct}%"></div></div></div></c:forEach></div></div>
<div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm" id="exam-schedule"><h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-space-sm">Exam date sheet</h2>
<c:if test="${empty exams}"><p class="text-on-surface-variant">No upcoming exams.</p></c:if>
<div class="flex flex-col gap-space-sm"><c:forEach var="x" items="${exams}"><div class="p-space-sm rounded-lg bg-surface-container-low"><div class="font-semibold text-on-surface"><c:out value="${x.subject}"/></div><div class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${x.exam}"/><br/><c:out value="${x.date}"/> &bull; <c:out value="${x.time}"/></div></div></c:forEach></div></div>
</div>
<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>
