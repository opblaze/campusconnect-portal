<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Receipt <c:out value="${r.receipt}"/> - Campus Connect</title>
<%@ include file="/WEB-INF/jspf/head.jspf" %>
</head>
<body class="bg-surface text-on-surface font-body-md text-body-md antialiased">
<main class="min-h-screen flex items-start justify-center p-space-lg">
  <div class="w-[min(96vw,640px)]">
    <div class="print:hidden flex justify-between mb-space-sm">
      <a href="${ctx}/app/fees" class="px-space-md py-1.5 rounded-lg bg-surface-container text-primary font-label-md text-label-md font-semibold">&larr; Back to fees</a>
      <button type="button" onclick="window.print()" class="px-space-md py-1.5 rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold flex items-center gap-1"><span class="material-symbols-outlined text-base">print</span>Print / Save as PDF</button>
    </div>
    <div class="bg-surface-container-lowest rounded-2xl shadow-sm print:shadow-none overflow-hidden">
      <div class="p-space-lg bg-gradient-to-r from-primary-container to-primary text-on-primary print:bg-none print:text-black flex items-center justify-between">
        <div><div class="font-headline-md text-headline-md font-bold">Marwadi University</div><div class="font-body-sm text-body-sm opacity-90">Campus Connect - Fee Receipt (Demo)</div></div>
        <span class="px-2 py-0.5 rounded bg-emerald-500 text-white font-label-sm text-label-sm font-bold">PAID</span>
      </div>
      <div class="p-space-lg flex flex-col gap-space-sm">
        <div class="flex justify-between"><span class="text-on-surface-variant">Receipt no.</span><b id="rc-no"><c:out value="${r.receipt}"/></b></div>
        <div class="flex justify-between"><span class="text-on-surface-variant">Date</span><b><c:out value="${r.paidOn}"/></b></div>
        <hr class="border-outline-variant/40">
        <div class="flex justify-between"><span class="text-on-surface-variant">Student</span><b><c:out value="${r.name}"/></b></div>
        <div class="flex justify-between"><span class="text-on-surface-variant">Enrollment no.</span><b><c:out value="${r.enrollment}"/></b></div>
        <div class="flex justify-between gap-4"><span class="text-on-surface-variant">Programme</span><b class="text-right"><c:out value="${r.program}"/></b></div>
        <div class="flex justify-between"><span class="text-on-surface-variant">Term</span><b><c:out value="${r.semester}"/></b></div>
        <hr class="border-outline-variant/40">
        <div class="flex justify-between gap-4"><span class="text-on-surface-variant">Fee</span><b class="text-right"><c:out value="${r.title}"/></b></div>
        <div class="flex justify-between"><span class="text-on-surface-variant">Category</span><b><c:out value="${r.categoryLabel}"/></b></div>
        <div class="flex justify-between"><span class="text-on-surface-variant">Payment method</span><b><c:out value="${r.method}"/></b></div>
        <div class="flex justify-between items-center pt-space-sm"><span class="font-headline-sm text-headline-sm">Amount paid</span><span class="font-display-lg text-display-lg font-bold text-primary print:text-black">&#8377; <c:out value="${r.amount}"/></span></div>
      </div>
      <div class="px-space-lg py-space-sm bg-surface-container-low text-on-surface-variant font-label-sm text-label-sm">This is a computer-generated demo receipt for a project; no real payment was made.</div>
    </div>
  </div>
</main>
</body>
</html>
