<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm"><div class="flex items-center gap-space-sm"><span class="p-2 rounded-lg bg-primary-container text-on-primary flex"><span class="material-symbols-outlined">support_agent</span></span><div><h1 class="font-headline-lg text-headline-lg text-on-surface font-bold">Campus Helpdesk</h1><p class="font-body-sm text-body-sm text-on-surface-variant">Ask a question - it is filtered and sent to the right office</p></div></div></div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-space-md">
<div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm lg:col-span-2"><h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-space-sm">Send a query</h2>
<form method="post" action="${ctx}/app/helpdesk" class="flex flex-col gap-space-sm" onsubmit="if(this.message.value.trim().length<8){alert('Please describe your query (at least 8 characters).');return false;}">
<input type="hidden" name="csrf" value="<c:out value='${csrf}'/>">
<textarea name="message" rows="5" maxlength="1500" required placeholder="Describe your problem or suggestion..." class="w-full p-space-sm rounded-lg bg-surface-container-low text-on-surface font-body-md text-body-md outline-none focus:ring-2 focus:ring-primary-container/30"></textarea>
<button class="self-start px-space-lg py-space-sm rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold" type="submit">Send to Helpdesk</button></form></div>
<div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm flex flex-col gap-space-sm"><h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Contacts</h2>
<div class="font-body-md text-body-md text-on-surface">Helpdesk: ext. 4402<br/>Accounts: ext. 4410<br/>Exam cell: ext. 4425<br/><span class="text-on-surface-variant font-body-sm">Mon-Sat, 9:00 AM - 5:00 PM</span></div>
<p class="font-body-sm text-body-sm text-on-surface-variant">Tip: the <b>Ask AI</b> button answers questions about your own attendance, marks and deadlines instantly.</p></div></div>
<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>
