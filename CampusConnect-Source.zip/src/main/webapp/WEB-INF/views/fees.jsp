<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm">
  <div class="flex items-center gap-space-sm">
    <span class="p-2 rounded-lg bg-primary-container text-on-primary flex"><span class="material-symbols-outlined">receipt_long</span></span>
    <div><h1 class="font-headline-lg text-headline-lg text-on-surface font-bold">Fees &amp; Dues</h1>
    <p class="font-body-sm text-body-sm text-on-surface-variant">Pay online (demo) and download your receipts</p></div>
  </div>
  <c:choose>
    <c:when test="${d.hosteler}"><span class="px-space-md py-1 rounded-lg bg-secondary-container text-on-secondary-container font-label-md text-label-md font-semibold flex items-center gap-1"><span class="material-symbols-outlined text-base">apartment</span>Hosteler &bull; <c:out value="${d.hostelName}"/></span></c:when>
    <c:otherwise><span class="px-space-md py-1 rounded-lg bg-surface-container text-on-surface-variant font-label-md text-label-md font-semibold flex items-center gap-1"><span class="material-symbols-outlined text-base">home</span>Not a hosteler - hostel fees do not apply</span></c:otherwise>
  </c:choose>
</div>

<%-- summary cards --%>
<div class="grid grid-cols-2 lg:grid-cols-5 gap-space-md">
  <div class="bg-surface-container-lowest rounded-xl p-space-md shadow-sm"><div class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Total payable</div><div class="font-headline-md text-headline-md font-bold text-on-surface">&#8377; <c:out value="${sum.totalDue}"/></div></div>
  <div class="bg-surface-container-lowest rounded-xl p-space-md shadow-sm"><div class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Paid so far</div><div class="font-headline-md text-headline-md font-bold text-secondary">&#8377; <c:out value="${sum.totalPaid}"/></div></div>
  <div class="bg-surface-container-lowest rounded-xl p-space-md shadow-sm ${sum.overdueCount > 0 ? 'ring-1 ring-red-400' : ''}"><div class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Overdue</div><div class="font-headline-md text-headline-md font-bold ${sum.overdueCount > 0 ? 'text-red-600 dark:text-red-300' : 'text-on-surface'}"><c:out value="${sum.overdueCount}"/></div></div>
  <div class="bg-surface-container-lowest rounded-xl p-space-md shadow-sm"><div class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Due soon</div><div class="font-headline-md text-headline-md font-bold text-amber-600 dark:text-amber-300"><c:out value="${sum.dueCount}"/></div></div>
  <div class="bg-surface-container-lowest rounded-xl p-space-md shadow-sm"><div class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Pending (upcoming)</div><div class="font-headline-md text-headline-md font-bold text-blue-600 dark:text-blue-300"><c:out value="${sum.pendingCount}"/></div></div>
</div>

<%-- category filter --%>
<div class="flex flex-wrap items-center gap-space-xs" id="fee-filter">
  <button type="button" data-cat="ALL" class="px-space-md py-1 rounded-full font-label-md text-label-md font-semibold bg-primary-container text-on-primary">All</button>
  <button type="button" data-cat="TUITION" class="px-space-md py-1 rounded-full font-label-md text-label-md font-semibold bg-surface-container text-on-surface-variant">Tuition</button>
  <c:if test="${d.hosteler}"><button type="button" data-cat="HOSTEL" class="px-space-md py-1 rounded-full font-label-md text-label-md font-semibold bg-surface-container text-on-surface-variant">Hostel Fees</button></c:if>
  <button type="button" data-cat="EXAM" class="px-space-md py-1 rounded-full font-label-md text-label-md font-semibold bg-surface-container text-on-surface-variant">Exam Fees</button>
  <button type="button" data-cat="PRC" class="px-space-md py-1 rounded-full font-label-md text-label-md font-semibold bg-surface-container text-on-surface-variant" title="Professional Regularity Charges">PRC</button>
</div>

<div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm flex flex-col gap-space-sm" id="fee-list">
  <c:if test="${empty rows}"><p class="text-on-surface-variant">No fee records.</p></c:if>
  <c:forEach var="f" items="${rows}">
    <div data-category="<c:out value='${f.category}'/>" data-state="${f.state}" class="fee-row p-space-md rounded-xl bg-surface-container-low flex flex-col md:flex-row md:items-center justify-between gap-space-sm ${f.state eq 'OVERDUE' ? 'ring-1 ring-red-400' : ''}">
      <div class="min-w-0">
        <div class="flex items-center gap-space-xs flex-wrap">
          <span class="px-space-sm py-0.5 rounded bg-surface-container-high text-primary font-label-sm text-label-sm font-bold"><c:out value="${f.categoryLabel}"/></span>
          <span class="px-space-sm py-0.5 rounded font-label-sm text-label-sm font-bold ${f.state eq 'PAID' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200' : (f.state eq 'OVERDUE' ? 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-200' : (f.state eq 'DUE' ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200' : 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-200'))}"><c:out value="${f.state}"/></span>
        </div>
        <div class="font-label-lg text-label-lg font-semibold text-on-surface mt-1"><c:out value="${f.title}"/></div>
        <div class="font-body-sm text-body-sm text-on-surface-variant">
          <c:choose>
            <c:when test="${f.state eq 'PAID'}">Paid on <c:out value="${f.paidOn}"/> &bull; <c:out value="${f.method}"/> &bull; Receipt <c:out value="${f.receipt}"/></c:when>
            <c:otherwise>Due <c:out value="${f.due}"/></c:otherwise>
          </c:choose>
        </div>
      </div>
      <div class="flex items-center gap-space-md">
        <span class="font-headline-sm text-headline-sm font-bold text-on-surface">&#8377; <c:out value="${f.amount}"/></span>
        <c:choose>
          <c:when test="${f.canPay}"><button type="button" data-pay-fee="${f.id}" data-title="<c:out value='${f.title}'/>" data-category="<c:out value='${f.categoryLabel}'/>" data-amount="<c:out value='${f.amount}'/>" class="px-space-md py-1.5 rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold flex items-center gap-1"><span class="material-symbols-outlined text-base">payments</span>Pay Now</button></c:when>
          <c:otherwise><a href="${ctx}/app/receipt?id=${f.id}" target="_blank" rel="noopener" class="px-space-md py-1.5 rounded-lg bg-surface-container text-primary font-label-md text-label-md font-semibold flex items-center gap-1"><span class="material-symbols-outlined text-base">receipt_long</span>Receipt</a></c:otherwise>
        </c:choose>
      </div>
    </div>
  </c:forEach>
  <p class="font-body-sm text-body-sm text-on-surface-variant">Status guide: <b>PAID</b> settled &bull; <b>DUE</b> due within 15 days &bull; <b>PENDING</b> not yet due &bull; <b>OVERDUE</b> deadline passed.
  PRC = Professional Regularity Charges. Payments use a demo gateway - a live deployment connects Razorpay / PayU.</p>
</div>
<script>
(function () {
  var box = document.getElementById('fee-filter');
  var on = 'px-space-md py-1 rounded-full font-label-md text-label-md font-semibold bg-primary-container text-on-primary';
  var off = 'px-space-md py-1 rounded-full font-label-md text-label-md font-semibold bg-surface-container text-on-surface-variant';
  box.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-cat]'); if (!b) { return; }
    box.querySelectorAll('button').forEach(function (x) { x.className = x === b ? on : off; });
    var cat = b.getAttribute('data-cat');
    document.querySelectorAll('#fee-list .fee-row').forEach(function (r) { r.style.display = (cat === 'ALL' || r.getAttribute('data-category') === cat) ? '' : 'none'; });
  });
})();
</script>
<%@ include file="/WEB-INF/jspf/pay-modal.jspf" %>
<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>
