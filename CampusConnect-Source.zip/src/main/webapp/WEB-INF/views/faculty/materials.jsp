<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="E-Content Library"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<div>
  <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface">E-Content Materials</h1>
  <p class="font-body-sm text-body-sm text-on-surface-variant">Upload lecture notes, slide decks, code samples and lab packs. Enrolled students receive instant notifications.</p>
</div>

<!-- Upload Material Form -->
<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-3">Upload New Study Material</h2>
  <form method="post" action="${ctx}/faculty/materials/upload" enctype="multipart/form-data" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
    <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="matSub">Subject</label>
      <select id="matSub" name="subjectId" required class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40">
        <c:forEach items="${data.subjects}" var="s">
          <option value="${s.id}"><c:out value="${s.code}"/> &mdash; <c:out value="${s.shortName}"/></option>
        </c:forEach>
      </select>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="matTitle">Title</label>
      <input id="matTitle" name="title" type="text" required maxlength="150" placeholder="e.g. Unit 3: Synchronization Notes" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"/>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="matType">Format</label>
      <select id="matType" name="fileType" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40">
        <option value="PDF">PDF Document</option>
        <option value="SLIDES">Slide Deck</option>
        <option value="CODE">Source Code / Text</option>
        <option value="ZIP">ZIP Archive</option>
      </select>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="matFile">File (optional, max 15 MB)</label>
      <input id="matFile" name="file" type="file" class="px-2 py-1.5 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40 text-sm"/>
    </div>
    <div class="md:col-span-3 flex flex-col gap-1">
      <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="matPath">Reference Label / Notes Path (if no file attached)</label>
      <input id="matPath" name="manualPath" type="text" maxlength="250" placeholder="Optional path or resource label" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"/>
    </div>
    <button type="submit" class="px-4 py-2.5 rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold flex items-center justify-center gap-2"><span class="material-symbols-outlined text-lg">upload</span>Publish Material</button>
  </form>
</section>

<!-- Materials Table -->
<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <div class="flex flex-wrap items-center justify-between gap-2 mb-4">
    <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Published Materials</h2>
    <div class="flex flex-wrap gap-1.5">
      <a href="${ctx}/faculty/materials" class="px-3 py-1 rounded-lg font-label-sm text-label-sm font-semibold ${empty filterSubjectId ? 'bg-primary-container text-on-primary' : 'bg-surface-container text-on-surface-variant'}">All</a>
      <c:forEach items="${data.subjects}" var="s">
        <a href="${ctx}/faculty/materials?subjectId=${s.id}" class="px-3 py-1 rounded-lg font-label-sm text-label-sm font-semibold ${filterSubjectId eq s.id ? 'bg-primary-container text-on-primary' : 'bg-surface-container text-on-surface-variant'}"><c:out value="${s.shortName}"/></a>
      </c:forEach>
    </div>
  </div>
  <c:choose>
    <c:when test="${empty data.materials}">
      <p class="font-body-sm text-body-sm text-on-surface-variant py-6 text-center">No materials found.</p>
    </c:when>
    <c:otherwise>
      <div class="flex flex-col gap-2">
        <c:forEach items="${data.materials}" var="m">
          <div class="p-space-sm rounded-xl bg-surface-container-low flex flex-wrap items-center justify-between gap-3">
            <div class="flex items-center gap-3 min-w-0">
              <span class="w-10 h-10 rounded-xl bg-primary-container/15 text-primary flex items-center justify-center shrink-0"><span class="material-symbols-outlined"><c:out value="${m.icon}"/></span></span>
              <div class="min-w-0">
                <div class="font-label-lg text-label-lg font-bold text-on-surface truncate"><c:out value="${m.title}"/></div>
                <div class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${m.subjectCode}"/> (<c:out value="${m.subjectName}"/>) &bull; <c:out value="${m.fileType}"/> &bull; <c:out value="${m.sizeLabel}"/> &bull; <c:out value="${m.uploadedLabel}"/></div>
              </div>
            </div>
            <div class="flex items-center gap-2 shrink-0">
              <button type="button" data-preview-id="${m.id}" data-preview-src="material" class="px-3 py-1.5 rounded-lg bg-surface-container text-primary font-label-sm text-label-sm font-semibold flex items-center gap-1 hover:bg-surface-container-high"><span class="material-symbols-outlined text-base">visibility</span>Preview</button>
              <a href="${ctx}/faculty/download?id=${m.id}" class="px-3 py-1.5 rounded-lg bg-surface-container text-on-surface font-label-sm text-label-sm font-semibold flex items-center gap-1 hover:bg-surface-container-high"><span class="material-symbols-outlined text-base">download</span>Download</a>
              <form method="post" action="${ctx}/faculty/materials/delete" class="m-0">
                <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
                <input type="hidden" name="materialId" value="${m.id}"/>
                <button type="submit" class="px-2.5 py-1.5 rounded-lg bg-error-container text-on-error-container font-label-sm text-label-sm font-semibold">Delete</button>
              </form>
            </div>
          </div>
        </c:forEach>
      </div>
    </c:otherwise>
  </c:choose>
</section>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

