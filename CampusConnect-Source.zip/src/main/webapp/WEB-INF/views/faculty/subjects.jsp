<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="My Subjects &amp; Rosters"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
  <div>
    <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface">My Teaching Subjects</h1>
    <p class="font-body-sm text-body-sm text-on-surface-variant">Track syllabus coverage, lecture schedule days and student rosters.</p>
  </div>
</div>

<!-- Subject Cards -->
<section class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-space-md">
  <c:forEach items="${data.subjects}" var="s">
    <a href="${ctx}/faculty/my-subjects?subjectId=${s.id}" class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] border-2 transition ${s.id eq data.selectedSubjectId ? 'border-primary' : 'border-transparent hover:border-outline-variant/50'}">
      <div class="flex items-center justify-between">
        <span class="px-2.5 py-0.5 rounded-md bg-primary-container/15 text-primary font-label-sm text-label-sm font-bold"><c:out value="${s.code}"/></span>
        <span class="font-label-sm text-label-sm text-on-surface-variant"><c:out value="${s.category}"/> &bull; Sem <c:out value="${s.semester}"/></span>
      </div>
      <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mt-2"><c:out value="${s.name}"/></h2>
      <p class="font-body-sm text-body-sm text-on-surface-variant mt-1"><c:out value="${s.enrolledCount}"/> enrolled &bull; <c:out value="${s.credits}"/> credits &bull; <c:out value="${s.meetingDays}"/></p>
      <div class="mt-3">
        <div class="flex justify-between font-label-sm text-label-sm mb-1">
          <span class="text-on-surface-variant">Syllabus</span>
          <span class="font-bold text-on-surface"><c:out value="${s.syllabusPct}"/>%</span>
        </div>
        <div class="w-full h-2 bg-surface-container rounded-full overflow-hidden">
          <div class="h-full bg-primary-container rounded-full" style="width:${s.syllabusPct}%"></div>
        </div>
      </div>
    </a>
  </c:forEach>
</section>

<c:if test="${not empty data.selectedSubjectId}">
  <!-- Syllabus Update Form -->
  <section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-3">Update Syllabus Progress &mdash; <c:out value="${data.selectedSubjectCode}"/> (<c:out value="${data.selectedSubjectName}"/>)</h2>
    <form method="post" action="${ctx}/faculty/subjects/syllabus" class="flex flex-wrap items-end gap-4">
      <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
      <input type="hidden" name="subjectId" value="${data.selectedSubjectId}"/>
      <div class="flex flex-col gap-1">
        <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="syllabusPct">Completion (%)</label>
        <input id="syllabusPct" name="syllabusPct" type="number" min="0" max="100" value="${data.selectedSyllabusPct}" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40 w-32"/>
      </div>
      <div class="flex flex-col gap-1">
        <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="meetingDays">Meeting Days (e.g. MO,WE,FR)</label>
        <input id="meetingDays" name="meetingDays" type="text" maxlength="40" value="<c:out value='${data.selectedMeetingDays}'/>" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40 w-56"/>
      </div>
      <button type="submit" class="px-4 py-2 rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold">Save Changes</button>
    </form>
  </section>

  <!-- Enrolled Roster -->
  <section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <div class="flex items-center justify-between mb-3">
      <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Enrolled Student Roster</h2>
      <div class="flex gap-2">
        <a href="${ctx}/faculty/attendance?subjectId=${data.selectedSubjectId}" class="px-3 py-1.5 rounded-lg bg-primary-container text-on-primary font-label-sm text-label-sm font-semibold">Mark Attendance</a>
        <a href="${ctx}/faculty/marks?subjectId=${data.selectedSubjectId}" class="px-3 py-1.5 rounded-lg bg-surface-container text-on-surface font-label-sm text-label-sm font-semibold">Enter Marks</a>
      </div>
    </div>
    <div class="overflow-x-auto">
      <table class="w-full text-left border-collapse">
        <thead>
          <tr class="border-b border-outline-variant/40 font-label-sm text-label-sm text-on-surface-variant uppercase">
            <th class="py-2.5 px-3">Enrollment</th>
            <th class="py-2.5 px-3">Student Name</th>
            <th class="py-2.5 px-3">Branch / Sem</th>
            <th class="py-2.5 px-3">Attendance</th>
            <th class="py-2.5 px-3">Status</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-outline-variant/20 font-body-sm text-body-sm">
          <c:forEach items="${data.roster}" var="st">
            <tr>
              <td class="py-2.5 px-3 font-mono font-semibold text-on-surface"><c:out value="${st.enrollmentNo}"/></td>
              <td class="py-2.5 px-3">
                <div class="font-semibold text-on-surface"><c:out value="${st.fullName}"/></div>
                <div class="text-xs text-on-surface-variant"><c:out value="${st.email}"/></div>
              </td>
              <td class="py-2.5 px-3 text-on-surface-variant"><c:out value="${st.branchCode}"/> &bull; Sem <c:out value="${st.semester}"/></td>
              <td class="py-2.5 px-3 text-on-surface"><c:out value="${st.attended}"/> / <c:out value="${st.held}"/> (<c:out value="${st.held == 0 ? 100 : st.pct}"/>%)</td>
              <td class="py-2.5 px-3">
                <c:choose>
                  <c:when test="${st.tone eq 'RED'}"><span class="px-2 py-0.5 rounded bg-error-container text-on-error-container font-label-sm text-label-sm font-bold">Low (&lt;75%)</span></c:when>
                  <c:when test="${st.tone eq 'YELLOW'}"><span class="px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-label-sm text-label-sm font-bold">Borderline</span></c:when>
                  <c:when test="${st.tone eq 'BLUE'}"><span class="px-2 py-0.5 rounded bg-primary-container/15 text-primary font-label-sm text-label-sm font-bold">No lectures</span></c:when>
                  <c:otherwise><span class="px-2 py-0.5 rounded bg-secondary-container text-on-secondary-container font-label-sm text-label-sm font-bold">Regular</span></c:otherwise>
                </c:choose>
              </td>
            </tr>
          </c:forEach>
        </tbody>
      </table>
    </div>
  </section>
</c:if>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

