<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Faculty Profile"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<div>
  <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface">Faculty Profile</h1>
  <p class="font-body-sm text-body-sm text-on-surface-variant">Institutional staff record, office location and password security.</p>
</div>

<section class="grid grid-cols-1 lg:grid-cols-2 gap-space-lg">
  <div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-[0_2px_10px_rgba(15,76,129,0.05)] flex flex-col gap-4">
    <div class="flex items-center gap-4">
      <div class="w-16 h-16 rounded-2xl bg-primary-container text-on-primary flex items-center justify-center font-headline-md text-headline-md font-bold"><c:out value="${ccUser.initials}"/></div>
      <div>
        <h2 class="font-headline-md text-headline-md font-bold text-on-surface"><c:out value="${faculty.title}"/> <c:out value="${faculty.user.fullName}"/></h2>
        <p class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${faculty.designation}"/> &bull; <c:out value="${faculty.department}"/></p>
      </div>
    </div>
    <dl class="grid grid-cols-2 gap-4 pt-3 border-t border-outline-variant/30 font-body-sm text-body-sm">
      <div><dt class="text-on-surface-variant">Employee Code</dt><dd class="font-mono font-bold text-on-surface mt-0.5"><c:out value="${faculty.employeeCode}"/></dd></div>
      <div><dt class="text-on-surface-variant">Official Email</dt><dd class="font-semibold text-on-surface mt-0.5"><c:out value="${faculty.user.email}"/></dd></div>
      <div><dt class="text-on-surface-variant">Department</dt><dd class="font-semibold text-on-surface mt-0.5"><c:out value="${faculty.department}"/></dd></div>
      <div><dt class="text-on-surface-variant">Office / Cabin</dt><dd class="font-semibold text-on-surface mt-0.5"><c:out value="${empty faculty.cabin ? 'Not assigned' : faculty.cabin}"/></dd></div>
    </dl>
  </div>

  <div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-4">Update Cabin &amp; Password</h2>
    <form method="post" action="${ctx}/faculty/profile/update" class="flex flex-col gap-4">
      <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
      <div class="flex flex-col gap-1">
        <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="cabinInput">Office / Cabin Location</label>
        <input id="cabinInput" name="cabin" type="text" maxlength="40" value="<c:out value='${faculty.cabin}'/>" placeholder="e.g. MA-204" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"/>
      </div>
      <div class="border-t border-outline-variant/30 pt-3 flex flex-col gap-3">
        <span class="font-label-sm text-label-sm font-semibold text-on-surface-variant">Change Password (leave blank to keep current)</span>
        <input name="currentPassword" type="password" autocomplete="current-password" placeholder="Current password" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"/>
        <input name="newPassword" type="password" autocomplete="new-password" minlength="8" placeholder="New password (8+ chars, with digit)" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"/>
      </div>
      <button type="submit" class="self-start px-5 py-2.5 rounded-xl bg-primary-container text-on-primary font-label-md text-label-md font-semibold">Save Profile</button>
    </form>
  </div>
</section>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

