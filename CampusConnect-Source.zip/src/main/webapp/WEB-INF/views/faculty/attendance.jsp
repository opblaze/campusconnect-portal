<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Attendance Register"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<div>
  <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface">Attendance Register</h1>
  <p class="font-body-sm text-body-sm text-on-surface-variant">Select a course and lecture date to record or update student attendance.</p>
</div>

<!-- Subject & Date Selector -->
<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <form method="get" action="${ctx}/faculty/attendance" class="flex flex-wrap items-end gap-4">
    <div class="flex flex-col gap-1 min-w-[240px]">
      <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="attSub">Subject</label>
      <select id="attSub" name="subjectId" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40">
        <c:forEach items="${data.subjects}" var="s">
          <option value="${s.id}" ${s.id eq data.selectedSubjectId ? 'selected' : ''}><c:out value="${s.code}"/> &mdash; <c:out value="${s.name}"/></option>
        </c:forEach>
      </select>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="attDate">Lecture Date</label>
      <input id="attDate" name="date" type="date" value="<c:out value='${data.dateValue}'/>" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"/>
    </div>
    <button type="submit" class="px-4 py-2 rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold">Load Register</button>
    <c:if test="${data.alreadyMarked}">
      <span class="px-3 py-1.5 rounded-lg bg-amber-100 text-amber-800 font-label-sm text-label-sm font-semibold">Existing attendance loaded for <c:out value="${data.dateLabel}"/> (saving will update)</span>
    </c:if>
  </form>
</section>

<c:if test="${not empty data.selectedSubjectId}">
  <section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <form method="post" action="${ctx}/faculty/attendance/save" id="attForm">
      <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
      <input type="hidden" name="subjectId" value="${data.selectedSubjectId}"/>
      <input type="hidden" name="date" value="<c:out value='${data.dateValue}'/>"/>
      <div class="flex flex-wrap items-center justify-between gap-2 mb-4">
        <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface"><c:out value="${data.selectedSubjectCode}"/> &bull; <c:out value="${data.selectedSubjectName}"/> (<c:out value="${data.dateLabel}"/>)</h2>
        <div class="flex gap-2">
          <button type="button" onclick="ccAttToggle(true)" class="px-3 py-1.5 rounded-lg bg-surface-container text-on-surface font-label-sm text-label-sm font-semibold hover:bg-surface-container-high">Mark All Present</button>
          <button type="button" onclick="ccAttToggle(false)" class="px-3 py-1.5 rounded-lg bg-surface-container text-on-surface font-label-sm text-label-sm font-semibold hover:bg-surface-container-high">Clear All</button>
        </div>
      </div>

      <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse">
          <thead>
            <tr class="border-b border-outline-variant/40 font-label-sm text-label-sm text-on-surface-variant uppercase">
              <th class="py-2.5 px-3 w-20">Present</th>
              <th class="py-2.5 px-3">Enrollment</th>
              <th class="py-2.5 px-3">Student Name</th>
              <th class="py-2.5 px-3">Semester Progress</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-outline-variant/20 font-body-sm text-body-sm">
            <c:forEach items="${data.entries}" var="e">
              <tr class="hover:bg-surface-container-low/60">
                <td class="py-2.5 px-3">
                  <input type="checkbox" name="presentIds" value="${e.studentId}" ${e.present ? 'checked' : ''} class="cc-att-cb w-5 h-5 accent-primary rounded cursor-pointer"/>
                </td>
                <td class="py-2.5 px-3 font-mono font-semibold text-on-surface"><c:out value="${e.enrollmentNo}"/></td>
                <td class="py-2.5 px-3 font-semibold text-on-surface"><c:out value="${e.fullName}"/></td>
                <td class="py-2.5 px-3">
                  <span class="text-on-surface-variant"><c:out value="${e.attended}"/> / <c:out value="${e.held}"/> lectures (<strong class="text-on-surface"><c:out value="${e.pct}"/>%</strong>)</span>
                </td>
              </tr>
            </c:forEach>
          </tbody>
        </table>
      </div>
      <div class="mt-4 flex justify-end">
        <button type="submit" class="px-5 py-2.5 rounded-xl bg-primary-container text-on-primary font-label-md text-label-md font-semibold flex items-center gap-2"><span class="material-symbols-outlined text-lg">save</span>Save Attendance</button>
      </div>
    </form>
  </section>
  <script>
    function ccAttToggle(val) {
      document.querySelectorAll('.cc-att-cb').forEach(function (cb) { cb.checked = val; });
    }
  </script>
</c:if>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

