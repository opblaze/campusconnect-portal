<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Announcements"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<div>
  <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface">Class Announcements</h1>
  <p class="font-body-sm text-body-sm text-on-surface-variant">Post notices to your subject cohorts or across the institute. Students receive immediate dashboard notifications.</p>
</div>

<!-- Compose Form -->
<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-3">Publish Announcement</h2>
  <form method="post" action="${ctx}/faculty/announcements/post" class="flex flex-col gap-4">
    <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div class="flex flex-col gap-1">
        <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="anSub">Audience / Subject</label>
        <select id="anSub" name="subjectId" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40">
          <option value="">All Students (Campus-wide)</option>
          <c:forEach items="${data.subjects}" var="s">
            <option value="${s.id}"><c:out value="${s.code}"/> &mdash; <c:out value="${s.name}"/></option>
          </c:forEach>
        </select>
      </div>
      <div class="md:col-span-2 flex flex-col gap-1">
        <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="anTitle">Headline</label>
        <input id="anTitle" name="title" type="text" required maxlength="150" placeholder="e.g. Lab viva schedule for Unit 3" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"/>
      </div>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="anBody">Message Body</label>
      <textarea id="anBody" name="body" rows="3" required maxlength="1500" placeholder="Write clear instructions, timings or room details..." class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"></textarea>
    </div>
    <div class="flex flex-wrap items-center justify-between gap-3">
      <label class="flex items-center gap-2 cursor-pointer">
        <input type="checkbox" name="important" value="true" class="w-4 h-4 accent-primary rounded"/>
        <span class="font-body-sm text-body-sm text-on-surface font-medium">Mark as High Importance notice</span>
      </label>
      <button type="submit" class="px-5 py-2.5 rounded-xl bg-primary-container text-on-primary font-label-md text-label-md font-semibold flex items-center gap-2"><span class="material-symbols-outlined text-lg">campaign</span>Publish Notice</button>
    </div>
  </form>
</section>

<!-- Two-column notices -->
<section class="grid grid-cols-1 lg:grid-cols-2 gap-space-lg">
  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-3">My Posted Notices</h2>
    <c:choose>
      <c:when test="${empty data.myNotices}">
        <p class="font-body-sm text-body-sm text-on-surface-variant py-6 text-center">You haven't posted any notices yet.</p>
      </c:when>
      <c:otherwise>
        <div class="flex flex-col gap-3">
          <c:forEach items="${data.myNotices}" var="n">
            <div class="p-space-sm rounded-xl bg-surface-container-low">
              <div class="flex items-start justify-between gap-2">
                <div>
                  <span class="px-2 py-0.5 rounded bg-primary-container/15 text-primary font-label-sm text-label-sm font-bold"><c:out value="${n.subjectCode}"/></span>
                  <c:if test="${n.important}"><span class="px-2 py-0.5 rounded bg-error-container text-on-error-container font-label-sm text-label-sm font-bold ml-1">Important</span></c:if>
                  <h3 class="font-label-lg text-label-lg font-bold text-on-surface mt-1"><c:out value="${n.title}"/></h3>
                </div>
                <form method="post" action="${ctx}/faculty/announcements/delete" class="m-0">
                  <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
                  <input type="hidden" name="announcementId" value="${n.id}"/>
                  <button type="submit" class="px-2.5 py-1 rounded bg-error-container text-on-error-container font-label-sm text-label-sm font-semibold">Delete</button>
                </form>
              </div>
              <p class="font-body-sm text-body-sm text-on-surface-variant mt-1"><c:out value="${n.body}"/></p>
              <div class="font-label-sm text-label-sm text-on-surface-variant mt-1"><c:out value="${n.createdLabel}"/></div>
            </div>
          </c:forEach>
        </div>
      </c:otherwise>
    </c:choose>
  </div>

  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-3">Latest Campus &amp; Department Notices</h2>
    <div class="flex flex-col gap-3">
      <c:forEach items="${data.campusNotices}" var="n">
        <div class="p-space-sm rounded-xl bg-surface-container-low">
          <div class="flex items-center justify-between gap-2">
            <span class="font-label-sm text-label-sm font-bold text-primary"><c:out value="${n.subjectCode}"/></span>
            <span class="font-label-sm text-label-sm text-on-surface-variant"><c:out value="${n.createdLabel}"/></span>
          </div>
          <h3 class="font-label-lg text-label-lg font-bold text-on-surface mt-1"><c:out value="${n.title}"/></h3>
          <p class="font-body-sm text-body-sm text-on-surface-variant mt-1"><c:out value="${n.body}"/></p>
          <div class="font-label-sm text-label-sm text-on-surface-variant mt-1">Posted by <c:out value="${n.authorName}"/></div>
        </div>
      </c:forEach>
    </div>
  </div>
</section>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

