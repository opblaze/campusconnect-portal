<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Teaching Timetable"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<div>
  <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface">Weekly Teaching Schedule</h1>
  <p class="font-body-sm text-body-sm text-on-surface-variant">Recurring lecture slots and upcoming examination dates across your assigned courses.</p>
</div>

<section class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-space-md">
  <c:forEach items="${data.byDay}" var="entry">
    <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] flex flex-col gap-3">
      <div class="flex items-center justify-between border-b border-outline-variant/30 pb-2">
        <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface"><c:out value="${entry.key}"/></h2>
        <span class="px-2 py-0.5 rounded bg-surface-container text-on-surface-variant font-label-sm text-label-sm font-semibold">${entry.value.size()} slot(s)</span>
      </div>
      <c:choose>
        <c:when test="${empty entry.value}">
          <p class="font-body-sm text-body-sm text-on-surface-variant py-4 text-center">No lectures scheduled.</p>
        </c:when>
        <c:otherwise>
          <div class="flex flex-col gap-2">
            <c:forEach items="${entry.value}" var="slot">
              <div class="p-space-sm rounded-xl bg-surface-container-low">
                <div class="flex items-center justify-between gap-2">
                  <span class="font-label-sm text-label-sm font-bold text-primary"><c:out value="${slot.subjectCode}"/></span>
                  <span class="font-label-sm text-label-sm font-semibold text-on-surface"><c:out value="${slot.timeRange}"/></span>
                </div>
                <div class="font-label-md text-label-md font-bold text-on-surface mt-1"><c:out value="${slot.subjectName}"/></div>
                <div class="font-body-sm text-body-sm text-on-surface-variant mt-0.5"><c:out value="${slot.room}"/> <c:if test="${not empty slot.block}">&bull; <c:out value="${slot.block}"/></c:if></div>
                <c:if test="${not empty slot.topic}">
                  <div class="font-label-sm text-label-sm text-on-surface-variant mt-1">Topic: <c:out value="${slot.topic}"/></div>
                </c:if>
              </div>
            </c:forEach>
          </div>
        </c:otherwise>
      </c:choose>
    </div>
  </c:forEach>
</section>

<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-3">Upcoming Examinations</h2>
  <c:choose>
    <c:when test="${empty data.exams}">
      <p class="font-body-sm text-body-sm text-on-surface-variant py-4 text-center">No upcoming exams found.</p>
    </c:when>
    <c:otherwise>
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        <c:forEach items="${data.exams}" var="ex">
          <div class="p-space-sm rounded-xl bg-surface-container-low flex items-center gap-3">
            <div class="w-12 h-12 rounded-xl bg-primary-container text-on-primary flex flex-col items-center justify-center shrink-0">
              <span class="font-label-sm text-[10px] uppercase leading-none"><c:out value="${ex.month}"/></span>
              <span class="font-headline-sm text-headline-sm font-bold leading-tight"><c:out value="${ex.day}"/></span>
            </div>
            <div class="min-w-0">
              <div class="font-label-md text-label-md font-bold text-on-surface truncate"><c:out value="${ex.code}"/> &bull; <c:out value="${ex.subjectName}"/></div>
              <div class="font-body-sm text-body-sm text-on-surface-variant truncate"><c:out value="${ex.timeRange}"/></div>
            </div>
          </div>
        </c:forEach>
      </div>
    </c:otherwise>
  </c:choose>
</section>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

