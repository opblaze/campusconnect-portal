<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Feedback Inbox"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<div>
  <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface">Student Feedback Inbox</h1>
  <p class="font-body-sm text-body-sm text-on-surface-variant">Course feedback and concerns routed to you from the Student Helpdesk &amp; Assistant.</p>
</div>

<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <c:choose>
    <c:when test="${empty feedbacks}">
      <p class="font-body-sm text-body-sm text-on-surface-variant py-8 text-center">Your feedback inbox is empty.</p>
    </c:when>
    <c:otherwise>
      <div class="flex flex-col gap-3">
        <c:forEach items="${feedbacks}" var="fb">
          <div class="p-space-md rounded-xl bg-surface-container-low flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div class="flex-1">
              <div class="flex items-center gap-2 flex-wrap">
                <span class="px-2 py-0.5 rounded bg-primary-container/15 text-primary font-label-sm text-label-sm font-bold"><c:out value="${fb.subjectCode}"/></span>
                <span class="px-2 py-0.5 rounded bg-surface-container text-on-surface-variant font-label-sm text-label-sm"><c:out value="${fb.category}"/></span>
                <span class="px-2 py-0.5 rounded font-label-sm text-label-sm font-bold ${fb.status eq 'SENT' ? 'bg-secondary-container text-on-secondary-container' : (fb.status eq 'REJECTED' ? 'bg-error-container text-on-error-container' : 'bg-amber-100 text-amber-800')}"><c:out value="${fb.status}"/></span>
                <span class="font-label-sm text-label-sm text-on-surface-variant"><c:out value="${fb.createdLabel}"/></span>
              </div>
              <p class="font-body-md text-body-md text-on-surface mt-2"><c:out value="${fb.message}"/></p>
              <div class="font-body-sm text-body-sm text-on-surface-variant mt-1">Submitted by <strong class="text-on-surface"><c:out value="${fb.studentName}"/></strong></div>
            </div>
            <div class="flex gap-2 shrink-0">
              <form method="post" action="${ctx}/faculty/feedback/status" class="m-0">
                <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
                <input type="hidden" name="feedbackId" value="${fb.id}"/>
                <input type="hidden" name="status" value="SENT"/>
                <button type="submit" class="px-3 py-1.5 rounded-lg bg-primary-container text-on-primary font-label-sm text-label-sm font-semibold">Mark Addressed</button>
              </form>
              <form method="post" action="${ctx}/faculty/feedback/status" class="m-0">
                <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
                <input type="hidden" name="feedbackId" value="${fb.id}"/>
                <input type="hidden" name="status" value="REJECTED"/>
                <button type="submit" class="px-3 py-1.5 rounded-lg bg-surface-container text-on-surface-variant font-label-sm text-label-sm font-semibold">Dismiss</button>
              </form>
            </div>
          </div>
        </c:forEach>
      </div>
    </c:otherwise>
  </c:choose>
</section>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

