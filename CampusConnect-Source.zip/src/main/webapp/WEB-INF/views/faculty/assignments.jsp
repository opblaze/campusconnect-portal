<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Assignments &amp; Grading"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<div>
  <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface">Assignments &amp; Submissions</h1>
  <p class="font-body-sm text-body-sm text-on-surface-variant">Create course assignments and grade student submissions.</p>
</div>

<!-- Create Assignment -->
<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-3">Create New Assignment</h2>
  <form method="post" action="${ctx}/faculty/assignments/create" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
    <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="asSubject">Subject</label>
      <select id="asSubject" name="subjectId" required class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40">
        <c:forEach items="${data.subjects}" var="s">
          <option value="${s.id}"><c:out value="${s.code}"/> &mdash; <c:out value="${s.shortName}"/></option>
        </c:forEach>
      </select>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="asTitle">Title</label>
      <input id="asTitle" name="title" type="text" required maxlength="150" placeholder="e.g. Lab 4: Servlet Filters" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"/>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="asDue">Due Date &amp; Time</label>
      <input id="asDue" name="dueAt" type="datetime-local" required value="<c:out value='${data.defaultDueValue}'/>" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"/>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="asMax">Max Marks</label>
      <input id="asMax" name="maxMarks" type="number" min="1" max="500" value="20" required class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"/>
    </div>
    
    <div class="md:col-span-2 lg:col-span-3 flex flex-col gap-1">
      <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="asDesc">Instructions (optional)</label>
      <input id="asDesc" name="description" type="text" maxlength="500" placeholder="Deliverables, rubric or submission instructions" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40"/>
    </div>
    <button type="submit" class="px-4 py-2.5 rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold">Publish Assignment</button>
  </form>
</section>

<!-- Two-column Assignments list + Submissions Grading -->
<section class="grid grid-cols-1 xl:grid-cols-12 gap-space-lg">
  <div class="xl:col-span-5 bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] flex flex-col gap-3">
    <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Course Assignments</h2>
    <c:choose>
      <c:when test="${empty data.assignments}">
        <p class="font-body-sm text-body-sm text-on-surface-variant py-4 text-center">No assignments posted yet.</p>
      </c:when>
      <c:otherwise>
        <c:forEach items="${data.assignments}" var="a">
          <a href="${ctx}/faculty/assignments?id=${a.id}" class="p-space-sm rounded-xl border-2 transition ${a.id eq data.selectedAssignmentId ? 'border-primary bg-primary-container/5' : 'border-transparent bg-surface-container-low hover:bg-surface-container'}">
            <div class="flex items-center justify-between gap-2">
              <span class="px-2 py-0.5 rounded bg-primary-container/15 text-primary font-label-sm text-label-sm font-bold"><c:out value="${a.subjectCode}"/></span>
              <span class="font-label-sm text-label-sm ${a.overdue ? 'text-error font-semibold' : 'text-on-surface-variant'}">Due <c:out value="${a.dueLabel}"/></span>
            </div>
            <div class="font-label-lg text-label-lg font-bold text-on-surface mt-1"><c:out value="${a.title}"/></div>
            <div class="font-body-sm text-body-sm text-on-surface-variant mt-1">Submitted: <strong class="text-on-surface"><c:out value="${a.submittedCount}"/> / <c:out value="${a.totalEnrolled}"/></strong> &bull; Graded: <c:out value="${a.gradedCount}"/> &bull; Max <c:out value="${a.maxMarks}"/></div>
          </a>
        </c:forEach>
      </c:otherwise>
    </c:choose>
  </div>

  <div class="xl:col-span-7 bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <c:choose>
      <c:when test="${empty data.selectedAssignmentId}">
        <p class="font-body-sm text-body-sm text-on-surface-variant py-8 text-center">Select an assignment to review submissions.</p>
      </c:when>
      <c:otherwise>
        <div class="mb-4">
          <span class="font-label-sm text-label-sm font-bold text-primary uppercase"><c:out value="${data.selectedSubjectCode}"/> &bull; Max <c:out value="${data.selectedMaxMarks}"/> marks</span>
          <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface"><c:out value="${data.selectedAssignmentTitle}"/></h2>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse">
            <thead>
              <tr class="border-b border-outline-variant/40 font-label-sm text-label-sm text-on-surface-variant uppercase">
                <th class="py-2 px-2">Student</th>
                <th class="py-2 px-2">Submitted</th>
                <th class="py-2 px-2">Status</th>
                <th class="py-2 px-2">Marks / Grade</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-outline-variant/20 font-body-sm text-body-sm">
              <c:forEach items="${data.submissions}" var="sub">
                <tr>
                  <td class="py-2.5 px-2">
                    <div class="font-semibold text-on-surface"><c:out value="${sub.studentName}"/></div>
                    <div class="text-xs font-mono text-on-surface-variant"><c:out value="${sub.enrollmentNo}"/></div>
                  </td>
                  <td class="py-2.5 px-2 text-on-surface-variant"><c:out value="${sub.submittedLabel}"/></td>
                  <td class="py-2.5 px-2">
                    <c:choose>
                      <c:when test="${sub.status eq 'GRADED'}"><span class="px-2 py-0.5 rounded bg-secondary-container text-on-secondary-container font-label-sm text-label-sm font-bold">GRADED</span></c:when>
                      <c:when test="${sub.status eq 'ON_TIME'}"><span class="px-2 py-0.5 rounded bg-primary-container/15 text-primary font-label-sm text-label-sm font-bold">ON TIME</span></c:when>
                      <c:when test="${sub.status eq 'LATE'}"><span class="px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-label-sm text-label-sm font-bold">LATE</span></c:when>
                      <c:otherwise><span class="px-2 py-0.5 rounded bg-surface-container text-on-surface-variant font-label-sm text-label-sm">PENDING</span></c:otherwise>
                    </c:choose>
                  </td>
                  <td class="py-2.5 px-2">
                    <c:choose>
                      <c:when test="${not empty sub.submissionId}">
                        <form method="post" action="${ctx}/faculty/assignments/grade" class="flex items-center gap-2 m-0">
                          <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
                          <input type="hidden" name="assignmentId" value="${data.selectedAssignmentId}"/>
                          <input type="hidden" name="submissionId" value="${sub.submissionId}"/>
                          <input type="number" step="0.5" min="0" max="${sub.maxMarks}" name="marks" value="<c:out value='${sub.marksAwarded}'/>" required placeholder="Score" class="w-20 px-2 py-1 rounded bg-surface-container-low border border-outline-variant/40 text-on-surface"/>
                          <button type="submit" class="px-3 py-1 rounded bg-primary-container text-on-primary font-label-sm text-label-sm font-semibold">Save</button>
                        </form>
                      </c:when>
                      <c:otherwise><span class="text-on-surface-variant">&mdash;</span></c:otherwise>
                    </c:choose>
                  </td>
                </tr>
              </c:forEach>
            </tbody>
          </table>
        </div>
      </c:otherwise>
    </c:choose>
  </div>
</section>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

