<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Marks Entry"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<div>
  <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface">Marks Entry &amp; Publishing</h1>
  <p class="font-body-sm text-body-sm text-on-surface-variant">Record CIE, Mid-Sem, End-Sem and Lab evaluations. Students are notified when scores are published.</p>
</div>

<section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
  <form method="get" action="${ctx}/faculty/marks" class="flex flex-wrap items-end gap-4">
    <div class="flex flex-col gap-1 min-w-[240px]">
      <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="mkSub">Subject</label>
      <select id="mkSub" name="subjectId" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40">
        <c:forEach items="${data.subjects}" var="s">
          <option value="${s.id}" ${s.id eq data.selectedSubjectId ? 'selected' : ''}><c:out value="${s.code}"/> &mdash; <c:out value="${s.name}"/></option>
        </c:forEach>
      </select>
    </div>
    <div class="flex flex-col gap-1">
      <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="mkType">Component</label>
      <select id="mkType" name="examType" class="px-3 py-2 rounded-lg bg-surface-container-low text-on-surface border border-outline-variant/40">
        <c:forEach items="${data.examTypes}" var="et">
          <option value="<c:out value='${et}'/>" ${et eq data.selectedExamType ? 'selected' : ''}><c:out value="${et}"/></option>
        </c:forEach>
      </select>
    </div>
    <button type="submit" class="px-4 py-2 rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold">Load Roster</button>
  </form>
</section>

<c:if test="${not empty data.selectedSubjectId}">
  <section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <form method="post" action="${ctx}/faculty/marks/save">
      <input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"/>
      <input type="hidden" name="subjectId" value="${data.selectedSubjectId}"/>
      <input type="hidden" name="examType" value="<c:out value='${data.selectedExamType}'/>"/>
      <div class="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div>
          <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface"><c:out value="${data.selectedSubjectCode}"/> &bull; <c:out value="${data.selectedExamType}"/></h2>
          <p class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${data.selectedSubjectName}"/></p>
        </div>
        <div class="flex items-center gap-2">
          <label class="font-label-sm text-label-sm font-semibold text-on-surface-variant" for="maxMarks">Maximum Marks:</label>
          <input id="maxMarks" name="maximum" type="number" step="0.5" min="1" max="200" value="<c:out value='${data.defaultMaximum}'/>" required class="w-24 px-3 py-1.5 rounded-lg bg-surface-container-low border border-outline-variant/40 text-on-surface"/>
        </div>
      </div>

      <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse">
          <thead>
            <tr class="border-b border-outline-variant/40 font-label-sm text-label-sm text-on-surface-variant uppercase">
              <th class="py-2.5 px-3">Enrollment</th>
              <th class="py-2.5 px-3">Student Name</th>
              <th class="py-2.5 px-3">Obtained Marks</th>
              <th class="py-2.5 px-3">Last Published</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-outline-variant/20 font-body-sm text-body-sm">
            <c:forEach items="${data.entries}" var="e">
              <tr>
                <td class="py-2.5 px-3 font-mono font-semibold text-on-surface"><c:out value="${e.enrollmentNo}"/></td>
                <td class="py-2.5 px-3 font-semibold text-on-surface"><c:out value="${e.fullName}"/></td>
                <td class="py-2.5 px-3">
                  <input type="number" step="0.5" min="0" name="score_${e.studentId}" value="<c:out value='${e.obtained}'/>" placeholder="Enter score" class="w-32 px-3 py-1.5 rounded-lg bg-surface-container-low border border-outline-variant/40 text-on-surface"/>
                </td>
                <td class="py-2.5 px-3 text-on-surface-variant"><c:out value="${e.publishedLabel}"/></td>
              </tr>
            </c:forEach>
          </tbody>
        </table>
      </div>
      <div class="mt-4 flex justify-end">
        <button type="submit" class="px-5 py-2.5 rounded-xl bg-primary-container text-on-primary font-label-md text-label-md font-semibold">Publish Marks</button>
      </div>
    </form>
  </section>
</c:if>

<c:if test="${not empty data.history}">
  <section class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mb-3">Recently Published Marks</h2>
    <div class="overflow-x-auto">
      <table class="w-full text-left border-collapse">
        <thead>
          <tr class="border-b border-outline-variant/40 font-label-sm text-label-sm text-on-surface-variant uppercase">
            <th class="py-2 px-3">Subject</th>
            <th class="py-2 px-3">Student</th>
            <th class="py-2 px-3">Component</th>
            <th class="py-2 px-3">Score</th>
            <th class="py-2 px-3">Published</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-outline-variant/20 font-body-sm text-body-sm">
          <c:forEach items="${data.history}" var="h">
            <tr>
              <td class="py-2 px-3 font-bold text-primary"><c:out value="${h.subjectCode}"/></td>
              <td class="py-2 px-3"><c:out value="${h.studentName}"/> (<span class="font-mono"><c:out value="${h.studentEnroll}"/></span>)</td>
              <td class="py-2 px-3 text-on-surface-variant"><c:out value="${h.examType}"/></td>
              <td class="py-2 px-3 font-semibold text-on-surface"><c:out value="${h.scoreLabel}"/></td>
              <td class="py-2 px-3 text-on-surface-variant"><c:out value="${h.publishedLabel}"/></td>
            </tr>
          </c:forEach>
        </tbody>
      </table>
    </div>
  </section>
</c:if>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

