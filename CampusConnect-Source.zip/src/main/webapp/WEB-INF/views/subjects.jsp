<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm"><div class="flex items-center gap-space-sm"><span class="p-2 rounded-lg bg-primary-container text-on-primary flex"><span class="material-symbols-outlined">menu_book</span></span><div><h1 class="font-headline-lg text-headline-lg text-on-surface font-bold">My Subjects</h1><p class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${fn:length(rows)}"/> courses registered in <c:out value="${d.semesterLabel}"/></p></div></div></div>

<c:if test="${empty rows}"><div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm text-center">You have no registered subjects yet. Please contact the Campus Helpdesk.</div></c:if>
<div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-space-md">
<c:forEach var="r" items="${rows}">
<div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm flex flex-col gap-space-sm">
  <div class="flex items-center justify-between"><span class="px-space-sm py-0.5 rounded bg-surface-container-high text-primary font-label-sm text-label-sm font-bold"><c:out value="${r.code}"/></span><span class="font-label-sm text-label-sm text-on-surface-variant"><c:out value="${r.days}"/></span></div>
  <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface"><c:out value="${r.name}"/></h2>
  <p class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${r.abbr}"/> &bull; <c:out value="${r.credits}"/> credits &bull; <c:out value="${r.category}"/></p>
  <div><div class="flex justify-between text-label-sm font-label-sm"><span class="text-on-surface-variant">Syllabus completion</span><span class="font-semibold text-primary"><c:out value="${r.syllabus}"/>%</span></div>
  <div class="w-full h-1.5 rounded-full bg-surface-container-high overflow-hidden mt-1"><div class="h-full bg-primary rounded-full" style="width:${r.syllabus}%"></div></div></div>
  <div class="font-body-sm text-body-sm text-on-surface"><span class="material-symbols-outlined text-sm align-middle text-primary">person</span> <c:out value="${r.faculty}"/><br/>
  <span class="text-on-surface-variant"><c:out value="${r.facultyEmail}"/><c:if test="${not empty r.cabin}"> &bull; <c:out value="${r.cabin}"/></c:if></span></div>
  <div class="flex gap-space-xs flex-wrap mt-auto pt-space-sm">
    <a href="${ctx}/app/assignments" class="px-space-sm py-1 rounded-lg font-label-sm text-label-sm font-semibold ${r.pending > 0 ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200' : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200'}"><c:out value="${r.pending}"/> pending assignment(s)</a>
    <a href="${ctx}/app/e-content?subject=${r.id}" class="px-space-sm py-1 rounded-lg bg-surface-container text-primary font-label-sm text-label-sm font-semibold"><c:out value="${r.materials}"/> file(s)</a>
  </div>
</div>
</c:forEach>
</div>
<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>
