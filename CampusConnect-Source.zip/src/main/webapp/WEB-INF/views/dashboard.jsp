<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<c:set var="ccUser" value="${sessionScope.ccUser}"/>
<%-- Colour tokens for the overall-attendance card: GREEN = good, YELLOW = mild attention, RED = risk --%>
<c:choose>
  <c:when test="${d.attendanceStatus eq 'GREEN'}">
    <c:set var="attText" value="text-secondary"/><c:set var="attRing" value="text-secondary"/>
    <c:set var="attChip" value="bg-secondary-container text-on-secondary-container"/>
    <c:set var="attCard" value="bg-surface-container-lowest"/><c:set var="attIcon" value="verified"/>
  </c:when>
  <c:when test="${d.attendanceStatus eq 'YELLOW'}">
    <c:set var="attText" value="text-amber-600 dark:text-amber-300"/><c:set var="attRing" value="text-amber-500"/>
    <c:set var="attChip" value="bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200"/>
    <c:set var="attCard" value="bg-surface-container-lowest ring-1 ring-amber-300"/><c:set var="attIcon" value="info"/>
  </c:when>
  <c:otherwise>
    <c:set var="attText" value="text-red-600 dark:text-red-300"/><c:set var="attRing" value="text-red-500"/>
    <c:set var="attChip" value="bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-200"/>
    <c:set var="attCard" value="bg-surface-container-lowest ring-1 ring-red-400"/><c:set var="attIcon" value="priority_high"/>
  </c:otherwise>
</c:choose>
<c:set var="risk" value="${d.attendanceStatus eq 'RED'}"/>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Dashboard - Campus Connect</title>
<%@ include file="/WEB-INF/jspf/head.jspf" %>
</head>
<body class="bg-background font-body-md text-body-md text-on-surface antialiased">
<%@ include file="/WEB-INF/jspf/header.jspf" %>
<%@ include file="/WEB-INF/jspf/sidebar.jspf" %>
<div class="lg:pl-64">
<main class="w-full min-h-screen pt-16 px-margin py-space-lg lg:px-margin-desktop bg-surface">
<div class="flex flex-col w-full">

<%-- ============ Top priority alert ticker (RED banner when attendance is at risk) ============ --%>
<c:choose>
<c:when test="${risk and d.hasEnrollments}">
  <div class="mb-space-lg w-full bg-gradient-to-r from-red-800 via-red-700 to-red-600 rounded-xl text-white p-space-md shadow-sm relative overflow-hidden">
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-space-sm">
      <div class="flex items-start gap-space-md">
        <span class="material-symbols-outlined text-2xl" style="font-variation-settings:'FILL' 1;">warning</span>
        <div>
          <div class="font-headline-sm text-headline-sm font-bold">URGENT ATTENDANCE SHORTFALL: Overall attendance is below the <c:out value="${d.minAttendance}"/>% threshold in <c:out value="${d.atRiskCount}"/> subject(s).</div>
          <div class="font-body-sm text-body-sm opacity-90">Hall ticket eligibility is at risk. Plan remedial classes with your faculty immediately.</div>
        </div>
      </div>
      <a href="${ctx}/app/attendance" class="px-space-md py-1.5 rounded-lg bg-white text-red-700 font-label-md text-label-md font-semibold text-center">View Attendance</a>
    </div>
  </div>
</c:when>
<c:when test="${not empty d.tickerExam or not empty d.tickerAssignment}">
  <div id="ticker" class="mb-space-lg w-full bg-gradient-to-r from-primary-container via-primary to-primary-container rounded-xl text-on-primary p-space-md shadow-sm relative overflow-hidden">
    <div class="absolute -right-10 -bottom-10 w-44 h-44 rounded-full bg-secondary/20 blur-2xl pointer-events-none"></div>
    <div class="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-space-sm">
      <div class="flex items-center gap-space-md">
        <span class="inline-flex items-center justify-center p-space-xs rounded-lg bg-surface-container-lowest/15 backdrop-blur-md"><span class="material-symbols-outlined text-secondary-fixed text-xl" style="font-variation-settings:'FILL' 1;">campaign</span></span>
        <div class="flex flex-wrap items-center gap-x-space-md gap-y-1">
          <span class="px-space-sm py-0.5 rounded-full bg-error text-on-error font-label-sm text-label-sm uppercase tracking-wider font-bold">Important</span>
          <c:if test="${not empty d.tickerExam}"><span class="font-body-md text-body-md text-white font-medium"><c:out value="${d.tickerExamName}"/> commences in <strong class="text-secondary-fixed font-bold"><c:out value="${d.tickerExam}"/></strong></span></c:if>
          <c:if test="${not empty d.tickerAssignment}"><span class="hidden lg:inline opacity-60">&bull;</span>
          <span class="inline-flex items-center gap-1 font-body-sm text-body-sm"><span class="material-symbols-outlined text-sm text-secondary-fixed">assignment_late</span> <c:out value="${d.tickerAssignmentTitle}"/> due <strong class="font-semibold"><c:out value="${d.tickerAssignment}"/></strong></span></c:if>
        </div>
      </div>
      <div class="flex items-center gap-space-sm self-end md:self-auto">
        <a class="px-space-md py-1.5 rounded-lg bg-surface-container-lowest/15 hover:bg-surface-container-lowest/25 text-on-primary font-label-md text-label-md transition-all" href="#exam-schedule">View Exam Schedule</a>
        <button class="p-1 rounded-lg opacity-80 hover:opacity-100" onclick="document.getElementById('ticker').style.display='none'" aria-label="Dismiss"><span class="material-symbols-outlined text-lg">close</span></button>
      </div>
    </div>
  </div>
</c:when>
</c:choose>

<%-- ============ Welcome hero ============ --%>
<div class="mb-space-xl bg-surface-container-lowest rounded-2xl p-space-xl shadow-sm relative overflow-hidden ${risk ? 'ring-1 ring-red-400' : ''}">
  <div class="absolute -top-24 right-0 w-80 h-80 rounded-full bg-surface-variant/40 blur-3xl pointer-events-none"></div>
  <div class="relative z-10 flex flex-col xl:flex-row items-start xl:items-center justify-between gap-space-lg">
    <div class="flex items-start gap-space-lg">
      <div class="relative hidden sm:block">
        <div class="w-20 h-20 rounded-2xl bg-primary-container text-on-primary flex items-center justify-center font-display-lg text-display-lg shadow-sm"><c:out value="${ccUser.initials}"/></div>
        <span class="absolute -bottom-1 -right-1 w-5 h-5 rounded-full ${risk ? 'bg-red-600' : 'bg-secondary'} border-2 border-surface-container-lowest flex items-center justify-center"><span class="material-symbols-outlined text-[12px] text-white">${risk ? 'priority_high' : 'school'}</span></span>
      </div>
      <div class="flex flex-col">
        <div class="flex items-center gap-space-sm flex-wrap">
          <h1 class="font-headline-lg text-headline-lg text-on-surface font-bold tracking-tight">Welcome back, <c:out value="${d.firstName}"/>!</h1>
          <span class="px-space-sm py-0.5 rounded-full bg-secondary-container text-on-secondary-container font-label-sm text-label-sm font-semibold">Verified Student</span>
          <c:if test="${risk}"><span class="px-space-sm py-0.5 rounded-full bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-200 font-label-sm text-label-sm font-semibold">Attendance At-Risk</span></c:if>
          <c:if test="${d.backlogs > 0}"><span class="px-space-sm py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200 font-label-sm text-label-sm font-semibold"><c:out value="${d.backlogs}"/> Active Backlog</span></c:if>
        </div>
        <div class="mt-1 flex flex-wrap items-center gap-x-space-md gap-y-1 text-on-surface-variant font-body-md text-body-md">
          <span class="flex items-center gap-1 font-semibold text-primary"><span class="material-symbols-outlined text-sm">badge</span> <c:out value="${d.enrollmentNo}"/></span><span>&bull;</span>
          <span><c:out value="${d.program}"/></span><span>&bull;</span>
          <span class="text-on-surface font-medium"><c:out value="${d.semesterLabel}"/> &bull; Academic Year <c:out value="${d.academicYear}"/></span>
        </div>
      </div>
    </div>
    <div class="flex items-center gap-space-sm self-stretch xl:self-auto justify-end">
      <button class="flex items-center gap-space-xs px-space-md py-space-sm rounded-lg bg-surface-container text-primary hover:bg-surface-container-high transition-all font-label-md text-label-md"><span class="material-symbols-outlined text-base">download</span><span>Semester Syllabus</span></button>
      <a href="${ctx}/app/fees" class="flex items-center gap-space-xs px-space-md py-space-sm rounded-lg bg-primary-container text-on-primary hover:bg-primary transition-all font-label-md text-label-md shadow-sm"><span class="material-symbols-outlined text-base">receipt_long</span><span>Fee Receipt</span></a>
    </div>
  </div>
  <div class="mt-space-lg pt-space-md flex flex-col gap-space-xs">
    <div class="flex justify-between items-center text-on-surface-variant font-label-md text-label-md"><span>Semester Timeline Completion</span><span class="font-bold text-primary">Week <c:out value="${d.weekNo}"/> of <c:out value="${d.totalWeeks}"/> (<c:out value="${d.timelinePct}"/>%)</span></div>
    <div class="w-full h-2 rounded-full bg-surface-container-high overflow-hidden"><div class="h-full bg-gradient-to-r from-secondary to-primary-container rounded-full" style="width:${d.timelinePct}%;"></div></div>
  </div>
</div>

<%-- ============ Five stat cards ============ --%>
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-space-md mb-space-xl">
  <div class="bg-surface-container-lowest p-space-lg rounded-xl shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow relative overflow-hidden">
    <div class="flex items-center justify-between"><span class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider font-semibold">Cumulative GPA</span><span class="p-space-xs rounded-lg bg-surface-container-low text-primary"><span class="material-symbols-outlined text-xl">award_star</span></span></div>
    <div class="mt-space-md"><div class="flex items-baseline gap-space-xs"><span class="font-display-lg text-display-lg font-bold text-primary"><c:out value="${d.cgpa}"/></span><span class="font-label-md text-label-md text-on-surface-variant font-medium">/ 10.0</span></div>
    <c:if test="${not empty d.cohortStanding}"><div class="mt-1 flex items-center gap-1 font-label-sm text-label-sm text-secondary"><span class="material-symbols-outlined text-xs">trending_up</span><span><c:out value="${d.cohortStanding}"/></span></div></c:if></div>
  </div>
  <div class="bg-surface-container-lowest p-space-lg rounded-xl shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow relative overflow-hidden">
    <div class="flex items-center justify-between"><span class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider font-semibold">Previous SGPA</span><span class="p-space-xs rounded-lg bg-surface-container-low text-secondary"><span class="material-symbols-outlined text-xl">query_stats</span></span></div>
    <div class="mt-space-md"><div class="flex items-baseline gap-space-xs"><span class="font-display-lg text-display-lg font-bold text-on-surface"><c:out value="${d.previousSgpa}"/></span><span class="font-label-md text-label-md text-on-surface-variant font-medium">Prev. sem</span></div>
    <div class="mt-1 flex items-center gap-1 font-label-sm text-label-sm text-on-surface-variant"><span class="material-symbols-outlined text-xs text-secondary">check_circle</span><span>Earned: <c:out value="${d.earnedCredits}"/> Credits</span></div></div>
  </div>
  <div class="${attCard} p-space-lg rounded-xl shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow relative">
    <div class="flex items-center justify-between"><span class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider font-semibold">Attendance</span><span class="px-space-xs py-0.5 rounded font-label-sm text-label-sm font-semibold ${attChip}"><c:out value="${d.attendanceLabel}"/></span></div>
    <div class="mt-space-sm flex items-center justify-between">
      <div><span class="font-display-lg text-display-lg font-bold ${attText}"><c:out value="${d.attendancePct}"/>%</span><br/><span class="font-body-sm text-body-sm text-on-surface-variant">Req. Min: <c:out value="${d.minAttendance}"/>%</span>
      <c:if test="${d.attendanceDeficit > 0}"><br/><span class="font-label-sm text-label-sm ${attText}">(-<c:out value="${d.attendanceDeficit}"/>% deficit)</span></c:if></div>
      <div class="relative w-14 h-14 flex items-center justify-center">
        <svg class="w-14 h-14 transform -rotate-90" viewBox="0 0 36 36"><path class="text-surface-container-high" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" stroke-width="3.5"></path><path class="${attRing}" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" stroke-dasharray="${d.attendancePct}, 100" stroke-linecap="round" stroke-width="3.5"></path></svg>
        <span class="material-symbols-outlined ${attText} absolute text-sm">${attIcon}</span>
      </div>
    </div>
  </div>
  <div class="bg-surface-container-lowest p-space-lg rounded-xl shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow relative overflow-hidden">
    <div class="flex items-center justify-between"><span class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider font-semibold">Assignments</span><span class="p-space-xs rounded-lg bg-surface-container-low text-primary"><span class="material-symbols-outlined text-xl">assignment_turned_in</span></span></div>
    <div class="mt-space-md"><div class="flex items-baseline gap-space-xs"><span class="font-display-lg text-display-lg font-bold text-on-surface"><c:out value="${d.submittedAssignments}"/></span><span class="font-headline-sm text-headline-sm text-on-surface-variant">/ <c:out value="${d.totalAssignments}"/></span></div>
    <c:choose>
      <c:when test="${d.pendingAssignments > 0}"><div class="mt-1 flex items-center gap-1 font-label-sm text-label-sm text-error font-medium"><span class="material-symbols-outlined text-xs">pending_actions</span><span><c:out value="${d.pendingAssignments}"/> pending submission</span></div></c:when>
      <c:otherwise><div class="mt-1 flex items-center gap-1 font-label-sm text-label-sm text-secondary font-medium"><span class="material-symbols-outlined text-xs">done_all</span><span>All submitted</span></div></c:otherwise>
    </c:choose></div>
  </div>
  <div class="bg-surface-container-lowest p-space-lg rounded-xl shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow relative overflow-hidden ${d.backlogs > 0 ? 'ring-1 ring-amber-300' : ''}">
    <div class="flex items-center justify-between"><span class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider font-semibold">Backlogs</span>
      <span class="p-space-xs rounded-lg ${d.backlogs > 0 ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200' : 'bg-secondary-container text-on-secondary-container'}"><span class="material-symbols-outlined text-xl">${d.backlogs > 0 ? 'error' : 'check_circle'}</span></span></div>
    <div class="mt-space-md"><div class="flex items-baseline gap-space-xs"><span class="font-display-lg text-display-lg font-bold ${d.backlogs > 0 ? 'text-amber-600 dark:text-amber-300' : 'text-secondary'}"><c:out value="${d.backlogs}"/></span><span class="font-label-md text-label-md text-on-surface-variant">${d.backlogs > 0 ? 'Active' : 'Clear'}</span></div>
    <div class="mt-1 flex items-center gap-1 font-label-sm text-label-sm text-on-surface-variant"><span class="material-symbols-outlined text-xs ${d.backlogs > 0 ? 'text-amber-500' : 'text-secondary'}">${d.backlogs > 0 ? 'schedule' : 'done_all'}</span><span>${d.backlogs > 0 ? 'Remedial exam pending' : '100% Courses Cleared'}</span></div></div>
  </div>
</div>

<%-- ============ Subjects (8 cols) + companion panel (4 cols) ============ --%>
<div class="grid grid-cols-1 lg:grid-cols-12 gap-space-lg mb-space-2xl">
<div class="lg:col-span-8 flex flex-col gap-space-lg">

  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm bg-surface-container-lowest p-space-md rounded-xl shadow-sm ${risk ? 'ring-1 ring-red-400' : ''}">
    <div class="flex items-center gap-space-sm">
      <span class="p-2 rounded-lg ${risk ? 'bg-red-600' : 'bg-primary-container'} text-on-primary flex items-center justify-center"><span class="material-symbols-outlined text-xl">${risk ? 'warning' : 'auto_stories'}</span></span>
      <div><h2 class="font-headline-md text-headline-md text-on-surface font-bold">Registered Subjects</h2>
      <p class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${fn:length(d.subjects)}"/> Active Courses in <c:out value="${d.semesterLabel}"/> &bull; Attendance &amp; Syllabus Tracking</p></div>
    </div>
    <div class="flex items-center gap-1 bg-surface-container p-1 rounded-lg" id="subject-filter">
      <button data-filter="ALL" class="px-space-md py-1 rounded-md bg-surface-container-lowest text-primary font-label-md text-label-md font-semibold shadow-xs">All (<c:out value="${fn:length(d.subjects)}"/>)</button>
      <button data-filter="CORE" class="px-space-md py-1 rounded-md text-on-surface-variant hover:text-on-surface font-label-md text-label-md transition-colors">Core (<c:out value="${d.coreCount}"/>)</button>
      <button data-filter="LAB" class="px-space-md py-1 rounded-md text-on-surface-variant hover:text-on-surface font-label-md text-label-md transition-colors">Labs (<c:out value="${d.labCount}"/>)</button>
    </div>
  </div>

  <c:if test="${not d.hasEnrollments}">
    <div class="bg-surface-container-lowest rounded-2xl p-space-2xl shadow-sm text-center">
      <span class="material-symbols-outlined text-5xl text-primary">school</span>
      <h3 class="font-headline-md text-headline-md text-on-surface font-bold mt-space-sm">No subjects registered yet</h3>
      <p class="font-body-md text-body-md text-on-surface-variant mt-1">Your semester enrollment is still pending. Contact the Campus Helpdesk to complete registration.</p>
      <a href="${ctx}/app/helpdesk" class="inline-block mt-space-md px-space-lg py-space-sm rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold">Open Helpdesk</a>
    </div>
  </c:if>

  <div class="grid grid-cols-1 md:grid-cols-2 gap-space-md" id="subject-grid">
  <c:forEach var="s" items="${d.subjects}">
    <div data-category="<c:out value='${s.category}'/>" class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm hover:shadow-md transition-all flex flex-col justify-between relative overflow-hidden group ${s.status eq 'RED' ? 'ring-1 ring-red-400' : ''}">
      <div class="absolute top-0 left-0 bottom-0 w-1.5 ${s.barClass}"></div>
      <div>
        <div class="flex items-center justify-between mb-space-sm">
          <span class="px-space-sm py-0.5 rounded bg-surface-container-high text-primary font-label-sm text-label-sm font-bold tracking-wider"><c:out value="${s.code}"/></span>
          <span class="font-label-sm text-label-sm text-on-surface-variant flex items-center gap-1"><span class="material-symbols-outlined text-xs">calendar_view_week</span> <c:out value="${s.meetingDays}"/></span>
        </div>
        <h3 class="font-headline-sm text-headline-sm text-on-surface font-bold group-hover:text-primary transition-colors"><c:out value="${s.name}"/></h3>
        <span class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${s.shortName}"/> &bull; <c:out value="${s.credits}"/> Credits</span>

        <%-- attendance chip: colour = GREEN / YELLOW / RED --%>
        <div class="mt-space-md flex items-center justify-between rounded-lg px-space-sm py-1 ${s.chipClass}">
          <span class="font-label-sm text-label-sm font-semibold">Attendance</span>
          <span class="font-label-md text-label-md font-bold"><c:out value="${s.attendancePct}"/>% &bull; <c:out value="${s.statusLabel}"/></span>
        </div>

        <div class="mt-space-md flex flex-col gap-1">
          <div class="flex justify-between text-label-sm font-label-sm"><span class="text-on-surface-variant">Syllabus Completion</span><span class="font-semibold text-primary"><c:out value="${s.syllabusPct}"/>%</span></div>
          <div class="w-full h-1.5 rounded-full bg-surface-container-high overflow-hidden"><div class="h-full bg-primary rounded-full" style="width:${s.syllabusPct}%;"></div></div>
        </div>
        <div class="mt-space-md p-space-xs px-space-sm rounded-lg bg-surface-container-low flex items-center justify-between text-on-surface-variant">
          <div class="flex items-center gap-1.5"><span class="material-symbols-outlined text-sm text-primary">schedule</span><span class="font-body-sm text-body-sm">Next: <c:out value="${s.nextSession}"/></span></div>
          <span class="font-label-sm text-label-sm text-primary font-semibold"><c:out value="${s.nextRoom}"/></span>
        </div>
      </div>
      <div class="mt-space-lg pt-space-md flex items-center justify-between bg-surface-container-low/50 -mx-space-lg -mb-space-lg px-space-lg py-space-sm">
        <div class="flex items-center gap-space-sm">
          <div class="w-7 h-7 rounded-full bg-primary-container text-on-primary flex items-center justify-center font-label-sm text-label-sm font-semibold"><c:out value="${s.facultyInitials}"/></div>
          <span class="font-label-md text-label-md text-on-surface font-medium truncate max-w-[130px]"><c:out value="${s.facultyName}"/></span>
        </div>
        <div class="flex items-center gap-space-xs">
          <a href="${ctx}/app/e-content" class="p-1.5 rounded-lg hover:bg-surface-container-high text-primary transition-colors" title="View E-Content"><span class="material-symbols-outlined text-lg">folder_open</span></a>
          <a href="${ctx}/app/my-subjects" class="p-1.5 rounded-lg hover:bg-surface-container-high text-on-surface-variant transition-colors" title="Course Details"><span class="material-symbols-outlined text-lg">arrow_forward</span></a>
        </div>
      </div>
    </div>
  </c:forEach>
  </div>

  <c:if test="${not empty d.cieTitle}">
  <div class="bg-surface-container-low rounded-2xl p-space-lg flex flex-col md:flex-row items-center justify-between gap-space-md">
    <div class="flex items-center gap-space-md"><div class="p-space-sm rounded-xl bg-surface-container-lowest text-primary shadow-xs"><span class="material-symbols-outlined text-2xl">verified</span></div>
    <div><h4 class="font-headline-sm text-headline-sm text-on-surface font-semibold"><c:out value="${d.cieTitle}"/></h4><p class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${d.cieText}"/></p></div></div>
    <a href="${ctx}/app/exams" class="px-space-lg py-space-sm rounded-lg bg-surface-container-lowest hover:bg-surface-container-high text-primary font-label-md text-label-md font-semibold transition-all shadow-xs shrink-0">View Grade Breakdown</a>
  </div>
  </c:if>
</div>

<%-- ---------------- companion panel ---------------- --%>
<div class="lg:col-span-4 flex flex-col gap-space-lg">
  <c:if test="${not empty d.nextLectureSubject}">
  <div class="bg-gradient-to-br from-primary-container to-primary text-on-primary rounded-2xl p-space-lg shadow-sm relative overflow-hidden">
    <div class="absolute -right-8 -top-8 w-32 h-32 rounded-full bg-secondary-fixed/15 blur-xl pointer-events-none"></div>
    <div class="flex items-center justify-between mb-space-sm"><span class="px-space-sm py-0.5 rounded-full bg-secondary-container text-on-secondary-container font-label-sm text-label-sm font-bold uppercase tracking-wider">Next Lecture</span>
    <span class="font-label-sm text-label-sm opacity-90 flex items-center gap-1"><span class="material-symbols-outlined text-xs">timer</span> <c:out value="${d.nextLectureTime}"/></span></div>
    <h3 class="font-headline-md text-headline-md font-bold text-white mt-1"><c:out value="${d.nextLectureSubject}"/></h3>
    <p class="font-body-sm text-body-sm opacity-90 mt-0.5">Code: <c:out value="${d.nextLectureCode}"/><c:if test="${not empty d.nextLectureTopic}"> &bull; Topic: <c:out value="${d.nextLectureTopic}"/></c:if></p>
    <div class="mt-space-md pt-space-md flex items-center justify-between border-t border-white/15">
      <div class="flex flex-col"><span class="font-label-md text-label-md font-semibold text-white"><c:out value="${d.nextLectureFaculty}"/></span><span class="font-label-sm text-label-sm opacity-90"><c:out value="${d.nextLectureRoom}"/></span></div>
      <button class="px-space-md py-1.5 rounded-lg bg-surface-container-lowest text-primary font-label-md text-label-md font-semibold hover:bg-surface-container transition-all shadow-xs">Check-In</button>
    </div>
  </div>
  </c:if>

  <c:if test="${not empty d.exams}">
  <div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm" id="exam-schedule">
    <div class="flex items-center justify-between mb-space-md"><div class="flex items-center gap-space-xs"><span class="material-symbols-outlined text-primary text-xl">event_upcoming</span><h3 class="font-headline-sm text-headline-sm text-on-surface font-bold">Upcoming Exams</h3></div><span class="font-label-sm text-label-sm text-on-surface-variant font-medium"><c:out value="${d.examMonthLabel}"/></span></div>
    <div class="flex flex-col gap-space-sm">
    <c:forEach var="x" items="${d.exams}">
      <div class="p-space-sm rounded-xl bg-surface-container-low flex items-center justify-between"><div class="flex items-center gap-space-md">
        <div class="flex flex-col items-center justify-center bg-surface-container-lowest px-2.5 py-1.5 rounded-lg shadow-xs min-w-[44px]"><span class="font-label-sm text-label-sm text-on-surface-variant font-bold uppercase"><c:out value="${x.month}"/></span><span class="font-headline-sm text-headline-sm text-primary font-bold"><c:out value="${x.day}"/></span></div>
        <div class="flex flex-col"><span class="font-label-lg text-label-lg font-semibold text-on-surface"><c:out value="${x.subjectName}"/></span><span class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${x.timeRange}"/> &bull; <c:out value="${x.code}"/></span></div></div>
        <span class="material-symbols-outlined text-on-surface-variant text-lg">calendar_today</span></div>
    </c:forEach>
    </div>
    <a href="${ctx}/app/timetable" class="w-full mt-space-md py-space-xs rounded-lg text-primary font-label-md text-label-md hover:bg-surface-container transition-colors flex items-center justify-center gap-1 font-semibold"><span>Open Timetable</span><span class="material-symbols-outlined text-base">arrow_forward</span></a>
  </div>
  </c:if>

  <div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm">
    <div class="flex items-center justify-between mb-space-md"><div class="flex items-center gap-space-xs"><span class="material-symbols-outlined text-secondary text-xl">folder_zip</span><h3 class="font-headline-sm text-headline-sm text-on-surface font-bold">Fresh E-Materials</h3></div><a class="font-label-sm text-label-sm text-primary font-semibold hover:underline" href="${ctx}/app/e-content">View All</a></div>
    <div class="flex flex-col gap-space-sm">
    <c:forEach var="m" items="${d.materials}">
      <div class="flex items-center justify-between p-space-sm rounded-xl hover:bg-surface-container transition-colors group"><div class="flex items-center gap-space-sm min-w-0">
        <span class="p-2 rounded-lg bg-surface-container-low text-primary"><span class="material-symbols-outlined text-lg"><c:out value="${m.icon}"/></span></span>
        <div class="flex flex-col min-w-0"><span class="font-label-md text-label-md font-semibold text-on-surface truncate"><c:out value="${m.title}"/></span><span class="font-body-sm text-body-sm text-on-surface-variant truncate"><c:out value="${m.subjectName}"/> &bull; <c:out value="${m.sizeLabel}"/></span></div></div>
        <div class="flex items-center gap-1 shrink-0"><button type="button" data-preview-src="material" data-preview-id="${m.id}" title="View" aria-label="View <c:out value='${m.title}'/>" class="eye-btn p-1.5 rounded-lg bg-surface-container text-primary hover:bg-surface-container-high"><span class="material-symbols-outlined text-lg">visibility</span></button>
        <a href="${ctx}/app/download?src=material&amp;id=${m.id}" title="Download" aria-label="Download <c:out value='${m.title}'/>" class="p-1.5 rounded-lg text-on-surface-variant hover:bg-surface-container-high flex"><span class="material-symbols-outlined text-lg">download</span></a></div></div>
    </c:forEach>
    <c:if test="${empty d.materials}"><p class="font-body-sm text-body-sm text-on-surface-variant">No study material uploaded yet.</p></c:if>
    </div>
  </div>

  <c:if test="${not empty d.recovery}">
  <div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm ring-1 ring-red-300">
    <div class="flex items-center justify-between mb-space-sm"><div class="flex items-center gap-space-xs"><span class="material-symbols-outlined text-red-600 dark:text-red-300 text-xl">target</span><h3 class="font-headline-sm text-headline-sm text-on-surface font-bold">Recovery Quota Tracker</h3></div><span class="px-space-sm py-0.5 rounded bg-red-600 text-white font-label-sm text-label-sm font-bold">MUST CLEAR</span></div>
    <p class="font-body-sm text-body-sm text-on-surface-variant mb-space-sm">Classes to attend in a row to become exam-eligible (&ge;<c:out value="${d.minAttendance}"/>%).</p>
    <div class="flex flex-col gap-space-xs">
    <c:forEach var="x" items="${d.recovery}"><div class="p-space-sm rounded-lg ${x.status eq 'RED' ? 'bg-red-50 dark:bg-red-900/30 text-red-800 dark:text-red-200' : 'bg-amber-50 dark:bg-amber-900/30 text-amber-800 dark:text-amber-200'}"><div class="flex justify-between font-label-md text-label-md font-semibold"><span><c:out value="${x.subjectName}"/></span><span><c:out value="${x.currentPct}"/>% &rarr; <c:out value="${d.minAttendance}"/>%</span></div><div class="font-body-sm text-body-sm">Attend next <b><c:out value="${x.classesNeeded}"/></b> class(es)</div></div></c:forEach>
    </div>
    <div class="mt-space-sm font-body-sm text-body-sm text-on-surface-variant">Regulation 4.2: students below 75% must present medical proof to the HOD within 5 days.</div>
  </div>
  </c:if>

  <c:if test="${not empty d.noticeTitle}">
  <div class="bg-surface-container-low rounded-2xl p-space-lg flex items-start gap-space-md"><span class="material-symbols-outlined text-primary">info</span>
  <div><h4 class="font-headline-sm text-headline-sm text-on-surface font-semibold"><c:out value="${d.noticeTitle}"/></h4><p class="font-body-sm text-body-sm text-on-surface-variant mt-1"><c:out value="${d.noticeText}"/></p></div></div>
  </c:if>
</div>
</div>

</div>
</main>
</div>
<script>
/* Subject filter pills: All / Core / Labs (client-side, no reload) */
(function () {
  var box = document.getElementById('subject-filter');
  if (!box) { return; }
  var on = 'px-space-md py-1 rounded-md bg-surface-container-lowest text-primary font-label-md text-label-md font-semibold shadow-xs';
  var off = 'px-space-md py-1 rounded-md text-on-surface-variant hover:text-on-surface font-label-md text-label-md transition-colors';
  box.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-filter]');
    if (!b) { return; }
    var f = b.getAttribute('data-filter');
    box.querySelectorAll('button').forEach(function (x) { x.className = (x === b) ? on : off; });
    document.querySelectorAll('#subject-grid [data-category]').forEach(function (card) {
      card.style.display = (f === 'ALL' || card.getAttribute('data-category').toUpperCase() === f) ? '' : 'none';
    });
  });
})();
</script>
<%@ include file="/WEB-INF/jspf/widgets.jspf" %>
</body>
</html>
