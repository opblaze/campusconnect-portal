<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm"><div class="flex items-center gap-space-sm"><span class="p-2 rounded-lg bg-primary-container text-on-primary flex"><span class="material-symbols-outlined">task</span></span><div><h1 class="font-headline-lg text-headline-lg text-on-surface font-bold">Assignments &amp; Submissions</h1><p class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${d.submittedAssignments}"/> of <c:out value="${d.totalAssignments}"/> submitted &bull; <c:out value="${d.pendingAssignments}"/> pending</p></div></div></div>

<div class="flex flex-col gap-space-md">
<c:if test="${empty rows}"><div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm">No assignments yet.</div></c:if>
<c:forEach var="a" items="${rows}"><div class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-sm ${a.state eq 'OVERDUE' ? 'ring-1 ring-red-400' : ''}">
<div class="flex flex-col md:flex-row md:items-start justify-between gap-space-sm">
<div><div class="flex items-center gap-space-xs flex-wrap"><span class="px-space-sm py-0.5 rounded bg-surface-container-high text-primary font-label-sm text-label-sm font-bold"><c:out value="${a.abbr}"/></span>
<span class="px-space-sm py-0.5 rounded font-label-sm text-label-sm font-semibold ${a.state eq 'DONE' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200' : (a.state eq 'OVERDUE' ? 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-200' : 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200')}"><c:out value="${a.state}"/></span></div>
<h2 class="font-headline-sm text-headline-sm font-bold text-on-surface mt-1"><c:out value="${a.title}"/></h2>
<p class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${a.desc}"/></p>
<p class="font-body-sm text-body-sm text-on-surface mt-1">Due: <b><c:out value="${a.due}"/></b> &bull; Max marks: <c:out value="${a.marks}"/><c:if test="${not empty a.submittedAt}"> &bull; Submitted: <c:out value="${a.submittedAt}"/></c:if></p></div>
<c:if test="${a.canSubmit}"><form method="post" action="${ctx}/app/assignments" enctype="multipart/form-data" class="flex flex-col sm:flex-row gap-space-xs md:items-center" onsubmit="return this.file.files.length>0 || (alert('Choose a file first'), false)">
<input type="hidden" name="csrf" value="<c:out value='${csrf}'/>"><input type="hidden" name="assignmentId" value="${a.id}">
<input type="file" name="file" class="font-body-sm text-body-sm text-on-surface-variant max-w-[220px]">
<button type="submit" class="px-space-md py-1.5 rounded-lg bg-primary-container text-on-primary font-label-md text-label-md font-semibold flex items-center gap-1"><span class="material-symbols-outlined text-base">upload_file</span>Submit</button></form></c:if>
</div></div></c:forEach></div>
<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>
