<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Admin Control Panel"/>
<%@ include file="/WEB-INF/jspf/shell-top.jspf" %>

<!-- Admin Hero -->
<section class="bg-surface-container-lowest rounded-2xl p-space-lg shadow-[0_2px_12px_rgba(15,76,129,0.06)] flex flex-col md:flex-row md:items-center justify-between gap-space-md">
  <div>
    <div class="flex items-center gap-2 flex-wrap">
      <span class="px-2.5 py-0.5 rounded-full bg-primary-container text-on-primary font-label-sm text-label-sm font-bold uppercase tracking-wider">Administration</span>
      <span class="px-2.5 py-0.5 rounded-full bg-surface-container-low text-on-surface-variant font-label-sm text-label-sm"><c:out value="${ad.email}"/></span>
    </div>
    <h1 class="font-headline-lg text-headline-lg font-bold text-on-surface mt-1">Campus Connect Control Center</h1>
    <p class="font-body-md text-body-md text-on-surface-variant">Signed in as <strong class="text-on-surface"><c:out value="${ad.fullName}"/></strong> &bull; <c:out value="${ad.todayLabel}"/></p>
  </div>
  <div class="flex flex-wrap gap-2">
    <a href="${ctx}/admin/users" class="px-4 py-2.5 rounded-xl bg-primary-container text-on-primary font-label-md text-label-md font-semibold flex items-center gap-2 hover:opacity-95 transition"><span class="material-symbols-outlined text-lg">person_add</span>Manage Users</a>
    <a href="${ctx}/admin/students" class="px-4 py-2.5 rounded-xl bg-surface-container text-on-surface font-label-md text-label-md font-semibold flex items-center gap-2 hover:bg-surface-container-high transition"><span class="material-symbols-outlined text-lg text-primary">school</span>Students</a>
    <a href="${ctx}/admin/fees" class="px-4 py-2.5 rounded-xl bg-surface-container text-on-surface font-label-md text-label-md font-semibold flex items-center gap-2 hover:bg-surface-container-high transition"><span class="material-symbols-outlined text-lg text-primary">payments</span>Fees</a>
    <a href="${ctx}/admin/announcements" class="px-4 py-2.5 rounded-xl bg-surface-container text-on-surface font-label-md text-label-md font-semibold flex items-center gap-2 hover:bg-surface-container-high transition"><span class="material-symbols-outlined text-lg text-primary">campaign</span>Broadcast</a>
  </div>
</section>

<!-- 4 Primary KPIs -->
<section class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-space-md">
  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] flex flex-col justify-between gap-space-sm">
    <div class="flex items-center justify-between">
      <span class="font-label-md text-label-md text-on-surface-variant font-semibold">Student Strength</span>
      <span class="w-10 h-10 rounded-xl bg-primary-container/15 text-primary flex items-center justify-center"><span class="material-symbols-outlined">school</span></span>
    </div>
    <div class="font-display-lg text-display-lg font-bold text-on-surface"><c:out value="${ad.totalStudents}"/></div>
    <div class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${ad.hostelerCount}"/> Hosteler &bull; <c:out value="${ad.dayScholarCount}"/> Day Scholar</div>
  </div>

  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] flex flex-col justify-between gap-space-sm">
    <div class="flex items-center justify-between">
      <span class="font-label-md text-label-md text-on-surface-variant font-semibold">Faculty &amp; Curriculum</span>
      <span class="w-10 h-10 rounded-xl bg-secondary-container text-on-secondary-container flex items-center justify-center"><span class="material-symbols-outlined">badge</span></span>
    </div>
    <div class="font-display-lg text-display-lg font-bold text-on-surface"><c:out value="${ad.totalFaculty}"/> <span class="text-base font-medium text-on-surface-variant">staff</span></div>
    <div class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${ad.departmentCount}"/> Depts &bull; <c:out value="${ad.totalSubjects}"/> Subjects (<c:out value="${ad.coreSubjects}"/>C/<c:out value="${ad.labSubjects}"/>L)</div>
  </div>

  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] flex flex-col justify-between gap-space-sm">
    <div class="flex items-center justify-between">
      <span class="font-label-md text-label-md text-on-surface-variant font-semibold">Fee Collection (<c:out value="${ad.feeCollectionPct}"/>%)</span>
      <span class="w-10 h-10 rounded-xl bg-secondary-container text-on-secondary-container flex items-center justify-center"><span class="material-symbols-outlined">payments</span></span>
    </div>
    <div class="font-headline-lg text-headline-lg font-bold text-on-surface"><c:out value="${ad.feeCollectedLabel}"/></div>
    <div class="font-body-sm text-body-sm text-on-surface-variant">Pending <strong class="text-on-surface"><c:out value="${ad.feePendingLabel}"/></strong> (<c:out value="${ad.overdueFeeCount}"/> overdue)</div>
  </div>

  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] flex flex-col justify-between gap-space-sm">
    <div class="flex items-center justify-between">
      <span class="font-label-md text-label-md text-on-surface-variant font-semibold">Campus Attendance</span>
      <span class="w-10 h-10 rounded-xl ${ad.atRiskStudents > 0 ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200' : 'bg-secondary-container text-on-secondary-container'} flex items-center justify-center"><span class="material-symbols-outlined">insights</span></span>
    </div>
    <div class="font-display-lg text-display-lg font-bold text-on-surface"><c:out value="${ad.avgAttendancePct}"/>%</div>
    <div class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${ad.atRiskStudents}"/> at-risk (&lt;75%) &bull; <c:out value="${ad.newFeedbackCount}"/> new tickets</div>
  </div>
</section>

<!-- Finance Bar + Account Summary -->
<section class="grid grid-cols-1 lg:grid-cols-12 gap-space-lg">
  <div class="lg:col-span-7 bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] flex flex-col justify-between gap-4">
    <div class="flex items-center justify-between">
      <div>
        <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Fee Ledger Health</h2>
        <p class="font-body-sm text-body-sm text-on-surface-variant">Total billed <c:out value="${ad.totalFeeBilledLabel}"/> across student fee demands</p>
      </div>
      <a href="${ctx}/admin/fees" class="font-label-sm text-label-sm text-primary font-semibold hover:underline">Open ledger &rarr;</a>
    </div>
    <div>
      <div class="flex justify-between font-label-sm text-label-sm mb-1.5">
        <span class="text-on-surface-variant">Collected Share</span>
        <span class="font-bold text-on-surface"><c:out value="${ad.feeCollectionPct}"/>%</span>
      </div>
      <div class="w-full h-3 rounded-full bg-surface-container overflow-hidden">
        <div class="h-full bg-secondary rounded-full" style="width:${ad.feeCollectionPct}%"></div>
      </div>
    </div>
    <div class="grid grid-cols-3 gap-3 pt-2 border-t border-outline-variant/30">
      <div><div class="font-label-sm text-label-sm text-on-surface-variant">Collected</div><div class="font-headline-sm text-headline-sm font-bold text-secondary"><c:out value="${ad.feeCollectedLabel}"/></div></div>
      <div><div class="font-label-sm text-label-sm text-on-surface-variant">Pending Dues</div><div class="font-headline-sm text-headline-sm font-bold text-on-surface"><c:out value="${ad.feePendingLabel}"/></div></div>
      <div><div class="font-label-sm text-label-sm text-on-surface-variant">Overdue</div><div class="font-headline-sm text-headline-sm font-bold text-error"><c:out value="${ad.feeOverdueLabel}"/></div></div>
    </div>
  </div>

  <div class="lg:col-span-5 bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)] flex flex-col justify-between gap-4">
    <div class="flex items-center justify-between">
      <div>
        <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Portal Accounts &amp; Academics</h2>
        <p class="font-body-sm text-body-sm text-on-surface-variant"><c:out value="${ad.activeUsers}"/> active / <c:out value="${ad.inactiveUsers}"/> suspended accounts</p>
      </div>
      <a href="${ctx}/admin/users" class="font-label-sm text-label-sm text-primary font-semibold hover:underline">Directory &rarr;</a>
    </div>
    <div class="grid grid-cols-3 gap-3">
      <div class="p-3 rounded-xl bg-surface-container-low"><div class="font-label-sm text-label-sm text-on-surface-variant">Students</div><div class="font-headline-md text-headline-md font-bold text-primary"><c:out value="${ad.studentUsers}"/></div></div>
      <div class="p-3 rounded-xl bg-surface-container-low"><div class="font-label-sm text-label-sm text-on-surface-variant">Faculty</div><div class="font-headline-md text-headline-md font-bold text-secondary"><c:out value="${ad.facultyUsers}"/></div></div>
      <div class="p-3 rounded-xl bg-surface-container-low"><div class="font-label-sm text-label-sm text-on-surface-variant">Admins</div><div class="font-headline-md text-headline-md font-bold text-on-surface"><c:out value="${ad.adminUsers}"/></div></div>
    </div>
    <div class="font-body-sm text-body-sm text-on-surface-variant pt-2 border-t border-outline-variant/30">
      Assignments: <strong class="text-on-surface"><c:out value="${ad.totalAssignments}"/></strong> &bull;
      Submissions: <strong class="text-on-surface"><c:out value="${ad.totalSubmissions}"/></strong> &bull;
      Ungraded: <strong class="text-on-surface"><c:out value="${ad.pendingGradingCount}"/></strong>
    </div>
  </div>
</section>

<!-- Academic Breakdown Tables -->
<section class="grid grid-cols-1 lg:grid-cols-2 gap-space-lg">
  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <div class="flex items-center justify-between mb-3">
      <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Department Distribution</h2>
      <a href="${ctx}/admin/faculty" class="font-label-sm text-label-sm text-primary font-semibold hover:underline">Faculty &rarr;</a>
    </div>
    <table class="w-full text-left border-collapse">
      <thead>
        <tr class="border-b border-outline-variant/40 font-label-sm text-label-sm text-on-surface-variant uppercase">
          <th class="py-2 px-2">Department</th>
          <th class="py-2 px-2 text-right">Faculty</th>
          <th class="py-2 px-2 text-right">Subjects</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-outline-variant/20 font-body-sm text-body-sm">
        <c:forEach items="${ad.departmentStats}" var="dpt">
          <tr>
            <td class="py-2.5 px-2 font-semibold text-on-surface"><c:out value="${dpt.department}"/></td>
            <td class="py-2.5 px-2 text-right font-mono"><c:out value="${dpt.facultyCount}"/></td>
            <td class="py-2.5 px-2 text-right font-mono"><c:out value="${dpt.subjectCount}"/></td>
          </tr>
        </c:forEach>
      </tbody>
    </table>
  </div>

  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <div class="flex items-center justify-between mb-3">
      <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Semester Overview</h2>
      <a href="${ctx}/admin/subjects" class="font-label-sm text-label-sm text-primary font-semibold hover:underline">Subjects &rarr;</a>
    </div>
    <table class="w-full text-left border-collapse">
      <thead>
        <tr class="border-b border-outline-variant/40 font-label-sm text-label-sm text-on-surface-variant uppercase">
          <th class="py-2 px-2">Semester</th>
          <th class="py-2 px-2 text-right">Students</th>
          <th class="py-2 px-2 text-right">Subjects</th>
          <th class="py-2 px-2 text-right">Avg CGPA</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-outline-variant/20 font-body-sm text-body-sm">
        <c:forEach items="${ad.semesterStats}" var="sm">
          <tr>
            <td class="py-2.5 px-2 font-semibold text-on-surface">Semester <c:out value="${sm.semester}"/></td>
            <td class="py-2.5 px-2 text-right font-mono"><c:out value="${sm.studentCount}"/></td>
            <td class="py-2.5 px-2 text-right font-mono"><c:out value="${sm.subjectCount}"/></td>
            <td class="py-2.5 px-2 text-right font-mono font-bold text-primary"><c:out value="${sm.avgCgpa}"/></td>
          </tr>
        </c:forEach>
      </tbody>
    </table>
  </div>
</section>

<!-- Bottom Operational Streams -->
<section class="grid grid-cols-1 xl:grid-cols-3 gap-space-lg">
  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <div class="flex items-center justify-between mb-3">
      <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Recent Users</h2>
      <a href="${ctx}/admin/users" class="font-label-sm text-label-sm text-primary font-semibold hover:underline">All users &rarr;</a>
    </div>
    <div class="flex flex-col gap-2">
      <c:forEach items="${ad.recentUsers}" var="u" end="5">
        <div class="p-2.5 rounded-xl bg-surface-container-low flex items-center justify-between gap-2">
          <div class="min-w-0">
            <div class="font-label-md text-label-md font-bold text-on-surface truncate"><c:out value="${u.fullName}"/></div>
            <div class="font-body-sm text-body-sm text-on-surface-variant truncate"><c:out value="${u.codeLabel}"/></div>
          </div>
          <span class="px-2 py-0.5 rounded font-label-sm text-label-sm font-bold shrink-0 ${u.role eq 'ADMIN' ? 'bg-primary-container text-on-primary' : (u.role eq 'FACULTY' ? 'bg-secondary-container text-on-secondary-container' : 'bg-surface-container text-on-surface')}"><c:out value="${u.role}"/></span>
        </div>
      </c:forEach>
    </div>
  </div>

  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <div class="flex items-center justify-between mb-3">
      <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Helpdesk &amp; Feedback</h2>
      <a href="${ctx}/admin/feedback" class="font-label-sm text-label-sm text-primary font-semibold hover:underline">Review &rarr;</a>
    </div>
    <c:choose>
      <c:when test="${empty ad.recentFeedback}">
        <p class="font-body-sm text-body-sm text-on-surface-variant py-6 text-center">No feedback submissions yet.</p>
      </c:when>
      <c:otherwise>
        <div class="flex flex-col gap-2">
          <c:forEach items="${ad.recentFeedback}" var="fb" end="4">
            <div class="p-2.5 rounded-xl bg-surface-container-low">
              <div class="flex items-center justify-between gap-2">
                <span class="font-label-sm text-label-sm font-bold text-on-surface truncate"><c:out value="${fb.studentName}"/></span>
                <span class="px-2 py-0.5 rounded font-label-sm text-label-sm font-bold ${fb.status eq 'SENT' ? 'bg-secondary-container text-on-secondary-container' : 'bg-amber-100 text-amber-800'}"><c:out value="${fb.status}"/></span>
              </div>
              <p class="font-body-sm text-body-sm text-on-surface-variant mt-1 line-clamp-2"><c:out value="${fb.message}"/></p>
            </div>
          </c:forEach>
        </div>
      </c:otherwise>
    </c:choose>
  </div>

  <div class="bg-surface-container-lowest rounded-2xl p-space-md shadow-[0_2px_10px_rgba(15,76,129,0.05)]">
    <div class="flex items-center justify-between mb-3">
      <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Recent Notices</h2>
      <a href="${ctx}/admin/announcements" class="font-label-sm text-label-sm text-primary font-semibold hover:underline">Manage &rarr;</a>
    </div>
    <div class="flex flex-col gap-2">
      <c:forEach items="${ad.recentAnnouncements}" var="n" end="4">
        <div class="p-2.5 rounded-xl bg-surface-container-low">
          <div class="flex items-center justify-between gap-2">
            <span class="font-label-sm text-label-sm font-bold text-primary"><c:out value="${n.subjectCode}"/></span>
            <span class="font-label-sm text-label-sm text-on-surface-variant"><c:out value="${n.createdLabel}"/></span>
          </div>
          <div class="font-label-md text-label-md font-bold text-on-surface mt-0.5"><c:out value="${n.title}"/></div>
          <div class="font-body-sm text-body-sm text-on-surface-variant mt-0.5">By <c:out value="${n.authorName}"/></div>
        </div>
      </c:forEach>
    </div>
  </div>
</section>

<%@ include file="/WEB-INF/jspf/shell-bottom.jspf" %>

