/*
 * Top bar behaviour:
 *   1. shows today's date (updates itself at midnight)
 *   2. LIVE SEARCH with keyword suggestions: type -> results appear instantly (calls /api/search)
 */
(function () {
  'use strict';
  var DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  /* ---------- 1. date ---------- */
  function today() {
    var d = new Date();
    return DAYS[d.getDay()] + ', ' + d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear();
  }
  var dateEl = document.getElementById('cc-date');
  if (dateEl) {
    dateEl.textContent = today();
    setInterval(function () { dateEl.textContent = today(); }, 30000);
  }

  /* ---------- 2. live search ---------- */
  var wrap = document.getElementById('cc-search-wrap');
  if (!wrap) { return; }
  var ctx = wrap.getAttribute('data-ctx') || '';
  var input = document.getElementById('cc-search');
  var dd = document.getElementById('cc-search-dd');
  var form = document.getElementById('cc-search-form');
  var timer = null, ctrl = null, active = -1;
  var FALLBACK = ['pending', 'done', 'due', 'late', 'overdue', 'paid', 'assignments', 'attendance', 'exam', 'fees', 'hostel', 'prc'];
  var TONE = {
    GREEN: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200',
    YELLOW: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200',
    RED: 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-200',
    BLUE: 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-200',
    NONE: 'bg-surface-container text-on-surface-variant'
  };
  var ICON = { Assignment: 'assignment', Fee: 'payments', Material: 'description', Exam: 'event', Subject: 'menu_book', Notice: 'campaign', Page: 'arrow_forward', Student: 'school', Faculty: 'badge', User: 'manage_accounts' };

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) { e.className = cls; }
    if (text !== undefined) { e.textContent = text; }
    return e;
  }
  function open() { dd.classList.remove('hidden'); input.setAttribute('aria-expanded', 'true'); }
  function close() { dd.classList.add('hidden'); input.setAttribute('aria-expanded', 'false'); active = -1; }

  function chooseKeyword(k) {
    var parts = input.value.trim().split(/\s+/).filter(Boolean);
    if (parts.length && !/\s$/.test(input.value) && k.indexOf(parts[parts.length - 1].toLowerCase()) === 0) { parts.pop(); }
    parts.push(k);
    input.value = parts.join(' ') + ' ';
    input.focus();
    run();
  }

  function render(data, q) {
    dd.textContent = '';
    var sug = (data && data.suggestions && data.suggestions.length) ? data.suggestions : FALLBACK;
    var box = el('div', 'px-3 pt-3 pb-2 border-b border-outline-variant/30');
    box.appendChild(el('div', 'font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant mb-2', 'Keywords'));
    var chips = el('div', 'flex flex-wrap gap-1.5');
    sug.forEach(function (k) {
      var b = el('button', 'cc-kw px-3 py-1 rounded-full bg-surface-container text-primary font-label-md text-label-md hover:bg-surface-container-high', k);
      b.type = 'button';
      b.setAttribute('data-kw', k);
      b.addEventListener('mousedown', function (e) { e.preventDefault(); chooseKeyword(k); });
      chips.appendChild(b);
    });
    box.appendChild(chips);
    dd.appendChild(box);

    var results = (data && data.results) || [];
    if (!q) {
      dd.appendChild(el('div', 'px-4 py-3 font-body-sm text-body-sm text-on-surface-variant', 'Type to search tasks, fees, study material, exams and notices.'));
      return;
    }
    if (!results.length) {
      dd.appendChild(el('div', 'px-4 py-4 font-body-sm text-body-sm text-on-surface-variant', 'No matches for "' + q + '".'));
      return;
    }
    var list = el('div', 'py-1');
    results.forEach(function (r) {
      var a = el('a', 'cc-item flex items-center gap-3 px-4 py-2 hover:bg-surface-container cursor-pointer');
      a.href = ctx + r.href;
      a.setAttribute('data-item', '1');
      a.setAttribute('role', 'option');
      a.appendChild(el('span', 'material-symbols-outlined text-primary text-xl', ICON[r.type] || 'search'));
      var mid = el('div', 'flex-1 min-w-0');
      mid.appendChild(el('div', 'font-label-lg text-label-lg text-on-surface font-semibold truncate', r.title));
      mid.appendChild(el('div', 'font-body-sm text-body-sm text-on-surface-variant truncate', r.type + ' \u2022 ' + r.sub));
      a.appendChild(mid);
      if (r.badge && r.badge !== 'PAGE') {
        a.appendChild(el('span', 'px-2 py-0.5 rounded font-label-sm text-label-sm font-bold ' + (TONE[r.tone] || TONE.NONE), r.badge));
      }
      list.appendChild(a);
    });
    dd.appendChild(list);
    dd.appendChild(el('div', 'px-4 py-2 border-t border-outline-variant/30 font-label-sm text-label-sm text-on-surface-variant', 'Press Enter for the full results page'));
  }

  function run() {
    var q = input.value.trim();
    if (ctrl) { ctrl.abort(); }
    ctrl = window.AbortController ? new AbortController() : null;
    fetch(ctx + '/api/search?q=' + encodeURIComponent(q), { credentials: 'same-origin', signal: ctrl ? ctrl.signal : undefined })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) { if (j) { active = -1; render(j, q); open(); } })
      .catch(function (e) { if (!e || e.name !== 'AbortError') { render(null, q); open(); } });
  }

  function items() { return dd.querySelectorAll('[data-item]'); }
  function highlight(i) {
    var list = items();
    list.forEach(function (n) { n.classList.remove('bg-surface-container-high'); });
    if (i >= 0 && i < list.length) { list[i].classList.add('bg-surface-container-high'); list[i].scrollIntoView({ block: 'nearest' }); }
  }

  input.addEventListener('input', function () { clearTimeout(timer); timer = setTimeout(run, 150); });
  input.addEventListener('focus', run);
  input.addEventListener('keydown', function (e) {
    var n = items().length;
    if (e.key === 'ArrowDown') { e.preventDefault(); if (n) { active = (active + 1) % n; highlight(active); } }
    else if (e.key === 'ArrowUp') { e.preventDefault(); if (n) { active = (active - 1 + n) % n; highlight(active); } }
    else if (e.key === 'Escape') { close(); input.blur(); }
    else if (e.key === 'Enter' && active >= 0 && items()[active]) { e.preventDefault(); window.location.href = items()[active].href; }
  });
  form.addEventListener('submit', function (e) { if (input.value.trim().length < 2) { e.preventDefault(); run(); } });
  document.addEventListener('click', function (e) { if (!wrap.contains(e.target)) { close(); } });
})();
