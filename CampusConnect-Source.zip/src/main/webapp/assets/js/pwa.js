/* Registers the service worker so Campus Connect can be installed (PWA). Path is derived from this file's own URL. */
(function () {
  if (!('serviceWorker' in navigator)) { return; }
  var src = document.currentScript ? document.currentScript.src : '';
  var base = src.replace(/assets\/js\/pwa\.js.*$/, '');
  window.addEventListener('load', function () {
    navigator.serviceWorker.register(base + 'sw.js').catch(function () { /* unsupported / http: ignore */ });
  });
})();
