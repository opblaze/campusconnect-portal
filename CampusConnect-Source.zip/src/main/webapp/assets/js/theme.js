/*
 * Campus Connect - automatic light/dark theme.
 * Mode "auto" (default): light from 06:00 to 17:59, dark otherwise, using the device clock.
 * The toggle button cycles auto -> light -> dark -> auto and remembers the choice in localStorage.
 * This file is loaded in <head> so the correct theme is applied BEFORE the page paints (no flash).
 */
(function () {
  var KEY = 'cc-theme';
  var ICONS = { auto: 'brightness_auto', light: 'light_mode', dark: 'dark_mode' };

  function mode() {
    try { return localStorage.getItem(KEY) || 'auto'; } catch (e) { return 'auto'; }
  }
  function byClock() {
    var h = new Date().getHours();
    return (h >= 6 && h < 18) ? 'light' : 'dark';
  }
  function apply() {
    var m = mode();
    var theme = m === 'auto' ? byClock() : m;
    document.documentElement.classList.toggle('dark', theme === 'dark');
    document.documentElement.setAttribute('data-theme-mode', m);
    var icons = document.querySelectorAll('[data-theme-icon]');
    for (var i = 0; i < icons.length; i++) { icons[i].textContent = ICONS[m]; }
    var btns = document.querySelectorAll('[data-theme-toggle]');
    for (var j = 0; j < btns.length; j++) {
      btns[j].title = 'Theme: ' + m + (m === 'auto' ? ' (' + theme + ' now)' : '');
    }
  }
  window.ccTheme = {
    apply: apply,
    toggle: function () {
      var next = { auto: 'light', light: 'dark', dark: 'auto' }[mode()];
      try { localStorage.setItem(KEY, next); } catch (e) { /* private mode: ignore */ }
      apply();
    }
  };
  apply();
  document.addEventListener('DOMContentLoaded', apply);
  setInterval(apply, 60000); // auto mode flips by itself when 06:00 / 18:00 passes
})();
