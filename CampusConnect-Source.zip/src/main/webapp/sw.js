/*
 * Campus Connect service worker (PWA).
 *  - /assets/* : cache-first (fast start, works offline)
 *  - pages     : network-first; if the device is offline the friendly offline.html is shown
 *  - NEVER caches /api/* or signed-in pages, so private data is not stored on the device (Confidentiality)
 */
var VERSION = 'cc-v1';
var PRECACHE = ['offline.html', 'assets/js/theme.js', 'assets/img/icon-192.png', 'assets/img/marwadi-logo.png'];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(VERSION).then(function (c) { return c.addAll(PRECACHE); }).then(function () { return self.skipWaiting(); }));
});

self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (keys) {
    return Promise.all(keys.filter(function (k) { return k !== VERSION; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});

self.addEventListener('fetch', function (e) {
  var req = e.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== self.location.origin || url.pathname.indexOf('/api/') !== -1) { return; }
  if (url.pathname.indexOf('/assets/') !== -1) {
    e.respondWith(caches.match(req).then(function (hit) {
      return hit || fetch(req).then(function (res) {
        var copy = res.clone();
        caches.open(VERSION).then(function (c) { c.put(req, copy); });
        return res;
      });
    }));
    return;
  }
  if (req.mode === 'navigate') {
    e.respondWith(fetch(req).catch(function () { return caches.match('offline.html'); }));
  }
});

self.addEventListener('notificationclick', function (e) {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: 'window' }).then(function (list) {
    if (list.length) { return list[0].focus(); }
    return self.clients.openWindow('dashboard');
  }));
});
